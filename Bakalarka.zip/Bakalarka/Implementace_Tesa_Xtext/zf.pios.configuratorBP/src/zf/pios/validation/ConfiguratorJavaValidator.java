package zf.pios.validation;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.resource.IResourceDescription;
import org.eclipse.xtext.resource.IResourceDescriptions;
import org.eclipse.xtext.util.CancelIndicator;
import org.eclipse.xtext.validation.Check;
import org.eclipse.xtext.validation.CheckType;
import org.eclipse.xtext.validation.ValidationMessageAcceptor;

import com.google.inject.Inject;

import zf.pios.configurator.*;
import zf.pios.configurator.impl.InputDatafieldImpl;
import zf.pios.configurator.impl.OutputDatafieldImpl;

public class ConfiguratorJavaValidator extends
        AbstractConfiguratorJavaValidator {

    private static final String ERROR_ARRAY_INDEX = "ZFMSG:TESATK(E0004) Same sorting index multiple used.";
    private static final String ERROR_DATAFIELD_NAME = "ZFMSG:TESATK(E0005) Datafield variant name must be unique.";
    private static final String ERROR_DRIVER_INDEX = "ZFMSG:TESATK(E0006) Driver index must be unique.";
    private static final String ERROR_LOWER_EXCEED_UPPER = "ZFMSG:TESATK(E0007) Lower limit exceed upper limit.";
    private static final String ERROR_VALUE_EXCEED_UPPER = "ZFMSG:TESATK(E0008) Value exceed upper limit.";
    private static final String ERROR_VALUE_EXCEED_LOWER = "ZFMSG:TESATK(E0009) Value exceed lower limit.";
    private static final String ERROR_DEFAULT_VARIANT = "ZFMSG:TESATK(E0011) Only one variant could be Default.";
    private static final String ERROR_NO_DEFAULT_VARIANT = "ZFMSG:TESATK(E0012) One variant must be set as Default.";
    private static final String ERROR_UNIQUE_REFERENCE = "ZFMSG:TESATK(E0013) Each reference could be used only once.";
    private static final String ERROR_VARIANT_NAME = "ZFMSG:TESATK(E0047) Variant name must be unique.";
    private static final String WARNING_VALUE_OUT_OF_RANGE_TYPE = "ZFMSG:TESATK(W0005) The value is out of bounds of signal's defined datatype.";
    private static final String WARNING_SOURCE_NOT_FOUND = "ZFMSG:TESATK(W0006) Source under this name was not found.";
    private static final String WARNING_PORTNAME = "ZFMSG:TESATK(W0008) For subsystems not defined by the user, appropriate port should be used.";
    private static final String ERROR_USED_NOT_REFERENCED_MODELS = "ZFMSG:TESATK(E0072) Used references from models which are not referenced in main file for merging'.";
    private static final String ERROR_ITEMP_IADC_DEPENDENCY = "ZFMSG:TESATK(E0082) Temperature sensor subsystem requires input analog subsystem configured. ";
    private static final String ERROR_IADC_NO_POWERSUPPLY = "ZFMSG:TESATK(E0085) IADC subsystem requires at least one input signal with power supply flag. ";
    private static final String WARNING_OCG_SIGNAL_POWER_TYPE = "ZFMSG:TESATK(W0012) Each OCG port should have power supply signal of the same type.";
    private static final String WARNING_POSITIVE_VALUES = "ZFMSG:TESATK(W0023) This value should be set non-negative.";
    @Inject
    private IResourceDescriptions resourceDesciptions;


    // Check IFRQ sensor for non-negative values. Validate in all resources.
    @Check
    public void checkIFRQsensor(IFRQSensor o) {
    		if (Integer.parseInt(o.getDirChangeMinPeriods())<0)
            warning(WARNING_POSITIVE_VALUES,
                    ConfiguratorPackage.eINSTANCE.getIFRQSensor_DirChangeMinPeriods());
    		if (Integer.parseInt(o.getDirectionChangeDebounceTime())<0)
    			warning(WARNING_POSITIVE_VALUES,
                    ConfiguratorPackage.eINSTANCE.getIFRQSensor_DirectionChangeDebounceTime());
    		if (Integer.parseInt(o.getInitialWaitingTime())<0)
    			warning(WARNING_POSITIVE_VALUES,
                    ConfiguratorPackage.eINSTANCE.getIFRQSensor_InitialWaitingTime());
    }

    // Check IFRQ for unique index. Validate in all resources.
    @Check
    public void checkIFRQ(IFRQ o) {
    		if (Integer.parseInt(o.getActive())<0)
    			warning(WARNING_POSITIVE_VALUES,
                    ConfiguratorPackage.eINSTANCE.getIFRQ_Active());
    		if (Integer.parseInt(o.getUpdateTime())<0)
    			warning(WARNING_POSITIVE_VALUES,
                    ConfiguratorPackage.eINSTANCE.getIFRQ_UpdateTime());
        String driverIndex = null;
        if (o.getDriverIndex() != null) {
            driverIndex = o.getDriverIndex();
        }

        ArrayList<EObject> ifrqs = getAllTypeResource(o);
        for (EObject ifrq : ifrqs) {
            if (ifrq instanceof IFRQ) {
                IFRQ localIfrq = (IFRQ) ifrq;
                String iterDriverIndex = null;
                if (o.getDriverIndex() != null) {
                    iterDriverIndex = localIfrq.getDriverIndex();
                } 

                if ((ifrq != o) && (driverIndex.matches(iterDriverIndex))) {
                    error(ERROR_DRIVER_INDEX,
                            ConfiguratorPackage.eINSTANCE.getIFRQ_DriverIndex());
                }
            }
        }
    }

   

    // Check ISPI for unique index. Validate in all resources.
    @Check
    public void checkISPI(SPI o) {
    	if(o.getCommand() != null) {
    		if (Integer.parseInt(o.getCommand())<0)
            error(WARNING_POSITIVE_VALUES,
                    ConfiguratorPackage.eINSTANCE.getSPI_Command());
    	}

    	if(o.getDataLength() != null) {
    		if (Integer.parseInt(o.getDataLength())<0)
            error(WARNING_POSITIVE_VALUES,
                    ConfiguratorPackage.eINSTANCE.getSPI_DataLength());
    	}

    	if(o.getModule() != null) {
    		if (Integer.parseInt(o.getModule())<0)
            error(WARNING_POSITIVE_VALUES,
                    ConfiguratorPackage.eINSTANCE.getSPI_Module());
    	}

        String driverIndex = null;
        if (o.getDriverIndex() != null) {
            driverIndex = o.getDriverIndex();
        } 

        ArrayList<EObject> ispis = getAllTypeResource(o);
        for (EObject ispi : ispis) {
            if (ispi instanceof SPI) {
                SPI localIspi = (SPI) ispi;
                String iterDriverIndex = null;
                if (o.getDriverIndex() != null) {
                    iterDriverIndex = localIspi.getDriverIndex();
                } 

                if ((ispi != o) && (driverIndex.matches(iterDriverIndex))) {
                    error(ERROR_DRIVER_INDEX,
                            ConfiguratorPackage.eINSTANCE.getSPI_DriverIndex());
                }
            }
        }
    }

    // Check OPWM for unique index. Validate in all resources.
    @Check
    public void checkOPWM(OPWM o) {
        String driverIndex = null;
        if (o.getDriverIndex() != null) {
            driverIndex = o.getDriverIndex();
        } 
        
        ArrayList<EObject> opwms = getAllTypeResource(o);
        for (EObject opwm : opwms) {
            if (opwm instanceof OPWM) {
                OPWM localOpwm = (OPWM) opwm;
                String iterDriverIndex = null;
                if (o.getDriverIndex() != null) {
                    iterDriverIndex = localOpwm.getDriverIndex();
                } 
                if ((opwm != o) && (driverIndex.matches(iterDriverIndex))) {
                    error(ERROR_DRIVER_INDEX,
                            ConfiguratorPackage.eINSTANCE.getOPWM_DriverIndex());
                }
            }
        }
    }


    // Check InputDatafield that datafield variant name is unique.
    // Check InputDatafield for lower limit not exceed the upper limit
    // Check InitValue for limit range
    // Check SubstituteValue for limit range

    @Check
    public void checkInputDatafield(InputDatafield o) throws ParseException {

        Variant variantName = o.getVariantName();
        for (InputDatafield datafield : ((InputSignal) o.eContainer())
                .getDatafield()) {
            if ((datafield != o)) {
                if ((datafield.getVariantName().getName() != null)
                        && (variantName.getName().equals(datafield
                                .getVariantName().getName()))) {
                    error(ERROR_DATAFIELD_NAME,
                            ConfiguratorPackage.eINSTANCE
                                    .getDatafield_VariantName());
                }
            }
        }

        try {
            String lowerLimit = null;
            if (o.getLowerLimit() != null) {
                lowerLimit = o.getLowerLimit();
            }
            Double lowLimit = Double.valueOf(tryConvertToInt(lowerLimit));

            if (valueOutOfBounds(lowLimit, ((InputSignal)o.eContainer()).getSignal().getDataType() ) ) {
                warning(WARNING_VALUE_OUT_OF_RANGE_TYPE,
                        ConfiguratorPackage.eINSTANCE.getDatafield_LowerLimit());
            }

            String upperLimit = null;
            if (o.getUpperLimit()!= null) {
                upperLimit = o.getUpperLimit();
            }
            Double upLimit = Double.valueOf(tryConvertToInt(upperLimit));

            if (valueOutOfBounds(upLimit, ((InputSignal)o.eContainer()).getSignal().getDataType() ) ) {
                warning(WARNING_VALUE_OUT_OF_RANGE_TYPE,
                        ConfiguratorPackage.eINSTANCE.getDatafield_UpperLimit());
            }

            if (lowLimit > upLimit) {
                error(ERROR_LOWER_EXCEED_UPPER,
                        ConfiguratorPackage.eINSTANCE.getDatafield_LowerLimit());
                error(ERROR_LOWER_EXCEED_UPPER,
                        ConfiguratorPackage.eINSTANCE.getDatafield_UpperLimit());
            }
            Double initValue = null;
            if (o.getInitValue()!= null) {
                initValue = Double.valueOf(tryConvertToInt(o.getInitValue() ));
            }
            if (initValue > upLimit) {
                error(ERROR_VALUE_EXCEED_UPPER,
                        ConfiguratorPackage.eINSTANCE.getDatafield_InitValue(),
                        ValidationMessageAcceptor.INSIGNIFICANT_INDEX);
            }
            if (initValue < lowLimit) {
                error(ERROR_VALUE_EXCEED_LOWER,
                        ConfiguratorPackage.eINSTANCE.getDatafield_InitValue(),
                        ValidationMessageAcceptor.INSIGNIFICANT_INDEX);
            }

            if (valueOutOfBounds(initValue, ((InputSignal)o.eContainer()).getSignal().getDataType() ) ) {
                warning(WARNING_VALUE_OUT_OF_RANGE_TYPE,
                        ConfiguratorPackage.eINSTANCE.getDatafield_InitValue());
            }

        } catch (NumberFormatException e) {

        }
    }

    // Check OutputDatafield that datafield variant name is unique.
    // Check OutputDatafield for lower limit not exceed the upper limit
    // Check InitValue for limit range
    // Check SubstituteValue for limit range

    @Check
    public void checkOutputDatafield(OutputDatafield o) {

        Variant variantName = o.getVariantName();
        for (OutputDatafield datafield : ((OutputSignal) o.eContainer())
                .getDatafield()) {
            if ((datafield != o)) {
                if ((datafield.getVariantName().getName() != null)
                        && (variantName.getName().equals(datafield
                                .getVariantName().getName()))) {
                    error(ERROR_DATAFIELD_NAME,
                            ConfiguratorPackage.eINSTANCE
                                    .getDatafield_VariantName());
                }
            }
        }
        try {

            String lowerLimit = null;

            if (o.getLowerLimit()!= null) {
                lowerLimit = o.getLowerLimit();
            }
            Double lowLimit = Double.valueOf(tryConvertToInt(lowerLimit));

            if (valueOutOfBounds(lowLimit, ((OutputSignal)o.eContainer()).getSignal().getDataType() ) ) {
                warning(WARNING_VALUE_OUT_OF_RANGE_TYPE,
                        ConfiguratorPackage.eINSTANCE.getDatafield_LowerLimit());
            }

            String upperLimit = null;
            if (o.getUpperLimit()!= null) {
                upperLimit = o.getUpperLimit();
            }
            Double upLimit = Double.valueOf(tryConvertToInt(upperLimit));
            if (lowLimit > upLimit) {
                error(ERROR_LOWER_EXCEED_UPPER,
                        ConfiguratorPackage.eINSTANCE.getDatafield_LowerLimit());
                error(ERROR_LOWER_EXCEED_UPPER,
                        ConfiguratorPackage.eINSTANCE.getDatafield_UpperLimit());
            }

            if (valueOutOfBounds(upLimit, ((OutputSignal)o.eContainer()).getSignal().getDataType() ) ) {
                warning(WARNING_VALUE_OUT_OF_RANGE_TYPE,
                        ConfiguratorPackage.eINSTANCE.getDatafield_UpperLimit());
            }

            Double initValue = null;
            if (o.getInitValue()!= null) {
                initValue = Double.valueOf(tryConvertToInt(o.getInitValue()));
            }
            if (initValue > upLimit) {
                error(ERROR_VALUE_EXCEED_UPPER,
                        ConfiguratorPackage.eINSTANCE.getDatafield_InitValue(),
                        ValidationMessageAcceptor.INSIGNIFICANT_INDEX);
            }
            if (initValue < lowLimit) {
                error(ERROR_VALUE_EXCEED_LOWER,
                        ConfiguratorPackage.eINSTANCE.getDatafield_InitValue(),
                        ValidationMessageAcceptor.INSIGNIFICANT_INDEX);
            }

            if (valueOutOfBounds(initValue, ((OutputSignal)o.eContainer()).getSignal().getDataType() ) ) {
                warning(WARNING_VALUE_OUT_OF_RANGE_TYPE,
                        ConfiguratorPackage.eINSTANCE.getDatafield_InitValue());
            }

        } catch (NumberFormatException e) {

        }

    }

    // Check Portname that is reference. Only on safe of document.
    @Check(CheckType.NORMAL)
    public void checkPortname(Portname o) {
        if (o.eContainer() instanceof InputDatafieldImpl) {
            if ( !( (((InputDatafieldImpl) o.eContainer()).getSubSystem() instanceof InputConfigSubsystemItem) ||
                    (((InputDatafieldImpl) o.eContainer()).getSubSystem() instanceof InputConfigSubsystemNull)  )) {
                if (o.getPort() == null) {
                    warning(WARNING_PORTNAME,
                            ConfiguratorPackage.eINSTANCE.getPortname_Number());
                }
            }
        } else if (o.eContainer() instanceof OutputDatafieldImpl) {
            if (  !( (((OutputDatafieldImpl) o.eContainer()).getSubSystem() instanceof OutputConfigSubsystemItem) ||
                     (((OutputDatafieldImpl) o.eContainer()).getSubSystem() instanceof OutputConfigSubsystemNull)  )) {
                if (o.getPort() == null) {
                    warning(WARNING_PORTNAME,
                            ConfiguratorPackage.eINSTANCE.getPortname_Number());
                }
            }
        }
    }

    // Check input driver for unique index and max value

    @Check
    public void checkInputDriverType(InputDriverType o) {
        int checkIndexSource = o.getSortingIndex();
        int checkIndexTarget;
        Class<? extends EObject> cls = o.eContainer().getClass();
        
        // Check if array index is unique
        Field fieldlist[] = cls.getDeclaredFields();
        for (int i = 0; i < fieldlist.length; i++) {
            Field fld = fieldlist[i];
            fld.setAccessible(true);
            try {
                Object checkObject = fld.get(o.eContainer());
                if (checkObject instanceof EObjectContainmentEList) {
                    Object[] elist = ((EObjectContainmentEList<?>) checkObject)
                            .data();
                    if(elist != null){
                        for (int j = 0; j < elist.length; j++) {
                            if (elist[j] instanceof InputDriverType) {
                                checkIndexTarget = ((InputDriverType) elist[j])
                                        .getSortingIndex();
                                if ((checkIndexSource == checkIndexTarget)
                                        && (o != ((InputDriverType) elist[j]))) {
                                    error(ERROR_ARRAY_INDEX,
                                            ConfiguratorPackage.eINSTANCE
                                                    .getGenericSubsystem_SortingIndex());
                                }
                            }
                        }
                    }
                }
                if (checkObject instanceof InputDriverType) {
                    checkIndexTarget = ((InputDriverType) checkObject)
                            .getSortingIndex();
                    if ((checkIndexSource == checkIndexTarget)
                            && (o != ((InputDriverType) checkObject))) {
                        error(ERROR_ARRAY_INDEX,
                                ConfiguratorPackage.eINSTANCE
                                        .getGenericSubsystem_SortingIndex());
                    }
                }
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    }

    // Check output driver for unique index and max value

    @Check
    public void checkOutputDriverType(OutputDriverType o) {
        int checkIndexSource = o.getSortingIndex();
        int checkIndexTarget;
        Class<? extends EObject> cls = o.eContainer().getClass();
        
        // Check if array index is unique
        Field fieldlist[] = cls.getDeclaredFields();
        for (int i = 0; i < fieldlist.length; i++) {
            Field fld = fieldlist[i];
            fld.setAccessible(true);
            try {
                Object checkObject = fld.get(o.eContainer());
                if (checkObject instanceof EObjectContainmentEList) {
                    Object[] elist = ((EObjectContainmentEList<?>) checkObject)
                            .data();
                    if(elist != null){
                        for (int j = 0; j < elist.length; j++) {
                            if (elist[j] instanceof OutputDriverType) {
                                checkIndexTarget = ((OutputDriverType) elist[j])
                                        .getSortingIndex();
                                if ((checkIndexSource == checkIndexTarget)
                                        && (o != ((OutputDriverType) elist[j]))) {
                                    error(ERROR_ARRAY_INDEX,
                                            ConfiguratorPackage.eINSTANCE
                                                    .getGenericSubsystem_SortingIndex());
                                }
                            }
                        }
                    }
                }
                if (checkObject instanceof OutputDriverType) {
                    checkIndexTarget = ((OutputDriverType) checkObject)
                            .getSortingIndex();
                    if ((checkIndexSource == checkIndexTarget)
                            && (o != ((OutputDriverType) checkObject))) {
                        error(ERROR_ARRAY_INDEX,
                                ConfiguratorPackage.eINSTANCE
                                        .getGenericSubsystem_SortingIndex());
                    }
                }
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    }

    private String tryConvertToInt(String value) {
    	Long intValue = null;
        if ((value.startsWith("0x") || value.startsWith("0X"))
                && value.contains(".") == false) {
        	intValue = Long.parseLong(value.substring(2), 16);
            return intValue.toString();
        }
        return value;
    }

    // Check Signal for lower and upper limit
    @Check
    public void checkSignal(Signal o) {

    	Double lowerLimit = null;
        Double upperLimit = null;
        try {
            if (o.getAsapMeasurment().getLowerLimit()!= null) {
                lowerLimit = Double.parseDouble(tryConvertToInt(o.getAsapMeasurment().getLowerLimit()));
            }

            if (o.getAsapMeasurment().getUpperLimit()!= null) {
                upperLimit = Double.valueOf(tryConvertToInt(o.getAsapMeasurment().getUpperLimit()));
            }

            if (lowerLimit > upperLimit) {
                error(ERROR_LOWER_EXCEED_UPPER,
                        //ConfiguratorPackage.eINSTANCE.getSignal_LowerLimit());
                		ConfiguratorPackage.eINSTANCE.getASAPMeasurment_LowerLimit());
                error(ERROR_LOWER_EXCEED_UPPER,
                        ConfiguratorPackage.eINSTANCE.getASAPMeasurment_UpperLimit());
            }

        } catch (NumberFormatException e) {

        }
    }

 

    // Check Variants for default
    @Check
    public void checkVariant(Variant o) {

        ArrayList<EObject> objects = getAllTypeResource(o);
        if (o.getDefaultVariant() != null) {
            for (EObject obj : objects) {
                if (obj instanceof Variant && obj != o) {
                    Variant iterVariant = (Variant) obj;
                    if (iterVariant.getDefaultVariant() != null) {
                        error(ERROR_DEFAULT_VARIANT,
                                o,
                                ConfiguratorPackage.eINSTANCE.getVariant_Name(),
                                ValidationMessageAcceptor.INSIGNIFICANT_INDEX);
                    }
                }
            }
        } else {
            boolean defaultVariantFound = false;
            for (EObject obj : objects) {
                if (obj instanceof Variant && obj != o) {
                    if (((Variant) obj).getDefaultVariant() != null)
                        defaultVariantFound = true;
                }
            }

            if (defaultVariantFound == false) {
                error(ERROR_NO_DEFAULT_VARIANT,
                        ConfiguratorPackage.eINSTANCE.getVariant_Name());
            }
        }

        for (EObject obj : objects) {
            if (obj instanceof Variant && obj != o) {
                Variant iterVariant = (Variant) obj;
                if (iterVariant.getName().matches(o.getName())) {
                    error(ERROR_VARIANT_NAME, o,
                            ConfiguratorPackage.eINSTANCE.getVariant_Name(),
                            ValidationMessageAcceptor.INSIGNIFICANT_INDEX);
                }
            }
        }


    }

    // Check DigDriversTable for unique names
    @Check
    public void checkInputDigDriversTable(InDigitalDriverTableRef o) {
        InDigDriver driverRef = o.getName();
        if (driverRef != null) {
            InputDigDriversTable digDrivers = (InputDigDriversTable) o
                    .eContainer();
            for (InDigitalDriverTableRef digDriver : digDrivers
                    .getDigitalDriverTableRef()) {
                if ((digDriver != o) && (driverRef == digDriver.getName())) {
                    error(ERROR_UNIQUE_REFERENCE,
                            ConfiguratorPackage.eINSTANCE
                                    .getInDigitalDriverTableRef_Name());
                }
            }
        }
    }

    @Check
    public void checkOutputDigDriversTable(OutDigitalDriverTableRef o) {
        OutDigDriver driverRef = o.getName();
        if (driverRef != null) {
            OutputDigDriversTable digDrivers = (OutputDigDriversTable) o
                    .eContainer();
            for (OutDigitalDriverTableRef digDriver : digDrivers
                    .getDigitalDriverTableRef()) {
                if ((digDriver != o) && (driverRef == digDriver.getName())) {
                    error(ERROR_UNIQUE_REFERENCE,
                            ConfiguratorPackage.eINSTANCE
                                    .getOutDigitalDriverTableRef_Name());
                }
            }
        }
    }

    /*
     *  IADC and ITemperature validation
     */

    @Check(CheckType.NORMAL)
    public void checkAnalogDriver(AnalogDriver arg_AnalogDriver){

        try {	// Actualizes all resource files
            if (resourceDesciptions.getAllResourceDescriptions() != null)
                for (IResourceDescription resourceDescrb : resourceDesciptions.getAllResourceDescriptions()) {
                    URI resourceURI = resourceDescrb.getURI();
                    if (arg_AnalogDriver.eResource().getResourceSet().getResource(resourceURI, false) == null) {
                    	arg_AnalogDriver.eResource().getResourceSet().getResource(resourceURI, true);
                    }
                }
        } catch (Exception e) {
        }

    	boolean loc_InputAnalogDriversFound = false;
    	for (Resource resource : arg_AnalogDriver.eResource().getResourceSet().getResources()) {
    		int loc_index=0;
       		if(resource.getContents().isEmpty()== false && resource.getContents().get(loc_index) instanceof Configuration) {
 				Configuration loc_Config = (Configuration)(resource.getContents().get(loc_index));
 							if (loc_Config.getHardware() != null
 									&& loc_Config.getHardware().getDriverToECU() != null
 									&& loc_Config.getHardware().getDriverToECU().getInputAnalogDrivers() != null
 									) {
 								loc_InputAnalogDriversFound = true;
 					}
 			}
 		}
        if(arg_AnalogDriver.eContainer() instanceof TempSensorSubsystem && loc_InputAnalogDriversFound==false)
        	{
        	error(ERROR_ITEMP_IADC_DEPENDENCY,
                    ConfiguratorPackage.eINSTANCE.getAnalogDriver_Name());
        	}
    }


    /*
     *  PowerSupplySignal and PowerSupplySwitchSignal for IADC
     */
    @Check //(CheckType.NORMAL)
    public void checkIADCPower(InputConfigSubsystemAnalog arg_ConfigSubs){

   			try {	// Actualizes all resource files
   				if (resourceDesciptions.getAllResourceDescriptions() != null)
   					for (IResourceDescription resourceDescrb : resourceDesciptions.getAllResourceDescriptions()) {
   						URI resourceURI = resourceDescrb.getURI();
   						if (arg_ConfigSubs.eResource().getResourceSet().getResource(resourceURI, false) == null) {
   							arg_ConfigSubs.eResource().getResourceSet().getResource(resourceURI, true);
   						}
                }
        } catch (Exception e) {
        }
            int loc_PSScount=0; //number of power supply signals
            
        	//try to find power supply signal
        	for (Resource resource : arg_ConfigSubs.eResource().getResourceSet().getResources()) {
        		int loc_index=0;
        		if(resource.getContents()!= null && resource.getContents().size()>0)
           		if(resource.getContents().get(loc_index) instanceof Configuration) {
     				Configuration loc_Config = (Configuration)(resource.getContents().get(loc_index));
     				if (loc_Config.getSignals() != null && loc_Config.getSignals().getPiosSignals() != null &&
     						loc_Config.getSignals().getPiosSignals().getGeneralSignal() != null)
     				{
     						List<GeneralSignal> loc_Signals = loc_Config.getSignals().getPiosSignals().getGeneralSignal();
     						for (GeneralSignal loc_Signal:loc_Signals) {

     							if(loc_Signal instanceof InputSignal) {
     								InputSignal loc_InputSignal = (InputSignal) loc_Signal;
     								if(loc_InputSignal.getPowerSupply()!=null) {loc_PSScount++;}
     							}
     							
     						}
     				}
        	}
        }

        // no PSS error
        	if(loc_PSScount==0)
        	{
        	error(ERROR_IADC_NO_POWERSUPPLY,
   		 				ConfiguratorPackage.eINSTANCE.getGenericSubsystem_Name());
        	}            
     }
    
 
        
    /*
     * check eldiag ports for different types of signals
     */
    @Check
    public void checkOCG(ElDiag eldiag) {
        ArrayList<EObject> objects = getAllTypeResource(eldiag);
        for (EObject obj : objects) {
            if (obj instanceof ElDiag && obj != eldiag) {
            	ElDiag eldiag_iter = (ElDiag) obj;
                if (!(eldiag.getPowerSupplySignal().getSignal().getDataType().toString().matches(eldiag_iter.getPowerSupplySignal().getSignal().getDataType().toString()))) {
                	warning(WARNING_OCG_SIGNAL_POWER_TYPE,
                            ConfiguratorPackage.eINSTANCE.getElDiag_PowerSupplySignal()); }
	            }
            }
        }

    /*
     * check that all imported sources exists.
     */
    @Check
    public void checkImportedSources(Imports imports) {
        ArrayList<EObject> objects = getAllTypeResource(EcoreUtil2.getRootContainer(imports));

        String[] parsedName = imports.getImportedNamespace().replace(".*", "").split("\\.");

        String nameOfSource = parsedName[0];

        boolean foundSource = false;

        // whole model is loaded
        if(parsedName.length <= 1){
            for (EObject obj : objects) {
                if(((Configuration)obj).getConfigurationName().matches(nameOfSource)){
                    foundSource = true;
                    break;
                }
            }
        }
        // part of model is loaded
        else{
            String nameOfPart = parsedName[1];
            for (EObject obj : objects) {
              Configuration config = (Configuration)obj;
              EList<EObject> listOfParts = config.eContents();
              for (EObject part : listOfParts) {
                if (part.eClass().getEStructuralFeature("name") != null) {
                    String nameOfFeature = part.eGet(part.eClass().getEStructuralFeature("name")).toString();
                    if(nameOfSource.matches(config.getConfigurationName()) && nameOfPart.matches(nameOfFeature)){
                        foundSource = true;
                        break;
                    }
                }
              }
            }
        }

        if(foundSource == false)
            warning(WARNING_SOURCE_NOT_FOUND, imports,
                    ConfiguratorPackage.eINSTANCE
                            .getImports_ImportedNamespace(),
                    ValidationMessageAcceptor.INSIGNIFICANT_INDEX);

    }




    private enum Datatype{
        UI16, UI32
    }

 

    /*
     * At save of a model check that all referenced objects are in models which are referenced
     * in a main file for merging
     */
    
    EList<Resource> resources;
    Resource mainFileForMerging;
    
    
    @Check(CheckType.NORMAL)
    public void checkWholeConfiguration(Configuration o) {
        resources = new BasicEList<Resource>();
        // add all missing resources
        for (Resource resource : o.eResource().getResourceSet().getResources()) {
            if (resources.contains(resource) == false) {
                resources.add(resource);
            }
        }

        int countOfConfigModels = 0;
        // find the main file for merging
        boolean mainFileFound = false;
        for (Resource resource : resources) {
            EcoreUtil2.resolveAll(resource);
            if ( (resource.getContents().isEmpty() == false) && (resource.getContents().get(0) instanceof Configuration) ) {
                countOfConfigModels++;
                Configuration config = (Configuration) resource.getContents()
                        .get(0);
                if (config.getMainMergeFile() != null) {
                    // if more then one main file for merging found skip this
                    // validation
                    if (mainFileFound == true) {
                        return;
                    }
                    mainFileForMerging = resource;
                    mainFileFound = true;
                }
            }
        }

        // working with only one configuration model
        if (countOfConfigModels == 1) {
            return;
        }

        EList<Imports> imports = ((Configuration) mainFileForMerging
                .getContents().get(0)).getImports();
        boolean modelFoundInImportedNamespaces = false;

        ArrayList<String> namesOfImportedModels = new ArrayList<String>();
        for (Imports imp : imports) {
            // get the name of a model and save it

            String[] parsedName = imp.getImportedNamespace().split("\\.");

            namesOfImportedModels.add(parsedName[0]);
            if (imp.getImportedNamespace().contains(o.getConfigurationName())) {
                modelFoundInImportedNamespaces = true;
            }
        }
        // add main file for merging to the list
        namesOfImportedModels.add(((Configuration) mainFileForMerging
                .getContents().get(0)).getConfigurationName());

        // don't check model which is not in main file for merging.
        if (o.eResource() != mainFileForMerging
                && modelFoundInImportedNamespaces == false) {
            return;
        }

        boolean objectFoundInImportedNamespaces = false;

        // load all files
        EcoreUtil2.resolveAll(o, CancelIndicator.NullImpl);
        // get all objects from tested file
        TreeIterator<EObject> tree = o.eResource().getAllContents();
        /*
         * go through each object, get all references and check if referenced
         * objects are from models referenced in main file for merging.
         */
        while (tree.hasNext()) {
            EObject obj = tree.next();
            List<EObject> referencedObjects = new BasicEList<EObject>();
            if (obj.eClass().getEAllReferences().size() > 0) {
                for (EReference ref : obj.eClass().getEAllReferences()) {
                    referencedObjects.addAll(EcoreUtil2
                            .getAllReferencedObjects(obj, ref));
                }
            }

            for (EObject refObject : referencedObjects) {
                if (!(refObject.eResource().getContents().get(0) instanceof Configuration)) {
                    continue;
                } else {
                    String name = ((Configuration) EcoreUtil2
                            .getRootContainer(refObject)).getConfigurationName();
                    for (String imp : namesOfImportedModels) {
                        if (imp.matches(name)) {
                            objectFoundInImportedNamespaces = true;
                            break;
                        } else {
                            objectFoundInImportedNamespaces = false;
                        }
                    }
                }

                if (objectFoundInImportedNamespaces == false) {
                    error(ERROR_USED_NOT_REFERENCED_MODELS, o,
                            ConfiguratorPackage.eINSTANCE
                                    .getConfiguration_ConfigurationName(),
                            ValidationMessageAcceptor.INSIGNIFICANT_INDEX);
                }
            }
        }
    }

    boolean valueOutOfBounds(Double lowLimit, dataTypeEnumeration datatype){
        if(datatype == dataTypeEnumeration.UI8){
            if(lowLimit < 0 || lowLimit > 255)
                return true;
        }
        else if(datatype == dataTypeEnumeration.UI16){
            if(lowLimit < 0 || lowLimit > 65535)
                return true;
        }
        else if(datatype == dataTypeEnumeration.SI8){
            if(lowLimit < -128 || lowLimit > 127)
                return true;
        }
        else if(datatype == dataTypeEnumeration.SI16){
            if(lowLimit < -32768 || lowLimit > 32767)
                return true;
        }
        else if(datatype == dataTypeEnumeration.SI32){
            if(lowLimit < -2147483648 || lowLimit > 2147483647)
                return true;
        }
        else if(datatype == dataTypeEnumeration.FL32){
            if( lowLimit < -Float.MAX_VALUE || lowLimit > Float.MAX_VALUE)
                return true;
        }
        return false;
    }

    boolean valueOutOfBounds(Long lowLimit, Datatype datatype){
        Long maxUi32 = new Long("4294967295");
        if(datatype == Datatype.UI16){
            if(lowLimit < 0 || lowLimit > 65535)
                return true;
        }
        else if(datatype == Datatype.UI32){
            if(lowLimit < 0 || lowLimit > maxUi32)
                return true;
        }
        return false;
    }

    // This function gets one class from all resources. Class is same as class
    // of parameter.
    private ArrayList<EObject> getAllTypeResource(EObject object) {
        try {
            if (resourceDesciptions.getAllResourceDescriptions() != null)
                for (IResourceDescription resourceDescrb : resourceDesciptions
                        .getAllResourceDescriptions()) {
                    URI resourceURI = resourceDescrb.getURI();
                    if (object.eResource().getResourceSet()
                            .getResource(resourceURI, false) == null) {
                        object.eResource().getResourceSet()
                                .getResource(resourceURI, true);
                    }
                }
        } catch (Exception e) {
        }

        ArrayList<EObject> result = new ArrayList<EObject>();
        EList<org.eclipse.emf.ecore.resource.Resource> resources = object
                .eResource().getResourceSet().getResources();

        for (org.eclipse.emf.ecore.resource.Resource resource : resources) {

            if (resource.getURI().fileExtension().equalsIgnoreCase("tesa")) {
                org.eclipse.emf.common.util.TreeIterator<EObject> iterator = resource
                        .getAllContents();
                while (iterator.hasNext()) {
                    EObject obj = iterator.next();
                    if (obj.eClass().isInstance(object)) {
                        result.add(obj);
                    }
                }
            }
        }
        return result;
    }
}
