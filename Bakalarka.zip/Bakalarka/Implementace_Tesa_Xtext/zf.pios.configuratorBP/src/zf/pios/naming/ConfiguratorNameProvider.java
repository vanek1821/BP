package zf.pios.naming;

import org.eclipse.xtext.naming.DefaultDeclarativeQualifiedNameProvider;

public class ConfiguratorNameProvider extends
		DefaultDeclarativeQualifiedNameProvider {

}
