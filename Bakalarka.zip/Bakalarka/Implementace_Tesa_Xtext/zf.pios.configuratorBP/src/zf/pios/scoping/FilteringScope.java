/*******************************************************************************
 * Copyright (c) 2010 itemis AG (http://www.itemis.eu) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package zf.pios.scoping;

import java.util.ArrayList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.xtext.naming.QualifiedName;
import org.eclipse.xtext.resource.IEObjectDescription;
import org.eclipse.xtext.resource.IResourceDescription;
import org.eclipse.xtext.scoping.IScope;
import com.google.common.base.Predicate;

public class FilteringScope implements IScope {

	private IScope delegate;
	private Predicate<EObject> filter;
//	private EList<IResourceDescription> resources;
	private ResourceSet resourceSet;

	public FilteringScope(IScope delegate, Predicate<EObject> filter, EList<IResourceDescription> resources, ResourceSet resourceSet) {
		this.delegate = delegate;
		this.filter = filter;
//		this.resources = resources;
		this.resourceSet = resourceSet;
	}

	@Override
	public IEObjectDescription getSingleElement(QualifiedName name) {
		return filter(delegate.getSingleElement(name));
	}

	@Override
	public Iterable<IEObjectDescription> getElements(QualifiedName name) {
		return filter(delegate.getElements(name));
	}

	@Override
	public IEObjectDescription getSingleElement(EObject object) {
		return filter(delegate.getSingleElement(object));
	}

	@Override
	public Iterable<IEObjectDescription> getElements(EObject object) {
		return filter(delegate.getElements(object));
	}

	@Override
	public Iterable<IEObjectDescription> getAllElements() {
		return filter(delegate.getAllElements());
	}
	
	
	protected Iterable<IEObjectDescription> filter(	Iterable<IEObjectDescription> unfiltered) {

		ArrayList<IEObjectDescription> filtered = new ArrayList<IEObjectDescription>() ;
		for (IEObjectDescription description : unfiltered) {
			if(filter(description) != null)
				filtered.add(description);
		}
		return filtered;
	}

	protected IEObjectDescription filter(IEObjectDescription contentByEObject) {

		EObject object = eobjectForIEObjectDescription(contentByEObject);
		if (!filter.apply(object))
			return null;
		return contentByEObject;
	}

	protected EObject eobjectForIEObjectDescription(IEObjectDescription objectDescription){

		EObject object = null;

		if(objectDescription != null)
					object = resourceSet.getEObject(objectDescription.getEObjectURI(), true);

		return object;
	}
}
