package zf.pios.scoping;

import java.util.ArrayList;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.naming.IQualifiedNameConverter;
import org.eclipse.xtext.resource.IResourceDescription;
import org.eclipse.xtext.resource.IResourceDescriptions;
import org.eclipse.xtext.resource.IResourceServiceProvider;
import org.eclipse.xtext.scoping.IScope;
import org.eclipse.xtext.scoping.impl.AbstractDeclarativeScopeProvider;
import zf.pios.configurator.AnalogDriver;
import zf.pios.configurator.Configuration;
import zf.pios.configurator.ElDiag;
import zf.pios.configurator.IADC;
import zf.pios.configurator.IFRQ;
import zf.pios.configurator.Imports;
import zf.pios.configurator.InDigDriver;
import zf.pios.configurator.InDigitalDriverTableRef;
import zf.pios.configurator.InputAnalogDrivers;
import zf.pios.configurator.InputConfigSubsystemAnalog;
import zf.pios.configurator.InputConfigSubsystemDigital;
import zf.pios.configurator.InputConfigSubsystemFrq;
import zf.pios.configurator.InputConfigSubsystemItem;
import zf.pios.configurator.InputConfigSubsystemSPI;
import zf.pios.configurator.InputConfigSubsystemTemperature;
import zf.pios.configurator.InputDatafield;
import zf.pios.configurator.InputDigitalDrivers;
import zf.pios.configurator.InputSignal;
import zf.pios.configurator.OPWM;
import zf.pios.configurator.OutDigDriver;
import zf.pios.configurator.OutDigitalDriverTableRef;
import zf.pios.configurator.OutputConfigSubsystemDigital;
import zf.pios.configurator.OutputConfigSubsystemElDiag;
import zf.pios.configurator.OutputConfigSubsystemItem;
import zf.pios.configurator.OutputConfigSubsystemPWM;
import zf.pios.configurator.OutputDatafield;
import zf.pios.configurator.OutputDigitalDrivers;
//import zf.pios.configurator.OutputSignal;
import zf.pios.configurator.SPI;
import zf.pios.configurator.TempSensorSubsystem;
import zf.pios.configurator.UserDefinedSubsystem;
import zf.pios.configurator.UserPort;
import zf.pios.naming.ConfiguratorNameProvider;

import com.google.common.base.Predicate;
import com.google.inject.Inject;

/**
 * This class contains custom scoping description.
 *
 * see : http://www.eclipse.org/Xtext/documentation/latest/xtext.html#scoping
 * on how and when to use it
 *
 */
public class ConfiguratorScopeProvider extends AbstractDeclarativeScopeProvider {

	@Inject
	private IResourceDescriptions resourceDescriptions;

	@Inject
	private IResourceServiceProvider.Registry register;

	@Inject
	IQualifiedNameConverter converter;


	@Inject
	ConfiguratorNameProvider nameProvider;

	private String inputDigDrivers = "InputDigDrivers";
	private String outputDigDrivers = "OutputDigDrivers";


	// Input signals
	IScope scope_Portname_port(final InputDatafield arg_Datafield, EReference arg_eRef)
	{

		Configuration loc_Configuration = (Configuration)(org.eclipse.xtext.EcoreUtil2.getRootContainer(arg_Datafield));

		IScope loc_Unfiltered = delegateGetScope(arg_Datafield, arg_eRef);

		ResourceSet resourceSet = arg_Datafield.eResource().getResourceSet();

		/* takes care about loading resources to ResourceSet if are not, from some reason, already there.
		 * works only if the 'resourceDesciptions' is filled!!!, then it contains all resource descriptions which are visible
		 * the second parameter 'true' in method getResource(), tells to resourceSet to load the resource to the set if it is not loaded.
		 */

		try{
			if(resourceDescriptions.getAllResourceDescriptions() != null)
				for(IResourceDescription resourceDescrb    : 	resourceDescriptions.getAllResourceDescriptions()){
					URI resourceURI = resourceDescrb.getURI();
					if(resourceSet.getResource(resourceURI, false) == null){
						resourceSet.getResource(resourceURI, true);
					}
				}
		}
		catch (Exception e){}

		workOnlyWithImportedFilesInResourceSet(loc_Configuration);


		EList<IResourceDescription> resourceDescriptions = resourceDescriptionsOfImportedFiles(arg_Datafield);

		// IFRQ
		 if(arg_Datafield.getSubSystem() instanceof InputConfigSubsystemFrq){

			FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
				public boolean apply(EObject input) {
					if(input instanceof IFRQ){
						return ( input!= null);
					}
					return false;
				};
			}, resourceDescriptions, resourceSet);

			return scope;

		}
		// ISPI
		else if(arg_Datafield.getSubSystem() instanceof InputConfigSubsystemSPI){
			FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
				public boolean apply(EObject input) {
					if(input instanceof SPI){
						return ( input!= null);
					}
					return false;
				};
			}, resourceDescriptions, resourceSet);

			return scope;
		}
		// Input analog/digital driver
		else if( (arg_Datafield.getSubSystem() instanceof InputConfigSubsystemDigital) || (arg_Datafield.getSubSystem()instanceof InputConfigSubsystemAnalog ))
		{
			if( arg_Datafield.getSubSystem() instanceof InputConfigSubsystemDigital ){
				final ArrayList<EObject> driversInTable = listOfAllInstances(loc_Configuration, inputDigDrivers);

				FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
					public boolean apply(EObject input) {
						if(input instanceof InDigDriver && input.eContainer() instanceof InputDigitalDrivers){
							return (input != null && driversInTable.contains(input));
						}
						return false;
					};
				}, resourceDescriptions, resourceSet);

				return scope;
			}
			else{
				FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
					public boolean apply(EObject input) {
						if(input instanceof AnalogDriver && input.eContainer() instanceof InputAnalogDrivers){
							return (input != null);
						}
						return false;					};
				}, resourceDescriptions, resourceSet);

				return scope;
		 }
		}

		// Input Temperature sensor
		else if(arg_Datafield.getSubSystem() instanceof InputConfigSubsystemTemperature){

			FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){

				public boolean apply(EObject input) {
					if(input instanceof AnalogDriver && input.eContainer() instanceof  TempSensorSubsystem ) {
						return ( input!= null);
					}
					return false;

				};
			}, resourceDescriptions, resourceSet);

			return scope;

		}


		// user defined subsystem
		else if(arg_Datafield.getSubSystem() instanceof InputConfigSubsystemItem){
			FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
			   public boolean apply(EObject input) {
			      if(input instanceof UserPort && (((UserDefinedSubsystem)input.eContainer()).getName() == arg_Datafield.getSubSystem()) ){
				     return ( input!= null);
			         }
				  return false;
			   };
			}, resourceDescriptions, resourceSet);
			return scope;
		}
		else
			return IScope.NULLSCOPE;
	}

	String resourceImportAlias(URI uri, java.util.List<zf.pios.configurator.Import> listImportUris)
	{
		for(zf.pios.configurator.Import importURI :listImportUris )
			if(uri.toString().contains(importURI.getImportURI()))
				return importURI.getName();


		return "";
	}

	// Output signals
	IScope scope_Portname_port(final OutputDatafield arg_Datafield, EReference arg_eRef)
	{
		Configuration loc_Configuration = (Configuration)(org.eclipse.xtext.EcoreUtil2.getRootContainer(arg_Datafield));

		IScope loc_Unfiltered = delegateGetScope(arg_Datafield, arg_eRef);

		ResourceSet loc_ResourceSet = arg_Datafield.eResource().getResourceSet();

		/* takes care about loading resources to ResourceSet if are not, from some reason, not already there.
		 * works only if the 'resourceDesciptions' is filled, then it contains all resource descriptions which are visible
		 * the option true in method getResource(), tells the resourceSet to load the resource to the set if it is not loaded.
		 */

		try{
			if(resourceDescriptions.getAllResourceDescriptions() != null)

				for(IResourceDescription resourceDescrb    : 	resourceDescriptions.getAllResourceDescriptions()){
					URI resourceURI = resourceDescrb.getURI();
					if(loc_ResourceSet.getResource(resourceURI, false) == null){
					    loc_ResourceSet.getResource(resourceURI, true);
					}
				}
		}
		catch (Exception e){}

		workOnlyWithImportedFilesInResourceSet(loc_Configuration);

		EList<IResourceDescription> resourceDescriptions = resourceDescriptionsOfImportedFiles(arg_Datafield);

		// OPWM
		if(arg_Datafield.getSubSystem() instanceof OutputConfigSubsystemPWM){
			FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
				public boolean apply(EObject input) {
					if(input instanceof OPWM){
						return ( input!= null);
					}
					return false;
				};
			}, resourceDescriptions, loc_ResourceSet);

			return scope;

		}

		// ElDiag
		else if(arg_Datafield.getSubSystem() instanceof OutputConfigSubsystemElDiag){

			FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){

				public boolean apply(EObject input) {
					if(input instanceof ElDiag){
						return ( input!= null);
					}
					return false;
				};
			}, resourceDescriptions, loc_ResourceSet);

			return scope;

		}

		// Output digital driver
		else if(arg_Datafield.getSubSystem() instanceof OutputConfigSubsystemDigital)
		{

			final ArrayList<EObject> driversInTable = listOfAllInstances(loc_Configuration, outputDigDrivers);
			FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
				public boolean apply(EObject input) {
					if(input instanceof OutDigDriver && input.eContainer() instanceof OutputDigitalDrivers){
						return (input != null && driversInTable.contains(input));
					}
					return false;
				};
			}, resourceDescriptions, loc_ResourceSet);

			return scope;
		}

		// user defined subsystem
		else if(arg_Datafield.getSubSystem() instanceof OutputConfigSubsystemItem){
			FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
				public boolean apply(EObject input) {
				      if(input instanceof UserPort && (((UserDefinedSubsystem)input.eContainer()).getName() == arg_Datafield.getSubSystem()) ){
						return ( input!= null);
					}
					return false;
				};
			}, resourceDescriptions, loc_ResourceSet);

			return scope;
		}
		else
			return IScope.NULLSCOPE;
	}


	//  Scoping for IADC/ITemp PowerSupplySignal
	IScope scope_IADC_powerSupplySignal(IADC arg_iadc, EReference arg_eRef){
		  Configuration configuration = (Configuration)org.eclipse.xtext.EcoreUtil2.getRootContainer(arg_iadc);
		  IScope loc_Unfiltered = delegateGetScope(configuration, arg_eRef);
		  ResourceSet resourceSet = arg_iadc.eResource().getResourceSet();
		  EList<IResourceDescription> resourceDescriptions = resourceDescriptionsOfImportedFiles(arg_iadc);

		   FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
		    public boolean apply(EObject input) {
		    	if (input != null) {
		         if(((InputSignal) input).getPowerSupply() != null) { return ( input!= null); }
		         else { return false; } }
		    	else { return false; }
		    };
		   }, resourceDescriptions, resourceSet);
		   return scope;

	}


	//  Scoping for OCG PowerSupplySignal
	IScope scope_OCG_powerSupplySignal(ElDiag arg_ocg, EReference arg_eRef){
		  Configuration loc_Configuration = (Configuration)org.eclipse.xtext.EcoreUtil2.getRootContainer(arg_ocg);
		  IScope loc_Unfiltered = delegateGetScope(loc_Configuration, arg_eRef);
		  ResourceSet loc_ResourceSet = arg_ocg.eResource().getResourceSet();
		  EList<IResourceDescription> loc_ResourceDescriptions = resourceDescriptionsOfImportedFiles(arg_ocg);

		   FilteringScope scope = new FilteringScope(loc_Unfiltered, new Predicate<EObject>(){
		    public boolean apply(EObject input) {
		    	if (input != null) {
		         if(((InputSignal) input).getPowerSupply() != null) { return ( input!= null); }
		         else { return false; } }
		    	else { return false; }
		    };
		   }, loc_ResourceDescriptions, loc_ResourceSet);
		   return scope;

	}






	private ArrayList<EObject> listOfAllInstances(Configuration configuration, String typeOfPort){

		ArrayList<Configuration> importedModels = configuratorsOfModels(configuration);
		ArrayList<EObject> offeredObjects =  new ArrayList<EObject>();



			// input digital drivers referenced in inputDigDriversTable
			if(typeOfPort.matches(inputDigDrivers))
			for(Configuration config : importedModels){
				if( (config.getHardware() != null) && (config.getHardware().getDriverToECU() != null) &&
				  (config.getHardware().getDriverToECU().getInputDigDriversTable() != null) ){
					for(InDigitalDriverTableRef driverRef : config.getHardware().getDriverToECU().getInputDigDriversTable().getDigitalDriverTableRef()){
						if(driverRef.getDummySignal() == null)
							offeredObjects.add(driverRef.getName());
					}
				}

			}

			// output digital drivers referenced in outputDigDriversTable
			if(typeOfPort.matches(outputDigDrivers))
			for(Configuration config : importedModels){
				if( (config.getHardware() != null) && (config.getHardware().getDriverToECU() != null) &&
				  (config.getHardware().getDriverToECU().getOutputDigDriversTable() != null) ){
					for(OutDigitalDriverTableRef driverRef : config.getHardware().getDriverToECU().getOutputDigDriversTable().getDigitalDriverTableRef()){
						if(driverRef.getDummySignal() == null)
							offeredObjects.add(driverRef.getName());
					}
				}
			}

		return offeredObjects;
	}

	/* get all resource descriptions of all resources
	 * note: for importedNamespace aware scoping resources are only of type configurator.
	 * For importURI aware scoping, resources contains all founded files of known types.
	 */
	private EList<IResourceDescription> resourceDescriptionsOfImportedFiles(EObject object){

		EList<IResourceDescription> resourceDescriptions = new BasicEList<IResourceDescription>();

		EList<Resource> allResources = object.eResource().getResourceSet().getResources();

		for(Resource resource : allResources){
			IResourceDescription resourceDescription = register.getResourceServiceProvider(resource.getURI()).getResourceDescriptionManager().getResourceDescription(resource);
			resourceDescriptions.add(resourceDescription);
		}
		return resourceDescriptions;
	}

	private ArrayList<Configuration> configuratorsOfModels(Configuration configuration ){

		EList<Resource> resources = configuration.eResource().getResourceSet().getResources();
		ResourceSet resourceSet = configuration.eResource().getResourceSet();

		try{
			if(resourceDescriptions.getAllResourceDescriptions() != null)
				for(IResourceDescription resourceDescrb    : 	resourceDescriptions.getAllResourceDescriptions()){
					URI resourceURI = resourceDescrb.getURI();
					if(resourceSet.getResource(resourceURI, false) == null){
						resourceSet.getResource(resourceURI, true);
					}
				}
		}
		catch (Exception e){}

		ArrayList<Configuration> importedModels = new ArrayList<Configuration>();

	       for (Resource resource : resources) {
	           if(resource.isLoaded() == false){
	             resourceSet.getResource(resource.getURI(), true);
	           }
	           if (resource.getURI().fileExtension().equalsIgnoreCase("tesa")) {

	        	  if( resource.getAllContents().hasNext() )
	        		  importedModels.add( (Configuration) EcoreUtil2.getRootContainer( resource.getAllContents().next() ) );
	           }
	         }
			return importedModels;
	}

	/* Goal is to have a ResourceSet which has only models imported into main merge file or work only with one file
	 * 		  1. Function for getting all models
	 * 		  2. Finding the main file
	 * 		  3. Selecting files which are imported, rest are removed from ResourceSet
	 *  Every model has its own unique name, this name is used for importing. By this names we will select models.
	 */

	private void workOnlyWithImportedFilesInResourceSet(Configuration configuration){
		try {
			ArrayList<Configuration> loadedConfigurators = configuratorsOfModels(configuration);

			if(loadedConfigurators.size() == 1){} //we are working only with one file
			else{
				Configuration mergeModel = null;
				boolean mainAlreadySet = false;
				for (Configuration iterModel : loadedConfigurators) {
					if (iterModel.getMainMergeFile() != null) {
						if (mainAlreadySet == true) {
							throw new Exception(
									"ZFMSG:TESATK(E0050) The main file for merging was already set, are there more models set to be main?");
						} else {
							mergeModel = iterModel;
							mainAlreadySet = true;
						}
					}
				}

				if (mergeModel == null) {
					throw new Exception(
							"ZFMSG:TESATK(E0051) No main file to which are other files imported was founded");
				}

				// remove merge model from the list loadedConfigurators, it doesn't include itself
				loadedConfigurators.remove(mergeModel);

				boolean modelImported = false;
				for(Configuration iterModel : loadedConfigurators){
					for(Imports importedModel : mergeModel.getImports()){
						String nameOfImportedFile = importedModel.getImportedNamespace().split("\\.")[0];
						if(iterModel.getConfigurationName().matches(nameOfImportedFile)){
							modelImported = true;
						}
					}
					if( (modelImported == false) && (iterModel != configuration) )
						configuration.eResource().getResourceSet().getResources().get(configuration.eResource().getResourceSet().getResources().indexOf(iterModel.eResource())).unload();

					modelImported = false;
				}
			}
		} catch (Exception e) {
			if(e.getMessage().isEmpty())
				throw new RuntimeException(e.getStackTrace().toString());
			else
				throw new RuntimeException(e.getMessage());
		}
	}



}
