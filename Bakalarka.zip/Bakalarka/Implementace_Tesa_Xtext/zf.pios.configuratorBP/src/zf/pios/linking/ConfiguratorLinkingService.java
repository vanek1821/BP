package zf.pios.linking;

import java.util.List;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.xtext.linking.impl.DefaultLinkingService;
import org.eclipse.xtext.linking.impl.IllegalNodeException;
import org.eclipse.xtext.linking.impl.LinkingHelper;
import org.eclipse.xtext.nodemodel.INode;
import org.eclipse.xtext.scoping.IScopeProvider;

import com.google.inject.Inject;
import com.google.inject.name.Named;

public class ConfiguratorLinkingService extends DefaultLinkingService {

	@Inject 
	LinkingHelper linkinghelper;

	
	public final static String NAMED_DELEGATE = "org.eclipse.xtext.scoping.impl.AbstractDeclarativeScopeProvider.delegate";	
	@Inject
	@Named(NAMED_DELEGATE)
	private IScopeProvider delegate;
	
	@Override
	public List<EObject> getLinkedObjects(EObject context, EReference ref, INode node)
			throws IllegalNodeException {		
     		return super.getLinkedObjects(context, ref, node);
	}
}
