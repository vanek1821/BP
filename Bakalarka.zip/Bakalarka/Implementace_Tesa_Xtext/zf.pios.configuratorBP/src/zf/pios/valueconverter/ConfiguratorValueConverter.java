package zf.pios.valueconverter;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.eclipse.xtext.AbstractElement;
import org.eclipse.xtext.AbstractRule;
import org.eclipse.xtext.Grammar;
import org.eclipse.xtext.IGrammarAccess;
import org.eclipse.xtext.common.services.DefaultTerminalConverters;
import org.eclipse.xtext.conversion.IValueConverter;
import org.eclipse.xtext.conversion.ValueConverter;
import org.eclipse.xtext.conversion.impl.QualifiedNameValueConverter;
import org.eclipse.xtext.impl.AlternativesImpl;
import org.eclipse.xtext.impl.AssignmentImpl;
import org.eclipse.xtext.impl.CrossReferenceImpl;
import org.eclipse.xtext.impl.EnumLiteralDeclarationImpl;
import org.eclipse.xtext.impl.GroupImpl;
import org.eclipse.xtext.impl.KeywordImpl;
import org.eclipse.xtext.impl.RuleCallImpl;
import org.eclipse.xtext.impl.UnorderedGroupImpl;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.google.inject.Inject;

public class ConfiguratorValueConverter extends DefaultTerminalConverters {

	//public static final String xmlFilePath = "C:\\Users\\z607884\\Z607884_tesa_feature_selector\\tesa\\tesaTK\\tools\\FeatureSelector\\file\\Grammar.xml";
	public static final String xmlFilePath = System.getenv("grammarFile");
	//public static final String xmlFilePath = "Grammar.xml";
	public static File xmlFile;// = new File(xmlFilePath);
	public static boolean generated = false;
	
	//Injecting IGrammarAccess
	@Inject
	private IGrammarAccess grammarAccess;
	
	@Inject
	private QualifiedNameValueConverter qnValueConverter;	
	
	@ValueConverter(rule = "QualifiedName")
	public IValueConverter<String> getQualifiedNameWithWildCard() {
		if(!generated) {
			if(xmlFilePath != null) {
				xmlFile = new File(xmlFilePath);
				printToXML(grammarAccess);
			}
			else {
				xmlFile = new File("Grammar.xml");
				printToXML(grammarAccess);
			}
			
		}
		return qnValueConverter;
	}
	/**
	 * Prints grammar elements to XML
	 * @param grammarAccess Interface to access grammar
	 */
	private void printToXML(IGrammarAccess grammarAccess) {
		//getting grammar
		Grammar grammar = grammarAccess.getGrammar();
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
			Document document = documentBuilder.newDocument();
			
			//root element of xml
			Element root = document.createElement("Grammar");
			document.appendChild(root);
			//Prints all rules to xml
			for (AbstractRule rule : grammar.getRules()) {
				//System.out.println(i++ + ": " + rule.getName());
				
				Element ruleElement = document.createElement("Rule");
				Attr attr = document.createAttribute("name");
				attr.setValue(rule.getName());
				ruleElement.setAttributeNode(attr);
				root.appendChild(ruleElement);	
				processType(rule.getAlternatives(), document, ruleElement);
				
			}
			
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(xmlFile);
            
            
            transformer.transform(domSource, streamResult);
            
            generated = true;
            //Desktop.getDesktop().open(xmlFile);
            System.out.println("XML GENERATED");
            System.out.println("File can be found in: " + xmlFile.getAbsolutePath());
		} catch (Exception e) {
			System.out.println("XML couldn't be generated. Possibly wrong file path");
		}
	}
	/**
	 * Processes element according to its type
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processType(AbstractElement element, Document document, Element lastXMLElement) {
		Class<? extends AbstractElement> cls = element.getClass();
		switch(cls.getSimpleName()) {
		case "KeywordImpl":
			processKeyword(element, document, lastXMLElement);
			break;
		case "AssignmentImpl":
			processAssignment(element, document, lastXMLElement);
			break;
		case "GroupImpl":
			processGroup(element, document, lastXMLElement);
			break;
		case "UnorderedGroupImpl":
			processUnorderedGroup(element, document, lastXMLElement);
			break;
		case "ActionImpl":
			processAction(element, document, lastXMLElement);
			break;
		case "RuleCallImpl":
			processRule(element, document, lastXMLElement);
			break;
		case "AlternativesImpl":
			processAlternatives(element, document, lastXMLElement);
			break;
		case "CrossReferenceImpl":
			processCrossReference(element, document, lastXMLElement);
			break;
		case "EnumLiteralDeclarationImpl":
			processEnumLiteral(element, document, lastXMLElement);
			break;
			
		}
	}
	/**
	 * Processing Keyword into xml
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processKeyword(AbstractElement element, Document document, Element lastXMLElement) {
		KeywordImpl feature = (KeywordImpl) element;
		Element xmlElement = document.createElement("Keyword");
		Attr attr = document.createAttribute("value");
		attr.setValue(feature.getValue());
		xmlElement.setAttributeNode(attr);
		lastXMLElement.appendChild(xmlElement);
	}
	/**
	 * Processing Assignment into xml
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processAssignment(AbstractElement element, Document document, Element lastXMLElement) {
		AssignmentImpl feature = (AssignmentImpl) element;
		
		Element xmlElement = document.createElement("Assignment");
		Attr attr = document.createAttribute("name");
		attr.setValue(feature.getFeature());
		xmlElement.setAttributeNode(attr);
		attr = document.createAttribute("cardinality");
		attr.setValue(feature.getCardinality());
		xmlElement.setAttributeNode(attr);
		lastXMLElement.appendChild(xmlElement);
		
		processType(feature.getTerminal(), document, xmlElement);
	}
	
	/**
	 * Processing Enum into xml
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processEnumLiteral(AbstractElement element, Document document, Element lastXMLElement) {
		EnumLiteralDeclarationImpl feature = (EnumLiteralDeclarationImpl) element;
		
		Element xmlElement = document.createElement("Enum");
		Attr attr = document.createAttribute("name");
		attr.setValue(feature.getEnumLiteral().getName());
		xmlElement.setAttributeNode(attr);
		attr = document.createAttribute("value");
		attr.setValue(feature.getLiteral().getValue());
		xmlElement.setAttributeNode(attr);
		lastXMLElement.appendChild(xmlElement);
	}
	/**
	 * Processing Group into xml
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processGroup(AbstractElement element, Document document, Element lastXMLElement) {
		GroupImpl feature = (GroupImpl) element;

		Element xmlElement = document.createElement("Group");
		Attr attr = document.createAttribute("cardinality");
		attr.setValue(feature.getCardinality());
		xmlElement.setAttributeNode(attr);
		lastXMLElement.appendChild(xmlElement);
		
		//process types for all elements of group
		for (AbstractElement ae : feature.getElements()) {
			processType(ae, document, xmlElement);
		}
	}
	
	/**
	 * Processing UnorderedGroup into xml
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processUnorderedGroup(AbstractElement element, Document document, Element lastXMLElement) {
		UnorderedGroupImpl feature = (UnorderedGroupImpl) element;
				
		Element xmlElement = document.createElement("Group");
		Attr attr = document.createAttribute("cardinality");
		attr.setValue(feature.getCardinality());
		xmlElement.setAttributeNode(attr);
		lastXMLElement.appendChild(xmlElement);
		
		//process types for all elements of group
		for (AbstractElement ae : feature.getElements()) {
			processType(ae, document, xmlElement);
		}
	}
	/**
	 * Processing Action into xml
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processAction(AbstractElement element, Document document, Element lastXMLElement) {
		//Actions are not relevant
	}
	/**
	 * Processing Rule into xml
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processRule(AbstractElement element, Document document, Element lastXMLElement) {
		RuleCallImpl feature = (RuleCallImpl) element;
				
		Element xmlElement = document.createElement("Parent");
		Attr attr = document.createAttribute("name");
		attr.setValue(feature.getRule().getName());
		xmlElement.setAttributeNode(attr);
		lastXMLElement.appendChild(xmlElement);	
	}
	/**
	 * Processing CrossReference into xml
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processCrossReference(AbstractElement element, Document document, Element lastXMLElement) {
		CrossReferenceImpl feature = (CrossReferenceImpl) element;
		
		Element xmlElement = document.createElement("Reference");
		Attr attr = document.createAttribute("name");
		attr.setValue(feature.getType().getClassifier().getName());
		xmlElement.setAttributeNode(attr);
		lastXMLElement.appendChild(xmlElement);	
		
		}
	/**
	 * Processing Alternatives into xml
	 * @param element element for printing
	 * @param document document for xml creation
	 * @param lastXMLElement last xmlElement examined
	 */
	private void processAlternatives(AbstractElement element, Document document, Element lastXMLElement) {
		AlternativesImpl feature = (AlternativesImpl) element;
				
		Attr attr = document.createAttribute("cardinality");
		attr.setValue("|");
		lastXMLElement.setAttributeNode(attr);
		
		for (AbstractElement ae : feature.getElements()) {
			processType(ae, document, lastXMLElement);
		}
	}	
}

