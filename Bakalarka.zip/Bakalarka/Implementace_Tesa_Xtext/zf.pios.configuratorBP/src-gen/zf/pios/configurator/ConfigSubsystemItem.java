/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Config Subsystem Item</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystemItem()
 * @model
 * @generated
 */
public interface ConfigSubsystemItem extends EObject
{
} // ConfigSubsystemItem
