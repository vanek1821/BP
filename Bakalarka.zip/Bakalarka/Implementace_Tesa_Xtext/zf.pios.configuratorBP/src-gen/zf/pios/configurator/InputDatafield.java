/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Datafield</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.InputDatafield#getSubSystem <em>Sub System</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputDatafield()
 * @model
 * @generated
 */
public interface InputDatafield extends Datafield
{
  /**
   * Returns the value of the '<em><b>Sub System</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Sub System</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Sub System</em>' reference.
   * @see #setSubSystem(InputDriverType)
   * @see zf.pios.configurator.ConfiguratorPackage#getInputDatafield_SubSystem()
   * @model
   * @generated
   */
  InputDriverType getSubSystem();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InputDatafield#getSubSystem <em>Sub System</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Sub System</em>' reference.
   * @see #getSubSystem()
   * @generated
   */
  void setSubSystem(InputDriverType value);

} // InputDatafield
