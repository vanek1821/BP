/**
 */
package zf.pios.configurator.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import zf.pios.configurator.ASAPMeasurment;
import zf.pios.configurator.AnalogDriver;
import zf.pios.configurator.CommonDriver;
import zf.pios.configurator.ConfigSubsystem;
import zf.pios.configurator.ConfigSubsystemInput;
import zf.pios.configurator.ConfigSubsystemItem;
import zf.pios.configurator.ConfigSubsystemOutput;
import zf.pios.configurator.Configuration;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.Datafield;
import zf.pios.configurator.DriverToECU;
import zf.pios.configurator.ElDiag;
import zf.pios.configurator.ElectricDiagSubsystem;
import zf.pios.configurator.FRQSubsystem;
import zf.pios.configurator.FrequencySubsystem;
import zf.pios.configurator.GeneralSignal;
import zf.pios.configurator.GeneralSignals;
import zf.pios.configurator.GenericSubsystem;
import zf.pios.configurator.Hardware;
import zf.pios.configurator.IADC;
import zf.pios.configurator.IFRQ;
import zf.pios.configurator.IFRQSensor;
import zf.pios.configurator.Import;
import zf.pios.configurator.Imports;
import zf.pios.configurator.InDigDriver;
import zf.pios.configurator.InDigitalDriverTableRef;
import zf.pios.configurator.InputAnalogDrivers;
import zf.pios.configurator.InputConfigSubsystemAnalog;
import zf.pios.configurator.InputConfigSubsystemDigital;
import zf.pios.configurator.InputConfigSubsystemFrq;
import zf.pios.configurator.InputConfigSubsystemItem;
import zf.pios.configurator.InputConfigSubsystemNull;
import zf.pios.configurator.InputConfigSubsystemSPI;
import zf.pios.configurator.InputConfigSubsystemTemperature;
import zf.pios.configurator.InputDatafield;
import zf.pios.configurator.InputDigDriversTable;
import zf.pios.configurator.InputDigitalDrivers;
import zf.pios.configurator.InputDriverType;
import zf.pios.configurator.InputSignal;
import zf.pios.configurator.InputSubsystems;
import zf.pios.configurator.OPWM;
import zf.pios.configurator.OPWMSubsystem;
import zf.pios.configurator.OutDigDriver;
import zf.pios.configurator.OutDigitalDriverTableRef;
import zf.pios.configurator.OutputConfigSubsystemDigital;
import zf.pios.configurator.OutputConfigSubsystemElDiag;
import zf.pios.configurator.OutputConfigSubsystemItem;
import zf.pios.configurator.OutputConfigSubsystemNull;
import zf.pios.configurator.OutputConfigSubsystemPWM;
import zf.pios.configurator.OutputDatafield;
import zf.pios.configurator.OutputDigDriversTable;
import zf.pios.configurator.OutputDigitalDrivers;
import zf.pios.configurator.OutputDriverType;
import zf.pios.configurator.OutputSignal;
import zf.pios.configurator.OutputSubsystems;
import zf.pios.configurator.Portname;
import zf.pios.configurator.SPI;
import zf.pios.configurator.SPITXData;
import zf.pios.configurator.SPIinputSys;
import zf.pios.configurator.Signal;
import zf.pios.configurator.Signals;
import zf.pios.configurator.TempSensorSubsystem;
import zf.pios.configurator.UserDefinedSubsystem;
import zf.pios.configurator.UserPort;
import zf.pios.configurator.Variant;
import zf.pios.configurator.Variants;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see zf.pios.configurator.ConfiguratorPackage
 * @generated
 */
public class ConfiguratorAdapterFactory extends AdapterFactoryImpl
{
  /**
   * The cached model package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static ConfiguratorPackage modelPackage;

  /**
   * Creates an instance of the adapter factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfiguratorAdapterFactory()
  {
    if (modelPackage == null)
    {
      modelPackage = ConfiguratorPackage.eINSTANCE;
    }
  }

  /**
   * Returns whether this factory is applicable for the type of the object.
   * <!-- begin-user-doc -->
   * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
   * <!-- end-user-doc -->
   * @return whether this factory is applicable for the type of the object.
   * @generated
   */
  @Override
  public boolean isFactoryForType(Object object)
  {
    if (object == modelPackage)
    {
      return true;
    }
    if (object instanceof EObject)
    {
      return ((EObject)object).eClass().getEPackage() == modelPackage;
    }
    return false;
  }

  /**
   * The switch that delegates to the <code>createXXX</code> methods.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ConfiguratorSwitch<Adapter> modelSwitch =
    new ConfiguratorSwitch<Adapter>()
    {
      @Override
      public Adapter caseConfiguration(Configuration object)
      {
        return createConfigurationAdapter();
      }
      @Override
      public Adapter caseSystem(zf.pios.configurator.System object)
      {
        return createSystemAdapter();
      }
      @Override
      public Adapter caseSignals(Signals object)
      {
        return createSignalsAdapter();
      }
      @Override
      public Adapter caseGeneralSignals(GeneralSignals object)
      {
        return createGeneralSignalsAdapter();
      }
      @Override
      public Adapter caseGeneralSignal(GeneralSignal object)
      {
        return createGeneralSignalAdapter();
      }
      @Override
      public Adapter caseInputSignal(InputSignal object)
      {
        return createInputSignalAdapter();
      }
      @Override
      public Adapter caseOutputSignal(OutputSignal object)
      {
        return createOutputSignalAdapter();
      }
      @Override
      public Adapter caseDatafield(Datafield object)
      {
        return createDatafieldAdapter();
      }
      @Override
      public Adapter caseInputDatafield(InputDatafield object)
      {
        return createInputDatafieldAdapter();
      }
      @Override
      public Adapter caseOutputDatafield(OutputDatafield object)
      {
        return createOutputDatafieldAdapter();
      }
      @Override
      public Adapter casePortname(Portname object)
      {
        return createPortnameAdapter();
      }
      @Override
      public Adapter caseVariants(Variants object)
      {
        return createVariantsAdapter();
      }
      @Override
      public Adapter caseVariant(Variant object)
      {
        return createVariantAdapter();
      }
      @Override
      public Adapter caseSignal(Signal object)
      {
        return createSignalAdapter();
      }
      @Override
      public Adapter caseASAPMeasurment(ASAPMeasurment object)
      {
        return createASAPMeasurmentAdapter();
      }
      @Override
      public Adapter caseHardware(Hardware object)
      {
        return createHardwareAdapter();
      }
      @Override
      public Adapter caseConfigSubsystem(ConfigSubsystem object)
      {
        return createConfigSubsystemAdapter();
      }
      @Override
      public Adapter caseConfigSubsystemInput(ConfigSubsystemInput object)
      {
        return createConfigSubsystemInputAdapter();
      }
      @Override
      public Adapter caseConfigSubsystemOutput(ConfigSubsystemOutput object)
      {
        return createConfigSubsystemOutputAdapter();
      }
      @Override
      public Adapter caseInputSubsystems(InputSubsystems object)
      {
        return createInputSubsystemsAdapter();
      }
      @Override
      public Adapter caseOutputSubsystems(OutputSubsystems object)
      {
        return createOutputSubsystemsAdapter();
      }
      @Override
      public Adapter caseInputConfigSubsystemNull(InputConfigSubsystemNull object)
      {
        return createInputConfigSubsystemNullAdapter();
      }
      @Override
      public Adapter caseOutputConfigSubsystemNull(OutputConfigSubsystemNull object)
      {
        return createOutputConfigSubsystemNullAdapter();
      }
      @Override
      public Adapter caseGenericSubsystem(GenericSubsystem object)
      {
        return createGenericSubsystemAdapter();
      }
      @Override
      public Adapter caseInputDriverType(InputDriverType object)
      {
        return createInputDriverTypeAdapter();
      }
      @Override
      public Adapter caseOutputDriverType(OutputDriverType object)
      {
        return createOutputDriverTypeAdapter();
      }
      @Override
      public Adapter caseInputConfigSubsystemAnalog(InputConfigSubsystemAnalog object)
      {
        return createInputConfigSubsystemAnalogAdapter();
      }
      @Override
      public Adapter caseInputConfigSubsystemTemperature(InputConfigSubsystemTemperature object)
      {
        return createInputConfigSubsystemTemperatureAdapter();
      }
      @Override
      public Adapter caseOutputConfigSubsystemElDiag(OutputConfigSubsystemElDiag object)
      {
        return createOutputConfigSubsystemElDiagAdapter();
      }
      @Override
      public Adapter caseInputConfigSubsystemSPI(InputConfigSubsystemSPI object)
      {
        return createInputConfigSubsystemSPIAdapter();
      }
      @Override
      public Adapter caseInputConfigSubsystemDigital(InputConfigSubsystemDigital object)
      {
        return createInputConfigSubsystemDigitalAdapter();
      }
      @Override
      public Adapter caseInputConfigSubsystemFrq(InputConfigSubsystemFrq object)
      {
        return createInputConfigSubsystemFrqAdapter();
      }
      @Override
      public Adapter caseOutputConfigSubsystemPWM(OutputConfigSubsystemPWM object)
      {
        return createOutputConfigSubsystemPWMAdapter();
      }
      @Override
      public Adapter caseOutputConfigSubsystemDigital(OutputConfigSubsystemDigital object)
      {
        return createOutputConfigSubsystemDigitalAdapter();
      }
      @Override
      public Adapter caseInputConfigSubsystemItem(InputConfigSubsystemItem object)
      {
        return createInputConfigSubsystemItemAdapter();
      }
      @Override
      public Adapter caseOutputConfigSubsystemItem(OutputConfigSubsystemItem object)
      {
        return createOutputConfigSubsystemItemAdapter();
      }
      @Override
      public Adapter caseDriverToECU(DriverToECU object)
      {
        return createDriverToECUAdapter();
      }
      @Override
      public Adapter caseTempSensorSubsystem(TempSensorSubsystem object)
      {
        return createTempSensorSubsystemAdapter();
      }
      @Override
      public Adapter caseInputAnalogDrivers(InputAnalogDrivers object)
      {
        return createInputAnalogDriversAdapter();
      }
      @Override
      public Adapter caseInputDigitalDrivers(InputDigitalDrivers object)
      {
        return createInputDigitalDriversAdapter();
      }
      @Override
      public Adapter caseOutputDigitalDrivers(OutputDigitalDrivers object)
      {
        return createOutputDigitalDriversAdapter();
      }
      @Override
      public Adapter caseAnalogDriver(AnalogDriver object)
      {
        return createAnalogDriverAdapter();
      }
      @Override
      public Adapter caseInDigDriver(InDigDriver object)
      {
        return createInDigDriverAdapter();
      }
      @Override
      public Adapter caseOutDigDriver(OutDigDriver object)
      {
        return createOutDigDriverAdapter();
      }
      @Override
      public Adapter caseCommonDriver(CommonDriver object)
      {
        return createCommonDriverAdapter();
      }
      @Override
      public Adapter caseInputDigDriversTable(InputDigDriversTable object)
      {
        return createInputDigDriversTableAdapter();
      }
      @Override
      public Adapter caseOutputDigDriversTable(OutputDigDriversTable object)
      {
        return createOutputDigDriversTableAdapter();
      }
      @Override
      public Adapter caseInDigitalDriverTableRef(InDigitalDriverTableRef object)
      {
        return createInDigitalDriverTableRefAdapter();
      }
      @Override
      public Adapter caseOutDigitalDriverTableRef(OutDigitalDriverTableRef object)
      {
        return createOutDigitalDriverTableRefAdapter();
      }
      @Override
      public Adapter caseElectricDiagSubsystem(ElectricDiagSubsystem object)
      {
        return createElectricDiagSubsystemAdapter();
      }
      @Override
      public Adapter caseElDiag(ElDiag object)
      {
        return createElDiagAdapter();
      }
      @Override
      public Adapter caseFrequencySubsystem(FrequencySubsystem object)
      {
        return createFrequencySubsystemAdapter();
      }
      @Override
      public Adapter caseIFRQ(IFRQ object)
      {
        return createIFRQAdapter();
      }
      @Override
      public Adapter caseIFRQSensor(IFRQSensor object)
      {
        return createIFRQSensorAdapter();
      }
      @Override
      public Adapter caseSPIinputSys(SPIinputSys object)
      {
        return createSPIinputSysAdapter();
      }
      @Override
      public Adapter caseSPI(SPI object)
      {
        return createSPIAdapter();
      }
      @Override
      public Adapter caseSPITXData(SPITXData object)
      {
        return createSPITXDataAdapter();
      }
      @Override
      public Adapter caseOPWMSubsystem(OPWMSubsystem object)
      {
        return createOPWMSubsystemAdapter();
      }
      @Override
      public Adapter caseOPWM(OPWM object)
      {
        return createOPWMAdapter();
      }
      @Override
      public Adapter caseIADC(IADC object)
      {
        return createIADCAdapter();
      }
      @Override
      public Adapter caseUserDefinedSubsystem(UserDefinedSubsystem object)
      {
        return createUserDefinedSubsystemAdapter();
      }
      @Override
      public Adapter caseConfigSubsystemItem(ConfigSubsystemItem object)
      {
        return createConfigSubsystemItemAdapter();
      }
      @Override
      public Adapter caseUserPort(UserPort object)
      {
        return createUserPortAdapter();
      }
      @Override
      public Adapter caseImport(Import object)
      {
        return createImportAdapter();
      }
      @Override
      public Adapter caseImports(Imports object)
      {
        return createImportsAdapter();
      }
      @Override
      public Adapter caseFRQSubsystem(FRQSubsystem object)
      {
        return createFRQSubsystemAdapter();
      }
      @Override
      public Adapter defaultCase(EObject object)
      {
        return createEObjectAdapter();
      }
    };

  /**
   * Creates an adapter for the <code>target</code>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param target the object to adapt.
   * @return the adapter for the <code>target</code>.
   * @generated
   */
  @Override
  public Adapter createAdapter(Notifier target)
  {
    return modelSwitch.doSwitch((EObject)target);
  }


  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Configuration <em>Configuration</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Configuration
   * @generated
   */
  public Adapter createConfigurationAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.System <em>System</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.System
   * @generated
   */
  public Adapter createSystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Signals <em>Signals</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Signals
   * @generated
   */
  public Adapter createSignalsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.GeneralSignals <em>General Signals</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.GeneralSignals
   * @generated
   */
  public Adapter createGeneralSignalsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.GeneralSignal <em>General Signal</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.GeneralSignal
   * @generated
   */
  public Adapter createGeneralSignalAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputSignal <em>Input Signal</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputSignal
   * @generated
   */
  public Adapter createInputSignalAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputSignal <em>Output Signal</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputSignal
   * @generated
   */
  public Adapter createOutputSignalAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Datafield <em>Datafield</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Datafield
   * @generated
   */
  public Adapter createDatafieldAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputDatafield <em>Input Datafield</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputDatafield
   * @generated
   */
  public Adapter createInputDatafieldAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputDatafield <em>Output Datafield</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputDatafield
   * @generated
   */
  public Adapter createOutputDatafieldAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Portname <em>Portname</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Portname
   * @generated
   */
  public Adapter createPortnameAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Variants <em>Variants</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Variants
   * @generated
   */
  public Adapter createVariantsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Variant <em>Variant</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Variant
   * @generated
   */
  public Adapter createVariantAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Signal <em>Signal</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Signal
   * @generated
   */
  public Adapter createSignalAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.ASAPMeasurment <em>ASAP Measurment</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.ASAPMeasurment
   * @generated
   */
  public Adapter createASAPMeasurmentAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Hardware <em>Hardware</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Hardware
   * @generated
   */
  public Adapter createHardwareAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.ConfigSubsystem <em>Config Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.ConfigSubsystem
   * @generated
   */
  public Adapter createConfigSubsystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.ConfigSubsystemInput <em>Config Subsystem Input</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.ConfigSubsystemInput
   * @generated
   */
  public Adapter createConfigSubsystemInputAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.ConfigSubsystemOutput <em>Config Subsystem Output</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.ConfigSubsystemOutput
   * @generated
   */
  public Adapter createConfigSubsystemOutputAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputSubsystems <em>Input Subsystems</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputSubsystems
   * @generated
   */
  public Adapter createInputSubsystemsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputSubsystems <em>Output Subsystems</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputSubsystems
   * @generated
   */
  public Adapter createOutputSubsystemsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputConfigSubsystemNull <em>Input Config Subsystem Null</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputConfigSubsystemNull
   * @generated
   */
  public Adapter createInputConfigSubsystemNullAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputConfigSubsystemNull <em>Output Config Subsystem Null</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputConfigSubsystemNull
   * @generated
   */
  public Adapter createOutputConfigSubsystemNullAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.GenericSubsystem <em>Generic Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.GenericSubsystem
   * @generated
   */
  public Adapter createGenericSubsystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputDriverType <em>Input Driver Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputDriverType
   * @generated
   */
  public Adapter createInputDriverTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputDriverType <em>Output Driver Type</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputDriverType
   * @generated
   */
  public Adapter createOutputDriverTypeAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputConfigSubsystemAnalog <em>Input Config Subsystem Analog</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputConfigSubsystemAnalog
   * @generated
   */
  public Adapter createInputConfigSubsystemAnalogAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputConfigSubsystemTemperature <em>Input Config Subsystem Temperature</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputConfigSubsystemTemperature
   * @generated
   */
  public Adapter createInputConfigSubsystemTemperatureAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputConfigSubsystemElDiag <em>Output Config Subsystem El Diag</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputConfigSubsystemElDiag
   * @generated
   */
  public Adapter createOutputConfigSubsystemElDiagAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputConfigSubsystemSPI <em>Input Config Subsystem SPI</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputConfigSubsystemSPI
   * @generated
   */
  public Adapter createInputConfigSubsystemSPIAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputConfigSubsystemDigital <em>Input Config Subsystem Digital</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputConfigSubsystemDigital
   * @generated
   */
  public Adapter createInputConfigSubsystemDigitalAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputConfigSubsystemFrq <em>Input Config Subsystem Frq</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputConfigSubsystemFrq
   * @generated
   */
  public Adapter createInputConfigSubsystemFrqAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputConfigSubsystemPWM <em>Output Config Subsystem PWM</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputConfigSubsystemPWM
   * @generated
   */
  public Adapter createOutputConfigSubsystemPWMAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputConfigSubsystemDigital <em>Output Config Subsystem Digital</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputConfigSubsystemDigital
   * @generated
   */
  public Adapter createOutputConfigSubsystemDigitalAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputConfigSubsystemItem <em>Input Config Subsystem Item</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputConfigSubsystemItem
   * @generated
   */
  public Adapter createInputConfigSubsystemItemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputConfigSubsystemItem <em>Output Config Subsystem Item</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputConfigSubsystemItem
   * @generated
   */
  public Adapter createOutputConfigSubsystemItemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.DriverToECU <em>Driver To ECU</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.DriverToECU
   * @generated
   */
  public Adapter createDriverToECUAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.TempSensorSubsystem <em>Temp Sensor Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.TempSensorSubsystem
   * @generated
   */
  public Adapter createTempSensorSubsystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputAnalogDrivers <em>Input Analog Drivers</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputAnalogDrivers
   * @generated
   */
  public Adapter createInputAnalogDriversAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputDigitalDrivers <em>Input Digital Drivers</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputDigitalDrivers
   * @generated
   */
  public Adapter createInputDigitalDriversAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputDigitalDrivers <em>Output Digital Drivers</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputDigitalDrivers
   * @generated
   */
  public Adapter createOutputDigitalDriversAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.AnalogDriver <em>Analog Driver</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.AnalogDriver
   * @generated
   */
  public Adapter createAnalogDriverAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InDigDriver <em>In Dig Driver</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InDigDriver
   * @generated
   */
  public Adapter createInDigDriverAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutDigDriver <em>Out Dig Driver</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutDigDriver
   * @generated
   */
  public Adapter createOutDigDriverAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.CommonDriver <em>Common Driver</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.CommonDriver
   * @generated
   */
  public Adapter createCommonDriverAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InputDigDriversTable <em>Input Dig Drivers Table</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InputDigDriversTable
   * @generated
   */
  public Adapter createInputDigDriversTableAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutputDigDriversTable <em>Output Dig Drivers Table</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutputDigDriversTable
   * @generated
   */
  public Adapter createOutputDigDriversTableAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.InDigitalDriverTableRef <em>In Digital Driver Table Ref</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.InDigitalDriverTableRef
   * @generated
   */
  public Adapter createInDigitalDriverTableRefAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OutDigitalDriverTableRef <em>Out Digital Driver Table Ref</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OutDigitalDriverTableRef
   * @generated
   */
  public Adapter createOutDigitalDriverTableRefAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.ElectricDiagSubsystem <em>Electric Diag Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.ElectricDiagSubsystem
   * @generated
   */
  public Adapter createElectricDiagSubsystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.ElDiag <em>El Diag</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.ElDiag
   * @generated
   */
  public Adapter createElDiagAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.FrequencySubsystem <em>Frequency Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.FrequencySubsystem
   * @generated
   */
  public Adapter createFrequencySubsystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.IFRQ <em>IFRQ</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.IFRQ
   * @generated
   */
  public Adapter createIFRQAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.IFRQSensor <em>IFRQ Sensor</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.IFRQSensor
   * @generated
   */
  public Adapter createIFRQSensorAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.SPIinputSys <em>SP Iinput Sys</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.SPIinputSys
   * @generated
   */
  public Adapter createSPIinputSysAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.SPI <em>SPI</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.SPI
   * @generated
   */
  public Adapter createSPIAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.SPITXData <em>SPITX Data</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.SPITXData
   * @generated
   */
  public Adapter createSPITXDataAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OPWMSubsystem <em>OPWM Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OPWMSubsystem
   * @generated
   */
  public Adapter createOPWMSubsystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.OPWM <em>OPWM</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.OPWM
   * @generated
   */
  public Adapter createOPWMAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.IADC <em>IADC</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.IADC
   * @generated
   */
  public Adapter createIADCAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.UserDefinedSubsystem <em>User Defined Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.UserDefinedSubsystem
   * @generated
   */
  public Adapter createUserDefinedSubsystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.ConfigSubsystemItem <em>Config Subsystem Item</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.ConfigSubsystemItem
   * @generated
   */
  public Adapter createConfigSubsystemItemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.UserPort <em>User Port</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.UserPort
   * @generated
   */
  public Adapter createUserPortAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Import <em>Import</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Import
   * @generated
   */
  public Adapter createImportAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.Imports <em>Imports</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.Imports
   * @generated
   */
  public Adapter createImportsAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for an object of class '{@link zf.pios.configurator.FRQSubsystem <em>FRQ Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * This default implementation returns null so that we can easily ignore cases;
   * it's useful to ignore a case when inheritance will catch all the cases anyway.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @see zf.pios.configurator.FRQSubsystem
   * @generated
   */
  public Adapter createFRQSubsystemAdapter()
  {
    return null;
  }

  /**
   * Creates a new adapter for the default case.
   * <!-- begin-user-doc -->
   * This default implementation returns null.
   * <!-- end-user-doc -->
   * @return the new adapter.
   * @generated
   */
  public Adapter createEObjectAdapter()
  {
    return null;
  }

} //ConfiguratorAdapterFactory
