/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IADC</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.IADC#getDriverIndex <em>Driver Index</em>}</li>
 *   <li>{@link zf.pios.configurator.IADC#getEnable <em>Enable</em>}</li>
 *   <li>{@link zf.pios.configurator.IADC#getPowerSupplySignal <em>Power Supply Signal</em>}</li>
 *   <li>{@link zf.pios.configurator.IADC#getEnableElDiagPowerSupplyOff <em>Enable El Diag Power Supply Off</em>}</li>
 *   <li>{@link zf.pios.configurator.IADC#getElDiagInstanceIdx <em>El Diag Instance Idx</em>}</li>
 *   <li>{@link zf.pios.configurator.IADC#getControllerPinName <em>Controller Pin Name</em>}</li>
 *   <li>{@link zf.pios.configurator.IADC#getDescription <em>Description</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getIADC()
 * @model
 * @generated
 */
public interface IADC extends EObject
{
  /**
   * Returns the value of the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Driver Index</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Driver Index</em>' attribute.
   * @see #setDriverIndex(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIADC_DriverIndex()
   * @model
   * @generated
   */
  String getDriverIndex();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IADC#getDriverIndex <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Driver Index</em>' attribute.
   * @see #getDriverIndex()
   * @generated
   */
  void setDriverIndex(String value);

  /**
   * Returns the value of the '<em><b>Enable</b></em>' attribute.
   * The literals are from the enumeration {@link zf.pios.configurator.iadcEnableEnumeration}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Enable</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Enable</em>' attribute.
   * @see zf.pios.configurator.iadcEnableEnumeration
   * @see #setEnable(iadcEnableEnumeration)
   * @see zf.pios.configurator.ConfiguratorPackage#getIADC_Enable()
   * @model
   * @generated
   */
  iadcEnableEnumeration getEnable();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IADC#getEnable <em>Enable</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Enable</em>' attribute.
   * @see zf.pios.configurator.iadcEnableEnumeration
   * @see #getEnable()
   * @generated
   */
  void setEnable(iadcEnableEnumeration value);

  /**
   * Returns the value of the '<em><b>Power Supply Signal</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Power Supply Signal</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Power Supply Signal</em>' reference.
   * @see #setPowerSupplySignal(InputSignal)
   * @see zf.pios.configurator.ConfiguratorPackage#getIADC_PowerSupplySignal()
   * @model
   * @generated
   */
  InputSignal getPowerSupplySignal();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IADC#getPowerSupplySignal <em>Power Supply Signal</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Power Supply Signal</em>' reference.
   * @see #getPowerSupplySignal()
   * @generated
   */
  void setPowerSupplySignal(InputSignal value);

  /**
   * Returns the value of the '<em><b>Enable El Diag Power Supply Off</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Enable El Diag Power Supply Off</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Enable El Diag Power Supply Off</em>' attribute.
   * @see #setEnableElDiagPowerSupplyOff(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIADC_EnableElDiagPowerSupplyOff()
   * @model
   * @generated
   */
  String getEnableElDiagPowerSupplyOff();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IADC#getEnableElDiagPowerSupplyOff <em>Enable El Diag Power Supply Off</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Enable El Diag Power Supply Off</em>' attribute.
   * @see #getEnableElDiagPowerSupplyOff()
   * @generated
   */
  void setEnableElDiagPowerSupplyOff(String value);

  /**
   * Returns the value of the '<em><b>El Diag Instance Idx</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>El Diag Instance Idx</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>El Diag Instance Idx</em>' attribute.
   * @see #setElDiagInstanceIdx(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIADC_ElDiagInstanceIdx()
   * @model
   * @generated
   */
  String getElDiagInstanceIdx();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IADC#getElDiagInstanceIdx <em>El Diag Instance Idx</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>El Diag Instance Idx</em>' attribute.
   * @see #getElDiagInstanceIdx()
   * @generated
   */
  void setElDiagInstanceIdx(String value);

  /**
   * Returns the value of the '<em><b>Controller Pin Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Controller Pin Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Controller Pin Name</em>' attribute.
   * @see #setControllerPinName(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIADC_ControllerPinName()
   * @model
   * @generated
   */
  String getControllerPinName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IADC#getControllerPinName <em>Controller Pin Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Controller Pin Name</em>' attribute.
   * @see #getControllerPinName()
   * @generated
   */
  void setControllerPinName(String value);

  /**
   * Returns the value of the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Description</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Description</em>' attribute.
   * @see #setDescription(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIADC_Description()
   * @model
   * @generated
   */
  String getDescription();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IADC#getDescription <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Description</em>' attribute.
   * @see #getDescription()
   * @generated
   */
  void setDescription(String value);

} // IADC
