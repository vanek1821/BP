/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfigSubsystem;
import zf.pios.configurator.ConfiguratorPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.SystemImpl#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SystemImpl#getConfigSubsystem <em>Config Subsystem</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SystemImpl extends MinimalEObjectImpl.Container implements zf.pios.configurator.System
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getConfigSubsystem() <em>Config Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConfigSubsystem()
   * @generated
   * @ordered
   */
  protected ConfigSubsystem configSubsystem;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SystemImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.SYSTEM;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SYSTEM__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigSubsystem getConfigSubsystem()
  {
    return configSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetConfigSubsystem(ConfigSubsystem newConfigSubsystem, NotificationChain msgs)
  {
    ConfigSubsystem oldConfigSubsystem = configSubsystem;
    configSubsystem = newConfigSubsystem;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SYSTEM__CONFIG_SUBSYSTEM, oldConfigSubsystem, newConfigSubsystem);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setConfigSubsystem(ConfigSubsystem newConfigSubsystem)
  {
    if (newConfigSubsystem != configSubsystem)
    {
      NotificationChain msgs = null;
      if (configSubsystem != null)
        msgs = ((InternalEObject)configSubsystem).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.SYSTEM__CONFIG_SUBSYSTEM, null, msgs);
      if (newConfigSubsystem != null)
        msgs = ((InternalEObject)newConfigSubsystem).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.SYSTEM__CONFIG_SUBSYSTEM, null, msgs);
      msgs = basicSetConfigSubsystem(newConfigSubsystem, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SYSTEM__CONFIG_SUBSYSTEM, newConfigSubsystem, newConfigSubsystem));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SYSTEM__CONFIG_SUBSYSTEM:
        return basicSetConfigSubsystem(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SYSTEM__NAME:
        return getName();
      case ConfiguratorPackage.SYSTEM__CONFIG_SUBSYSTEM:
        return getConfigSubsystem();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SYSTEM__NAME:
        setName((String)newValue);
        return;
      case ConfiguratorPackage.SYSTEM__CONFIG_SUBSYSTEM:
        setConfigSubsystem((ConfigSubsystem)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SYSTEM__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.SYSTEM__CONFIG_SUBSYSTEM:
        setConfigSubsystem((ConfigSubsystem)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SYSTEM__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ConfiguratorPackage.SYSTEM__CONFIG_SUBSYSTEM:
        return configSubsystem != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(')');
    return result.toString();
  }

} //SystemImpl
