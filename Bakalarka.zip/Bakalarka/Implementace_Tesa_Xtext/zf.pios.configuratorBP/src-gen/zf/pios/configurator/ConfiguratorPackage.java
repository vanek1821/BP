/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see zf.pios.configurator.ConfiguratorFactory
 * @model kind="package"
 * @generated
 */
public interface ConfiguratorPackage extends EPackage
{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "configurator";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.pios.zf/Configurator";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "configurator";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  ConfiguratorPackage eINSTANCE = zf.pios.configurator.impl.ConfiguratorPackageImpl.init();

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ConfigurationImpl <em>Configuration</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ConfigurationImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfiguration()
   * @generated
   */
  int CONFIGURATION = 0;

  /**
   * The feature id for the '<em><b>Configuration Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIGURATION__CONFIGURATION_NAME = 0;

  /**
   * The feature id for the '<em><b>Version</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIGURATION__VERSION = 1;

  /**
   * The feature id for the '<em><b>Main Merge File</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIGURATION__MAIN_MERGE_FILE = 2;

  /**
   * The feature id for the '<em><b>Imports</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIGURATION__IMPORTS = 3;

  /**
   * The feature id for the '<em><b>Variants</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIGURATION__VARIANTS = 4;

  /**
   * The feature id for the '<em><b>System</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIGURATION__SYSTEM = 5;

  /**
   * The feature id for the '<em><b>Hardware</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIGURATION__HARDWARE = 6;

  /**
   * The feature id for the '<em><b>Signals</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIGURATION__SIGNALS = 7;

  /**
   * The number of structural features of the '<em>Configuration</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIGURATION_FEATURE_COUNT = 8;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.SystemImpl <em>System</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.SystemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSystem()
   * @generated
   */
  int SYSTEM = 1;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SYSTEM__NAME = 0;

  /**
   * The feature id for the '<em><b>Config Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SYSTEM__CONFIG_SUBSYSTEM = 1;

  /**
   * The number of structural features of the '<em>System</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SYSTEM_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.SignalsImpl <em>Signals</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.SignalsImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSignals()
   * @generated
   */
  int SIGNALS = 2;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIGNALS__NAME = 0;

  /**
   * The feature id for the '<em><b>Pios Signals</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIGNALS__PIOS_SIGNALS = 1;

  /**
   * The number of structural features of the '<em>Signals</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIGNALS_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.GeneralSignalsImpl <em>General Signals</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.GeneralSignalsImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getGeneralSignals()
   * @generated
   */
  int GENERAL_SIGNALS = 3;

  /**
   * The feature id for the '<em><b>General Signal</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GENERAL_SIGNALS__GENERAL_SIGNAL = 0;

  /**
   * The number of structural features of the '<em>General Signals</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GENERAL_SIGNALS_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.GeneralSignalImpl <em>General Signal</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.GeneralSignalImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getGeneralSignal()
   * @generated
   */
  int GENERAL_SIGNAL = 4;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GENERAL_SIGNAL__NAME = 0;

  /**
   * The feature id for the '<em><b>Signal</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GENERAL_SIGNAL__SIGNAL = 1;

  /**
   * The number of structural features of the '<em>General Signal</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GENERAL_SIGNAL_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputSignalImpl <em>Input Signal</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputSignalImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputSignal()
   * @generated
   */
  int INPUT_SIGNAL = 5;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SIGNAL__NAME = GENERAL_SIGNAL__NAME;

  /**
   * The feature id for the '<em><b>Signal</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SIGNAL__SIGNAL = GENERAL_SIGNAL__SIGNAL;

  /**
   * The feature id for the '<em><b>Power Supply</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SIGNAL__POWER_SUPPLY = GENERAL_SIGNAL_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Datafield</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SIGNAL__DATAFIELD = GENERAL_SIGNAL_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>Input Signal</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SIGNAL_FEATURE_COUNT = GENERAL_SIGNAL_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputSignalImpl <em>Output Signal</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputSignalImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputSignal()
   * @generated
   */
  int OUTPUT_SIGNAL = 6;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SIGNAL__NAME = GENERAL_SIGNAL__NAME;

  /**
   * The feature id for the '<em><b>Signal</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SIGNAL__SIGNAL = GENERAL_SIGNAL__SIGNAL;

  /**
   * The feature id for the '<em><b>Pull Up Resistor Signal</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SIGNAL__PULL_UP_RESISTOR_SIGNAL = GENERAL_SIGNAL_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Datafield</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SIGNAL__DATAFIELD = GENERAL_SIGNAL_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>Output Signal</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SIGNAL_FEATURE_COUNT = GENERAL_SIGNAL_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.DatafieldImpl <em>Datafield</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.DatafieldImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getDatafield()
   * @generated
   */
  int DATAFIELD = 7;

  /**
   * The feature id for the '<em><b>Variant Name</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DATAFIELD__VARIANT_NAME = 0;

  /**
   * The feature id for the '<em><b>Lower Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DATAFIELD__LOWER_LIMIT = 1;

  /**
   * The feature id for the '<em><b>Upper Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DATAFIELD__UPPER_LIMIT = 2;

  /**
   * The feature id for the '<em><b>Init Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DATAFIELD__INIT_VALUE = 3;

  /**
   * The feature id for the '<em><b>Portname</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DATAFIELD__PORTNAME = 4;

  /**
   * The number of structural features of the '<em>Datafield</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DATAFIELD_FEATURE_COUNT = 5;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputDatafieldImpl <em>Input Datafield</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputDatafieldImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputDatafield()
   * @generated
   */
  int INPUT_DATAFIELD = 8;

  /**
   * The feature id for the '<em><b>Variant Name</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DATAFIELD__VARIANT_NAME = DATAFIELD__VARIANT_NAME;

  /**
   * The feature id for the '<em><b>Lower Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DATAFIELD__LOWER_LIMIT = DATAFIELD__LOWER_LIMIT;

  /**
   * The feature id for the '<em><b>Upper Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DATAFIELD__UPPER_LIMIT = DATAFIELD__UPPER_LIMIT;

  /**
   * The feature id for the '<em><b>Init Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DATAFIELD__INIT_VALUE = DATAFIELD__INIT_VALUE;

  /**
   * The feature id for the '<em><b>Portname</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DATAFIELD__PORTNAME = DATAFIELD__PORTNAME;

  /**
   * The feature id for the '<em><b>Sub System</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DATAFIELD__SUB_SYSTEM = DATAFIELD_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Input Datafield</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DATAFIELD_FEATURE_COUNT = DATAFIELD_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputDatafieldImpl <em>Output Datafield</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputDatafieldImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputDatafield()
   * @generated
   */
  int OUTPUT_DATAFIELD = 9;

  /**
   * The feature id for the '<em><b>Variant Name</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DATAFIELD__VARIANT_NAME = DATAFIELD__VARIANT_NAME;

  /**
   * The feature id for the '<em><b>Lower Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DATAFIELD__LOWER_LIMIT = DATAFIELD__LOWER_LIMIT;

  /**
   * The feature id for the '<em><b>Upper Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DATAFIELD__UPPER_LIMIT = DATAFIELD__UPPER_LIMIT;

  /**
   * The feature id for the '<em><b>Init Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DATAFIELD__INIT_VALUE = DATAFIELD__INIT_VALUE;

  /**
   * The feature id for the '<em><b>Portname</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DATAFIELD__PORTNAME = DATAFIELD__PORTNAME;

  /**
   * The feature id for the '<em><b>Sub System</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DATAFIELD__SUB_SYSTEM = DATAFIELD_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Output Datafield</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DATAFIELD_FEATURE_COUNT = DATAFIELD_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.PortnameImpl <em>Portname</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.PortnameImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getPortname()
   * @generated
   */
  int PORTNAME = 10;

  /**
   * The feature id for the '<em><b>Number</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PORTNAME__NUMBER = 0;

  /**
   * The feature id for the '<em><b>Port</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PORTNAME__PORT = 1;

  /**
   * The number of structural features of the '<em>Portname</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PORTNAME_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.VariantsImpl <em>Variants</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.VariantsImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getVariants()
   * @generated
   */
  int VARIANTS = 11;

  /**
   * The feature id for the '<em><b>Variants</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VARIANTS__VARIANTS = 0;

  /**
   * The number of structural features of the '<em>Variants</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VARIANTS_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.VariantImpl <em>Variant</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.VariantImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getVariant()
   * @generated
   */
  int VARIANT = 12;

  /**
   * The feature id for the '<em><b>Default Variant</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VARIANT__DEFAULT_VARIANT = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VARIANT__NAME = 1;

  /**
   * The number of structural features of the '<em>Variant</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VARIANT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.SignalImpl <em>Signal</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.SignalImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSignal()
   * @generated
   */
  int SIGNAL = 13;

  /**
   * The feature id for the '<em><b>Data Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIGNAL__DATA_TYPE = 0;

  /**
   * The feature id for the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIGNAL__DESCRIPTION = 1;

  /**
   * The feature id for the '<em><b>Asap Measurment</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIGNAL__ASAP_MEASURMENT = 2;

  /**
   * The number of structural features of the '<em>Signal</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SIGNAL_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ASAPMeasurmentImpl <em>ASAP Measurment</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ASAPMeasurmentImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getASAPMeasurment()
   * @generated
   */
  int ASAP_MEASURMENT = 14;

  /**
   * The feature id for the '<em><b>Lower Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ASAP_MEASURMENT__LOWER_LIMIT = 0;

  /**
   * The feature id for the '<em><b>Upper Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ASAP_MEASURMENT__UPPER_LIMIT = 1;

  /**
   * The number of structural features of the '<em>ASAP Measurment</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ASAP_MEASURMENT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.HardwareImpl <em>Hardware</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.HardwareImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getHardware()
   * @generated
   */
  int HARDWARE = 15;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HARDWARE__NAME = 0;

  /**
   * The feature id for the '<em><b>Driver To ECU</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HARDWARE__DRIVER_TO_ECU = 1;

  /**
   * The feature id for the '<em><b>Temp Sensor Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HARDWARE__TEMP_SENSOR_SUBSYSTEM = 2;

  /**
   * The feature id for the '<em><b>Electric Diag Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HARDWARE__ELECTRIC_DIAG_SUBSYSTEM = 3;

  /**
   * The feature id for the '<em><b>Frequency Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HARDWARE__FREQUENCY_SUBSYSTEM = 4;

  /**
   * The feature id for the '<em><b>Spi Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HARDWARE__SPI_SUBSYSTEM = 5;

  /**
   * The feature id for the '<em><b>Opwm Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HARDWARE__OPWM_SUBSYSTEM = 6;

  /**
   * The feature id for the '<em><b>User Defined Subsystem</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HARDWARE__USER_DEFINED_SUBSYSTEM = 7;

  /**
   * The number of structural features of the '<em>Hardware</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HARDWARE_FEATURE_COUNT = 8;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ConfigSubsystemImpl <em>Config Subsystem</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ConfigSubsystemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfigSubsystem()
   * @generated
   */
  int CONFIG_SUBSYSTEM = 16;

  /**
   * The feature id for the '<em><b>Config Subsystem Input</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT = 0;

  /**
   * The feature id for the '<em><b>Config Subsystem Output</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT = 1;

  /**
   * The number of structural features of the '<em>Config Subsystem</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ConfigSubsystemInputImpl <em>Config Subsystem Input</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ConfigSubsystemInputImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfigSubsystemInput()
   * @generated
   */
  int CONFIG_SUBSYSTEM_INPUT = 17;

  /**
   * The feature id for the '<em><b>Maximal Number Input Subsystems</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM_INPUT__MAXIMAL_NUMBER_INPUT_SUBSYSTEMS = 0;

  /**
   * The feature id for the '<em><b>Input Subsystems</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS = 1;

  /**
   * The number of structural features of the '<em>Config Subsystem Input</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM_INPUT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ConfigSubsystemOutputImpl <em>Config Subsystem Output</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ConfigSubsystemOutputImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfigSubsystemOutput()
   * @generated
   */
  int CONFIG_SUBSYSTEM_OUTPUT = 18;

  /**
   * The feature id for the '<em><b>Maximal Number Output Subsystems</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM_OUTPUT__MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS = 0;

  /**
   * The feature id for the '<em><b>Output Subsystems</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS = 1;

  /**
   * The number of structural features of the '<em>Config Subsystem Output</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM_OUTPUT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputSubsystemsImpl <em>Input Subsystems</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputSubsystemsImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputSubsystems()
   * @generated
   */
  int INPUT_SUBSYSTEMS = 19;

  /**
   * The feature id for the '<em><b>Input Null</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SUBSYSTEMS__INPUT_NULL = 0;

  /**
   * The feature id for the '<em><b>Input Analog</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SUBSYSTEMS__INPUT_ANALOG = 1;

  /**
   * The feature id for the '<em><b>Input Temperature</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SUBSYSTEMS__INPUT_TEMPERATURE = 2;

  /**
   * The feature id for the '<em><b>Input Digital</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SUBSYSTEMS__INPUT_DIGITAL = 3;

  /**
   * The feature id for the '<em><b>Input Frq</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SUBSYSTEMS__INPUT_FRQ = 4;

  /**
   * The feature id for the '<em><b>Input SPI</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SUBSYSTEMS__INPUT_SPI = 5;

  /**
   * The feature id for the '<em><b>Input Config Subsystem</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SUBSYSTEMS__INPUT_CONFIG_SUBSYSTEM = 6;

  /**
   * The number of structural features of the '<em>Input Subsystems</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_SUBSYSTEMS_FEATURE_COUNT = 7;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputSubsystemsImpl <em>Output Subsystems</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputSubsystemsImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputSubsystems()
   * @generated
   */
  int OUTPUT_SUBSYSTEMS = 20;

  /**
   * The feature id for the '<em><b>Output Null</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SUBSYSTEMS__OUTPUT_NULL = 0;

  /**
   * The feature id for the '<em><b>Output Digital</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL = 1;

  /**
   * The feature id for the '<em><b>Output PWM</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SUBSYSTEMS__OUTPUT_PWM = 2;

  /**
   * The feature id for the '<em><b>Output El Diag</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG = 3;

  /**
   * The feature id for the '<em><b>Output Config Subsystem</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SUBSYSTEMS__OUTPUT_CONFIG_SUBSYSTEM = 4;

  /**
   * The number of structural features of the '<em>Output Subsystems</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_SUBSYSTEMS_FEATURE_COUNT = 5;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.GenericSubsystemImpl <em>Generic Subsystem</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.GenericSubsystemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getGenericSubsystem()
   * @generated
   */
  int GENERIC_SUBSYSTEM = 23;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GENERIC_SUBSYSTEM__NAME = 0;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GENERIC_SUBSYSTEM__SORTING_INDEX = 1;

  /**
   * The number of structural features of the '<em>Generic Subsystem</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GENERIC_SUBSYSTEM_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputDriverTypeImpl <em>Input Driver Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputDriverTypeImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputDriverType()
   * @generated
   */
  int INPUT_DRIVER_TYPE = 24;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DRIVER_TYPE__NAME = GENERIC_SUBSYSTEM__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DRIVER_TYPE__SORTING_INDEX = GENERIC_SUBSYSTEM__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Input Driver Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DRIVER_TYPE_FEATURE_COUNT = GENERIC_SUBSYSTEM_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputConfigSubsystemNullImpl <em>Input Config Subsystem Null</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputConfigSubsystemNullImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemNull()
   * @generated
   */
  int INPUT_CONFIG_SUBSYSTEM_NULL = 21;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_NULL__NAME = INPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_NULL__SORTING_INDEX = INPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Input Config Subsystem Null</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_NULL_FEATURE_COUNT = INPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputDriverTypeImpl <em>Output Driver Type</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputDriverTypeImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputDriverType()
   * @generated
   */
  int OUTPUT_DRIVER_TYPE = 25;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DRIVER_TYPE__NAME = GENERIC_SUBSYSTEM__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DRIVER_TYPE__SORTING_INDEX = GENERIC_SUBSYSTEM__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Output Driver Type</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DRIVER_TYPE_FEATURE_COUNT = GENERIC_SUBSYSTEM_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemNullImpl <em>Output Config Subsystem Null</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputConfigSubsystemNullImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemNull()
   * @generated
   */
  int OUTPUT_CONFIG_SUBSYSTEM_NULL = 22;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_NULL__NAME = OUTPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_NULL__SORTING_INDEX = OUTPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Output Config Subsystem Null</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_NULL_FEATURE_COUNT = OUTPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputConfigSubsystemAnalogImpl <em>Input Config Subsystem Analog</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputConfigSubsystemAnalogImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemAnalog()
   * @generated
   */
  int INPUT_CONFIG_SUBSYSTEM_ANALOG = 26;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_ANALOG__NAME = INPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_ANALOG__SORTING_INDEX = INPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Input Config Subsystem Analog</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_ANALOG_FEATURE_COUNT = INPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputConfigSubsystemTemperatureImpl <em>Input Config Subsystem Temperature</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputConfigSubsystemTemperatureImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemTemperature()
   * @generated
   */
  int INPUT_CONFIG_SUBSYSTEM_TEMPERATURE = 27;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_TEMPERATURE__NAME = INPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_TEMPERATURE__SORTING_INDEX = INPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Input Config Subsystem Temperature</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_TEMPERATURE_FEATURE_COUNT = INPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemElDiagImpl <em>Output Config Subsystem El Diag</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputConfigSubsystemElDiagImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemElDiag()
   * @generated
   */
  int OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG = 28;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__NAME = OUTPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__SORTING_INDEX = OUTPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The feature id for the '<em><b>Temp Sensor</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__TEMP_SENSOR = OUTPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Output Config Subsystem El Diag</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG_FEATURE_COUNT = OUTPUT_DRIVER_TYPE_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputConfigSubsystemSPIImpl <em>Input Config Subsystem SPI</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputConfigSubsystemSPIImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemSPI()
   * @generated
   */
  int INPUT_CONFIG_SUBSYSTEM_SPI = 29;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_SPI__NAME = INPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_SPI__SORTING_INDEX = INPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Input Config Subsystem SPI</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_SPI_FEATURE_COUNT = INPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputConfigSubsystemDigitalImpl <em>Input Config Subsystem Digital</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputConfigSubsystemDigitalImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemDigital()
   * @generated
   */
  int INPUT_CONFIG_SUBSYSTEM_DIGITAL = 30;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_DIGITAL__NAME = INPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_DIGITAL__SORTING_INDEX = INPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Input Config Subsystem Digital</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_DIGITAL_FEATURE_COUNT = INPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputConfigSubsystemFrqImpl <em>Input Config Subsystem Frq</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputConfigSubsystemFrqImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemFrq()
   * @generated
   */
  int INPUT_CONFIG_SUBSYSTEM_FRQ = 31;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_FRQ__NAME = INPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_FRQ__SORTING_INDEX = INPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Input Config Subsystem Frq</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_FRQ_FEATURE_COUNT = INPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemPWMImpl <em>Output Config Subsystem PWM</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputConfigSubsystemPWMImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemPWM()
   * @generated
   */
  int OUTPUT_CONFIG_SUBSYSTEM_PWM = 32;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_PWM__NAME = OUTPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_PWM__SORTING_INDEX = OUTPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Output Config Subsystem PWM</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_PWM_FEATURE_COUNT = OUTPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemDigitalImpl <em>Output Config Subsystem Digital</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputConfigSubsystemDigitalImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemDigital()
   * @generated
   */
  int OUTPUT_CONFIG_SUBSYSTEM_DIGITAL = 33;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_DIGITAL__NAME = OUTPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_DIGITAL__SORTING_INDEX = OUTPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Output Config Subsystem Digital</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_DIGITAL_FEATURE_COUNT = OUTPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputConfigSubsystemItemImpl <em>Input Config Subsystem Item</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputConfigSubsystemItemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemItem()
   * @generated
   */
  int INPUT_CONFIG_SUBSYSTEM_ITEM = 34;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_ITEM__NAME = INPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_ITEM__SORTING_INDEX = INPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Input Config Subsystem Item</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_CONFIG_SUBSYSTEM_ITEM_FEATURE_COUNT = INPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemItemImpl <em>Output Config Subsystem Item</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputConfigSubsystemItemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemItem()
   * @generated
   */
  int OUTPUT_CONFIG_SUBSYSTEM_ITEM = 35;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_ITEM__NAME = OUTPUT_DRIVER_TYPE__NAME;

  /**
   * The feature id for the '<em><b>Sorting Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_ITEM__SORTING_INDEX = OUTPUT_DRIVER_TYPE__SORTING_INDEX;

  /**
   * The number of structural features of the '<em>Output Config Subsystem Item</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_CONFIG_SUBSYSTEM_ITEM_FEATURE_COUNT = OUTPUT_DRIVER_TYPE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.DriverToECUImpl <em>Driver To ECU</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.DriverToECUImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getDriverToECU()
   * @generated
   */
  int DRIVER_TO_ECU = 36;

  /**
   * The feature id for the '<em><b>Input Analog Drivers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS = 0;

  /**
   * The feature id for the '<em><b>Input Digital Drivers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS = 1;

  /**
   * The feature id for the '<em><b>Input Dig Drivers Table</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE = 2;

  /**
   * The feature id for the '<em><b>Output Digital Drivers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS = 3;

  /**
   * The feature id for the '<em><b>Output Dig Drivers Table</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE = 4;

  /**
   * The number of structural features of the '<em>Driver To ECU</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int DRIVER_TO_ECU_FEATURE_COUNT = 5;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.TempSensorSubsystemImpl <em>Temp Sensor Subsystem</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.TempSensorSubsystemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getTempSensorSubsystem()
   * @generated
   */
  int TEMP_SENSOR_SUBSYSTEM = 37;

  /**
   * The feature id for the '<em><b>Driver</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TEMP_SENSOR_SUBSYSTEM__DRIVER = 0;

  /**
   * The number of structural features of the '<em>Temp Sensor Subsystem</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TEMP_SENSOR_SUBSYSTEM_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputAnalogDriversImpl <em>Input Analog Drivers</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputAnalogDriversImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputAnalogDrivers()
   * @generated
   */
  int INPUT_ANALOG_DRIVERS = 38;

  /**
   * The feature id for the '<em><b>Driver</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ANALOG_DRIVERS__DRIVER = 0;

  /**
   * The number of structural features of the '<em>Input Analog Drivers</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_ANALOG_DRIVERS_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputDigitalDriversImpl <em>Input Digital Drivers</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputDigitalDriversImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputDigitalDrivers()
   * @generated
   */
  int INPUT_DIGITAL_DRIVERS = 39;

  /**
   * The feature id for the '<em><b>Driver</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DIGITAL_DRIVERS__DRIVER = 0;

  /**
   * The number of structural features of the '<em>Input Digital Drivers</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DIGITAL_DRIVERS_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputDigitalDriversImpl <em>Output Digital Drivers</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputDigitalDriversImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputDigitalDrivers()
   * @generated
   */
  int OUTPUT_DIGITAL_DRIVERS = 40;

  /**
   * The feature id for the '<em><b>Driver</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DIGITAL_DRIVERS__DRIVER = 0;

  /**
   * The number of structural features of the '<em>Output Digital Drivers</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DIGITAL_DRIVERS_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.AnalogDriverImpl <em>Analog Driver</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.AnalogDriverImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getAnalogDriver()
   * @generated
   */
  int ANALOG_DRIVER = 41;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ANALOG_DRIVER__NAME = 0;

  /**
   * The feature id for the '<em><b>Driver Setup</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ANALOG_DRIVER__DRIVER_SETUP = 1;

  /**
   * The number of structural features of the '<em>Analog Driver</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ANALOG_DRIVER_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InDigDriverImpl <em>In Dig Driver</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InDigDriverImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInDigDriver()
   * @generated
   */
  int IN_DIG_DRIVER = 42;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IN_DIG_DRIVER__NAME = 0;

  /**
   * The feature id for the '<em><b>Driver Setup</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IN_DIG_DRIVER__DRIVER_SETUP = 1;

  /**
   * The number of structural features of the '<em>In Dig Driver</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IN_DIG_DRIVER_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutDigDriverImpl <em>Out Dig Driver</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutDigDriverImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutDigDriver()
   * @generated
   */
  int OUT_DIG_DRIVER = 43;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUT_DIG_DRIVER__NAME = 0;

  /**
   * The feature id for the '<em><b>Driver Setup</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUT_DIG_DRIVER__DRIVER_SETUP = 1;

  /**
   * The number of structural features of the '<em>Out Dig Driver</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUT_DIG_DRIVER_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.CommonDriverImpl <em>Common Driver</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.CommonDriverImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getCommonDriver()
   * @generated
   */
  int COMMON_DRIVER = 44;

  /**
   * The feature id for the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMON_DRIVER__DRIVER_INDEX = 0;

  /**
   * The feature id for the '<em><b>Controller Pin Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMON_DRIVER__CONTROLLER_PIN_NAME = 1;

  /**
   * The feature id for the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMON_DRIVER__DESCRIPTION = 2;

  /**
   * The number of structural features of the '<em>Common Driver</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMMON_DRIVER_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InputDigDriversTableImpl <em>Input Dig Drivers Table</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InputDigDriversTableImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputDigDriversTable()
   * @generated
   */
  int INPUT_DIG_DRIVERS_TABLE = 45;

  /**
   * The feature id for the '<em><b>Digital Driver Table Ref</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF = 0;

  /**
   * The number of structural features of the '<em>Input Dig Drivers Table</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_DIG_DRIVERS_TABLE_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutputDigDriversTableImpl <em>Output Dig Drivers Table</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutputDigDriversTableImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputDigDriversTable()
   * @generated
   */
  int OUTPUT_DIG_DRIVERS_TABLE = 46;

  /**
   * The feature id for the '<em><b>Digital Driver Table Ref</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF = 0;

  /**
   * The number of structural features of the '<em>Output Dig Drivers Table</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUTPUT_DIG_DRIVERS_TABLE_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.InDigitalDriverTableRefImpl <em>In Digital Driver Table Ref</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.InDigitalDriverTableRefImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInDigitalDriverTableRef()
   * @generated
   */
  int IN_DIGITAL_DRIVER_TABLE_REF = 47;

  /**
   * The feature id for the '<em><b>Dummy Signal</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IN_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IN_DIGITAL_DRIVER_TABLE_REF__NAME = 1;

  /**
   * The number of structural features of the '<em>In Digital Driver Table Ref</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IN_DIGITAL_DRIVER_TABLE_REF_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OutDigitalDriverTableRefImpl <em>Out Digital Driver Table Ref</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OutDigitalDriverTableRefImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutDigitalDriverTableRef()
   * @generated
   */
  int OUT_DIGITAL_DRIVER_TABLE_REF = 48;

  /**
   * The feature id for the '<em><b>Dummy Signal</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUT_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUT_DIGITAL_DRIVER_TABLE_REF__NAME = 1;

  /**
   * The number of structural features of the '<em>Out Digital Driver Table Ref</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OUT_DIGITAL_DRIVER_TABLE_REF_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ElectricDiagSubsystemImpl <em>Electric Diag Subsystem</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ElectricDiagSubsystemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getElectricDiagSubsystem()
   * @generated
   */
  int ELECTRIC_DIAG_SUBSYSTEM = 49;

  /**
   * The feature id for the '<em><b>El Diag</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELECTRIC_DIAG_SUBSYSTEM__EL_DIAG = 0;

  /**
   * The number of structural features of the '<em>Electric Diag Subsystem</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELECTRIC_DIAG_SUBSYSTEM_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ElDiagImpl <em>El Diag</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ElDiagImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getElDiag()
   * @generated
   */
  int EL_DIAG = 50;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EL_DIAG__NAME = 0;

  /**
   * The feature id for the '<em><b>Enable</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EL_DIAG__ENABLE = 1;

  /**
   * The feature id for the '<em><b>Diagnosis Enable</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EL_DIAG__DIAGNOSIS_ENABLE = 2;

  /**
   * The feature id for the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EL_DIAG__DRIVER_INDEX = 3;

  /**
   * The feature id for the '<em><b>Pwm Diagnosis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EL_DIAG__PWM_DIAGNOSIS = 4;

  /**
   * The feature id for the '<em><b>Power Supply Signal</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EL_DIAG__POWER_SUPPLY_SIGNAL = 5;

  /**
   * The feature id for the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EL_DIAG__DESCRIPTION = 6;

  /**
   * The number of structural features of the '<em>El Diag</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EL_DIAG_FEATURE_COUNT = 7;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.FrequencySubsystemImpl <em>Frequency Subsystem</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.FrequencySubsystemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getFrequencySubsystem()
   * @generated
   */
  int FREQUENCY_SUBSYSTEM = 51;

  /**
   * The number of structural features of the '<em>Frequency Subsystem</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FREQUENCY_SUBSYSTEM_FEATURE_COUNT = 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.IFRQImpl <em>IFRQ</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.IFRQImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getIFRQ()
   * @generated
   */
  int IFRQ = 52;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ__NAME = 0;

  /**
   * The feature id for the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ__DRIVER_INDEX = 1;

  /**
   * The feature id for the '<em><b>Sensor Index</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ__SENSOR_INDEX = 2;

  /**
   * The feature id for the '<em><b>Update Time</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ__UPDATE_TIME = 3;

  /**
   * The feature id for the '<em><b>Active</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ__ACTIVE = 4;

  /**
   * The number of structural features of the '<em>IFRQ</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ_FEATURE_COUNT = 5;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.IFRQSensorImpl <em>IFRQ Sensor</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.IFRQSensorImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getIFRQSensor()
   * @generated
   */
  int IFRQ_SENSOR = 53;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ_SENSOR__NAME = 0;

  /**
   * The feature id for the '<em><b>Initial Waiting Time</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ_SENSOR__INITIAL_WAITING_TIME = 1;

  /**
   * The feature id for the '<em><b>Dir Change Min Periods</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ_SENSOR__DIR_CHANGE_MIN_PERIODS = 2;

  /**
   * The feature id for the '<em><b>Direction Change Debounce Time</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ_SENSOR__DIRECTION_CHANGE_DEBOUNCE_TIME = 3;

  /**
   * The number of structural features of the '<em>IFRQ Sensor</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IFRQ_SENSOR_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.SPIinputSysImpl <em>SP Iinput Sys</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.SPIinputSysImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSPIinputSys()
   * @generated
   */
  int SP_IINPUT_SYS = 54;

  /**
   * The feature id for the '<em><b>Spi</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SP_IINPUT_SYS__SPI = 0;

  /**
   * The number of structural features of the '<em>SP Iinput Sys</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SP_IINPUT_SYS_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.SPIImpl <em>SPI</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.SPIImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSPI()
   * @generated
   */
  int SPI = 55;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPI__NAME = 0;

  /**
   * The feature id for the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPI__DRIVER_INDEX = 1;

  /**
   * The feature id for the '<em><b>Data Storage Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPI__DATA_STORAGE_MODE = 2;

  /**
   * The feature id for the '<em><b>Command</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPI__COMMAND = 3;

  /**
   * The feature id for the '<em><b>Data Length</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPI__DATA_LENGTH = 4;

  /**
   * The feature id for the '<em><b>Spitx Data</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPI__SPITX_DATA = 5;

  /**
   * The feature id for the '<em><b>Module</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPI__MODULE = 6;

  /**
   * The feature id for the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPI__DESCRIPTION = 7;

  /**
   * The number of structural features of the '<em>SPI</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPI_FEATURE_COUNT = 8;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.SPITXDataImpl <em>SPITX Data</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.SPITXDataImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSPITXData()
   * @generated
   */
  int SPITX_DATA = 56;

  /**
   * The feature id for the '<em><b>Byte One</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPITX_DATA__BYTE_ONE = 0;

  /**
   * The feature id for the '<em><b>Byte Two</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPITX_DATA__BYTE_TWO = 1;

  /**
   * The feature id for the '<em><b>Byte Three</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPITX_DATA__BYTE_THREE = 2;

  /**
   * The feature id for the '<em><b>Byte Four</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPITX_DATA__BYTE_FOUR = 3;

  /**
   * The number of structural features of the '<em>SPITX Data</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SPITX_DATA_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OPWMSubsystemImpl <em>OPWM Subsystem</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OPWMSubsystemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOPWMSubsystem()
   * @generated
   */
  int OPWM_SUBSYSTEM = 57;

  /**
   * The feature id for the '<em><b>Opwm</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPWM_SUBSYSTEM__OPWM = 0;

  /**
   * The number of structural features of the '<em>OPWM Subsystem</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPWM_SUBSYSTEM_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.OPWMImpl <em>OPWM</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.OPWMImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOPWM()
   * @generated
   */
  int OPWM = 58;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPWM__NAME = 0;

  /**
   * The feature id for the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPWM__DRIVER_INDEX = 1;

  /**
   * The feature id for the '<em><b>Period</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPWM__PERIOD = 2;

  /**
   * The feature id for the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPWM__DESCRIPTION = 3;

  /**
   * The number of structural features of the '<em>OPWM</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPWM_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.IADCImpl <em>IADC</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.IADCImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getIADC()
   * @generated
   */
  int IADC = 59;

  /**
   * The feature id for the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IADC__DRIVER_INDEX = 0;

  /**
   * The feature id for the '<em><b>Enable</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IADC__ENABLE = 1;

  /**
   * The feature id for the '<em><b>Power Supply Signal</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IADC__POWER_SUPPLY_SIGNAL = 2;

  /**
   * The feature id for the '<em><b>Enable El Diag Power Supply Off</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IADC__ENABLE_EL_DIAG_POWER_SUPPLY_OFF = 3;

  /**
   * The feature id for the '<em><b>El Diag Instance Idx</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IADC__EL_DIAG_INSTANCE_IDX = 4;

  /**
   * The feature id for the '<em><b>Controller Pin Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IADC__CONTROLLER_PIN_NAME = 5;

  /**
   * The feature id for the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IADC__DESCRIPTION = 6;

  /**
   * The number of structural features of the '<em>IADC</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IADC_FEATURE_COUNT = 7;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.UserDefinedSubsystemImpl <em>User Defined Subsystem</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.UserDefinedSubsystemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getUserDefinedSubsystem()
   * @generated
   */
  int USER_DEFINED_SUBSYSTEM = 60;

  /**
   * The feature id for the '<em><b>Name</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int USER_DEFINED_SUBSYSTEM__NAME = 0;

  /**
   * The feature id for the '<em><b>User Port</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int USER_DEFINED_SUBSYSTEM__USER_PORT = 1;

  /**
   * The number of structural features of the '<em>User Defined Subsystem</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int USER_DEFINED_SUBSYSTEM_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ConfigSubsystemItemImpl <em>Config Subsystem Item</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ConfigSubsystemItemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfigSubsystemItem()
   * @generated
   */
  int CONFIG_SUBSYSTEM_ITEM = 61;

  /**
   * The number of structural features of the '<em>Config Subsystem Item</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONFIG_SUBSYSTEM_ITEM_FEATURE_COUNT = 0;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.UserPortImpl <em>User Port</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.UserPortImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getUserPort()
   * @generated
   */
  int USER_PORT = 62;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int USER_PORT__NAME = 0;

  /**
   * The feature id for the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int USER_PORT__DRIVER_INDEX = 1;

  /**
   * The feature id for the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int USER_PORT__DESCRIPTION = 2;

  /**
   * The number of structural features of the '<em>User Port</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int USER_PORT_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ImportImpl <em>Import</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ImportImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getImport()
   * @generated
   */
  int IMPORT = 63;

  /**
   * The feature id for the '<em><b>Import URI</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMPORT__IMPORT_URI = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMPORT__NAME = 1;

  /**
   * The number of structural features of the '<em>Import</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMPORT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.ImportsImpl <em>Imports</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.ImportsImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getImports()
   * @generated
   */
  int IMPORTS = 64;

  /**
   * The feature id for the '<em><b>Imported Namespace</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMPORTS__IMPORTED_NAMESPACE = 0;

  /**
   * The number of structural features of the '<em>Imports</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMPORTS_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link zf.pios.configurator.impl.FRQSubsystemImpl <em>FRQ Subsystem</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.impl.FRQSubsystemImpl
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getFRQSubsystem()
   * @generated
   */
  int FRQ_SUBSYSTEM = 65;

  /**
   * The feature id for the '<em><b>Ifrq Sensor</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FRQ_SUBSYSTEM__IFRQ_SENSOR = FREQUENCY_SUBSYSTEM_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Ifrq</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FRQ_SUBSYSTEM__IFRQ = FREQUENCY_SUBSYSTEM_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>FRQ Subsystem</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FRQ_SUBSYSTEM_FEATURE_COUNT = FREQUENCY_SUBSYSTEM_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link zf.pios.configurator.dataTypeEnumeration <em>data Type Enumeration</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.dataTypeEnumeration
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getdataTypeEnumeration()
   * @generated
   */
  int DATA_TYPE_ENUMERATION = 66;

  /**
   * The meta object id for the '{@link zf.pios.configurator.iadcEnableEnumeration <em>iadc Enable Enumeration</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.iadcEnableEnumeration
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getiadcEnableEnumeration()
   * @generated
   */
  int IADC_ENABLE_ENUMERATION = 67;

  /**
   * The meta object id for the '{@link zf.pios.configurator.BOOLfalseDefault <em>BOO Lfalse Default</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see zf.pios.configurator.BOOLfalseDefault
   * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getBOOLfalseDefault()
   * @generated
   */
  int BOO_LFALSE_DEFAULT = 68;


  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Configuration <em>Configuration</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Configuration</em>'.
   * @see zf.pios.configurator.Configuration
   * @generated
   */
  EClass getConfiguration();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Configuration#getConfigurationName <em>Configuration Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Configuration Name</em>'.
   * @see zf.pios.configurator.Configuration#getConfigurationName()
   * @see #getConfiguration()
   * @generated
   */
  EAttribute getConfiguration_ConfigurationName();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Configuration#getVersion <em>Version</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Version</em>'.
   * @see zf.pios.configurator.Configuration#getVersion()
   * @see #getConfiguration()
   * @generated
   */
  EAttribute getConfiguration_Version();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Configuration#getMainMergeFile <em>Main Merge File</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Main Merge File</em>'.
   * @see zf.pios.configurator.Configuration#getMainMergeFile()
   * @see #getConfiguration()
   * @generated
   */
  EAttribute getConfiguration_MainMergeFile();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.Configuration#getImports <em>Imports</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Imports</em>'.
   * @see zf.pios.configurator.Configuration#getImports()
   * @see #getConfiguration()
   * @generated
   */
  EReference getConfiguration_Imports();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Configuration#getVariants <em>Variants</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Variants</em>'.
   * @see zf.pios.configurator.Configuration#getVariants()
   * @see #getConfiguration()
   * @generated
   */
  EReference getConfiguration_Variants();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Configuration#getSystem <em>System</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>System</em>'.
   * @see zf.pios.configurator.Configuration#getSystem()
   * @see #getConfiguration()
   * @generated
   */
  EReference getConfiguration_System();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Configuration#getHardware <em>Hardware</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Hardware</em>'.
   * @see zf.pios.configurator.Configuration#getHardware()
   * @see #getConfiguration()
   * @generated
   */
  EReference getConfiguration_Hardware();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Configuration#getSignals <em>Signals</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Signals</em>'.
   * @see zf.pios.configurator.Configuration#getSignals()
   * @see #getConfiguration()
   * @generated
   */
  EReference getConfiguration_Signals();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.System <em>System</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>System</em>'.
   * @see zf.pios.configurator.System
   * @generated
   */
  EClass getSystem();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.System#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.System#getName()
   * @see #getSystem()
   * @generated
   */
  EAttribute getSystem_Name();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.System#getConfigSubsystem <em>Config Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Config Subsystem</em>'.
   * @see zf.pios.configurator.System#getConfigSubsystem()
   * @see #getSystem()
   * @generated
   */
  EReference getSystem_ConfigSubsystem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Signals <em>Signals</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Signals</em>'.
   * @see zf.pios.configurator.Signals
   * @generated
   */
  EClass getSignals();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Signals#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.Signals#getName()
   * @see #getSignals()
   * @generated
   */
  EAttribute getSignals_Name();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Signals#getPiosSignals <em>Pios Signals</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Pios Signals</em>'.
   * @see zf.pios.configurator.Signals#getPiosSignals()
   * @see #getSignals()
   * @generated
   */
  EReference getSignals_PiosSignals();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.GeneralSignals <em>General Signals</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>General Signals</em>'.
   * @see zf.pios.configurator.GeneralSignals
   * @generated
   */
  EClass getGeneralSignals();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.GeneralSignals#getGeneralSignal <em>General Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>General Signal</em>'.
   * @see zf.pios.configurator.GeneralSignals#getGeneralSignal()
   * @see #getGeneralSignals()
   * @generated
   */
  EReference getGeneralSignals_GeneralSignal();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.GeneralSignal <em>General Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>General Signal</em>'.
   * @see zf.pios.configurator.GeneralSignal
   * @generated
   */
  EClass getGeneralSignal();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.GeneralSignal#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.GeneralSignal#getName()
   * @see #getGeneralSignal()
   * @generated
   */
  EAttribute getGeneralSignal_Name();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.GeneralSignal#getSignal <em>Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Signal</em>'.
   * @see zf.pios.configurator.GeneralSignal#getSignal()
   * @see #getGeneralSignal()
   * @generated
   */
  EReference getGeneralSignal_Signal();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputSignal <em>Input Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Signal</em>'.
   * @see zf.pios.configurator.InputSignal
   * @generated
   */
  EClass getInputSignal();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.InputSignal#getPowerSupply <em>Power Supply</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Power Supply</em>'.
   * @see zf.pios.configurator.InputSignal#getPowerSupply()
   * @see #getInputSignal()
   * @generated
   */
  EAttribute getInputSignal_PowerSupply();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.InputSignal#getDatafield <em>Datafield</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Datafield</em>'.
   * @see zf.pios.configurator.InputSignal#getDatafield()
   * @see #getInputSignal()
   * @generated
   */
  EReference getInputSignal_Datafield();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputSignal <em>Output Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Signal</em>'.
   * @see zf.pios.configurator.OutputSignal
   * @generated
   */
  EClass getOutputSignal();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.OutputSignal#getPullUpResistorSignal <em>Pull Up Resistor Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Pull Up Resistor Signal</em>'.
   * @see zf.pios.configurator.OutputSignal#getPullUpResistorSignal()
   * @see #getOutputSignal()
   * @generated
   */
  EAttribute getOutputSignal_PullUpResistorSignal();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.OutputSignal#getDatafield <em>Datafield</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Datafield</em>'.
   * @see zf.pios.configurator.OutputSignal#getDatafield()
   * @see #getOutputSignal()
   * @generated
   */
  EReference getOutputSignal_Datafield();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Datafield <em>Datafield</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Datafield</em>'.
   * @see zf.pios.configurator.Datafield
   * @generated
   */
  EClass getDatafield();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.Datafield#getVariantName <em>Variant Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Variant Name</em>'.
   * @see zf.pios.configurator.Datafield#getVariantName()
   * @see #getDatafield()
   * @generated
   */
  EReference getDatafield_VariantName();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Datafield#getLowerLimit <em>Lower Limit</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Lower Limit</em>'.
   * @see zf.pios.configurator.Datafield#getLowerLimit()
   * @see #getDatafield()
   * @generated
   */
  EAttribute getDatafield_LowerLimit();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Datafield#getUpperLimit <em>Upper Limit</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Upper Limit</em>'.
   * @see zf.pios.configurator.Datafield#getUpperLimit()
   * @see #getDatafield()
   * @generated
   */
  EAttribute getDatafield_UpperLimit();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Datafield#getInitValue <em>Init Value</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Init Value</em>'.
   * @see zf.pios.configurator.Datafield#getInitValue()
   * @see #getDatafield()
   * @generated
   */
  EAttribute getDatafield_InitValue();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Datafield#getPortname <em>Portname</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Portname</em>'.
   * @see zf.pios.configurator.Datafield#getPortname()
   * @see #getDatafield()
   * @generated
   */
  EReference getDatafield_Portname();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputDatafield <em>Input Datafield</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Datafield</em>'.
   * @see zf.pios.configurator.InputDatafield
   * @generated
   */
  EClass getInputDatafield();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.InputDatafield#getSubSystem <em>Sub System</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Sub System</em>'.
   * @see zf.pios.configurator.InputDatafield#getSubSystem()
   * @see #getInputDatafield()
   * @generated
   */
  EReference getInputDatafield_SubSystem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputDatafield <em>Output Datafield</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Datafield</em>'.
   * @see zf.pios.configurator.OutputDatafield
   * @generated
   */
  EClass getOutputDatafield();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.OutputDatafield#getSubSystem <em>Sub System</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Sub System</em>'.
   * @see zf.pios.configurator.OutputDatafield#getSubSystem()
   * @see #getOutputDatafield()
   * @generated
   */
  EReference getOutputDatafield_SubSystem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Portname <em>Portname</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Portname</em>'.
   * @see zf.pios.configurator.Portname
   * @generated
   */
  EClass getPortname();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Portname#getNumber <em>Number</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Number</em>'.
   * @see zf.pios.configurator.Portname#getNumber()
   * @see #getPortname()
   * @generated
   */
  EAttribute getPortname_Number();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.Portname#getPort <em>Port</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Port</em>'.
   * @see zf.pios.configurator.Portname#getPort()
   * @see #getPortname()
   * @generated
   */
  EReference getPortname_Port();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Variants <em>Variants</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Variants</em>'.
   * @see zf.pios.configurator.Variants
   * @generated
   */
  EClass getVariants();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.Variants#getVariants <em>Variants</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Variants</em>'.
   * @see zf.pios.configurator.Variants#getVariants()
   * @see #getVariants()
   * @generated
   */
  EReference getVariants_Variants();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Variant <em>Variant</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Variant</em>'.
   * @see zf.pios.configurator.Variant
   * @generated
   */
  EClass getVariant();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Variant#getDefaultVariant <em>Default Variant</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Default Variant</em>'.
   * @see zf.pios.configurator.Variant#getDefaultVariant()
   * @see #getVariant()
   * @generated
   */
  EAttribute getVariant_DefaultVariant();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Variant#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.Variant#getName()
   * @see #getVariant()
   * @generated
   */
  EAttribute getVariant_Name();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Signal <em>Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Signal</em>'.
   * @see zf.pios.configurator.Signal
   * @generated
   */
  EClass getSignal();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Signal#getDataType <em>Data Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Data Type</em>'.
   * @see zf.pios.configurator.Signal#getDataType()
   * @see #getSignal()
   * @generated
   */
  EAttribute getSignal_DataType();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Signal#getDescription <em>Description</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Description</em>'.
   * @see zf.pios.configurator.Signal#getDescription()
   * @see #getSignal()
   * @generated
   */
  EAttribute getSignal_Description();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Signal#getAsapMeasurment <em>Asap Measurment</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Asap Measurment</em>'.
   * @see zf.pios.configurator.Signal#getAsapMeasurment()
   * @see #getSignal()
   * @generated
   */
  EReference getSignal_AsapMeasurment();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.ASAPMeasurment <em>ASAP Measurment</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>ASAP Measurment</em>'.
   * @see zf.pios.configurator.ASAPMeasurment
   * @generated
   */
  EClass getASAPMeasurment();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ASAPMeasurment#getLowerLimit <em>Lower Limit</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Lower Limit</em>'.
   * @see zf.pios.configurator.ASAPMeasurment#getLowerLimit()
   * @see #getASAPMeasurment()
   * @generated
   */
  EAttribute getASAPMeasurment_LowerLimit();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ASAPMeasurment#getUpperLimit <em>Upper Limit</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Upper Limit</em>'.
   * @see zf.pios.configurator.ASAPMeasurment#getUpperLimit()
   * @see #getASAPMeasurment()
   * @generated
   */
  EAttribute getASAPMeasurment_UpperLimit();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Hardware <em>Hardware</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Hardware</em>'.
   * @see zf.pios.configurator.Hardware
   * @generated
   */
  EClass getHardware();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Hardware#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.Hardware#getName()
   * @see #getHardware()
   * @generated
   */
  EAttribute getHardware_Name();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Hardware#getDriverToECU <em>Driver To ECU</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Driver To ECU</em>'.
   * @see zf.pios.configurator.Hardware#getDriverToECU()
   * @see #getHardware()
   * @generated
   */
  EReference getHardware_DriverToECU();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Hardware#getTempSensorSubsystem <em>Temp Sensor Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Temp Sensor Subsystem</em>'.
   * @see zf.pios.configurator.Hardware#getTempSensorSubsystem()
   * @see #getHardware()
   * @generated
   */
  EReference getHardware_TempSensorSubsystem();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Hardware#getElectricDiagSubsystem <em>Electric Diag Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Electric Diag Subsystem</em>'.
   * @see zf.pios.configurator.Hardware#getElectricDiagSubsystem()
   * @see #getHardware()
   * @generated
   */
  EReference getHardware_ElectricDiagSubsystem();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Hardware#getFrequencySubsystem <em>Frequency Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Frequency Subsystem</em>'.
   * @see zf.pios.configurator.Hardware#getFrequencySubsystem()
   * @see #getHardware()
   * @generated
   */
  EReference getHardware_FrequencySubsystem();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Hardware#getSpiSubsystem <em>Spi Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Spi Subsystem</em>'.
   * @see zf.pios.configurator.Hardware#getSpiSubsystem()
   * @see #getHardware()
   * @generated
   */
  EReference getHardware_SpiSubsystem();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.Hardware#getOpwmSubsystem <em>Opwm Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Opwm Subsystem</em>'.
   * @see zf.pios.configurator.Hardware#getOpwmSubsystem()
   * @see #getHardware()
   * @generated
   */
  EReference getHardware_OpwmSubsystem();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.Hardware#getUserDefinedSubsystem <em>User Defined Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>User Defined Subsystem</em>'.
   * @see zf.pios.configurator.Hardware#getUserDefinedSubsystem()
   * @see #getHardware()
   * @generated
   */
  EReference getHardware_UserDefinedSubsystem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.ConfigSubsystem <em>Config Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Config Subsystem</em>'.
   * @see zf.pios.configurator.ConfigSubsystem
   * @generated
   */
  EClass getConfigSubsystem();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.ConfigSubsystem#getConfigSubsystemInput <em>Config Subsystem Input</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Config Subsystem Input</em>'.
   * @see zf.pios.configurator.ConfigSubsystem#getConfigSubsystemInput()
   * @see #getConfigSubsystem()
   * @generated
   */
  EReference getConfigSubsystem_ConfigSubsystemInput();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.ConfigSubsystem#getConfigSubsystemOutput <em>Config Subsystem Output</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Config Subsystem Output</em>'.
   * @see zf.pios.configurator.ConfigSubsystem#getConfigSubsystemOutput()
   * @see #getConfigSubsystem()
   * @generated
   */
  EReference getConfigSubsystem_ConfigSubsystemOutput();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.ConfigSubsystemInput <em>Config Subsystem Input</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Config Subsystem Input</em>'.
   * @see zf.pios.configurator.ConfigSubsystemInput
   * @generated
   */
  EClass getConfigSubsystemInput();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ConfigSubsystemInput#getMaximalNumberInputSubsystems <em>Maximal Number Input Subsystems</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Maximal Number Input Subsystems</em>'.
   * @see zf.pios.configurator.ConfigSubsystemInput#getMaximalNumberInputSubsystems()
   * @see #getConfigSubsystemInput()
   * @generated
   */
  EAttribute getConfigSubsystemInput_MaximalNumberInputSubsystems();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.ConfigSubsystemInput#getInputSubsystems <em>Input Subsystems</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Subsystems</em>'.
   * @see zf.pios.configurator.ConfigSubsystemInput#getInputSubsystems()
   * @see #getConfigSubsystemInput()
   * @generated
   */
  EReference getConfigSubsystemInput_InputSubsystems();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.ConfigSubsystemOutput <em>Config Subsystem Output</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Config Subsystem Output</em>'.
   * @see zf.pios.configurator.ConfigSubsystemOutput
   * @generated
   */
  EClass getConfigSubsystemOutput();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ConfigSubsystemOutput#getMaximalNumberOutputSubsystems <em>Maximal Number Output Subsystems</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Maximal Number Output Subsystems</em>'.
   * @see zf.pios.configurator.ConfigSubsystemOutput#getMaximalNumberOutputSubsystems()
   * @see #getConfigSubsystemOutput()
   * @generated
   */
  EAttribute getConfigSubsystemOutput_MaximalNumberOutputSubsystems();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.ConfigSubsystemOutput#getOutputSubsystems <em>Output Subsystems</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Output Subsystems</em>'.
   * @see zf.pios.configurator.ConfigSubsystemOutput#getOutputSubsystems()
   * @see #getConfigSubsystemOutput()
   * @generated
   */
  EReference getConfigSubsystemOutput_OutputSubsystems();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputSubsystems <em>Input Subsystems</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Subsystems</em>'.
   * @see zf.pios.configurator.InputSubsystems
   * @generated
   */
  EClass getInputSubsystems();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.InputSubsystems#getInputNull <em>Input Null</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Null</em>'.
   * @see zf.pios.configurator.InputSubsystems#getInputNull()
   * @see #getInputSubsystems()
   * @generated
   */
  EReference getInputSubsystems_InputNull();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.InputSubsystems#getInputAnalog <em>Input Analog</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Analog</em>'.
   * @see zf.pios.configurator.InputSubsystems#getInputAnalog()
   * @see #getInputSubsystems()
   * @generated
   */
  EReference getInputSubsystems_InputAnalog();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.InputSubsystems#getInputTemperature <em>Input Temperature</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Temperature</em>'.
   * @see zf.pios.configurator.InputSubsystems#getInputTemperature()
   * @see #getInputSubsystems()
   * @generated
   */
  EReference getInputSubsystems_InputTemperature();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.InputSubsystems#getInputDigital <em>Input Digital</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Digital</em>'.
   * @see zf.pios.configurator.InputSubsystems#getInputDigital()
   * @see #getInputSubsystems()
   * @generated
   */
  EReference getInputSubsystems_InputDigital();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.InputSubsystems#getInputFrq <em>Input Frq</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Frq</em>'.
   * @see zf.pios.configurator.InputSubsystems#getInputFrq()
   * @see #getInputSubsystems()
   * @generated
   */
  EReference getInputSubsystems_InputFrq();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.InputSubsystems#getInputSPI <em>Input SPI</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input SPI</em>'.
   * @see zf.pios.configurator.InputSubsystems#getInputSPI()
   * @see #getInputSubsystems()
   * @generated
   */
  EReference getInputSubsystems_InputSPI();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.InputSubsystems#getInputConfigSubsystem <em>Input Config Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Input Config Subsystem</em>'.
   * @see zf.pios.configurator.InputSubsystems#getInputConfigSubsystem()
   * @see #getInputSubsystems()
   * @generated
   */
  EReference getInputSubsystems_InputConfigSubsystem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputSubsystems <em>Output Subsystems</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Subsystems</em>'.
   * @see zf.pios.configurator.OutputSubsystems
   * @generated
   */
  EClass getOutputSubsystems();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.OutputSubsystems#getOutputNull <em>Output Null</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Output Null</em>'.
   * @see zf.pios.configurator.OutputSubsystems#getOutputNull()
   * @see #getOutputSubsystems()
   * @generated
   */
  EReference getOutputSubsystems_OutputNull();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.OutputSubsystems#getOutputDigital <em>Output Digital</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Output Digital</em>'.
   * @see zf.pios.configurator.OutputSubsystems#getOutputDigital()
   * @see #getOutputSubsystems()
   * @generated
   */
  EReference getOutputSubsystems_OutputDigital();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.OutputSubsystems#getOutputPWM <em>Output PWM</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Output PWM</em>'.
   * @see zf.pios.configurator.OutputSubsystems#getOutputPWM()
   * @see #getOutputSubsystems()
   * @generated
   */
  EReference getOutputSubsystems_OutputPWM();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.OutputSubsystems#getOutputElDiag <em>Output El Diag</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Output El Diag</em>'.
   * @see zf.pios.configurator.OutputSubsystems#getOutputElDiag()
   * @see #getOutputSubsystems()
   * @generated
   */
  EReference getOutputSubsystems_OutputElDiag();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.OutputSubsystems#getOutputConfigSubsystem <em>Output Config Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Output Config Subsystem</em>'.
   * @see zf.pios.configurator.OutputSubsystems#getOutputConfigSubsystem()
   * @see #getOutputSubsystems()
   * @generated
   */
  EReference getOutputSubsystems_OutputConfigSubsystem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputConfigSubsystemNull <em>Input Config Subsystem Null</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Config Subsystem Null</em>'.
   * @see zf.pios.configurator.InputConfigSubsystemNull
   * @generated
   */
  EClass getInputConfigSubsystemNull();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputConfigSubsystemNull <em>Output Config Subsystem Null</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Config Subsystem Null</em>'.
   * @see zf.pios.configurator.OutputConfigSubsystemNull
   * @generated
   */
  EClass getOutputConfigSubsystemNull();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.GenericSubsystem <em>Generic Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Generic Subsystem</em>'.
   * @see zf.pios.configurator.GenericSubsystem
   * @generated
   */
  EClass getGenericSubsystem();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.GenericSubsystem#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.GenericSubsystem#getName()
   * @see #getGenericSubsystem()
   * @generated
   */
  EAttribute getGenericSubsystem_Name();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.GenericSubsystem#getSortingIndex <em>Sorting Index</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Sorting Index</em>'.
   * @see zf.pios.configurator.GenericSubsystem#getSortingIndex()
   * @see #getGenericSubsystem()
   * @generated
   */
  EAttribute getGenericSubsystem_SortingIndex();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputDriverType <em>Input Driver Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Driver Type</em>'.
   * @see zf.pios.configurator.InputDriverType
   * @generated
   */
  EClass getInputDriverType();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputDriverType <em>Output Driver Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Driver Type</em>'.
   * @see zf.pios.configurator.OutputDriverType
   * @generated
   */
  EClass getOutputDriverType();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputConfigSubsystemAnalog <em>Input Config Subsystem Analog</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Config Subsystem Analog</em>'.
   * @see zf.pios.configurator.InputConfigSubsystemAnalog
   * @generated
   */
  EClass getInputConfigSubsystemAnalog();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputConfigSubsystemTemperature <em>Input Config Subsystem Temperature</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Config Subsystem Temperature</em>'.
   * @see zf.pios.configurator.InputConfigSubsystemTemperature
   * @generated
   */
  EClass getInputConfigSubsystemTemperature();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputConfigSubsystemElDiag <em>Output Config Subsystem El Diag</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Config Subsystem El Diag</em>'.
   * @see zf.pios.configurator.OutputConfigSubsystemElDiag
   * @generated
   */
  EClass getOutputConfigSubsystemElDiag();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.OutputConfigSubsystemElDiag#getTempSensor <em>Temp Sensor</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Temp Sensor</em>'.
   * @see zf.pios.configurator.OutputConfigSubsystemElDiag#getTempSensor()
   * @see #getOutputConfigSubsystemElDiag()
   * @generated
   */
  EReference getOutputConfigSubsystemElDiag_TempSensor();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputConfigSubsystemSPI <em>Input Config Subsystem SPI</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Config Subsystem SPI</em>'.
   * @see zf.pios.configurator.InputConfigSubsystemSPI
   * @generated
   */
  EClass getInputConfigSubsystemSPI();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputConfigSubsystemDigital <em>Input Config Subsystem Digital</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Config Subsystem Digital</em>'.
   * @see zf.pios.configurator.InputConfigSubsystemDigital
   * @generated
   */
  EClass getInputConfigSubsystemDigital();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputConfigSubsystemFrq <em>Input Config Subsystem Frq</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Config Subsystem Frq</em>'.
   * @see zf.pios.configurator.InputConfigSubsystemFrq
   * @generated
   */
  EClass getInputConfigSubsystemFrq();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputConfigSubsystemPWM <em>Output Config Subsystem PWM</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Config Subsystem PWM</em>'.
   * @see zf.pios.configurator.OutputConfigSubsystemPWM
   * @generated
   */
  EClass getOutputConfigSubsystemPWM();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputConfigSubsystemDigital <em>Output Config Subsystem Digital</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Config Subsystem Digital</em>'.
   * @see zf.pios.configurator.OutputConfigSubsystemDigital
   * @generated
   */
  EClass getOutputConfigSubsystemDigital();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputConfigSubsystemItem <em>Input Config Subsystem Item</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Config Subsystem Item</em>'.
   * @see zf.pios.configurator.InputConfigSubsystemItem
   * @generated
   */
  EClass getInputConfigSubsystemItem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputConfigSubsystemItem <em>Output Config Subsystem Item</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Config Subsystem Item</em>'.
   * @see zf.pios.configurator.OutputConfigSubsystemItem
   * @generated
   */
  EClass getOutputConfigSubsystemItem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.DriverToECU <em>Driver To ECU</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Driver To ECU</em>'.
   * @see zf.pios.configurator.DriverToECU
   * @generated
   */
  EClass getDriverToECU();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.DriverToECU#getInputAnalogDrivers <em>Input Analog Drivers</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Analog Drivers</em>'.
   * @see zf.pios.configurator.DriverToECU#getInputAnalogDrivers()
   * @see #getDriverToECU()
   * @generated
   */
  EReference getDriverToECU_InputAnalogDrivers();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.DriverToECU#getInputDigitalDrivers <em>Input Digital Drivers</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Digital Drivers</em>'.
   * @see zf.pios.configurator.DriverToECU#getInputDigitalDrivers()
   * @see #getDriverToECU()
   * @generated
   */
  EReference getDriverToECU_InputDigitalDrivers();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.DriverToECU#getInputDigDriversTable <em>Input Dig Drivers Table</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Input Dig Drivers Table</em>'.
   * @see zf.pios.configurator.DriverToECU#getInputDigDriversTable()
   * @see #getDriverToECU()
   * @generated
   */
  EReference getDriverToECU_InputDigDriversTable();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.DriverToECU#getOutputDigitalDrivers <em>Output Digital Drivers</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Output Digital Drivers</em>'.
   * @see zf.pios.configurator.DriverToECU#getOutputDigitalDrivers()
   * @see #getDriverToECU()
   * @generated
   */
  EReference getDriverToECU_OutputDigitalDrivers();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.DriverToECU#getOutputDigDriversTable <em>Output Dig Drivers Table</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Output Dig Drivers Table</em>'.
   * @see zf.pios.configurator.DriverToECU#getOutputDigDriversTable()
   * @see #getDriverToECU()
   * @generated
   */
  EReference getDriverToECU_OutputDigDriversTable();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.TempSensorSubsystem <em>Temp Sensor Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Temp Sensor Subsystem</em>'.
   * @see zf.pios.configurator.TempSensorSubsystem
   * @generated
   */
  EClass getTempSensorSubsystem();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.TempSensorSubsystem#getDriver <em>Driver</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Driver</em>'.
   * @see zf.pios.configurator.TempSensorSubsystem#getDriver()
   * @see #getTempSensorSubsystem()
   * @generated
   */
  EReference getTempSensorSubsystem_Driver();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputAnalogDrivers <em>Input Analog Drivers</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Analog Drivers</em>'.
   * @see zf.pios.configurator.InputAnalogDrivers
   * @generated
   */
  EClass getInputAnalogDrivers();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.InputAnalogDrivers#getDriver <em>Driver</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Driver</em>'.
   * @see zf.pios.configurator.InputAnalogDrivers#getDriver()
   * @see #getInputAnalogDrivers()
   * @generated
   */
  EReference getInputAnalogDrivers_Driver();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputDigitalDrivers <em>Input Digital Drivers</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Digital Drivers</em>'.
   * @see zf.pios.configurator.InputDigitalDrivers
   * @generated
   */
  EClass getInputDigitalDrivers();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.InputDigitalDrivers#getDriver <em>Driver</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Driver</em>'.
   * @see zf.pios.configurator.InputDigitalDrivers#getDriver()
   * @see #getInputDigitalDrivers()
   * @generated
   */
  EReference getInputDigitalDrivers_Driver();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputDigitalDrivers <em>Output Digital Drivers</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Digital Drivers</em>'.
   * @see zf.pios.configurator.OutputDigitalDrivers
   * @generated
   */
  EClass getOutputDigitalDrivers();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.OutputDigitalDrivers#getDriver <em>Driver</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Driver</em>'.
   * @see zf.pios.configurator.OutputDigitalDrivers#getDriver()
   * @see #getOutputDigitalDrivers()
   * @generated
   */
  EReference getOutputDigitalDrivers_Driver();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.AnalogDriver <em>Analog Driver</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Analog Driver</em>'.
   * @see zf.pios.configurator.AnalogDriver
   * @generated
   */
  EClass getAnalogDriver();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.AnalogDriver#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.AnalogDriver#getName()
   * @see #getAnalogDriver()
   * @generated
   */
  EAttribute getAnalogDriver_Name();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.AnalogDriver#getDriverSetup <em>Driver Setup</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Driver Setup</em>'.
   * @see zf.pios.configurator.AnalogDriver#getDriverSetup()
   * @see #getAnalogDriver()
   * @generated
   */
  EReference getAnalogDriver_DriverSetup();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InDigDriver <em>In Dig Driver</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>In Dig Driver</em>'.
   * @see zf.pios.configurator.InDigDriver
   * @generated
   */
  EClass getInDigDriver();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.InDigDriver#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.InDigDriver#getName()
   * @see #getInDigDriver()
   * @generated
   */
  EAttribute getInDigDriver_Name();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.InDigDriver#getDriverSetup <em>Driver Setup</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Driver Setup</em>'.
   * @see zf.pios.configurator.InDigDriver#getDriverSetup()
   * @see #getInDigDriver()
   * @generated
   */
  EReference getInDigDriver_DriverSetup();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutDigDriver <em>Out Dig Driver</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Out Dig Driver</em>'.
   * @see zf.pios.configurator.OutDigDriver
   * @generated
   */
  EClass getOutDigDriver();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.OutDigDriver#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.OutDigDriver#getName()
   * @see #getOutDigDriver()
   * @generated
   */
  EAttribute getOutDigDriver_Name();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.OutDigDriver#getDriverSetup <em>Driver Setup</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Driver Setup</em>'.
   * @see zf.pios.configurator.OutDigDriver#getDriverSetup()
   * @see #getOutDigDriver()
   * @generated
   */
  EReference getOutDigDriver_DriverSetup();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.CommonDriver <em>Common Driver</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Common Driver</em>'.
   * @see zf.pios.configurator.CommonDriver
   * @generated
   */
  EClass getCommonDriver();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.CommonDriver#getDriverIndex <em>Driver Index</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Driver Index</em>'.
   * @see zf.pios.configurator.CommonDriver#getDriverIndex()
   * @see #getCommonDriver()
   * @generated
   */
  EAttribute getCommonDriver_DriverIndex();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.CommonDriver#getControllerPinName <em>Controller Pin Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Controller Pin Name</em>'.
   * @see zf.pios.configurator.CommonDriver#getControllerPinName()
   * @see #getCommonDriver()
   * @generated
   */
  EAttribute getCommonDriver_ControllerPinName();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.CommonDriver#getDescription <em>Description</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Description</em>'.
   * @see zf.pios.configurator.CommonDriver#getDescription()
   * @see #getCommonDriver()
   * @generated
   */
  EAttribute getCommonDriver_Description();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InputDigDriversTable <em>Input Dig Drivers Table</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input Dig Drivers Table</em>'.
   * @see zf.pios.configurator.InputDigDriversTable
   * @generated
   */
  EClass getInputDigDriversTable();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.InputDigDriversTable#getDigitalDriverTableRef <em>Digital Driver Table Ref</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Digital Driver Table Ref</em>'.
   * @see zf.pios.configurator.InputDigDriversTable#getDigitalDriverTableRef()
   * @see #getInputDigDriversTable()
   * @generated
   */
  EReference getInputDigDriversTable_DigitalDriverTableRef();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutputDigDriversTable <em>Output Dig Drivers Table</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Output Dig Drivers Table</em>'.
   * @see zf.pios.configurator.OutputDigDriversTable
   * @generated
   */
  EClass getOutputDigDriversTable();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.OutputDigDriversTable#getDigitalDriverTableRef <em>Digital Driver Table Ref</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Digital Driver Table Ref</em>'.
   * @see zf.pios.configurator.OutputDigDriversTable#getDigitalDriverTableRef()
   * @see #getOutputDigDriversTable()
   * @generated
   */
  EReference getOutputDigDriversTable_DigitalDriverTableRef();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.InDigitalDriverTableRef <em>In Digital Driver Table Ref</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>In Digital Driver Table Ref</em>'.
   * @see zf.pios.configurator.InDigitalDriverTableRef
   * @generated
   */
  EClass getInDigitalDriverTableRef();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.InDigitalDriverTableRef#getDummySignal <em>Dummy Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dummy Signal</em>'.
   * @see zf.pios.configurator.InDigitalDriverTableRef#getDummySignal()
   * @see #getInDigitalDriverTableRef()
   * @generated
   */
  EAttribute getInDigitalDriverTableRef_DummySignal();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.InDigitalDriverTableRef#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Name</em>'.
   * @see zf.pios.configurator.InDigitalDriverTableRef#getName()
   * @see #getInDigitalDriverTableRef()
   * @generated
   */
  EReference getInDigitalDriverTableRef_Name();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OutDigitalDriverTableRef <em>Out Digital Driver Table Ref</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Out Digital Driver Table Ref</em>'.
   * @see zf.pios.configurator.OutDigitalDriverTableRef
   * @generated
   */
  EClass getOutDigitalDriverTableRef();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.OutDigitalDriverTableRef#getDummySignal <em>Dummy Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dummy Signal</em>'.
   * @see zf.pios.configurator.OutDigitalDriverTableRef#getDummySignal()
   * @see #getOutDigitalDriverTableRef()
   * @generated
   */
  EAttribute getOutDigitalDriverTableRef_DummySignal();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.OutDigitalDriverTableRef#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Name</em>'.
   * @see zf.pios.configurator.OutDigitalDriverTableRef#getName()
   * @see #getOutDigitalDriverTableRef()
   * @generated
   */
  EReference getOutDigitalDriverTableRef_Name();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.ElectricDiagSubsystem <em>Electric Diag Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Electric Diag Subsystem</em>'.
   * @see zf.pios.configurator.ElectricDiagSubsystem
   * @generated
   */
  EClass getElectricDiagSubsystem();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.ElectricDiagSubsystem#getElDiag <em>El Diag</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>El Diag</em>'.
   * @see zf.pios.configurator.ElectricDiagSubsystem#getElDiag()
   * @see #getElectricDiagSubsystem()
   * @generated
   */
  EReference getElectricDiagSubsystem_ElDiag();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.ElDiag <em>El Diag</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>El Diag</em>'.
   * @see zf.pios.configurator.ElDiag
   * @generated
   */
  EClass getElDiag();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ElDiag#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.ElDiag#getName()
   * @see #getElDiag()
   * @generated
   */
  EAttribute getElDiag_Name();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ElDiag#getEnable <em>Enable</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Enable</em>'.
   * @see zf.pios.configurator.ElDiag#getEnable()
   * @see #getElDiag()
   * @generated
   */
  EAttribute getElDiag_Enable();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ElDiag#getDiagnosisEnable <em>Diagnosis Enable</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Diagnosis Enable</em>'.
   * @see zf.pios.configurator.ElDiag#getDiagnosisEnable()
   * @see #getElDiag()
   * @generated
   */
  EAttribute getElDiag_DiagnosisEnable();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ElDiag#getDriverIndex <em>Driver Index</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Driver Index</em>'.
   * @see zf.pios.configurator.ElDiag#getDriverIndex()
   * @see #getElDiag()
   * @generated
   */
  EAttribute getElDiag_DriverIndex();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ElDiag#getPwmDiagnosis <em>Pwm Diagnosis</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Pwm Diagnosis</em>'.
   * @see zf.pios.configurator.ElDiag#getPwmDiagnosis()
   * @see #getElDiag()
   * @generated
   */
  EAttribute getElDiag_PwmDiagnosis();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.ElDiag#getPowerSupplySignal <em>Power Supply Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Power Supply Signal</em>'.
   * @see zf.pios.configurator.ElDiag#getPowerSupplySignal()
   * @see #getElDiag()
   * @generated
   */
  EReference getElDiag_PowerSupplySignal();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.ElDiag#getDescription <em>Description</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Description</em>'.
   * @see zf.pios.configurator.ElDiag#getDescription()
   * @see #getElDiag()
   * @generated
   */
  EAttribute getElDiag_Description();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.FrequencySubsystem <em>Frequency Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Frequency Subsystem</em>'.
   * @see zf.pios.configurator.FrequencySubsystem
   * @generated
   */
  EClass getFrequencySubsystem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.IFRQ <em>IFRQ</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>IFRQ</em>'.
   * @see zf.pios.configurator.IFRQ
   * @generated
   */
  EClass getIFRQ();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IFRQ#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.IFRQ#getName()
   * @see #getIFRQ()
   * @generated
   */
  EAttribute getIFRQ_Name();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IFRQ#getDriverIndex <em>Driver Index</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Driver Index</em>'.
   * @see zf.pios.configurator.IFRQ#getDriverIndex()
   * @see #getIFRQ()
   * @generated
   */
  EAttribute getIFRQ_DriverIndex();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.IFRQ#getSensorIndex <em>Sensor Index</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Sensor Index</em>'.
   * @see zf.pios.configurator.IFRQ#getSensorIndex()
   * @see #getIFRQ()
   * @generated
   */
  EReference getIFRQ_SensorIndex();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IFRQ#getUpdateTime <em>Update Time</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Update Time</em>'.
   * @see zf.pios.configurator.IFRQ#getUpdateTime()
   * @see #getIFRQ()
   * @generated
   */
  EAttribute getIFRQ_UpdateTime();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IFRQ#getActive <em>Active</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Active</em>'.
   * @see zf.pios.configurator.IFRQ#getActive()
   * @see #getIFRQ()
   * @generated
   */
  EAttribute getIFRQ_Active();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.IFRQSensor <em>IFRQ Sensor</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>IFRQ Sensor</em>'.
   * @see zf.pios.configurator.IFRQSensor
   * @generated
   */
  EClass getIFRQSensor();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IFRQSensor#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.IFRQSensor#getName()
   * @see #getIFRQSensor()
   * @generated
   */
  EAttribute getIFRQSensor_Name();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IFRQSensor#getInitialWaitingTime <em>Initial Waiting Time</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Initial Waiting Time</em>'.
   * @see zf.pios.configurator.IFRQSensor#getInitialWaitingTime()
   * @see #getIFRQSensor()
   * @generated
   */
  EAttribute getIFRQSensor_InitialWaitingTime();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IFRQSensor#getDirChangeMinPeriods <em>Dir Change Min Periods</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Dir Change Min Periods</em>'.
   * @see zf.pios.configurator.IFRQSensor#getDirChangeMinPeriods()
   * @see #getIFRQSensor()
   * @generated
   */
  EAttribute getIFRQSensor_DirChangeMinPeriods();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IFRQSensor#getDirectionChangeDebounceTime <em>Direction Change Debounce Time</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Direction Change Debounce Time</em>'.
   * @see zf.pios.configurator.IFRQSensor#getDirectionChangeDebounceTime()
   * @see #getIFRQSensor()
   * @generated
   */
  EAttribute getIFRQSensor_DirectionChangeDebounceTime();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.SPIinputSys <em>SP Iinput Sys</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>SP Iinput Sys</em>'.
   * @see zf.pios.configurator.SPIinputSys
   * @generated
   */
  EClass getSPIinputSys();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.SPIinputSys#getSpi <em>Spi</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Spi</em>'.
   * @see zf.pios.configurator.SPIinputSys#getSpi()
   * @see #getSPIinputSys()
   * @generated
   */
  EReference getSPIinputSys_Spi();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.SPI <em>SPI</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>SPI</em>'.
   * @see zf.pios.configurator.SPI
   * @generated
   */
  EClass getSPI();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPI#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.SPI#getName()
   * @see #getSPI()
   * @generated
   */
  EAttribute getSPI_Name();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPI#getDriverIndex <em>Driver Index</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Driver Index</em>'.
   * @see zf.pios.configurator.SPI#getDriverIndex()
   * @see #getSPI()
   * @generated
   */
  EAttribute getSPI_DriverIndex();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPI#getDataStorageMode <em>Data Storage Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Data Storage Mode</em>'.
   * @see zf.pios.configurator.SPI#getDataStorageMode()
   * @see #getSPI()
   * @generated
   */
  EAttribute getSPI_DataStorageMode();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPI#getCommand <em>Command</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Command</em>'.
   * @see zf.pios.configurator.SPI#getCommand()
   * @see #getSPI()
   * @generated
   */
  EAttribute getSPI_Command();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPI#getDataLength <em>Data Length</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Data Length</em>'.
   * @see zf.pios.configurator.SPI#getDataLength()
   * @see #getSPI()
   * @generated
   */
  EAttribute getSPI_DataLength();

  /**
   * Returns the meta object for the containment reference '{@link zf.pios.configurator.SPI#getSpitxData <em>Spitx Data</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Spitx Data</em>'.
   * @see zf.pios.configurator.SPI#getSpitxData()
   * @see #getSPI()
   * @generated
   */
  EReference getSPI_SpitxData();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPI#getModule <em>Module</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Module</em>'.
   * @see zf.pios.configurator.SPI#getModule()
   * @see #getSPI()
   * @generated
   */
  EAttribute getSPI_Module();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPI#getDescription <em>Description</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Description</em>'.
   * @see zf.pios.configurator.SPI#getDescription()
   * @see #getSPI()
   * @generated
   */
  EAttribute getSPI_Description();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.SPITXData <em>SPITX Data</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>SPITX Data</em>'.
   * @see zf.pios.configurator.SPITXData
   * @generated
   */
  EClass getSPITXData();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPITXData#getByteOne <em>Byte One</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Byte One</em>'.
   * @see zf.pios.configurator.SPITXData#getByteOne()
   * @see #getSPITXData()
   * @generated
   */
  EAttribute getSPITXData_ByteOne();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPITXData#getByteTwo <em>Byte Two</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Byte Two</em>'.
   * @see zf.pios.configurator.SPITXData#getByteTwo()
   * @see #getSPITXData()
   * @generated
   */
  EAttribute getSPITXData_ByteTwo();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPITXData#getByteThree <em>Byte Three</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Byte Three</em>'.
   * @see zf.pios.configurator.SPITXData#getByteThree()
   * @see #getSPITXData()
   * @generated
   */
  EAttribute getSPITXData_ByteThree();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.SPITXData#getByteFour <em>Byte Four</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Byte Four</em>'.
   * @see zf.pios.configurator.SPITXData#getByteFour()
   * @see #getSPITXData()
   * @generated
   */
  EAttribute getSPITXData_ByteFour();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OPWMSubsystem <em>OPWM Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>OPWM Subsystem</em>'.
   * @see zf.pios.configurator.OPWMSubsystem
   * @generated
   */
  EClass getOPWMSubsystem();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.OPWMSubsystem#getOpwm <em>Opwm</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Opwm</em>'.
   * @see zf.pios.configurator.OPWMSubsystem#getOpwm()
   * @see #getOPWMSubsystem()
   * @generated
   */
  EReference getOPWMSubsystem_Opwm();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.OPWM <em>OPWM</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>OPWM</em>'.
   * @see zf.pios.configurator.OPWM
   * @generated
   */
  EClass getOPWM();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.OPWM#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.OPWM#getName()
   * @see #getOPWM()
   * @generated
   */
  EAttribute getOPWM_Name();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.OPWM#getDriverIndex <em>Driver Index</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Driver Index</em>'.
   * @see zf.pios.configurator.OPWM#getDriverIndex()
   * @see #getOPWM()
   * @generated
   */
  EAttribute getOPWM_DriverIndex();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.OPWM#getPeriod <em>Period</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Period</em>'.
   * @see zf.pios.configurator.OPWM#getPeriod()
   * @see #getOPWM()
   * @generated
   */
  EAttribute getOPWM_Period();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.OPWM#getDescription <em>Description</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Description</em>'.
   * @see zf.pios.configurator.OPWM#getDescription()
   * @see #getOPWM()
   * @generated
   */
  EAttribute getOPWM_Description();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.IADC <em>IADC</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>IADC</em>'.
   * @see zf.pios.configurator.IADC
   * @generated
   */
  EClass getIADC();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IADC#getDriverIndex <em>Driver Index</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Driver Index</em>'.
   * @see zf.pios.configurator.IADC#getDriverIndex()
   * @see #getIADC()
   * @generated
   */
  EAttribute getIADC_DriverIndex();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IADC#getEnable <em>Enable</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Enable</em>'.
   * @see zf.pios.configurator.IADC#getEnable()
   * @see #getIADC()
   * @generated
   */
  EAttribute getIADC_Enable();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.IADC#getPowerSupplySignal <em>Power Supply Signal</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Power Supply Signal</em>'.
   * @see zf.pios.configurator.IADC#getPowerSupplySignal()
   * @see #getIADC()
   * @generated
   */
  EReference getIADC_PowerSupplySignal();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IADC#getEnableElDiagPowerSupplyOff <em>Enable El Diag Power Supply Off</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Enable El Diag Power Supply Off</em>'.
   * @see zf.pios.configurator.IADC#getEnableElDiagPowerSupplyOff()
   * @see #getIADC()
   * @generated
   */
  EAttribute getIADC_EnableElDiagPowerSupplyOff();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IADC#getElDiagInstanceIdx <em>El Diag Instance Idx</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>El Diag Instance Idx</em>'.
   * @see zf.pios.configurator.IADC#getElDiagInstanceIdx()
   * @see #getIADC()
   * @generated
   */
  EAttribute getIADC_ElDiagInstanceIdx();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IADC#getControllerPinName <em>Controller Pin Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Controller Pin Name</em>'.
   * @see zf.pios.configurator.IADC#getControllerPinName()
   * @see #getIADC()
   * @generated
   */
  EAttribute getIADC_ControllerPinName();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.IADC#getDescription <em>Description</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Description</em>'.
   * @see zf.pios.configurator.IADC#getDescription()
   * @see #getIADC()
   * @generated
   */
  EAttribute getIADC_Description();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.UserDefinedSubsystem <em>User Defined Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>User Defined Subsystem</em>'.
   * @see zf.pios.configurator.UserDefinedSubsystem
   * @generated
   */
  EClass getUserDefinedSubsystem();

  /**
   * Returns the meta object for the reference '{@link zf.pios.configurator.UserDefinedSubsystem#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Name</em>'.
   * @see zf.pios.configurator.UserDefinedSubsystem#getName()
   * @see #getUserDefinedSubsystem()
   * @generated
   */
  EReference getUserDefinedSubsystem_Name();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.UserDefinedSubsystem#getUserPort <em>User Port</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>User Port</em>'.
   * @see zf.pios.configurator.UserDefinedSubsystem#getUserPort()
   * @see #getUserDefinedSubsystem()
   * @generated
   */
  EReference getUserDefinedSubsystem_UserPort();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.ConfigSubsystemItem <em>Config Subsystem Item</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Config Subsystem Item</em>'.
   * @see zf.pios.configurator.ConfigSubsystemItem
   * @generated
   */
  EClass getConfigSubsystemItem();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.UserPort <em>User Port</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>User Port</em>'.
   * @see zf.pios.configurator.UserPort
   * @generated
   */
  EClass getUserPort();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.UserPort#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.UserPort#getName()
   * @see #getUserPort()
   * @generated
   */
  EAttribute getUserPort_Name();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.UserPort#getDriverIndex <em>Driver Index</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Driver Index</em>'.
   * @see zf.pios.configurator.UserPort#getDriverIndex()
   * @see #getUserPort()
   * @generated
   */
  EAttribute getUserPort_DriverIndex();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.UserPort#getDescription <em>Description</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Description</em>'.
   * @see zf.pios.configurator.UserPort#getDescription()
   * @see #getUserPort()
   * @generated
   */
  EAttribute getUserPort_Description();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Import <em>Import</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Import</em>'.
   * @see zf.pios.configurator.Import
   * @generated
   */
  EClass getImport();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Import#getImportURI <em>Import URI</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Import URI</em>'.
   * @see zf.pios.configurator.Import#getImportURI()
   * @see #getImport()
   * @generated
   */
  EAttribute getImport_ImportURI();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Import#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see zf.pios.configurator.Import#getName()
   * @see #getImport()
   * @generated
   */
  EAttribute getImport_Name();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.Imports <em>Imports</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Imports</em>'.
   * @see zf.pios.configurator.Imports
   * @generated
   */
  EClass getImports();

  /**
   * Returns the meta object for the attribute '{@link zf.pios.configurator.Imports#getImportedNamespace <em>Imported Namespace</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Imported Namespace</em>'.
   * @see zf.pios.configurator.Imports#getImportedNamespace()
   * @see #getImports()
   * @generated
   */
  EAttribute getImports_ImportedNamespace();

  /**
   * Returns the meta object for class '{@link zf.pios.configurator.FRQSubsystem <em>FRQ Subsystem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>FRQ Subsystem</em>'.
   * @see zf.pios.configurator.FRQSubsystem
   * @generated
   */
  EClass getFRQSubsystem();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.FRQSubsystem#getIfrqSensor <em>Ifrq Sensor</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Ifrq Sensor</em>'.
   * @see zf.pios.configurator.FRQSubsystem#getIfrqSensor()
   * @see #getFRQSubsystem()
   * @generated
   */
  EReference getFRQSubsystem_IfrqSensor();

  /**
   * Returns the meta object for the containment reference list '{@link zf.pios.configurator.FRQSubsystem#getIfrq <em>Ifrq</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Ifrq</em>'.
   * @see zf.pios.configurator.FRQSubsystem#getIfrq()
   * @see #getFRQSubsystem()
   * @generated
   */
  EReference getFRQSubsystem_Ifrq();

  /**
   * Returns the meta object for enum '{@link zf.pios.configurator.dataTypeEnumeration <em>data Type Enumeration</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>data Type Enumeration</em>'.
   * @see zf.pios.configurator.dataTypeEnumeration
   * @generated
   */
  EEnum getdataTypeEnumeration();

  /**
   * Returns the meta object for enum '{@link zf.pios.configurator.iadcEnableEnumeration <em>iadc Enable Enumeration</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>iadc Enable Enumeration</em>'.
   * @see zf.pios.configurator.iadcEnableEnumeration
   * @generated
   */
  EEnum getiadcEnableEnumeration();

  /**
   * Returns the meta object for enum '{@link zf.pios.configurator.BOOLfalseDefault <em>BOO Lfalse Default</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>BOO Lfalse Default</em>'.
   * @see zf.pios.configurator.BOOLfalseDefault
   * @generated
   */
  EEnum getBOOLfalseDefault();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  ConfiguratorFactory getConfiguratorFactory();

  /**
   * <!-- begin-user-doc -->
   * Defines literals for the meta objects that represent
   * <ul>
   *   <li>each class,</li>
   *   <li>each feature of each class,</li>
   *   <li>each enum,</li>
   *   <li>and each data type</li>
   * </ul>
   * <!-- end-user-doc -->
   * @generated
   */
  interface Literals
  {
    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ConfigurationImpl <em>Configuration</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ConfigurationImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfiguration()
     * @generated
     */
    EClass CONFIGURATION = eINSTANCE.getConfiguration();

    /**
     * The meta object literal for the '<em><b>Configuration Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CONFIGURATION__CONFIGURATION_NAME = eINSTANCE.getConfiguration_ConfigurationName();

    /**
     * The meta object literal for the '<em><b>Version</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CONFIGURATION__VERSION = eINSTANCE.getConfiguration_Version();

    /**
     * The meta object literal for the '<em><b>Main Merge File</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CONFIGURATION__MAIN_MERGE_FILE = eINSTANCE.getConfiguration_MainMergeFile();

    /**
     * The meta object literal for the '<em><b>Imports</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONFIGURATION__IMPORTS = eINSTANCE.getConfiguration_Imports();

    /**
     * The meta object literal for the '<em><b>Variants</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONFIGURATION__VARIANTS = eINSTANCE.getConfiguration_Variants();

    /**
     * The meta object literal for the '<em><b>System</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONFIGURATION__SYSTEM = eINSTANCE.getConfiguration_System();

    /**
     * The meta object literal for the '<em><b>Hardware</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONFIGURATION__HARDWARE = eINSTANCE.getConfiguration_Hardware();

    /**
     * The meta object literal for the '<em><b>Signals</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONFIGURATION__SIGNALS = eINSTANCE.getConfiguration_Signals();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.SystemImpl <em>System</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.SystemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSystem()
     * @generated
     */
    EClass SYSTEM = eINSTANCE.getSystem();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SYSTEM__NAME = eINSTANCE.getSystem_Name();

    /**
     * The meta object literal for the '<em><b>Config Subsystem</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SYSTEM__CONFIG_SUBSYSTEM = eINSTANCE.getSystem_ConfigSubsystem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.SignalsImpl <em>Signals</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.SignalsImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSignals()
     * @generated
     */
    EClass SIGNALS = eINSTANCE.getSignals();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SIGNALS__NAME = eINSTANCE.getSignals_Name();

    /**
     * The meta object literal for the '<em><b>Pios Signals</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SIGNALS__PIOS_SIGNALS = eINSTANCE.getSignals_PiosSignals();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.GeneralSignalsImpl <em>General Signals</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.GeneralSignalsImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getGeneralSignals()
     * @generated
     */
    EClass GENERAL_SIGNALS = eINSTANCE.getGeneralSignals();

    /**
     * The meta object literal for the '<em><b>General Signal</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference GENERAL_SIGNALS__GENERAL_SIGNAL = eINSTANCE.getGeneralSignals_GeneralSignal();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.GeneralSignalImpl <em>General Signal</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.GeneralSignalImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getGeneralSignal()
     * @generated
     */
    EClass GENERAL_SIGNAL = eINSTANCE.getGeneralSignal();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute GENERAL_SIGNAL__NAME = eINSTANCE.getGeneralSignal_Name();

    /**
     * The meta object literal for the '<em><b>Signal</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference GENERAL_SIGNAL__SIGNAL = eINSTANCE.getGeneralSignal_Signal();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputSignalImpl <em>Input Signal</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputSignalImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputSignal()
     * @generated
     */
    EClass INPUT_SIGNAL = eINSTANCE.getInputSignal();

    /**
     * The meta object literal for the '<em><b>Power Supply</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute INPUT_SIGNAL__POWER_SUPPLY = eINSTANCE.getInputSignal_PowerSupply();

    /**
     * The meta object literal for the '<em><b>Datafield</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_SIGNAL__DATAFIELD = eINSTANCE.getInputSignal_Datafield();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputSignalImpl <em>Output Signal</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputSignalImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputSignal()
     * @generated
     */
    EClass OUTPUT_SIGNAL = eINSTANCE.getOutputSignal();

    /**
     * The meta object literal for the '<em><b>Pull Up Resistor Signal</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute OUTPUT_SIGNAL__PULL_UP_RESISTOR_SIGNAL = eINSTANCE.getOutputSignal_PullUpResistorSignal();

    /**
     * The meta object literal for the '<em><b>Datafield</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_SIGNAL__DATAFIELD = eINSTANCE.getOutputSignal_Datafield();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.DatafieldImpl <em>Datafield</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.DatafieldImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getDatafield()
     * @generated
     */
    EClass DATAFIELD = eINSTANCE.getDatafield();

    /**
     * The meta object literal for the '<em><b>Variant Name</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DATAFIELD__VARIANT_NAME = eINSTANCE.getDatafield_VariantName();

    /**
     * The meta object literal for the '<em><b>Lower Limit</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute DATAFIELD__LOWER_LIMIT = eINSTANCE.getDatafield_LowerLimit();

    /**
     * The meta object literal for the '<em><b>Upper Limit</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute DATAFIELD__UPPER_LIMIT = eINSTANCE.getDatafield_UpperLimit();

    /**
     * The meta object literal for the '<em><b>Init Value</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute DATAFIELD__INIT_VALUE = eINSTANCE.getDatafield_InitValue();

    /**
     * The meta object literal for the '<em><b>Portname</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DATAFIELD__PORTNAME = eINSTANCE.getDatafield_Portname();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputDatafieldImpl <em>Input Datafield</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputDatafieldImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputDatafield()
     * @generated
     */
    EClass INPUT_DATAFIELD = eINSTANCE.getInputDatafield();

    /**
     * The meta object literal for the '<em><b>Sub System</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_DATAFIELD__SUB_SYSTEM = eINSTANCE.getInputDatafield_SubSystem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputDatafieldImpl <em>Output Datafield</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputDatafieldImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputDatafield()
     * @generated
     */
    EClass OUTPUT_DATAFIELD = eINSTANCE.getOutputDatafield();

    /**
     * The meta object literal for the '<em><b>Sub System</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_DATAFIELD__SUB_SYSTEM = eINSTANCE.getOutputDatafield_SubSystem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.PortnameImpl <em>Portname</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.PortnameImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getPortname()
     * @generated
     */
    EClass PORTNAME = eINSTANCE.getPortname();

    /**
     * The meta object literal for the '<em><b>Number</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute PORTNAME__NUMBER = eINSTANCE.getPortname_Number();

    /**
     * The meta object literal for the '<em><b>Port</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference PORTNAME__PORT = eINSTANCE.getPortname_Port();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.VariantsImpl <em>Variants</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.VariantsImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getVariants()
     * @generated
     */
    EClass VARIANTS = eINSTANCE.getVariants();

    /**
     * The meta object literal for the '<em><b>Variants</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference VARIANTS__VARIANTS = eINSTANCE.getVariants_Variants();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.VariantImpl <em>Variant</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.VariantImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getVariant()
     * @generated
     */
    EClass VARIANT = eINSTANCE.getVariant();

    /**
     * The meta object literal for the '<em><b>Default Variant</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute VARIANT__DEFAULT_VARIANT = eINSTANCE.getVariant_DefaultVariant();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute VARIANT__NAME = eINSTANCE.getVariant_Name();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.SignalImpl <em>Signal</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.SignalImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSignal()
     * @generated
     */
    EClass SIGNAL = eINSTANCE.getSignal();

    /**
     * The meta object literal for the '<em><b>Data Type</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SIGNAL__DATA_TYPE = eINSTANCE.getSignal_DataType();

    /**
     * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SIGNAL__DESCRIPTION = eINSTANCE.getSignal_Description();

    /**
     * The meta object literal for the '<em><b>Asap Measurment</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SIGNAL__ASAP_MEASURMENT = eINSTANCE.getSignal_AsapMeasurment();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ASAPMeasurmentImpl <em>ASAP Measurment</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ASAPMeasurmentImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getASAPMeasurment()
     * @generated
     */
    EClass ASAP_MEASURMENT = eINSTANCE.getASAPMeasurment();

    /**
     * The meta object literal for the '<em><b>Lower Limit</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ASAP_MEASURMENT__LOWER_LIMIT = eINSTANCE.getASAPMeasurment_LowerLimit();

    /**
     * The meta object literal for the '<em><b>Upper Limit</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ASAP_MEASURMENT__UPPER_LIMIT = eINSTANCE.getASAPMeasurment_UpperLimit();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.HardwareImpl <em>Hardware</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.HardwareImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getHardware()
     * @generated
     */
    EClass HARDWARE = eINSTANCE.getHardware();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute HARDWARE__NAME = eINSTANCE.getHardware_Name();

    /**
     * The meta object literal for the '<em><b>Driver To ECU</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference HARDWARE__DRIVER_TO_ECU = eINSTANCE.getHardware_DriverToECU();

    /**
     * The meta object literal for the '<em><b>Temp Sensor Subsystem</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference HARDWARE__TEMP_SENSOR_SUBSYSTEM = eINSTANCE.getHardware_TempSensorSubsystem();

    /**
     * The meta object literal for the '<em><b>Electric Diag Subsystem</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference HARDWARE__ELECTRIC_DIAG_SUBSYSTEM = eINSTANCE.getHardware_ElectricDiagSubsystem();

    /**
     * The meta object literal for the '<em><b>Frequency Subsystem</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference HARDWARE__FREQUENCY_SUBSYSTEM = eINSTANCE.getHardware_FrequencySubsystem();

    /**
     * The meta object literal for the '<em><b>Spi Subsystem</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference HARDWARE__SPI_SUBSYSTEM = eINSTANCE.getHardware_SpiSubsystem();

    /**
     * The meta object literal for the '<em><b>Opwm Subsystem</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference HARDWARE__OPWM_SUBSYSTEM = eINSTANCE.getHardware_OpwmSubsystem();

    /**
     * The meta object literal for the '<em><b>User Defined Subsystem</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference HARDWARE__USER_DEFINED_SUBSYSTEM = eINSTANCE.getHardware_UserDefinedSubsystem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ConfigSubsystemImpl <em>Config Subsystem</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ConfigSubsystemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfigSubsystem()
     * @generated
     */
    EClass CONFIG_SUBSYSTEM = eINSTANCE.getConfigSubsystem();

    /**
     * The meta object literal for the '<em><b>Config Subsystem Input</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT = eINSTANCE.getConfigSubsystem_ConfigSubsystemInput();

    /**
     * The meta object literal for the '<em><b>Config Subsystem Output</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT = eINSTANCE.getConfigSubsystem_ConfigSubsystemOutput();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ConfigSubsystemInputImpl <em>Config Subsystem Input</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ConfigSubsystemInputImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfigSubsystemInput()
     * @generated
     */
    EClass CONFIG_SUBSYSTEM_INPUT = eINSTANCE.getConfigSubsystemInput();

    /**
     * The meta object literal for the '<em><b>Maximal Number Input Subsystems</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CONFIG_SUBSYSTEM_INPUT__MAXIMAL_NUMBER_INPUT_SUBSYSTEMS = eINSTANCE.getConfigSubsystemInput_MaximalNumberInputSubsystems();

    /**
     * The meta object literal for the '<em><b>Input Subsystems</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS = eINSTANCE.getConfigSubsystemInput_InputSubsystems();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ConfigSubsystemOutputImpl <em>Config Subsystem Output</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ConfigSubsystemOutputImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfigSubsystemOutput()
     * @generated
     */
    EClass CONFIG_SUBSYSTEM_OUTPUT = eINSTANCE.getConfigSubsystemOutput();

    /**
     * The meta object literal for the '<em><b>Maximal Number Output Subsystems</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CONFIG_SUBSYSTEM_OUTPUT__MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS = eINSTANCE.getConfigSubsystemOutput_MaximalNumberOutputSubsystems();

    /**
     * The meta object literal for the '<em><b>Output Subsystems</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS = eINSTANCE.getConfigSubsystemOutput_OutputSubsystems();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputSubsystemsImpl <em>Input Subsystems</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputSubsystemsImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputSubsystems()
     * @generated
     */
    EClass INPUT_SUBSYSTEMS = eINSTANCE.getInputSubsystems();

    /**
     * The meta object literal for the '<em><b>Input Null</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_SUBSYSTEMS__INPUT_NULL = eINSTANCE.getInputSubsystems_InputNull();

    /**
     * The meta object literal for the '<em><b>Input Analog</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_SUBSYSTEMS__INPUT_ANALOG = eINSTANCE.getInputSubsystems_InputAnalog();

    /**
     * The meta object literal for the '<em><b>Input Temperature</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_SUBSYSTEMS__INPUT_TEMPERATURE = eINSTANCE.getInputSubsystems_InputTemperature();

    /**
     * The meta object literal for the '<em><b>Input Digital</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_SUBSYSTEMS__INPUT_DIGITAL = eINSTANCE.getInputSubsystems_InputDigital();

    /**
     * The meta object literal for the '<em><b>Input Frq</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_SUBSYSTEMS__INPUT_FRQ = eINSTANCE.getInputSubsystems_InputFrq();

    /**
     * The meta object literal for the '<em><b>Input SPI</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_SUBSYSTEMS__INPUT_SPI = eINSTANCE.getInputSubsystems_InputSPI();

    /**
     * The meta object literal for the '<em><b>Input Config Subsystem</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_SUBSYSTEMS__INPUT_CONFIG_SUBSYSTEM = eINSTANCE.getInputSubsystems_InputConfigSubsystem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputSubsystemsImpl <em>Output Subsystems</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputSubsystemsImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputSubsystems()
     * @generated
     */
    EClass OUTPUT_SUBSYSTEMS = eINSTANCE.getOutputSubsystems();

    /**
     * The meta object literal for the '<em><b>Output Null</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_SUBSYSTEMS__OUTPUT_NULL = eINSTANCE.getOutputSubsystems_OutputNull();

    /**
     * The meta object literal for the '<em><b>Output Digital</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL = eINSTANCE.getOutputSubsystems_OutputDigital();

    /**
     * The meta object literal for the '<em><b>Output PWM</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_SUBSYSTEMS__OUTPUT_PWM = eINSTANCE.getOutputSubsystems_OutputPWM();

    /**
     * The meta object literal for the '<em><b>Output El Diag</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG = eINSTANCE.getOutputSubsystems_OutputElDiag();

    /**
     * The meta object literal for the '<em><b>Output Config Subsystem</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_SUBSYSTEMS__OUTPUT_CONFIG_SUBSYSTEM = eINSTANCE.getOutputSubsystems_OutputConfigSubsystem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputConfigSubsystemNullImpl <em>Input Config Subsystem Null</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputConfigSubsystemNullImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemNull()
     * @generated
     */
    EClass INPUT_CONFIG_SUBSYSTEM_NULL = eINSTANCE.getInputConfigSubsystemNull();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemNullImpl <em>Output Config Subsystem Null</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputConfigSubsystemNullImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemNull()
     * @generated
     */
    EClass OUTPUT_CONFIG_SUBSYSTEM_NULL = eINSTANCE.getOutputConfigSubsystemNull();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.GenericSubsystemImpl <em>Generic Subsystem</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.GenericSubsystemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getGenericSubsystem()
     * @generated
     */
    EClass GENERIC_SUBSYSTEM = eINSTANCE.getGenericSubsystem();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute GENERIC_SUBSYSTEM__NAME = eINSTANCE.getGenericSubsystem_Name();

    /**
     * The meta object literal for the '<em><b>Sorting Index</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute GENERIC_SUBSYSTEM__SORTING_INDEX = eINSTANCE.getGenericSubsystem_SortingIndex();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputDriverTypeImpl <em>Input Driver Type</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputDriverTypeImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputDriverType()
     * @generated
     */
    EClass INPUT_DRIVER_TYPE = eINSTANCE.getInputDriverType();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputDriverTypeImpl <em>Output Driver Type</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputDriverTypeImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputDriverType()
     * @generated
     */
    EClass OUTPUT_DRIVER_TYPE = eINSTANCE.getOutputDriverType();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputConfigSubsystemAnalogImpl <em>Input Config Subsystem Analog</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputConfigSubsystemAnalogImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemAnalog()
     * @generated
     */
    EClass INPUT_CONFIG_SUBSYSTEM_ANALOG = eINSTANCE.getInputConfigSubsystemAnalog();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputConfigSubsystemTemperatureImpl <em>Input Config Subsystem Temperature</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputConfigSubsystemTemperatureImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemTemperature()
     * @generated
     */
    EClass INPUT_CONFIG_SUBSYSTEM_TEMPERATURE = eINSTANCE.getInputConfigSubsystemTemperature();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemElDiagImpl <em>Output Config Subsystem El Diag</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputConfigSubsystemElDiagImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemElDiag()
     * @generated
     */
    EClass OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG = eINSTANCE.getOutputConfigSubsystemElDiag();

    /**
     * The meta object literal for the '<em><b>Temp Sensor</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__TEMP_SENSOR = eINSTANCE.getOutputConfigSubsystemElDiag_TempSensor();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputConfigSubsystemSPIImpl <em>Input Config Subsystem SPI</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputConfigSubsystemSPIImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemSPI()
     * @generated
     */
    EClass INPUT_CONFIG_SUBSYSTEM_SPI = eINSTANCE.getInputConfigSubsystemSPI();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputConfigSubsystemDigitalImpl <em>Input Config Subsystem Digital</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputConfigSubsystemDigitalImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemDigital()
     * @generated
     */
    EClass INPUT_CONFIG_SUBSYSTEM_DIGITAL = eINSTANCE.getInputConfigSubsystemDigital();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputConfigSubsystemFrqImpl <em>Input Config Subsystem Frq</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputConfigSubsystemFrqImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemFrq()
     * @generated
     */
    EClass INPUT_CONFIG_SUBSYSTEM_FRQ = eINSTANCE.getInputConfigSubsystemFrq();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemPWMImpl <em>Output Config Subsystem PWM</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputConfigSubsystemPWMImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemPWM()
     * @generated
     */
    EClass OUTPUT_CONFIG_SUBSYSTEM_PWM = eINSTANCE.getOutputConfigSubsystemPWM();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemDigitalImpl <em>Output Config Subsystem Digital</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputConfigSubsystemDigitalImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemDigital()
     * @generated
     */
    EClass OUTPUT_CONFIG_SUBSYSTEM_DIGITAL = eINSTANCE.getOutputConfigSubsystemDigital();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputConfigSubsystemItemImpl <em>Input Config Subsystem Item</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputConfigSubsystemItemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputConfigSubsystemItem()
     * @generated
     */
    EClass INPUT_CONFIG_SUBSYSTEM_ITEM = eINSTANCE.getInputConfigSubsystemItem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputConfigSubsystemItemImpl <em>Output Config Subsystem Item</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputConfigSubsystemItemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputConfigSubsystemItem()
     * @generated
     */
    EClass OUTPUT_CONFIG_SUBSYSTEM_ITEM = eINSTANCE.getOutputConfigSubsystemItem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.DriverToECUImpl <em>Driver To ECU</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.DriverToECUImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getDriverToECU()
     * @generated
     */
    EClass DRIVER_TO_ECU = eINSTANCE.getDriverToECU();

    /**
     * The meta object literal for the '<em><b>Input Analog Drivers</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS = eINSTANCE.getDriverToECU_InputAnalogDrivers();

    /**
     * The meta object literal for the '<em><b>Input Digital Drivers</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS = eINSTANCE.getDriverToECU_InputDigitalDrivers();

    /**
     * The meta object literal for the '<em><b>Input Dig Drivers Table</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE = eINSTANCE.getDriverToECU_InputDigDriversTable();

    /**
     * The meta object literal for the '<em><b>Output Digital Drivers</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS = eINSTANCE.getDriverToECU_OutputDigitalDrivers();

    /**
     * The meta object literal for the '<em><b>Output Dig Drivers Table</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE = eINSTANCE.getDriverToECU_OutputDigDriversTable();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.TempSensorSubsystemImpl <em>Temp Sensor Subsystem</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.TempSensorSubsystemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getTempSensorSubsystem()
     * @generated
     */
    EClass TEMP_SENSOR_SUBSYSTEM = eINSTANCE.getTempSensorSubsystem();

    /**
     * The meta object literal for the '<em><b>Driver</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference TEMP_SENSOR_SUBSYSTEM__DRIVER = eINSTANCE.getTempSensorSubsystem_Driver();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputAnalogDriversImpl <em>Input Analog Drivers</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputAnalogDriversImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputAnalogDrivers()
     * @generated
     */
    EClass INPUT_ANALOG_DRIVERS = eINSTANCE.getInputAnalogDrivers();

    /**
     * The meta object literal for the '<em><b>Driver</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_ANALOG_DRIVERS__DRIVER = eINSTANCE.getInputAnalogDrivers_Driver();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputDigitalDriversImpl <em>Input Digital Drivers</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputDigitalDriversImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputDigitalDrivers()
     * @generated
     */
    EClass INPUT_DIGITAL_DRIVERS = eINSTANCE.getInputDigitalDrivers();

    /**
     * The meta object literal for the '<em><b>Driver</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_DIGITAL_DRIVERS__DRIVER = eINSTANCE.getInputDigitalDrivers_Driver();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputDigitalDriversImpl <em>Output Digital Drivers</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputDigitalDriversImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputDigitalDrivers()
     * @generated
     */
    EClass OUTPUT_DIGITAL_DRIVERS = eINSTANCE.getOutputDigitalDrivers();

    /**
     * The meta object literal for the '<em><b>Driver</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_DIGITAL_DRIVERS__DRIVER = eINSTANCE.getOutputDigitalDrivers_Driver();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.AnalogDriverImpl <em>Analog Driver</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.AnalogDriverImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getAnalogDriver()
     * @generated
     */
    EClass ANALOG_DRIVER = eINSTANCE.getAnalogDriver();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ANALOG_DRIVER__NAME = eINSTANCE.getAnalogDriver_Name();

    /**
     * The meta object literal for the '<em><b>Driver Setup</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ANALOG_DRIVER__DRIVER_SETUP = eINSTANCE.getAnalogDriver_DriverSetup();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InDigDriverImpl <em>In Dig Driver</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InDigDriverImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInDigDriver()
     * @generated
     */
    EClass IN_DIG_DRIVER = eINSTANCE.getInDigDriver();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IN_DIG_DRIVER__NAME = eINSTANCE.getInDigDriver_Name();

    /**
     * The meta object literal for the '<em><b>Driver Setup</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference IN_DIG_DRIVER__DRIVER_SETUP = eINSTANCE.getInDigDriver_DriverSetup();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutDigDriverImpl <em>Out Dig Driver</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutDigDriverImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutDigDriver()
     * @generated
     */
    EClass OUT_DIG_DRIVER = eINSTANCE.getOutDigDriver();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute OUT_DIG_DRIVER__NAME = eINSTANCE.getOutDigDriver_Name();

    /**
     * The meta object literal for the '<em><b>Driver Setup</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUT_DIG_DRIVER__DRIVER_SETUP = eINSTANCE.getOutDigDriver_DriverSetup();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.CommonDriverImpl <em>Common Driver</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.CommonDriverImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getCommonDriver()
     * @generated
     */
    EClass COMMON_DRIVER = eINSTANCE.getCommonDriver();

    /**
     * The meta object literal for the '<em><b>Driver Index</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute COMMON_DRIVER__DRIVER_INDEX = eINSTANCE.getCommonDriver_DriverIndex();

    /**
     * The meta object literal for the '<em><b>Controller Pin Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute COMMON_DRIVER__CONTROLLER_PIN_NAME = eINSTANCE.getCommonDriver_ControllerPinName();

    /**
     * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute COMMON_DRIVER__DESCRIPTION = eINSTANCE.getCommonDriver_Description();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InputDigDriversTableImpl <em>Input Dig Drivers Table</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InputDigDriversTableImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInputDigDriversTable()
     * @generated
     */
    EClass INPUT_DIG_DRIVERS_TABLE = eINSTANCE.getInputDigDriversTable();

    /**
     * The meta object literal for the '<em><b>Digital Driver Table Ref</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF = eINSTANCE.getInputDigDriversTable_DigitalDriverTableRef();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutputDigDriversTableImpl <em>Output Dig Drivers Table</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutputDigDriversTableImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutputDigDriversTable()
     * @generated
     */
    EClass OUTPUT_DIG_DRIVERS_TABLE = eINSTANCE.getOutputDigDriversTable();

    /**
     * The meta object literal for the '<em><b>Digital Driver Table Ref</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUTPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF = eINSTANCE.getOutputDigDriversTable_DigitalDriverTableRef();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.InDigitalDriverTableRefImpl <em>In Digital Driver Table Ref</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.InDigitalDriverTableRefImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getInDigitalDriverTableRef()
     * @generated
     */
    EClass IN_DIGITAL_DRIVER_TABLE_REF = eINSTANCE.getInDigitalDriverTableRef();

    /**
     * The meta object literal for the '<em><b>Dummy Signal</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IN_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL = eINSTANCE.getInDigitalDriverTableRef_DummySignal();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference IN_DIGITAL_DRIVER_TABLE_REF__NAME = eINSTANCE.getInDigitalDriverTableRef_Name();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OutDigitalDriverTableRefImpl <em>Out Digital Driver Table Ref</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OutDigitalDriverTableRefImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOutDigitalDriverTableRef()
     * @generated
     */
    EClass OUT_DIGITAL_DRIVER_TABLE_REF = eINSTANCE.getOutDigitalDriverTableRef();

    /**
     * The meta object literal for the '<em><b>Dummy Signal</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute OUT_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL = eINSTANCE.getOutDigitalDriverTableRef_DummySignal();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OUT_DIGITAL_DRIVER_TABLE_REF__NAME = eINSTANCE.getOutDigitalDriverTableRef_Name();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ElectricDiagSubsystemImpl <em>Electric Diag Subsystem</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ElectricDiagSubsystemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getElectricDiagSubsystem()
     * @generated
     */
    EClass ELECTRIC_DIAG_SUBSYSTEM = eINSTANCE.getElectricDiagSubsystem();

    /**
     * The meta object literal for the '<em><b>El Diag</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ELECTRIC_DIAG_SUBSYSTEM__EL_DIAG = eINSTANCE.getElectricDiagSubsystem_ElDiag();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ElDiagImpl <em>El Diag</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ElDiagImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getElDiag()
     * @generated
     */
    EClass EL_DIAG = eINSTANCE.getElDiag();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EL_DIAG__NAME = eINSTANCE.getElDiag_Name();

    /**
     * The meta object literal for the '<em><b>Enable</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EL_DIAG__ENABLE = eINSTANCE.getElDiag_Enable();

    /**
     * The meta object literal for the '<em><b>Diagnosis Enable</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EL_DIAG__DIAGNOSIS_ENABLE = eINSTANCE.getElDiag_DiagnosisEnable();

    /**
     * The meta object literal for the '<em><b>Driver Index</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EL_DIAG__DRIVER_INDEX = eINSTANCE.getElDiag_DriverIndex();

    /**
     * The meta object literal for the '<em><b>Pwm Diagnosis</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EL_DIAG__PWM_DIAGNOSIS = eINSTANCE.getElDiag_PwmDiagnosis();

    /**
     * The meta object literal for the '<em><b>Power Supply Signal</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference EL_DIAG__POWER_SUPPLY_SIGNAL = eINSTANCE.getElDiag_PowerSupplySignal();

    /**
     * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EL_DIAG__DESCRIPTION = eINSTANCE.getElDiag_Description();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.FrequencySubsystemImpl <em>Frequency Subsystem</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.FrequencySubsystemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getFrequencySubsystem()
     * @generated
     */
    EClass FREQUENCY_SUBSYSTEM = eINSTANCE.getFrequencySubsystem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.IFRQImpl <em>IFRQ</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.IFRQImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getIFRQ()
     * @generated
     */
    EClass IFRQ = eINSTANCE.getIFRQ();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IFRQ__NAME = eINSTANCE.getIFRQ_Name();

    /**
     * The meta object literal for the '<em><b>Driver Index</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IFRQ__DRIVER_INDEX = eINSTANCE.getIFRQ_DriverIndex();

    /**
     * The meta object literal for the '<em><b>Sensor Index</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference IFRQ__SENSOR_INDEX = eINSTANCE.getIFRQ_SensorIndex();

    /**
     * The meta object literal for the '<em><b>Update Time</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IFRQ__UPDATE_TIME = eINSTANCE.getIFRQ_UpdateTime();

    /**
     * The meta object literal for the '<em><b>Active</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IFRQ__ACTIVE = eINSTANCE.getIFRQ_Active();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.IFRQSensorImpl <em>IFRQ Sensor</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.IFRQSensorImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getIFRQSensor()
     * @generated
     */
    EClass IFRQ_SENSOR = eINSTANCE.getIFRQSensor();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IFRQ_SENSOR__NAME = eINSTANCE.getIFRQSensor_Name();

    /**
     * The meta object literal for the '<em><b>Initial Waiting Time</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IFRQ_SENSOR__INITIAL_WAITING_TIME = eINSTANCE.getIFRQSensor_InitialWaitingTime();

    /**
     * The meta object literal for the '<em><b>Dir Change Min Periods</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IFRQ_SENSOR__DIR_CHANGE_MIN_PERIODS = eINSTANCE.getIFRQSensor_DirChangeMinPeriods();

    /**
     * The meta object literal for the '<em><b>Direction Change Debounce Time</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IFRQ_SENSOR__DIRECTION_CHANGE_DEBOUNCE_TIME = eINSTANCE.getIFRQSensor_DirectionChangeDebounceTime();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.SPIinputSysImpl <em>SP Iinput Sys</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.SPIinputSysImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSPIinputSys()
     * @generated
     */
    EClass SP_IINPUT_SYS = eINSTANCE.getSPIinputSys();

    /**
     * The meta object literal for the '<em><b>Spi</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SP_IINPUT_SYS__SPI = eINSTANCE.getSPIinputSys_Spi();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.SPIImpl <em>SPI</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.SPIImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSPI()
     * @generated
     */
    EClass SPI = eINSTANCE.getSPI();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPI__NAME = eINSTANCE.getSPI_Name();

    /**
     * The meta object literal for the '<em><b>Driver Index</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPI__DRIVER_INDEX = eINSTANCE.getSPI_DriverIndex();

    /**
     * The meta object literal for the '<em><b>Data Storage Mode</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPI__DATA_STORAGE_MODE = eINSTANCE.getSPI_DataStorageMode();

    /**
     * The meta object literal for the '<em><b>Command</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPI__COMMAND = eINSTANCE.getSPI_Command();

    /**
     * The meta object literal for the '<em><b>Data Length</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPI__DATA_LENGTH = eINSTANCE.getSPI_DataLength();

    /**
     * The meta object literal for the '<em><b>Spitx Data</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SPI__SPITX_DATA = eINSTANCE.getSPI_SpitxData();

    /**
     * The meta object literal for the '<em><b>Module</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPI__MODULE = eINSTANCE.getSPI_Module();

    /**
     * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPI__DESCRIPTION = eINSTANCE.getSPI_Description();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.SPITXDataImpl <em>SPITX Data</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.SPITXDataImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getSPITXData()
     * @generated
     */
    EClass SPITX_DATA = eINSTANCE.getSPITXData();

    /**
     * The meta object literal for the '<em><b>Byte One</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPITX_DATA__BYTE_ONE = eINSTANCE.getSPITXData_ByteOne();

    /**
     * The meta object literal for the '<em><b>Byte Two</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPITX_DATA__BYTE_TWO = eINSTANCE.getSPITXData_ByteTwo();

    /**
     * The meta object literal for the '<em><b>Byte Three</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPITX_DATA__BYTE_THREE = eINSTANCE.getSPITXData_ByteThree();

    /**
     * The meta object literal for the '<em><b>Byte Four</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SPITX_DATA__BYTE_FOUR = eINSTANCE.getSPITXData_ByteFour();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OPWMSubsystemImpl <em>OPWM Subsystem</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OPWMSubsystemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOPWMSubsystem()
     * @generated
     */
    EClass OPWM_SUBSYSTEM = eINSTANCE.getOPWMSubsystem();

    /**
     * The meta object literal for the '<em><b>Opwm</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OPWM_SUBSYSTEM__OPWM = eINSTANCE.getOPWMSubsystem_Opwm();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.OPWMImpl <em>OPWM</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.OPWMImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getOPWM()
     * @generated
     */
    EClass OPWM = eINSTANCE.getOPWM();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute OPWM__NAME = eINSTANCE.getOPWM_Name();

    /**
     * The meta object literal for the '<em><b>Driver Index</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute OPWM__DRIVER_INDEX = eINSTANCE.getOPWM_DriverIndex();

    /**
     * The meta object literal for the '<em><b>Period</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute OPWM__PERIOD = eINSTANCE.getOPWM_Period();

    /**
     * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute OPWM__DESCRIPTION = eINSTANCE.getOPWM_Description();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.IADCImpl <em>IADC</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.IADCImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getIADC()
     * @generated
     */
    EClass IADC = eINSTANCE.getIADC();

    /**
     * The meta object literal for the '<em><b>Driver Index</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IADC__DRIVER_INDEX = eINSTANCE.getIADC_DriverIndex();

    /**
     * The meta object literal for the '<em><b>Enable</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IADC__ENABLE = eINSTANCE.getIADC_Enable();

    /**
     * The meta object literal for the '<em><b>Power Supply Signal</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference IADC__POWER_SUPPLY_SIGNAL = eINSTANCE.getIADC_PowerSupplySignal();

    /**
     * The meta object literal for the '<em><b>Enable El Diag Power Supply Off</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IADC__ENABLE_EL_DIAG_POWER_SUPPLY_OFF = eINSTANCE.getIADC_EnableElDiagPowerSupplyOff();

    /**
     * The meta object literal for the '<em><b>El Diag Instance Idx</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IADC__EL_DIAG_INSTANCE_IDX = eINSTANCE.getIADC_ElDiagInstanceIdx();

    /**
     * The meta object literal for the '<em><b>Controller Pin Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IADC__CONTROLLER_PIN_NAME = eINSTANCE.getIADC_ControllerPinName();

    /**
     * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IADC__DESCRIPTION = eINSTANCE.getIADC_Description();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.UserDefinedSubsystemImpl <em>User Defined Subsystem</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.UserDefinedSubsystemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getUserDefinedSubsystem()
     * @generated
     */
    EClass USER_DEFINED_SUBSYSTEM = eINSTANCE.getUserDefinedSubsystem();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference USER_DEFINED_SUBSYSTEM__NAME = eINSTANCE.getUserDefinedSubsystem_Name();

    /**
     * The meta object literal for the '<em><b>User Port</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference USER_DEFINED_SUBSYSTEM__USER_PORT = eINSTANCE.getUserDefinedSubsystem_UserPort();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ConfigSubsystemItemImpl <em>Config Subsystem Item</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ConfigSubsystemItemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getConfigSubsystemItem()
     * @generated
     */
    EClass CONFIG_SUBSYSTEM_ITEM = eINSTANCE.getConfigSubsystemItem();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.UserPortImpl <em>User Port</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.UserPortImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getUserPort()
     * @generated
     */
    EClass USER_PORT = eINSTANCE.getUserPort();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute USER_PORT__NAME = eINSTANCE.getUserPort_Name();

    /**
     * The meta object literal for the '<em><b>Driver Index</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute USER_PORT__DRIVER_INDEX = eINSTANCE.getUserPort_DriverIndex();

    /**
     * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute USER_PORT__DESCRIPTION = eINSTANCE.getUserPort_Description();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ImportImpl <em>Import</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ImportImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getImport()
     * @generated
     */
    EClass IMPORT = eINSTANCE.getImport();

    /**
     * The meta object literal for the '<em><b>Import URI</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IMPORT__IMPORT_URI = eINSTANCE.getImport_ImportURI();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IMPORT__NAME = eINSTANCE.getImport_Name();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.ImportsImpl <em>Imports</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.ImportsImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getImports()
     * @generated
     */
    EClass IMPORTS = eINSTANCE.getImports();

    /**
     * The meta object literal for the '<em><b>Imported Namespace</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IMPORTS__IMPORTED_NAMESPACE = eINSTANCE.getImports_ImportedNamespace();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.impl.FRQSubsystemImpl <em>FRQ Subsystem</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.impl.FRQSubsystemImpl
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getFRQSubsystem()
     * @generated
     */
    EClass FRQ_SUBSYSTEM = eINSTANCE.getFRQSubsystem();

    /**
     * The meta object literal for the '<em><b>Ifrq Sensor</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FRQ_SUBSYSTEM__IFRQ_SENSOR = eINSTANCE.getFRQSubsystem_IfrqSensor();

    /**
     * The meta object literal for the '<em><b>Ifrq</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FRQ_SUBSYSTEM__IFRQ = eINSTANCE.getFRQSubsystem_Ifrq();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.dataTypeEnumeration <em>data Type Enumeration</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.dataTypeEnumeration
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getdataTypeEnumeration()
     * @generated
     */
    EEnum DATA_TYPE_ENUMERATION = eINSTANCE.getdataTypeEnumeration();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.iadcEnableEnumeration <em>iadc Enable Enumeration</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.iadcEnableEnumeration
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getiadcEnableEnumeration()
     * @generated
     */
    EEnum IADC_ENABLE_ENUMERATION = eINSTANCE.getiadcEnableEnumeration();

    /**
     * The meta object literal for the '{@link zf.pios.configurator.BOOLfalseDefault <em>BOO Lfalse Default</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see zf.pios.configurator.BOOLfalseDefault
     * @see zf.pios.configurator.impl.ConfiguratorPackageImpl#getBOOLfalseDefault()
     * @generated
     */
    EEnum BOO_LFALSE_DEFAULT = eINSTANCE.getBOOLfalseDefault();

  }

} //ConfiguratorPackage
