/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.CommonDriver;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutDigDriver;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Out Dig Driver</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.OutDigDriverImpl#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.OutDigDriverImpl#getDriverSetup <em>Driver Setup</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutDigDriverImpl extends MinimalEObjectImpl.Container implements OutDigDriver
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getDriverSetup() <em>Driver Setup</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverSetup()
   * @generated
   * @ordered
   */
  protected CommonDriver driverSetup;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutDigDriverImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUT_DIG_DRIVER;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUT_DIG_DRIVER__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public CommonDriver getDriverSetup()
  {
    return driverSetup;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetDriverSetup(CommonDriver newDriverSetup, NotificationChain msgs)
  {
    CommonDriver oldDriverSetup = driverSetup;
    driverSetup = newDriverSetup;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUT_DIG_DRIVER__DRIVER_SETUP, oldDriverSetup, newDriverSetup);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDriverSetup(CommonDriver newDriverSetup)
  {
    if (newDriverSetup != driverSetup)
    {
      NotificationChain msgs = null;
      if (driverSetup != null)
        msgs = ((InternalEObject)driverSetup).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUT_DIG_DRIVER__DRIVER_SETUP, null, msgs);
      if (newDriverSetup != null)
        msgs = ((InternalEObject)newDriverSetup).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUT_DIG_DRIVER__DRIVER_SETUP, null, msgs);
      msgs = basicSetDriverSetup(newDriverSetup, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUT_DIG_DRIVER__DRIVER_SETUP, newDriverSetup, newDriverSetup));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUT_DIG_DRIVER__DRIVER_SETUP:
        return basicSetDriverSetup(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUT_DIG_DRIVER__NAME:
        return getName();
      case ConfiguratorPackage.OUT_DIG_DRIVER__DRIVER_SETUP:
        return getDriverSetup();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUT_DIG_DRIVER__NAME:
        setName((String)newValue);
        return;
      case ConfiguratorPackage.OUT_DIG_DRIVER__DRIVER_SETUP:
        setDriverSetup((CommonDriver)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUT_DIG_DRIVER__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.OUT_DIG_DRIVER__DRIVER_SETUP:
        setDriverSetup((CommonDriver)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUT_DIG_DRIVER__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ConfiguratorPackage.OUT_DIG_DRIVER__DRIVER_SETUP:
        return driverSetup != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(')');
    return result.toString();
  }

} //OutDigDriverImpl
