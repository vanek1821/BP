/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Frequency Subsystem</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getFrequencySubsystem()
 * @model
 * @generated
 */
public interface FrequencySubsystem extends EObject
{
} // FrequencySubsystem
