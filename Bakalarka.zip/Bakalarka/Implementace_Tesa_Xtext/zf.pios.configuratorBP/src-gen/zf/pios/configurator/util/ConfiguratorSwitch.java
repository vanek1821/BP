/**
 */
package zf.pios.configurator.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import zf.pios.configurator.ASAPMeasurment;
import zf.pios.configurator.AnalogDriver;
import zf.pios.configurator.CommonDriver;
import zf.pios.configurator.ConfigSubsystem;
import zf.pios.configurator.ConfigSubsystemInput;
import zf.pios.configurator.ConfigSubsystemItem;
import zf.pios.configurator.ConfigSubsystemOutput;
import zf.pios.configurator.Configuration;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.Datafield;
import zf.pios.configurator.DriverToECU;
import zf.pios.configurator.ElDiag;
import zf.pios.configurator.ElectricDiagSubsystem;
import zf.pios.configurator.FRQSubsystem;
import zf.pios.configurator.FrequencySubsystem;
import zf.pios.configurator.GeneralSignal;
import zf.pios.configurator.GeneralSignals;
import zf.pios.configurator.GenericSubsystem;
import zf.pios.configurator.Hardware;
import zf.pios.configurator.IADC;
import zf.pios.configurator.IFRQ;
import zf.pios.configurator.IFRQSensor;
import zf.pios.configurator.Import;
import zf.pios.configurator.Imports;
import zf.pios.configurator.InDigDriver;
import zf.pios.configurator.InDigitalDriverTableRef;
import zf.pios.configurator.InputAnalogDrivers;
import zf.pios.configurator.InputConfigSubsystemAnalog;
import zf.pios.configurator.InputConfigSubsystemDigital;
import zf.pios.configurator.InputConfigSubsystemFrq;
import zf.pios.configurator.InputConfigSubsystemItem;
import zf.pios.configurator.InputConfigSubsystemNull;
import zf.pios.configurator.InputConfigSubsystemSPI;
import zf.pios.configurator.InputConfigSubsystemTemperature;
import zf.pios.configurator.InputDatafield;
import zf.pios.configurator.InputDigDriversTable;
import zf.pios.configurator.InputDigitalDrivers;
import zf.pios.configurator.InputDriverType;
import zf.pios.configurator.InputSignal;
import zf.pios.configurator.InputSubsystems;
import zf.pios.configurator.OPWM;
import zf.pios.configurator.OPWMSubsystem;
import zf.pios.configurator.OutDigDriver;
import zf.pios.configurator.OutDigitalDriverTableRef;
import zf.pios.configurator.OutputConfigSubsystemDigital;
import zf.pios.configurator.OutputConfigSubsystemElDiag;
import zf.pios.configurator.OutputConfigSubsystemItem;
import zf.pios.configurator.OutputConfigSubsystemNull;
import zf.pios.configurator.OutputConfigSubsystemPWM;
import zf.pios.configurator.OutputDatafield;
import zf.pios.configurator.OutputDigDriversTable;
import zf.pios.configurator.OutputDigitalDrivers;
import zf.pios.configurator.OutputDriverType;
import zf.pios.configurator.OutputSignal;
import zf.pios.configurator.OutputSubsystems;
import zf.pios.configurator.Portname;
import zf.pios.configurator.SPI;
import zf.pios.configurator.SPITXData;
import zf.pios.configurator.SPIinputSys;
import zf.pios.configurator.Signal;
import zf.pios.configurator.Signals;
import zf.pios.configurator.TempSensorSubsystem;
import zf.pios.configurator.UserDefinedSubsystem;
import zf.pios.configurator.UserPort;
import zf.pios.configurator.Variant;
import zf.pios.configurator.Variants;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see zf.pios.configurator.ConfiguratorPackage
 * @generated
 */
public class ConfiguratorSwitch<T> extends Switch<T>
{
  /**
   * The cached model package
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static ConfiguratorPackage modelPackage;

  /**
   * Creates an instance of the switch.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfiguratorSwitch()
  {
    if (modelPackage == null)
    {
      modelPackage = ConfiguratorPackage.eINSTANCE;
    }
  }

  /**
   * Checks whether this is a switch for the given package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param ePackage the package in question.
   * @return whether this is a switch for the given package.
   * @generated
   */
  @Override
  protected boolean isSwitchFor(EPackage ePackage)
  {
    return ePackage == modelPackage;
  }

  /**
   * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the first non-null result returned by a <code>caseXXX</code> call.
   * @generated
   */
  @Override
  protected T doSwitch(int classifierID, EObject theEObject)
  {
    switch (classifierID)
    {
      case ConfiguratorPackage.CONFIGURATION:
      {
        Configuration configuration = (Configuration)theEObject;
        T result = caseConfiguration(configuration);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.SYSTEM:
      {
        zf.pios.configurator.System system = (zf.pios.configurator.System)theEObject;
        T result = caseSystem(system);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.SIGNALS:
      {
        Signals signals = (Signals)theEObject;
        T result = caseSignals(signals);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.GENERAL_SIGNALS:
      {
        GeneralSignals generalSignals = (GeneralSignals)theEObject;
        T result = caseGeneralSignals(generalSignals);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.GENERAL_SIGNAL:
      {
        GeneralSignal generalSignal = (GeneralSignal)theEObject;
        T result = caseGeneralSignal(generalSignal);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_SIGNAL:
      {
        InputSignal inputSignal = (InputSignal)theEObject;
        T result = caseInputSignal(inputSignal);
        if (result == null) result = caseGeneralSignal(inputSignal);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_SIGNAL:
      {
        OutputSignal outputSignal = (OutputSignal)theEObject;
        T result = caseOutputSignal(outputSignal);
        if (result == null) result = caseGeneralSignal(outputSignal);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.DATAFIELD:
      {
        Datafield datafield = (Datafield)theEObject;
        T result = caseDatafield(datafield);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_DATAFIELD:
      {
        InputDatafield inputDatafield = (InputDatafield)theEObject;
        T result = caseInputDatafield(inputDatafield);
        if (result == null) result = caseDatafield(inputDatafield);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_DATAFIELD:
      {
        OutputDatafield outputDatafield = (OutputDatafield)theEObject;
        T result = caseOutputDatafield(outputDatafield);
        if (result == null) result = caseDatafield(outputDatafield);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.PORTNAME:
      {
        Portname portname = (Portname)theEObject;
        T result = casePortname(portname);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.VARIANTS:
      {
        Variants variants = (Variants)theEObject;
        T result = caseVariants(variants);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.VARIANT:
      {
        Variant variant = (Variant)theEObject;
        T result = caseVariant(variant);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.SIGNAL:
      {
        Signal signal = (Signal)theEObject;
        T result = caseSignal(signal);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.ASAP_MEASURMENT:
      {
        ASAPMeasurment asapMeasurment = (ASAPMeasurment)theEObject;
        T result = caseASAPMeasurment(asapMeasurment);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.HARDWARE:
      {
        Hardware hardware = (Hardware)theEObject;
        T result = caseHardware(hardware);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.CONFIG_SUBSYSTEM:
      {
        ConfigSubsystem configSubsystem = (ConfigSubsystem)theEObject;
        T result = caseConfigSubsystem(configSubsystem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT:
      {
        ConfigSubsystemInput configSubsystemInput = (ConfigSubsystemInput)theEObject;
        T result = caseConfigSubsystemInput(configSubsystemInput);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT:
      {
        ConfigSubsystemOutput configSubsystemOutput = (ConfigSubsystemOutput)theEObject;
        T result = caseConfigSubsystemOutput(configSubsystemOutput);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_SUBSYSTEMS:
      {
        InputSubsystems inputSubsystems = (InputSubsystems)theEObject;
        T result = caseInputSubsystems(inputSubsystems);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS:
      {
        OutputSubsystems outputSubsystems = (OutputSubsystems)theEObject;
        T result = caseOutputSubsystems(outputSubsystems);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_NULL:
      {
        InputConfigSubsystemNull inputConfigSubsystemNull = (InputConfigSubsystemNull)theEObject;
        T result = caseInputConfigSubsystemNull(inputConfigSubsystemNull);
        if (result == null) result = caseInputDriverType(inputConfigSubsystemNull);
        if (result == null) result = caseGenericSubsystem(inputConfigSubsystemNull);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_NULL:
      {
        OutputConfigSubsystemNull outputConfigSubsystemNull = (OutputConfigSubsystemNull)theEObject;
        T result = caseOutputConfigSubsystemNull(outputConfigSubsystemNull);
        if (result == null) result = caseOutputDriverType(outputConfigSubsystemNull);
        if (result == null) result = caseGenericSubsystem(outputConfigSubsystemNull);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.GENERIC_SUBSYSTEM:
      {
        GenericSubsystem genericSubsystem = (GenericSubsystem)theEObject;
        T result = caseGenericSubsystem(genericSubsystem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_DRIVER_TYPE:
      {
        InputDriverType inputDriverType = (InputDriverType)theEObject;
        T result = caseInputDriverType(inputDriverType);
        if (result == null) result = caseGenericSubsystem(inputDriverType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_DRIVER_TYPE:
      {
        OutputDriverType outputDriverType = (OutputDriverType)theEObject;
        T result = caseOutputDriverType(outputDriverType);
        if (result == null) result = caseGenericSubsystem(outputDriverType);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_ANALOG:
      {
        InputConfigSubsystemAnalog inputConfigSubsystemAnalog = (InputConfigSubsystemAnalog)theEObject;
        T result = caseInputConfigSubsystemAnalog(inputConfigSubsystemAnalog);
        if (result == null) result = caseInputDriverType(inputConfigSubsystemAnalog);
        if (result == null) result = caseGenericSubsystem(inputConfigSubsystemAnalog);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_TEMPERATURE:
      {
        InputConfigSubsystemTemperature inputConfigSubsystemTemperature = (InputConfigSubsystemTemperature)theEObject;
        T result = caseInputConfigSubsystemTemperature(inputConfigSubsystemTemperature);
        if (result == null) result = caseInputDriverType(inputConfigSubsystemTemperature);
        if (result == null) result = caseGenericSubsystem(inputConfigSubsystemTemperature);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG:
      {
        OutputConfigSubsystemElDiag outputConfigSubsystemElDiag = (OutputConfigSubsystemElDiag)theEObject;
        T result = caseOutputConfigSubsystemElDiag(outputConfigSubsystemElDiag);
        if (result == null) result = caseOutputDriverType(outputConfigSubsystemElDiag);
        if (result == null) result = caseGenericSubsystem(outputConfigSubsystemElDiag);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_SPI:
      {
        InputConfigSubsystemSPI inputConfigSubsystemSPI = (InputConfigSubsystemSPI)theEObject;
        T result = caseInputConfigSubsystemSPI(inputConfigSubsystemSPI);
        if (result == null) result = caseInputDriverType(inputConfigSubsystemSPI);
        if (result == null) result = caseGenericSubsystem(inputConfigSubsystemSPI);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_DIGITAL:
      {
        InputConfigSubsystemDigital inputConfigSubsystemDigital = (InputConfigSubsystemDigital)theEObject;
        T result = caseInputConfigSubsystemDigital(inputConfigSubsystemDigital);
        if (result == null) result = caseInputDriverType(inputConfigSubsystemDigital);
        if (result == null) result = caseGenericSubsystem(inputConfigSubsystemDigital);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_FRQ:
      {
        InputConfigSubsystemFrq inputConfigSubsystemFrq = (InputConfigSubsystemFrq)theEObject;
        T result = caseInputConfigSubsystemFrq(inputConfigSubsystemFrq);
        if (result == null) result = caseInputDriverType(inputConfigSubsystemFrq);
        if (result == null) result = caseGenericSubsystem(inputConfigSubsystemFrq);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_PWM:
      {
        OutputConfigSubsystemPWM outputConfigSubsystemPWM = (OutputConfigSubsystemPWM)theEObject;
        T result = caseOutputConfigSubsystemPWM(outputConfigSubsystemPWM);
        if (result == null) result = caseOutputDriverType(outputConfigSubsystemPWM);
        if (result == null) result = caseGenericSubsystem(outputConfigSubsystemPWM);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_DIGITAL:
      {
        OutputConfigSubsystemDigital outputConfigSubsystemDigital = (OutputConfigSubsystemDigital)theEObject;
        T result = caseOutputConfigSubsystemDigital(outputConfigSubsystemDigital);
        if (result == null) result = caseOutputDriverType(outputConfigSubsystemDigital);
        if (result == null) result = caseGenericSubsystem(outputConfigSubsystemDigital);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_ITEM:
      {
        InputConfigSubsystemItem inputConfigSubsystemItem = (InputConfigSubsystemItem)theEObject;
        T result = caseInputConfigSubsystemItem(inputConfigSubsystemItem);
        if (result == null) result = caseInputDriverType(inputConfigSubsystemItem);
        if (result == null) result = caseConfigSubsystemItem(inputConfigSubsystemItem);
        if (result == null) result = caseGenericSubsystem(inputConfigSubsystemItem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_ITEM:
      {
        OutputConfigSubsystemItem outputConfigSubsystemItem = (OutputConfigSubsystemItem)theEObject;
        T result = caseOutputConfigSubsystemItem(outputConfigSubsystemItem);
        if (result == null) result = caseOutputDriverType(outputConfigSubsystemItem);
        if (result == null) result = caseConfigSubsystemItem(outputConfigSubsystemItem);
        if (result == null) result = caseGenericSubsystem(outputConfigSubsystemItem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.DRIVER_TO_ECU:
      {
        DriverToECU driverToECU = (DriverToECU)theEObject;
        T result = caseDriverToECU(driverToECU);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.TEMP_SENSOR_SUBSYSTEM:
      {
        TempSensorSubsystem tempSensorSubsystem = (TempSensorSubsystem)theEObject;
        T result = caseTempSensorSubsystem(tempSensorSubsystem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_ANALOG_DRIVERS:
      {
        InputAnalogDrivers inputAnalogDrivers = (InputAnalogDrivers)theEObject;
        T result = caseInputAnalogDrivers(inputAnalogDrivers);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_DIGITAL_DRIVERS:
      {
        InputDigitalDrivers inputDigitalDrivers = (InputDigitalDrivers)theEObject;
        T result = caseInputDigitalDrivers(inputDigitalDrivers);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_DIGITAL_DRIVERS:
      {
        OutputDigitalDrivers outputDigitalDrivers = (OutputDigitalDrivers)theEObject;
        T result = caseOutputDigitalDrivers(outputDigitalDrivers);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.ANALOG_DRIVER:
      {
        AnalogDriver analogDriver = (AnalogDriver)theEObject;
        T result = caseAnalogDriver(analogDriver);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.IN_DIG_DRIVER:
      {
        InDigDriver inDigDriver = (InDigDriver)theEObject;
        T result = caseInDigDriver(inDigDriver);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUT_DIG_DRIVER:
      {
        OutDigDriver outDigDriver = (OutDigDriver)theEObject;
        T result = caseOutDigDriver(outDigDriver);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.COMMON_DRIVER:
      {
        CommonDriver commonDriver = (CommonDriver)theEObject;
        T result = caseCommonDriver(commonDriver);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.INPUT_DIG_DRIVERS_TABLE:
      {
        InputDigDriversTable inputDigDriversTable = (InputDigDriversTable)theEObject;
        T result = caseInputDigDriversTable(inputDigDriversTable);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUTPUT_DIG_DRIVERS_TABLE:
      {
        OutputDigDriversTable outputDigDriversTable = (OutputDigDriversTable)theEObject;
        T result = caseOutputDigDriversTable(outputDigDriversTable);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.IN_DIGITAL_DRIVER_TABLE_REF:
      {
        InDigitalDriverTableRef inDigitalDriverTableRef = (InDigitalDriverTableRef)theEObject;
        T result = caseInDigitalDriverTableRef(inDigitalDriverTableRef);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF:
      {
        OutDigitalDriverTableRef outDigitalDriverTableRef = (OutDigitalDriverTableRef)theEObject;
        T result = caseOutDigitalDriverTableRef(outDigitalDriverTableRef);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.ELECTRIC_DIAG_SUBSYSTEM:
      {
        ElectricDiagSubsystem electricDiagSubsystem = (ElectricDiagSubsystem)theEObject;
        T result = caseElectricDiagSubsystem(electricDiagSubsystem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.EL_DIAG:
      {
        ElDiag elDiag = (ElDiag)theEObject;
        T result = caseElDiag(elDiag);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.FREQUENCY_SUBSYSTEM:
      {
        FrequencySubsystem frequencySubsystem = (FrequencySubsystem)theEObject;
        T result = caseFrequencySubsystem(frequencySubsystem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.IFRQ:
      {
        IFRQ ifrq = (IFRQ)theEObject;
        T result = caseIFRQ(ifrq);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.IFRQ_SENSOR:
      {
        IFRQSensor ifrqSensor = (IFRQSensor)theEObject;
        T result = caseIFRQSensor(ifrqSensor);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.SP_IINPUT_SYS:
      {
        SPIinputSys spIinputSys = (SPIinputSys)theEObject;
        T result = caseSPIinputSys(spIinputSys);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.SPI:
      {
        SPI spi = (SPI)theEObject;
        T result = caseSPI(spi);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.SPITX_DATA:
      {
        SPITXData spitxData = (SPITXData)theEObject;
        T result = caseSPITXData(spitxData);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OPWM_SUBSYSTEM:
      {
        OPWMSubsystem opwmSubsystem = (OPWMSubsystem)theEObject;
        T result = caseOPWMSubsystem(opwmSubsystem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.OPWM:
      {
        OPWM opwm = (OPWM)theEObject;
        T result = caseOPWM(opwm);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.IADC:
      {
        IADC iadc = (IADC)theEObject;
        T result = caseIADC(iadc);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.USER_DEFINED_SUBSYSTEM:
      {
        UserDefinedSubsystem userDefinedSubsystem = (UserDefinedSubsystem)theEObject;
        T result = caseUserDefinedSubsystem(userDefinedSubsystem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_ITEM:
      {
        ConfigSubsystemItem configSubsystemItem = (ConfigSubsystemItem)theEObject;
        T result = caseConfigSubsystemItem(configSubsystemItem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.USER_PORT:
      {
        UserPort userPort = (UserPort)theEObject;
        T result = caseUserPort(userPort);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.IMPORT:
      {
        Import import_ = (Import)theEObject;
        T result = caseImport(import_);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.IMPORTS:
      {
        Imports imports = (Imports)theEObject;
        T result = caseImports(imports);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case ConfiguratorPackage.FRQ_SUBSYSTEM:
      {
        FRQSubsystem frqSubsystem = (FRQSubsystem)theEObject;
        T result = caseFRQSubsystem(frqSubsystem);
        if (result == null) result = caseFrequencySubsystem(frqSubsystem);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      default: return defaultCase(theEObject);
    }
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Configuration</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Configuration</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfiguration(Configuration object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>System</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>System</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSystem(zf.pios.configurator.System object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Signals</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Signals</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSignals(Signals object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>General Signals</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>General Signals</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGeneralSignals(GeneralSignals object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>General Signal</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>General Signal</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGeneralSignal(GeneralSignal object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Signal</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Signal</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputSignal(InputSignal object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Signal</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Signal</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputSignal(OutputSignal object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Datafield</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Datafield</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseDatafield(Datafield object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Datafield</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Datafield</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputDatafield(InputDatafield object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Datafield</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Datafield</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputDatafield(OutputDatafield object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Portname</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Portname</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casePortname(Portname object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Variants</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Variants</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVariants(Variants object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Variant</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Variant</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVariant(Variant object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Signal</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Signal</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSignal(Signal object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>ASAP Measurment</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>ASAP Measurment</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseASAPMeasurment(ASAPMeasurment object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Hardware</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Hardware</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHardware(Hardware object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Config Subsystem</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Config Subsystem</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfigSubsystem(ConfigSubsystem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Config Subsystem Input</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Config Subsystem Input</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfigSubsystemInput(ConfigSubsystemInput object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Config Subsystem Output</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Config Subsystem Output</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfigSubsystemOutput(ConfigSubsystemOutput object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Subsystems</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Subsystems</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputSubsystems(InputSubsystems object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Subsystems</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Subsystems</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputSubsystems(OutputSubsystems object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Config Subsystem Null</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Config Subsystem Null</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputConfigSubsystemNull(InputConfigSubsystemNull object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Config Subsystem Null</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Config Subsystem Null</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputConfigSubsystemNull(OutputConfigSubsystemNull object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Generic Subsystem</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Generic Subsystem</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseGenericSubsystem(GenericSubsystem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Driver Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Driver Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputDriverType(InputDriverType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Driver Type</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Driver Type</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputDriverType(OutputDriverType object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Config Subsystem Analog</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Config Subsystem Analog</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputConfigSubsystemAnalog(InputConfigSubsystemAnalog object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Config Subsystem Temperature</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Config Subsystem Temperature</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputConfigSubsystemTemperature(InputConfigSubsystemTemperature object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Config Subsystem El Diag</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Config Subsystem El Diag</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputConfigSubsystemElDiag(OutputConfigSubsystemElDiag object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Config Subsystem SPI</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Config Subsystem SPI</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputConfigSubsystemSPI(InputConfigSubsystemSPI object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Config Subsystem Digital</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Config Subsystem Digital</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputConfigSubsystemDigital(InputConfigSubsystemDigital object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Config Subsystem Frq</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Config Subsystem Frq</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputConfigSubsystemFrq(InputConfigSubsystemFrq object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Config Subsystem PWM</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Config Subsystem PWM</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputConfigSubsystemPWM(OutputConfigSubsystemPWM object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Config Subsystem Digital</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Config Subsystem Digital</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputConfigSubsystemDigital(OutputConfigSubsystemDigital object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Config Subsystem Item</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Config Subsystem Item</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputConfigSubsystemItem(InputConfigSubsystemItem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Config Subsystem Item</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Config Subsystem Item</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputConfigSubsystemItem(OutputConfigSubsystemItem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Driver To ECU</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Driver To ECU</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseDriverToECU(DriverToECU object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Temp Sensor Subsystem</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Temp Sensor Subsystem</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTempSensorSubsystem(TempSensorSubsystem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Analog Drivers</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Analog Drivers</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputAnalogDrivers(InputAnalogDrivers object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Digital Drivers</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Digital Drivers</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputDigitalDrivers(InputDigitalDrivers object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Digital Drivers</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Digital Drivers</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputDigitalDrivers(OutputDigitalDrivers object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Analog Driver</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Analog Driver</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAnalogDriver(AnalogDriver object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>In Dig Driver</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>In Dig Driver</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInDigDriver(InDigDriver object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Out Dig Driver</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Out Dig Driver</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutDigDriver(OutDigDriver object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Common Driver</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Common Driver</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseCommonDriver(CommonDriver object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input Dig Drivers Table</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input Dig Drivers Table</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInputDigDriversTable(InputDigDriversTable object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Output Dig Drivers Table</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Output Dig Drivers Table</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutputDigDriversTable(OutputDigDriversTable object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>In Digital Driver Table Ref</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>In Digital Driver Table Ref</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInDigitalDriverTableRef(InDigitalDriverTableRef object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Out Digital Driver Table Ref</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Out Digital Driver Table Ref</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOutDigitalDriverTableRef(OutDigitalDriverTableRef object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Electric Diag Subsystem</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Electric Diag Subsystem</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseElectricDiagSubsystem(ElectricDiagSubsystem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>El Diag</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>El Diag</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseElDiag(ElDiag object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Frequency Subsystem</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Frequency Subsystem</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFrequencySubsystem(FrequencySubsystem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>IFRQ</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>IFRQ</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseIFRQ(IFRQ object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>IFRQ Sensor</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>IFRQ Sensor</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseIFRQSensor(IFRQSensor object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>SP Iinput Sys</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>SP Iinput Sys</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSPIinputSys(SPIinputSys object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>SPI</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>SPI</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSPI(SPI object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>SPITX Data</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>SPITX Data</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSPITXData(SPITXData object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>OPWM Subsystem</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>OPWM Subsystem</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOPWMSubsystem(OPWMSubsystem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>OPWM</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>OPWM</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseOPWM(OPWM object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>IADC</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>IADC</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseIADC(IADC object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>User Defined Subsystem</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>User Defined Subsystem</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseUserDefinedSubsystem(UserDefinedSubsystem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Config Subsystem Item</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Config Subsystem Item</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseConfigSubsystemItem(ConfigSubsystemItem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>User Port</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>User Port</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseUserPort(UserPort object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Import</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Import</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseImport(Import object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Imports</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Imports</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseImports(Imports object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>FRQ Subsystem</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>FRQ Subsystem</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFRQSubsystem(FRQSubsystem object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch, but this is the last case anyway.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject)
   * @generated
   */
  @Override
  public T defaultCase(EObject object)
  {
    return null;
  }

} //ConfiguratorSwitch
