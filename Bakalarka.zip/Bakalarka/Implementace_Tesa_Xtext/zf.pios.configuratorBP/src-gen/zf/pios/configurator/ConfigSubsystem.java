/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Config Subsystem</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.ConfigSubsystem#getConfigSubsystemInput <em>Config Subsystem Input</em>}</li>
 *   <li>{@link zf.pios.configurator.ConfigSubsystem#getConfigSubsystemOutput <em>Config Subsystem Output</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystem()
 * @model
 * @generated
 */
public interface ConfigSubsystem extends EObject
{
  /**
   * Returns the value of the '<em><b>Config Subsystem Input</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Config Subsystem Input</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Config Subsystem Input</em>' containment reference.
   * @see #setConfigSubsystemInput(ConfigSubsystemInput)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystem_ConfigSubsystemInput()
   * @model containment="true"
   * @generated
   */
  ConfigSubsystemInput getConfigSubsystemInput();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ConfigSubsystem#getConfigSubsystemInput <em>Config Subsystem Input</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Config Subsystem Input</em>' containment reference.
   * @see #getConfigSubsystemInput()
   * @generated
   */
  void setConfigSubsystemInput(ConfigSubsystemInput value);

  /**
   * Returns the value of the '<em><b>Config Subsystem Output</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Config Subsystem Output</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Config Subsystem Output</em>' containment reference.
   * @see #setConfigSubsystemOutput(ConfigSubsystemOutput)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystem_ConfigSubsystemOutput()
   * @model containment="true"
   * @generated
   */
  ConfigSubsystemOutput getConfigSubsystemOutput();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ConfigSubsystem#getConfigSubsystemOutput <em>Config Subsystem Output</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Config Subsystem Output</em>' containment reference.
   * @see #getConfigSubsystemOutput()
   * @generated
   */
  void setConfigSubsystemOutput(ConfigSubsystemOutput value);

} // ConfigSubsystem
