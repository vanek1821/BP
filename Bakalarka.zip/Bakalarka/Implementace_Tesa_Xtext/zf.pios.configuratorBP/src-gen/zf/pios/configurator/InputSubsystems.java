/**
 */
package zf.pios.configurator;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Subsystems</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.InputSubsystems#getInputNull <em>Input Null</em>}</li>
 *   <li>{@link zf.pios.configurator.InputSubsystems#getInputAnalog <em>Input Analog</em>}</li>
 *   <li>{@link zf.pios.configurator.InputSubsystems#getInputTemperature <em>Input Temperature</em>}</li>
 *   <li>{@link zf.pios.configurator.InputSubsystems#getInputDigital <em>Input Digital</em>}</li>
 *   <li>{@link zf.pios.configurator.InputSubsystems#getInputFrq <em>Input Frq</em>}</li>
 *   <li>{@link zf.pios.configurator.InputSubsystems#getInputSPI <em>Input SPI</em>}</li>
 *   <li>{@link zf.pios.configurator.InputSubsystems#getInputConfigSubsystem <em>Input Config Subsystem</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputSubsystems()
 * @model
 * @generated
 */
public interface InputSubsystems extends EObject
{
  /**
   * Returns the value of the '<em><b>Input Null</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Null</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Null</em>' containment reference.
   * @see #setInputNull(InputConfigSubsystemNull)
   * @see zf.pios.configurator.ConfiguratorPackage#getInputSubsystems_InputNull()
   * @model containment="true"
   * @generated
   */
  InputConfigSubsystemNull getInputNull();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InputSubsystems#getInputNull <em>Input Null</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Null</em>' containment reference.
   * @see #getInputNull()
   * @generated
   */
  void setInputNull(InputConfigSubsystemNull value);

  /**
   * Returns the value of the '<em><b>Input Analog</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Analog</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Analog</em>' containment reference.
   * @see #setInputAnalog(InputConfigSubsystemAnalog)
   * @see zf.pios.configurator.ConfiguratorPackage#getInputSubsystems_InputAnalog()
   * @model containment="true"
   * @generated
   */
  InputConfigSubsystemAnalog getInputAnalog();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InputSubsystems#getInputAnalog <em>Input Analog</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Analog</em>' containment reference.
   * @see #getInputAnalog()
   * @generated
   */
  void setInputAnalog(InputConfigSubsystemAnalog value);

  /**
   * Returns the value of the '<em><b>Input Temperature</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Temperature</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Temperature</em>' containment reference.
   * @see #setInputTemperature(InputConfigSubsystemTemperature)
   * @see zf.pios.configurator.ConfiguratorPackage#getInputSubsystems_InputTemperature()
   * @model containment="true"
   * @generated
   */
  InputConfigSubsystemTemperature getInputTemperature();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InputSubsystems#getInputTemperature <em>Input Temperature</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Temperature</em>' containment reference.
   * @see #getInputTemperature()
   * @generated
   */
  void setInputTemperature(InputConfigSubsystemTemperature value);

  /**
   * Returns the value of the '<em><b>Input Digital</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Digital</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Digital</em>' containment reference.
   * @see #setInputDigital(InputConfigSubsystemDigital)
   * @see zf.pios.configurator.ConfiguratorPackage#getInputSubsystems_InputDigital()
   * @model containment="true"
   * @generated
   */
  InputConfigSubsystemDigital getInputDigital();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InputSubsystems#getInputDigital <em>Input Digital</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Digital</em>' containment reference.
   * @see #getInputDigital()
   * @generated
   */
  void setInputDigital(InputConfigSubsystemDigital value);

  /**
   * Returns the value of the '<em><b>Input Frq</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Frq</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Frq</em>' containment reference.
   * @see #setInputFrq(InputConfigSubsystemFrq)
   * @see zf.pios.configurator.ConfiguratorPackage#getInputSubsystems_InputFrq()
   * @model containment="true"
   * @generated
   */
  InputConfigSubsystemFrq getInputFrq();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InputSubsystems#getInputFrq <em>Input Frq</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Frq</em>' containment reference.
   * @see #getInputFrq()
   * @generated
   */
  void setInputFrq(InputConfigSubsystemFrq value);

  /**
   * Returns the value of the '<em><b>Input SPI</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input SPI</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input SPI</em>' containment reference.
   * @see #setInputSPI(InputConfigSubsystemSPI)
   * @see zf.pios.configurator.ConfiguratorPackage#getInputSubsystems_InputSPI()
   * @model containment="true"
   * @generated
   */
  InputConfigSubsystemSPI getInputSPI();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InputSubsystems#getInputSPI <em>Input SPI</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input SPI</em>' containment reference.
   * @see #getInputSPI()
   * @generated
   */
  void setInputSPI(InputConfigSubsystemSPI value);

  /**
   * Returns the value of the '<em><b>Input Config Subsystem</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.InputConfigSubsystemItem}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Config Subsystem</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Config Subsystem</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getInputSubsystems_InputConfigSubsystem()
   * @model containment="true"
   * @generated
   */
  EList<InputConfigSubsystemItem> getInputConfigSubsystem();

} // InputSubsystems
