/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfigSubsystem;
import zf.pios.configurator.ConfigSubsystemInput;
import zf.pios.configurator.ConfigSubsystemOutput;
import zf.pios.configurator.ConfiguratorPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Config Subsystem</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.ConfigSubsystemImpl#getConfigSubsystemInput <em>Config Subsystem Input</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigSubsystemImpl#getConfigSubsystemOutput <em>Config Subsystem Output</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConfigSubsystemImpl extends MinimalEObjectImpl.Container implements ConfigSubsystem
{
  /**
   * The cached value of the '{@link #getConfigSubsystemInput() <em>Config Subsystem Input</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConfigSubsystemInput()
   * @generated
   * @ordered
   */
  protected ConfigSubsystemInput configSubsystemInput;

  /**
   * The cached value of the '{@link #getConfigSubsystemOutput() <em>Config Subsystem Output</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConfigSubsystemOutput()
   * @generated
   * @ordered
   */
  protected ConfigSubsystemOutput configSubsystemOutput;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ConfigSubsystemImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.CONFIG_SUBSYSTEM;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigSubsystemInput getConfigSubsystemInput()
  {
    return configSubsystemInput;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetConfigSubsystemInput(ConfigSubsystemInput newConfigSubsystemInput, NotificationChain msgs)
  {
    ConfigSubsystemInput oldConfigSubsystemInput = configSubsystemInput;
    configSubsystemInput = newConfigSubsystemInput;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT, oldConfigSubsystemInput, newConfigSubsystemInput);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setConfigSubsystemInput(ConfigSubsystemInput newConfigSubsystemInput)
  {
    if (newConfigSubsystemInput != configSubsystemInput)
    {
      NotificationChain msgs = null;
      if (configSubsystemInput != null)
        msgs = ((InternalEObject)configSubsystemInput).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT, null, msgs);
      if (newConfigSubsystemInput != null)
        msgs = ((InternalEObject)newConfigSubsystemInput).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT, null, msgs);
      msgs = basicSetConfigSubsystemInput(newConfigSubsystemInput, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT, newConfigSubsystemInput, newConfigSubsystemInput));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigSubsystemOutput getConfigSubsystemOutput()
  {
    return configSubsystemOutput;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetConfigSubsystemOutput(ConfigSubsystemOutput newConfigSubsystemOutput, NotificationChain msgs)
  {
    ConfigSubsystemOutput oldConfigSubsystemOutput = configSubsystemOutput;
    configSubsystemOutput = newConfigSubsystemOutput;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT, oldConfigSubsystemOutput, newConfigSubsystemOutput);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setConfigSubsystemOutput(ConfigSubsystemOutput newConfigSubsystemOutput)
  {
    if (newConfigSubsystemOutput != configSubsystemOutput)
    {
      NotificationChain msgs = null;
      if (configSubsystemOutput != null)
        msgs = ((InternalEObject)configSubsystemOutput).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT, null, msgs);
      if (newConfigSubsystemOutput != null)
        msgs = ((InternalEObject)newConfigSubsystemOutput).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT, null, msgs);
      msgs = basicSetConfigSubsystemOutput(newConfigSubsystemOutput, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT, newConfigSubsystemOutput, newConfigSubsystemOutput));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT:
        return basicSetConfigSubsystemInput(null, msgs);
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT:
        return basicSetConfigSubsystemOutput(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT:
        return getConfigSubsystemInput();
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT:
        return getConfigSubsystemOutput();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT:
        setConfigSubsystemInput((ConfigSubsystemInput)newValue);
        return;
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT:
        setConfigSubsystemOutput((ConfigSubsystemOutput)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT:
        setConfigSubsystemInput((ConfigSubsystemInput)null);
        return;
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT:
        setConfigSubsystemOutput((ConfigSubsystemOutput)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT:
        return configSubsystemInput != null;
      case ConfiguratorPackage.CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT:
        return configSubsystemOutput != null;
    }
    return super.eIsSet(featureID);
  }

} //ConfigSubsystemImpl
