/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputConfigSubsystemAnalog;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Config Subsystem Analog</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InputConfigSubsystemAnalogImpl extends InputDriverTypeImpl implements InputConfigSubsystemAnalog
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputConfigSubsystemAnalogImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.INPUT_CONFIG_SUBSYSTEM_ANALOG;
  }

} //InputConfigSubsystemAnalogImpl
