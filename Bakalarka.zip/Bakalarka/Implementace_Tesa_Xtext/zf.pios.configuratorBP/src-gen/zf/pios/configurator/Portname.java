/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Portname</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.Portname#getNumber <em>Number</em>}</li>
 *   <li>{@link zf.pios.configurator.Portname#getPort <em>Port</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getPortname()
 * @model
 * @generated
 */
public interface Portname extends EObject
{
  /**
   * Returns the value of the '<em><b>Number</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Number</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Number</em>' attribute.
   * @see #setNumber(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getPortname_Number()
   * @model
   * @generated
   */
  String getNumber();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Portname#getNumber <em>Number</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Number</em>' attribute.
   * @see #getNumber()
   * @generated
   */
  void setNumber(String value);

  /**
   * Returns the value of the '<em><b>Port</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Port</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Port</em>' reference.
   * @see #setPort(EObject)
   * @see zf.pios.configurator.ConfiguratorPackage#getPortname_Port()
   * @model
   * @generated
   */
  EObject getPort();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Portname#getPort <em>Port</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Port</em>' reference.
   * @see #getPort()
   * @generated
   */
  void setPort(EObject value);

} // Portname
