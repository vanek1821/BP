/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Config Subsystem Digital</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputConfigSubsystemDigital()
 * @model
 * @generated
 */
public interface InputConfigSubsystemDigital extends InputDriverType
{
} // InputConfigSubsystemDigital
