/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfigSubsystemInput;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputSubsystems;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Config Subsystem Input</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.ConfigSubsystemInputImpl#getMaximalNumberInputSubsystems <em>Maximal Number Input Subsystems</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigSubsystemInputImpl#getInputSubsystems <em>Input Subsystems</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConfigSubsystemInputImpl extends MinimalEObjectImpl.Container implements ConfigSubsystemInput
{
  /**
   * The default value of the '{@link #getMaximalNumberInputSubsystems() <em>Maximal Number Input Subsystems</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMaximalNumberInputSubsystems()
   * @generated
   * @ordered
   */
  protected static final int MAXIMAL_NUMBER_INPUT_SUBSYSTEMS_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getMaximalNumberInputSubsystems() <em>Maximal Number Input Subsystems</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMaximalNumberInputSubsystems()
   * @generated
   * @ordered
   */
  protected int maximalNumberInputSubsystems = MAXIMAL_NUMBER_INPUT_SUBSYSTEMS_EDEFAULT;

  /**
   * The cached value of the '{@link #getInputSubsystems() <em>Input Subsystems</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputSubsystems()
   * @generated
   * @ordered
   */
  protected InputSubsystems inputSubsystems;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ConfigSubsystemInputImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.CONFIG_SUBSYSTEM_INPUT;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getMaximalNumberInputSubsystems()
  {
    return maximalNumberInputSubsystems;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMaximalNumberInputSubsystems(int newMaximalNumberInputSubsystems)
  {
    int oldMaximalNumberInputSubsystems = maximalNumberInputSubsystems;
    maximalNumberInputSubsystems = newMaximalNumberInputSubsystems;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__MAXIMAL_NUMBER_INPUT_SUBSYSTEMS, oldMaximalNumberInputSubsystems, maximalNumberInputSubsystems));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSubsystems getInputSubsystems()
  {
    return inputSubsystems;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputSubsystems(InputSubsystems newInputSubsystems, NotificationChain msgs)
  {
    InputSubsystems oldInputSubsystems = inputSubsystems;
    inputSubsystems = newInputSubsystems;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS, oldInputSubsystems, newInputSubsystems);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputSubsystems(InputSubsystems newInputSubsystems)
  {
    if (newInputSubsystems != inputSubsystems)
    {
      NotificationChain msgs = null;
      if (inputSubsystems != null)
        msgs = ((InternalEObject)inputSubsystems).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS, null, msgs);
      if (newInputSubsystems != null)
        msgs = ((InternalEObject)newInputSubsystems).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS, null, msgs);
      msgs = basicSetInputSubsystems(newInputSubsystems, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS, newInputSubsystems, newInputSubsystems));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS:
        return basicSetInputSubsystems(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__MAXIMAL_NUMBER_INPUT_SUBSYSTEMS:
        return getMaximalNumberInputSubsystems();
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS:
        return getInputSubsystems();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__MAXIMAL_NUMBER_INPUT_SUBSYSTEMS:
        setMaximalNumberInputSubsystems((Integer)newValue);
        return;
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS:
        setInputSubsystems((InputSubsystems)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__MAXIMAL_NUMBER_INPUT_SUBSYSTEMS:
        setMaximalNumberInputSubsystems(MAXIMAL_NUMBER_INPUT_SUBSYSTEMS_EDEFAULT);
        return;
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS:
        setInputSubsystems((InputSubsystems)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__MAXIMAL_NUMBER_INPUT_SUBSYSTEMS:
        return maximalNumberInputSubsystems != MAXIMAL_NUMBER_INPUT_SUBSYSTEMS_EDEFAULT;
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS:
        return inputSubsystems != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (maximalNumberInputSubsystems: ");
    result.append(maximalNumberInputSubsystems);
    result.append(')');
    return result.toString();
  }

} //ConfigSubsystemInputImpl
