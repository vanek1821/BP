/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OPWM;
import zf.pios.configurator.OPWMSubsystem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>OPWM Subsystem</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.OPWMSubsystemImpl#getOpwm <em>Opwm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OPWMSubsystemImpl extends MinimalEObjectImpl.Container implements OPWMSubsystem
{
  /**
   * The cached value of the '{@link #getOpwm() <em>Opwm</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOpwm()
   * @generated
   * @ordered
   */
  protected EList<OPWM> opwm;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OPWMSubsystemImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OPWM_SUBSYSTEM;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<OPWM> getOpwm()
  {
    if (opwm == null)
    {
      opwm = new EObjectContainmentEList<OPWM>(OPWM.class, this, ConfiguratorPackage.OPWM_SUBSYSTEM__OPWM);
    }
    return opwm;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OPWM_SUBSYSTEM__OPWM:
        return ((InternalEList<?>)getOpwm()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OPWM_SUBSYSTEM__OPWM:
        return getOpwm();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OPWM_SUBSYSTEM__OPWM:
        getOpwm().clear();
        getOpwm().addAll((Collection<? extends OPWM>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OPWM_SUBSYSTEM__OPWM:
        getOpwm().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OPWM_SUBSYSTEM__OPWM:
        return opwm != null && !opwm.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //OPWMSubsystemImpl
