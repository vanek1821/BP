/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputDriverType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Driver Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InputDriverTypeImpl extends GenericSubsystemImpl implements InputDriverType
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputDriverTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.INPUT_DRIVER_TYPE;
  }

} //InputDriverTypeImpl
