/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Datafield</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.Datafield#getVariantName <em>Variant Name</em>}</li>
 *   <li>{@link zf.pios.configurator.Datafield#getLowerLimit <em>Lower Limit</em>}</li>
 *   <li>{@link zf.pios.configurator.Datafield#getUpperLimit <em>Upper Limit</em>}</li>
 *   <li>{@link zf.pios.configurator.Datafield#getInitValue <em>Init Value</em>}</li>
 *   <li>{@link zf.pios.configurator.Datafield#getPortname <em>Portname</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getDatafield()
 * @model
 * @generated
 */
public interface Datafield extends EObject
{
  /**
   * Returns the value of the '<em><b>Variant Name</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Variant Name</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Variant Name</em>' reference.
   * @see #setVariantName(Variant)
   * @see zf.pios.configurator.ConfiguratorPackage#getDatafield_VariantName()
   * @model
   * @generated
   */
  Variant getVariantName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Datafield#getVariantName <em>Variant Name</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Variant Name</em>' reference.
   * @see #getVariantName()
   * @generated
   */
  void setVariantName(Variant value);

  /**
   * Returns the value of the '<em><b>Lower Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Lower Limit</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Lower Limit</em>' attribute.
   * @see #setLowerLimit(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getDatafield_LowerLimit()
   * @model
   * @generated
   */
  String getLowerLimit();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Datafield#getLowerLimit <em>Lower Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Lower Limit</em>' attribute.
   * @see #getLowerLimit()
   * @generated
   */
  void setLowerLimit(String value);

  /**
   * Returns the value of the '<em><b>Upper Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Upper Limit</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Upper Limit</em>' attribute.
   * @see #setUpperLimit(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getDatafield_UpperLimit()
   * @model
   * @generated
   */
  String getUpperLimit();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Datafield#getUpperLimit <em>Upper Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Upper Limit</em>' attribute.
   * @see #getUpperLimit()
   * @generated
   */
  void setUpperLimit(String value);

  /**
   * Returns the value of the '<em><b>Init Value</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Init Value</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Init Value</em>' attribute.
   * @see #setInitValue(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getDatafield_InitValue()
   * @model
   * @generated
   */
  String getInitValue();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Datafield#getInitValue <em>Init Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Init Value</em>' attribute.
   * @see #getInitValue()
   * @generated
   */
  void setInitValue(String value);

  /**
   * Returns the value of the '<em><b>Portname</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Portname</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Portname</em>' containment reference.
   * @see #setPortname(Portname)
   * @see zf.pios.configurator.ConfiguratorPackage#getDatafield_Portname()
   * @model containment="true"
   * @generated
   */
  Portname getPortname();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Datafield#getPortname <em>Portname</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Portname</em>' containment reference.
   * @see #getPortname()
   * @generated
   */
  void setPortname(Portname value);

} // Datafield
