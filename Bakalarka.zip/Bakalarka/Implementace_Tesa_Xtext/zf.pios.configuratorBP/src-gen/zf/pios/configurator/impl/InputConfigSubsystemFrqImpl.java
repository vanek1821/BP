/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputConfigSubsystemFrq;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Config Subsystem Frq</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InputConfigSubsystemFrqImpl extends InputDriverTypeImpl implements InputConfigSubsystemFrq
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputConfigSubsystemFrqImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.INPUT_CONFIG_SUBSYSTEM_FRQ;
  }

} //InputConfigSubsystemFrqImpl
