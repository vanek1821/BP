/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import zf.pios.configurator.ASAPMeasurment;
import zf.pios.configurator.AnalogDriver;
import zf.pios.configurator.BOOLfalseDefault;
import zf.pios.configurator.CommonDriver;
import zf.pios.configurator.ConfigSubsystem;
import zf.pios.configurator.ConfigSubsystemInput;
import zf.pios.configurator.ConfigSubsystemItem;
import zf.pios.configurator.ConfigSubsystemOutput;
import zf.pios.configurator.Configuration;
import zf.pios.configurator.ConfiguratorFactory;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.Datafield;
import zf.pios.configurator.DriverToECU;
import zf.pios.configurator.ElDiag;
import zf.pios.configurator.ElectricDiagSubsystem;
import zf.pios.configurator.FRQSubsystem;
import zf.pios.configurator.FrequencySubsystem;
import zf.pios.configurator.GeneralSignal;
import zf.pios.configurator.GeneralSignals;
import zf.pios.configurator.GenericSubsystem;
import zf.pios.configurator.Hardware;
import zf.pios.configurator.IADC;
import zf.pios.configurator.IFRQ;
import zf.pios.configurator.IFRQSensor;
import zf.pios.configurator.Import;
import zf.pios.configurator.Imports;
import zf.pios.configurator.InDigDriver;
import zf.pios.configurator.InDigitalDriverTableRef;
import zf.pios.configurator.InputAnalogDrivers;
import zf.pios.configurator.InputConfigSubsystemAnalog;
import zf.pios.configurator.InputConfigSubsystemDigital;
import zf.pios.configurator.InputConfigSubsystemFrq;
import zf.pios.configurator.InputConfigSubsystemItem;
import zf.pios.configurator.InputConfigSubsystemNull;
import zf.pios.configurator.InputConfigSubsystemSPI;
import zf.pios.configurator.InputConfigSubsystemTemperature;
import zf.pios.configurator.InputDatafield;
import zf.pios.configurator.InputDigDriversTable;
import zf.pios.configurator.InputDigitalDrivers;
import zf.pios.configurator.InputDriverType;
import zf.pios.configurator.InputSignal;
import zf.pios.configurator.InputSubsystems;
import zf.pios.configurator.OPWM;
import zf.pios.configurator.OPWMSubsystem;
import zf.pios.configurator.OutDigDriver;
import zf.pios.configurator.OutDigitalDriverTableRef;
import zf.pios.configurator.OutputConfigSubsystemDigital;
import zf.pios.configurator.OutputConfigSubsystemElDiag;
import zf.pios.configurator.OutputConfigSubsystemItem;
import zf.pios.configurator.OutputConfigSubsystemNull;
import zf.pios.configurator.OutputConfigSubsystemPWM;
import zf.pios.configurator.OutputDatafield;
import zf.pios.configurator.OutputDigDriversTable;
import zf.pios.configurator.OutputDigitalDrivers;
import zf.pios.configurator.OutputDriverType;
import zf.pios.configurator.OutputSignal;
import zf.pios.configurator.OutputSubsystems;
import zf.pios.configurator.Portname;
import zf.pios.configurator.SPI;
import zf.pios.configurator.SPITXData;
import zf.pios.configurator.SPIinputSys;
import zf.pios.configurator.Signal;
import zf.pios.configurator.Signals;
import zf.pios.configurator.TempSensorSubsystem;
import zf.pios.configurator.UserDefinedSubsystem;
import zf.pios.configurator.UserPort;
import zf.pios.configurator.Variant;
import zf.pios.configurator.Variants;
import zf.pios.configurator.dataTypeEnumeration;
import zf.pios.configurator.iadcEnableEnumeration;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ConfiguratorFactoryImpl extends EFactoryImpl implements ConfiguratorFactory
{
  /**
   * Creates the default factory implementation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static ConfiguratorFactory init()
  {
    try
    {
      ConfiguratorFactory theConfiguratorFactory = (ConfiguratorFactory)EPackage.Registry.INSTANCE.getEFactory(ConfiguratorPackage.eNS_URI);
      if (theConfiguratorFactory != null)
      {
        return theConfiguratorFactory;
      }
    }
    catch (Exception exception)
    {
      EcorePlugin.INSTANCE.log(exception);
    }
    return new ConfiguratorFactoryImpl();
  }

  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfiguratorFactoryImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public EObject create(EClass eClass)
  {
    switch (eClass.getClassifierID())
    {
      case ConfiguratorPackage.CONFIGURATION: return createConfiguration();
      case ConfiguratorPackage.SYSTEM: return createSystem();
      case ConfiguratorPackage.SIGNALS: return createSignals();
      case ConfiguratorPackage.GENERAL_SIGNALS: return createGeneralSignals();
      case ConfiguratorPackage.GENERAL_SIGNAL: return createGeneralSignal();
      case ConfiguratorPackage.INPUT_SIGNAL: return createInputSignal();
      case ConfiguratorPackage.OUTPUT_SIGNAL: return createOutputSignal();
      case ConfiguratorPackage.DATAFIELD: return createDatafield();
      case ConfiguratorPackage.INPUT_DATAFIELD: return createInputDatafield();
      case ConfiguratorPackage.OUTPUT_DATAFIELD: return createOutputDatafield();
      case ConfiguratorPackage.PORTNAME: return createPortname();
      case ConfiguratorPackage.VARIANTS: return createVariants();
      case ConfiguratorPackage.VARIANT: return createVariant();
      case ConfiguratorPackage.SIGNAL: return createSignal();
      case ConfiguratorPackage.ASAP_MEASURMENT: return createASAPMeasurment();
      case ConfiguratorPackage.HARDWARE: return createHardware();
      case ConfiguratorPackage.CONFIG_SUBSYSTEM: return createConfigSubsystem();
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_INPUT: return createConfigSubsystemInput();
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT: return createConfigSubsystemOutput();
      case ConfiguratorPackage.INPUT_SUBSYSTEMS: return createInputSubsystems();
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS: return createOutputSubsystems();
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_NULL: return createInputConfigSubsystemNull();
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_NULL: return createOutputConfigSubsystemNull();
      case ConfiguratorPackage.GENERIC_SUBSYSTEM: return createGenericSubsystem();
      case ConfiguratorPackage.INPUT_DRIVER_TYPE: return createInputDriverType();
      case ConfiguratorPackage.OUTPUT_DRIVER_TYPE: return createOutputDriverType();
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_ANALOG: return createInputConfigSubsystemAnalog();
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_TEMPERATURE: return createInputConfigSubsystemTemperature();
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG: return createOutputConfigSubsystemElDiag();
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_SPI: return createInputConfigSubsystemSPI();
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_DIGITAL: return createInputConfigSubsystemDigital();
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_FRQ: return createInputConfigSubsystemFrq();
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_PWM: return createOutputConfigSubsystemPWM();
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_DIGITAL: return createOutputConfigSubsystemDigital();
      case ConfiguratorPackage.INPUT_CONFIG_SUBSYSTEM_ITEM: return createInputConfigSubsystemItem();
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_ITEM: return createOutputConfigSubsystemItem();
      case ConfiguratorPackage.DRIVER_TO_ECU: return createDriverToECU();
      case ConfiguratorPackage.TEMP_SENSOR_SUBSYSTEM: return createTempSensorSubsystem();
      case ConfiguratorPackage.INPUT_ANALOG_DRIVERS: return createInputAnalogDrivers();
      case ConfiguratorPackage.INPUT_DIGITAL_DRIVERS: return createInputDigitalDrivers();
      case ConfiguratorPackage.OUTPUT_DIGITAL_DRIVERS: return createOutputDigitalDrivers();
      case ConfiguratorPackage.ANALOG_DRIVER: return createAnalogDriver();
      case ConfiguratorPackage.IN_DIG_DRIVER: return createInDigDriver();
      case ConfiguratorPackage.OUT_DIG_DRIVER: return createOutDigDriver();
      case ConfiguratorPackage.COMMON_DRIVER: return createCommonDriver();
      case ConfiguratorPackage.INPUT_DIG_DRIVERS_TABLE: return createInputDigDriversTable();
      case ConfiguratorPackage.OUTPUT_DIG_DRIVERS_TABLE: return createOutputDigDriversTable();
      case ConfiguratorPackage.IN_DIGITAL_DRIVER_TABLE_REF: return createInDigitalDriverTableRef();
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF: return createOutDigitalDriverTableRef();
      case ConfiguratorPackage.ELECTRIC_DIAG_SUBSYSTEM: return createElectricDiagSubsystem();
      case ConfiguratorPackage.EL_DIAG: return createElDiag();
      case ConfiguratorPackage.FREQUENCY_SUBSYSTEM: return createFrequencySubsystem();
      case ConfiguratorPackage.IFRQ: return createIFRQ();
      case ConfiguratorPackage.IFRQ_SENSOR: return createIFRQSensor();
      case ConfiguratorPackage.SP_IINPUT_SYS: return createSPIinputSys();
      case ConfiguratorPackage.SPI: return createSPI();
      case ConfiguratorPackage.SPITX_DATA: return createSPITXData();
      case ConfiguratorPackage.OPWM_SUBSYSTEM: return createOPWMSubsystem();
      case ConfiguratorPackage.OPWM: return createOPWM();
      case ConfiguratorPackage.IADC: return createIADC();
      case ConfiguratorPackage.USER_DEFINED_SUBSYSTEM: return createUserDefinedSubsystem();
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_ITEM: return createConfigSubsystemItem();
      case ConfiguratorPackage.USER_PORT: return createUserPort();
      case ConfiguratorPackage.IMPORT: return createImport();
      case ConfiguratorPackage.IMPORTS: return createImports();
      case ConfiguratorPackage.FRQ_SUBSYSTEM: return createFRQSubsystem();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object createFromString(EDataType eDataType, String initialValue)
  {
    switch (eDataType.getClassifierID())
    {
      case ConfiguratorPackage.DATA_TYPE_ENUMERATION:
        return createdataTypeEnumerationFromString(eDataType, initialValue);
      case ConfiguratorPackage.IADC_ENABLE_ENUMERATION:
        return createiadcEnableEnumerationFromString(eDataType, initialValue);
      case ConfiguratorPackage.BOO_LFALSE_DEFAULT:
        return createBOOLfalseDefaultFromString(eDataType, initialValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String convertToString(EDataType eDataType, Object instanceValue)
  {
    switch (eDataType.getClassifierID())
    {
      case ConfiguratorPackage.DATA_TYPE_ENUMERATION:
        return convertdataTypeEnumerationToString(eDataType, instanceValue);
      case ConfiguratorPackage.IADC_ENABLE_ENUMERATION:
        return convertiadcEnableEnumerationToString(eDataType, instanceValue);
      case ConfiguratorPackage.BOO_LFALSE_DEFAULT:
        return convertBOOLfalseDefaultToString(eDataType, instanceValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Configuration createConfiguration()
  {
    ConfigurationImpl configuration = new ConfigurationImpl();
    return configuration;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public zf.pios.configurator.System createSystem()
  {
    SystemImpl system = new SystemImpl();
    return system;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Signals createSignals()
  {
    SignalsImpl signals = new SignalsImpl();
    return signals;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GeneralSignals createGeneralSignals()
  {
    GeneralSignalsImpl generalSignals = new GeneralSignalsImpl();
    return generalSignals;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GeneralSignal createGeneralSignal()
  {
    GeneralSignalImpl generalSignal = new GeneralSignalImpl();
    return generalSignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSignal createInputSignal()
  {
    InputSignalImpl inputSignal = new InputSignalImpl();
    return inputSignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputSignal createOutputSignal()
  {
    OutputSignalImpl outputSignal = new OutputSignalImpl();
    return outputSignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Datafield createDatafield()
  {
    DatafieldImpl datafield = new DatafieldImpl();
    return datafield;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputDatafield createInputDatafield()
  {
    InputDatafieldImpl inputDatafield = new InputDatafieldImpl();
    return inputDatafield;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputDatafield createOutputDatafield()
  {
    OutputDatafieldImpl outputDatafield = new OutputDatafieldImpl();
    return outputDatafield;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Portname createPortname()
  {
    PortnameImpl portname = new PortnameImpl();
    return portname;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Variants createVariants()
  {
    VariantsImpl variants = new VariantsImpl();
    return variants;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Variant createVariant()
  {
    VariantImpl variant = new VariantImpl();
    return variant;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Signal createSignal()
  {
    SignalImpl signal = new SignalImpl();
    return signal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ASAPMeasurment createASAPMeasurment()
  {
    ASAPMeasurmentImpl asapMeasurment = new ASAPMeasurmentImpl();
    return asapMeasurment;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Hardware createHardware()
  {
    HardwareImpl hardware = new HardwareImpl();
    return hardware;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigSubsystem createConfigSubsystem()
  {
    ConfigSubsystemImpl configSubsystem = new ConfigSubsystemImpl();
    return configSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigSubsystemInput createConfigSubsystemInput()
  {
    ConfigSubsystemInputImpl configSubsystemInput = new ConfigSubsystemInputImpl();
    return configSubsystemInput;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigSubsystemOutput createConfigSubsystemOutput()
  {
    ConfigSubsystemOutputImpl configSubsystemOutput = new ConfigSubsystemOutputImpl();
    return configSubsystemOutput;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSubsystems createInputSubsystems()
  {
    InputSubsystemsImpl inputSubsystems = new InputSubsystemsImpl();
    return inputSubsystems;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputSubsystems createOutputSubsystems()
  {
    OutputSubsystemsImpl outputSubsystems = new OutputSubsystemsImpl();
    return outputSubsystems;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemNull createInputConfigSubsystemNull()
  {
    InputConfigSubsystemNullImpl inputConfigSubsystemNull = new InputConfigSubsystemNullImpl();
    return inputConfigSubsystemNull;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputConfigSubsystemNull createOutputConfigSubsystemNull()
  {
    OutputConfigSubsystemNullImpl outputConfigSubsystemNull = new OutputConfigSubsystemNullImpl();
    return outputConfigSubsystemNull;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenericSubsystem createGenericSubsystem()
  {
    GenericSubsystemImpl genericSubsystem = new GenericSubsystemImpl();
    return genericSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputDriverType createInputDriverType()
  {
    InputDriverTypeImpl inputDriverType = new InputDriverTypeImpl();
    return inputDriverType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputDriverType createOutputDriverType()
  {
    OutputDriverTypeImpl outputDriverType = new OutputDriverTypeImpl();
    return outputDriverType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemAnalog createInputConfigSubsystemAnalog()
  {
    InputConfigSubsystemAnalogImpl inputConfigSubsystemAnalog = new InputConfigSubsystemAnalogImpl();
    return inputConfigSubsystemAnalog;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemTemperature createInputConfigSubsystemTemperature()
  {
    InputConfigSubsystemTemperatureImpl inputConfigSubsystemTemperature = new InputConfigSubsystemTemperatureImpl();
    return inputConfigSubsystemTemperature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputConfigSubsystemElDiag createOutputConfigSubsystemElDiag()
  {
    OutputConfigSubsystemElDiagImpl outputConfigSubsystemElDiag = new OutputConfigSubsystemElDiagImpl();
    return outputConfigSubsystemElDiag;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemSPI createInputConfigSubsystemSPI()
  {
    InputConfigSubsystemSPIImpl inputConfigSubsystemSPI = new InputConfigSubsystemSPIImpl();
    return inputConfigSubsystemSPI;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemDigital createInputConfigSubsystemDigital()
  {
    InputConfigSubsystemDigitalImpl inputConfigSubsystemDigital = new InputConfigSubsystemDigitalImpl();
    return inputConfigSubsystemDigital;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemFrq createInputConfigSubsystemFrq()
  {
    InputConfigSubsystemFrqImpl inputConfigSubsystemFrq = new InputConfigSubsystemFrqImpl();
    return inputConfigSubsystemFrq;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputConfigSubsystemPWM createOutputConfigSubsystemPWM()
  {
    OutputConfigSubsystemPWMImpl outputConfigSubsystemPWM = new OutputConfigSubsystemPWMImpl();
    return outputConfigSubsystemPWM;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputConfigSubsystemDigital createOutputConfigSubsystemDigital()
  {
    OutputConfigSubsystemDigitalImpl outputConfigSubsystemDigital = new OutputConfigSubsystemDigitalImpl();
    return outputConfigSubsystemDigital;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemItem createInputConfigSubsystemItem()
  {
    InputConfigSubsystemItemImpl inputConfigSubsystemItem = new InputConfigSubsystemItemImpl();
    return inputConfigSubsystemItem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputConfigSubsystemItem createOutputConfigSubsystemItem()
  {
    OutputConfigSubsystemItemImpl outputConfigSubsystemItem = new OutputConfigSubsystemItemImpl();
    return outputConfigSubsystemItem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DriverToECU createDriverToECU()
  {
    DriverToECUImpl driverToECU = new DriverToECUImpl();
    return driverToECU;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TempSensorSubsystem createTempSensorSubsystem()
  {
    TempSensorSubsystemImpl tempSensorSubsystem = new TempSensorSubsystemImpl();
    return tempSensorSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputAnalogDrivers createInputAnalogDrivers()
  {
    InputAnalogDriversImpl inputAnalogDrivers = new InputAnalogDriversImpl();
    return inputAnalogDrivers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputDigitalDrivers createInputDigitalDrivers()
  {
    InputDigitalDriversImpl inputDigitalDrivers = new InputDigitalDriversImpl();
    return inputDigitalDrivers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputDigitalDrivers createOutputDigitalDrivers()
  {
    OutputDigitalDriversImpl outputDigitalDrivers = new OutputDigitalDriversImpl();
    return outputDigitalDrivers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AnalogDriver createAnalogDriver()
  {
    AnalogDriverImpl analogDriver = new AnalogDriverImpl();
    return analogDriver;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InDigDriver createInDigDriver()
  {
    InDigDriverImpl inDigDriver = new InDigDriverImpl();
    return inDigDriver;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutDigDriver createOutDigDriver()
  {
    OutDigDriverImpl outDigDriver = new OutDigDriverImpl();
    return outDigDriver;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public CommonDriver createCommonDriver()
  {
    CommonDriverImpl commonDriver = new CommonDriverImpl();
    return commonDriver;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputDigDriversTable createInputDigDriversTable()
  {
    InputDigDriversTableImpl inputDigDriversTable = new InputDigDriversTableImpl();
    return inputDigDriversTable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputDigDriversTable createOutputDigDriversTable()
  {
    OutputDigDriversTableImpl outputDigDriversTable = new OutputDigDriversTableImpl();
    return outputDigDriversTable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InDigitalDriverTableRef createInDigitalDriverTableRef()
  {
    InDigitalDriverTableRefImpl inDigitalDriverTableRef = new InDigitalDriverTableRefImpl();
    return inDigitalDriverTableRef;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutDigitalDriverTableRef createOutDigitalDriverTableRef()
  {
    OutDigitalDriverTableRefImpl outDigitalDriverTableRef = new OutDigitalDriverTableRefImpl();
    return outDigitalDriverTableRef;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ElectricDiagSubsystem createElectricDiagSubsystem()
  {
    ElectricDiagSubsystemImpl electricDiagSubsystem = new ElectricDiagSubsystemImpl();
    return electricDiagSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ElDiag createElDiag()
  {
    ElDiagImpl elDiag = new ElDiagImpl();
    return elDiag;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FrequencySubsystem createFrequencySubsystem()
  {
    FrequencySubsystemImpl frequencySubsystem = new FrequencySubsystemImpl();
    return frequencySubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IFRQ createIFRQ()
  {
    IFRQImpl ifrq = new IFRQImpl();
    return ifrq;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IFRQSensor createIFRQSensor()
  {
    IFRQSensorImpl ifrqSensor = new IFRQSensorImpl();
    return ifrqSensor;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SPIinputSys createSPIinputSys()
  {
    SPIinputSysImpl spIinputSys = new SPIinputSysImpl();
    return spIinputSys;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SPI createSPI()
  {
    SPIImpl spi = new SPIImpl();
    return spi;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SPITXData createSPITXData()
  {
    SPITXDataImpl spitxData = new SPITXDataImpl();
    return spitxData;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OPWMSubsystem createOPWMSubsystem()
  {
    OPWMSubsystemImpl opwmSubsystem = new OPWMSubsystemImpl();
    return opwmSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OPWM createOPWM()
  {
    OPWMImpl opwm = new OPWMImpl();
    return opwm;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IADC createIADC()
  {
    IADCImpl iadc = new IADCImpl();
    return iadc;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UserDefinedSubsystem createUserDefinedSubsystem()
  {
    UserDefinedSubsystemImpl userDefinedSubsystem = new UserDefinedSubsystemImpl();
    return userDefinedSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfigSubsystemItem createConfigSubsystemItem()
  {
    ConfigSubsystemItemImpl configSubsystemItem = new ConfigSubsystemItemImpl();
    return configSubsystemItem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public UserPort createUserPort()
  {
    UserPortImpl userPort = new UserPortImpl();
    return userPort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Import createImport()
  {
    ImportImpl import_ = new ImportImpl();
    return import_;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Imports createImports()
  {
    ImportsImpl imports = new ImportsImpl();
    return imports;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FRQSubsystem createFRQSubsystem()
  {
    FRQSubsystemImpl frqSubsystem = new FRQSubsystemImpl();
    return frqSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public dataTypeEnumeration createdataTypeEnumerationFromString(EDataType eDataType, String initialValue)
  {
    dataTypeEnumeration result = dataTypeEnumeration.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertdataTypeEnumerationToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public iadcEnableEnumeration createiadcEnableEnumerationFromString(EDataType eDataType, String initialValue)
  {
    iadcEnableEnumeration result = iadcEnableEnumeration.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertiadcEnableEnumerationToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BOOLfalseDefault createBOOLfalseDefaultFromString(EDataType eDataType, String initialValue)
  {
    BOOLfalseDefault result = BOOLfalseDefault.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertBOOLfalseDefaultToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfiguratorPackage getConfiguratorPackage()
  {
    return (ConfiguratorPackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  @Deprecated
  public static ConfiguratorPackage getPackage()
  {
    return ConfiguratorPackage.eINSTANCE;
  }

} //ConfiguratorFactoryImpl
