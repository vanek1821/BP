/**
 */
package zf.pios.configurator;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>FRQ Subsystem</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.FRQSubsystem#getIfrqSensor <em>Ifrq Sensor</em>}</li>
 *   <li>{@link zf.pios.configurator.FRQSubsystem#getIfrq <em>Ifrq</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getFRQSubsystem()
 * @model
 * @generated
 */
public interface FRQSubsystem extends FrequencySubsystem
{
  /**
   * Returns the value of the '<em><b>Ifrq Sensor</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.IFRQSensor}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ifrq Sensor</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ifrq Sensor</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getFRQSubsystem_IfrqSensor()
   * @model containment="true"
   * @generated
   */
  EList<IFRQSensor> getIfrqSensor();

  /**
   * Returns the value of the '<em><b>Ifrq</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.IFRQ}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ifrq</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ifrq</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getFRQSubsystem_Ifrq()
   * @model containment="true"
   * @generated
   */
  EList<IFRQ> getIfrq();

} // FRQSubsystem
