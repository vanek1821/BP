/**
 */
package zf.pios.configurator;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Dig Drivers Table</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.OutputDigDriversTable#getDigitalDriverTableRef <em>Digital Driver Table Ref</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputDigDriversTable()
 * @model
 * @generated
 */
public interface OutputDigDriversTable extends EObject
{
  /**
   * Returns the value of the '<em><b>Digital Driver Table Ref</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.OutDigitalDriverTableRef}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Digital Driver Table Ref</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Digital Driver Table Ref</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputDigDriversTable_DigitalDriverTableRef()
   * @model containment="true"
   * @generated
   */
  EList<OutDigitalDriverTableRef> getDigitalDriverTableRef();

} // OutputDigDriversTable
