/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.Datafield;
import zf.pios.configurator.Portname;
import zf.pios.configurator.Variant;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Datafield</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.DatafieldImpl#getVariantName <em>Variant Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.DatafieldImpl#getLowerLimit <em>Lower Limit</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.DatafieldImpl#getUpperLimit <em>Upper Limit</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.DatafieldImpl#getInitValue <em>Init Value</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.DatafieldImpl#getPortname <em>Portname</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DatafieldImpl extends MinimalEObjectImpl.Container implements Datafield
{
  /**
   * The cached value of the '{@link #getVariantName() <em>Variant Name</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVariantName()
   * @generated
   * @ordered
   */
  protected Variant variantName;

  /**
   * The default value of the '{@link #getLowerLimit() <em>Lower Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLowerLimit()
   * @generated
   * @ordered
   */
  protected static final String LOWER_LIMIT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLowerLimit() <em>Lower Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLowerLimit()
   * @generated
   * @ordered
   */
  protected String lowerLimit = LOWER_LIMIT_EDEFAULT;

  /**
   * The default value of the '{@link #getUpperLimit() <em>Upper Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUpperLimit()
   * @generated
   * @ordered
   */
  protected static final String UPPER_LIMIT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getUpperLimit() <em>Upper Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUpperLimit()
   * @generated
   * @ordered
   */
  protected String upperLimit = UPPER_LIMIT_EDEFAULT;

  /**
   * The default value of the '{@link #getInitValue() <em>Init Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInitValue()
   * @generated
   * @ordered
   */
  protected static final String INIT_VALUE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getInitValue() <em>Init Value</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInitValue()
   * @generated
   * @ordered
   */
  protected String initValue = INIT_VALUE_EDEFAULT;

  /**
   * The cached value of the '{@link #getPortname() <em>Portname</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPortname()
   * @generated
   * @ordered
   */
  protected Portname portname;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected DatafieldImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.DATAFIELD;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Variant getVariantName()
  {
    if (variantName != null && variantName.eIsProxy())
    {
      InternalEObject oldVariantName = (InternalEObject)variantName;
      variantName = (Variant)eResolveProxy(oldVariantName);
      if (variantName != oldVariantName)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ConfiguratorPackage.DATAFIELD__VARIANT_NAME, oldVariantName, variantName));
      }
    }
    return variantName;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Variant basicGetVariantName()
  {
    return variantName;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setVariantName(Variant newVariantName)
  {
    Variant oldVariantName = variantName;
    variantName = newVariantName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DATAFIELD__VARIANT_NAME, oldVariantName, variantName));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLowerLimit()
  {
    return lowerLimit;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLowerLimit(String newLowerLimit)
  {
    String oldLowerLimit = lowerLimit;
    lowerLimit = newLowerLimit;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DATAFIELD__LOWER_LIMIT, oldLowerLimit, lowerLimit));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getUpperLimit()
  {
    return upperLimit;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUpperLimit(String newUpperLimit)
  {
    String oldUpperLimit = upperLimit;
    upperLimit = newUpperLimit;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DATAFIELD__UPPER_LIMIT, oldUpperLimit, upperLimit));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getInitValue()
  {
    return initValue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInitValue(String newInitValue)
  {
    String oldInitValue = initValue;
    initValue = newInitValue;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DATAFIELD__INIT_VALUE, oldInitValue, initValue));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Portname getPortname()
  {
    return portname;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetPortname(Portname newPortname, NotificationChain msgs)
  {
    Portname oldPortname = portname;
    portname = newPortname;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DATAFIELD__PORTNAME, oldPortname, newPortname);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPortname(Portname newPortname)
  {
    if (newPortname != portname)
    {
      NotificationChain msgs = null;
      if (portname != null)
        msgs = ((InternalEObject)portname).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DATAFIELD__PORTNAME, null, msgs);
      if (newPortname != null)
        msgs = ((InternalEObject)newPortname).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DATAFIELD__PORTNAME, null, msgs);
      msgs = basicSetPortname(newPortname, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DATAFIELD__PORTNAME, newPortname, newPortname));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DATAFIELD__PORTNAME:
        return basicSetPortname(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DATAFIELD__VARIANT_NAME:
        if (resolve) return getVariantName();
        return basicGetVariantName();
      case ConfiguratorPackage.DATAFIELD__LOWER_LIMIT:
        return getLowerLimit();
      case ConfiguratorPackage.DATAFIELD__UPPER_LIMIT:
        return getUpperLimit();
      case ConfiguratorPackage.DATAFIELD__INIT_VALUE:
        return getInitValue();
      case ConfiguratorPackage.DATAFIELD__PORTNAME:
        return getPortname();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DATAFIELD__VARIANT_NAME:
        setVariantName((Variant)newValue);
        return;
      case ConfiguratorPackage.DATAFIELD__LOWER_LIMIT:
        setLowerLimit((String)newValue);
        return;
      case ConfiguratorPackage.DATAFIELD__UPPER_LIMIT:
        setUpperLimit((String)newValue);
        return;
      case ConfiguratorPackage.DATAFIELD__INIT_VALUE:
        setInitValue((String)newValue);
        return;
      case ConfiguratorPackage.DATAFIELD__PORTNAME:
        setPortname((Portname)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DATAFIELD__VARIANT_NAME:
        setVariantName((Variant)null);
        return;
      case ConfiguratorPackage.DATAFIELD__LOWER_LIMIT:
        setLowerLimit(LOWER_LIMIT_EDEFAULT);
        return;
      case ConfiguratorPackage.DATAFIELD__UPPER_LIMIT:
        setUpperLimit(UPPER_LIMIT_EDEFAULT);
        return;
      case ConfiguratorPackage.DATAFIELD__INIT_VALUE:
        setInitValue(INIT_VALUE_EDEFAULT);
        return;
      case ConfiguratorPackage.DATAFIELD__PORTNAME:
        setPortname((Portname)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DATAFIELD__VARIANT_NAME:
        return variantName != null;
      case ConfiguratorPackage.DATAFIELD__LOWER_LIMIT:
        return LOWER_LIMIT_EDEFAULT == null ? lowerLimit != null : !LOWER_LIMIT_EDEFAULT.equals(lowerLimit);
      case ConfiguratorPackage.DATAFIELD__UPPER_LIMIT:
        return UPPER_LIMIT_EDEFAULT == null ? upperLimit != null : !UPPER_LIMIT_EDEFAULT.equals(upperLimit);
      case ConfiguratorPackage.DATAFIELD__INIT_VALUE:
        return INIT_VALUE_EDEFAULT == null ? initValue != null : !INIT_VALUE_EDEFAULT.equals(initValue);
      case ConfiguratorPackage.DATAFIELD__PORTNAME:
        return portname != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (lowerLimit: ");
    result.append(lowerLimit);
    result.append(", upperLimit: ");
    result.append(upperLimit);
    result.append(", initValue: ");
    result.append(initValue);
    result.append(')');
    return result.toString();
  }

} //DatafieldImpl
