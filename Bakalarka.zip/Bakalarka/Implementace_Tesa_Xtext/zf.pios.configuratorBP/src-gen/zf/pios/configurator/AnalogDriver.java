/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Analog Driver</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.AnalogDriver#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.AnalogDriver#getDriverSetup <em>Driver Setup</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getAnalogDriver()
 * @model
 * @generated
 */
public interface AnalogDriver extends EObject
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getAnalogDriver_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.AnalogDriver#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Driver Setup</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Driver Setup</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Driver Setup</em>' containment reference.
   * @see #setDriverSetup(IADC)
   * @see zf.pios.configurator.ConfiguratorPackage#getAnalogDriver_DriverSetup()
   * @model containment="true"
   * @generated
   */
  IADC getDriverSetup();

  /**
   * Sets the value of the '{@link zf.pios.configurator.AnalogDriver#getDriverSetup <em>Driver Setup</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Driver Setup</em>' containment reference.
   * @see #getDriverSetup()
   * @generated
   */
  void setDriverSetup(IADC value);

} // AnalogDriver
