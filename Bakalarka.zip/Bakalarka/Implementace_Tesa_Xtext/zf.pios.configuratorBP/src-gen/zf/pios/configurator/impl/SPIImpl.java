/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.SPI;
import zf.pios.configurator.SPITXData;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SPI</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.SPIImpl#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPIImpl#getDriverIndex <em>Driver Index</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPIImpl#getDataStorageMode <em>Data Storage Mode</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPIImpl#getCommand <em>Command</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPIImpl#getDataLength <em>Data Length</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPIImpl#getSpitxData <em>Spitx Data</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPIImpl#getModule <em>Module</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPIImpl#getDescription <em>Description</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SPIImpl extends MinimalEObjectImpl.Container implements SPI
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected static final String DRIVER_INDEX_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected String driverIndex = DRIVER_INDEX_EDEFAULT;

  /**
   * The default value of the '{@link #getDataStorageMode() <em>Data Storage Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDataStorageMode()
   * @generated
   * @ordered
   */
  protected static final String DATA_STORAGE_MODE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDataStorageMode() <em>Data Storage Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDataStorageMode()
   * @generated
   * @ordered
   */
  protected String dataStorageMode = DATA_STORAGE_MODE_EDEFAULT;

  /**
   * The default value of the '{@link #getCommand() <em>Command</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCommand()
   * @generated
   * @ordered
   */
  protected static final String COMMAND_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCommand() <em>Command</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCommand()
   * @generated
   * @ordered
   */
  protected String command = COMMAND_EDEFAULT;

  /**
   * The default value of the '{@link #getDataLength() <em>Data Length</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDataLength()
   * @generated
   * @ordered
   */
  protected static final String DATA_LENGTH_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDataLength() <em>Data Length</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDataLength()
   * @generated
   * @ordered
   */
  protected String dataLength = DATA_LENGTH_EDEFAULT;

  /**
   * The cached value of the '{@link #getSpitxData() <em>Spitx Data</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSpitxData()
   * @generated
   * @ordered
   */
  protected SPITXData spitxData;

  /**
   * The default value of the '{@link #getModule() <em>Module</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getModule()
   * @generated
   * @ordered
   */
  protected static final String MODULE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getModule() <em>Module</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getModule()
   * @generated
   * @ordered
   */
  protected String module = MODULE_EDEFAULT;

  /**
   * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected static final String DESCRIPTION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected String description = DESCRIPTION_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SPIImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.SPI;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPI__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDriverIndex()
  {
    return driverIndex;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDriverIndex(String newDriverIndex)
  {
    String oldDriverIndex = driverIndex;
    driverIndex = newDriverIndex;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPI__DRIVER_INDEX, oldDriverIndex, driverIndex));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDataStorageMode()
  {
    return dataStorageMode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDataStorageMode(String newDataStorageMode)
  {
    String oldDataStorageMode = dataStorageMode;
    dataStorageMode = newDataStorageMode;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPI__DATA_STORAGE_MODE, oldDataStorageMode, dataStorageMode));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCommand()
  {
    return command;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCommand(String newCommand)
  {
    String oldCommand = command;
    command = newCommand;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPI__COMMAND, oldCommand, command));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDataLength()
  {
    return dataLength;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDataLength(String newDataLength)
  {
    String oldDataLength = dataLength;
    dataLength = newDataLength;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPI__DATA_LENGTH, oldDataLength, dataLength));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SPITXData getSpitxData()
  {
    return spitxData;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetSpitxData(SPITXData newSpitxData, NotificationChain msgs)
  {
    SPITXData oldSpitxData = spitxData;
    spitxData = newSpitxData;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPI__SPITX_DATA, oldSpitxData, newSpitxData);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSpitxData(SPITXData newSpitxData)
  {
    if (newSpitxData != spitxData)
    {
      NotificationChain msgs = null;
      if (spitxData != null)
        msgs = ((InternalEObject)spitxData).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.SPI__SPITX_DATA, null, msgs);
      if (newSpitxData != null)
        msgs = ((InternalEObject)newSpitxData).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.SPI__SPITX_DATA, null, msgs);
      msgs = basicSetSpitxData(newSpitxData, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPI__SPITX_DATA, newSpitxData, newSpitxData));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getModule()
  {
    return module;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setModule(String newModule)
  {
    String oldModule = module;
    module = newModule;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPI__MODULE, oldModule, module));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDescription()
  {
    return description;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDescription(String newDescription)
  {
    String oldDescription = description;
    description = newDescription;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPI__DESCRIPTION, oldDescription, description));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SPI__SPITX_DATA:
        return basicSetSpitxData(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SPI__NAME:
        return getName();
      case ConfiguratorPackage.SPI__DRIVER_INDEX:
        return getDriverIndex();
      case ConfiguratorPackage.SPI__DATA_STORAGE_MODE:
        return getDataStorageMode();
      case ConfiguratorPackage.SPI__COMMAND:
        return getCommand();
      case ConfiguratorPackage.SPI__DATA_LENGTH:
        return getDataLength();
      case ConfiguratorPackage.SPI__SPITX_DATA:
        return getSpitxData();
      case ConfiguratorPackage.SPI__MODULE:
        return getModule();
      case ConfiguratorPackage.SPI__DESCRIPTION:
        return getDescription();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SPI__NAME:
        setName((String)newValue);
        return;
      case ConfiguratorPackage.SPI__DRIVER_INDEX:
        setDriverIndex((String)newValue);
        return;
      case ConfiguratorPackage.SPI__DATA_STORAGE_MODE:
        setDataStorageMode((String)newValue);
        return;
      case ConfiguratorPackage.SPI__COMMAND:
        setCommand((String)newValue);
        return;
      case ConfiguratorPackage.SPI__DATA_LENGTH:
        setDataLength((String)newValue);
        return;
      case ConfiguratorPackage.SPI__SPITX_DATA:
        setSpitxData((SPITXData)newValue);
        return;
      case ConfiguratorPackage.SPI__MODULE:
        setModule((String)newValue);
        return;
      case ConfiguratorPackage.SPI__DESCRIPTION:
        setDescription((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SPI__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.SPI__DRIVER_INDEX:
        setDriverIndex(DRIVER_INDEX_EDEFAULT);
        return;
      case ConfiguratorPackage.SPI__DATA_STORAGE_MODE:
        setDataStorageMode(DATA_STORAGE_MODE_EDEFAULT);
        return;
      case ConfiguratorPackage.SPI__COMMAND:
        setCommand(COMMAND_EDEFAULT);
        return;
      case ConfiguratorPackage.SPI__DATA_LENGTH:
        setDataLength(DATA_LENGTH_EDEFAULT);
        return;
      case ConfiguratorPackage.SPI__SPITX_DATA:
        setSpitxData((SPITXData)null);
        return;
      case ConfiguratorPackage.SPI__MODULE:
        setModule(MODULE_EDEFAULT);
        return;
      case ConfiguratorPackage.SPI__DESCRIPTION:
        setDescription(DESCRIPTION_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SPI__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ConfiguratorPackage.SPI__DRIVER_INDEX:
        return DRIVER_INDEX_EDEFAULT == null ? driverIndex != null : !DRIVER_INDEX_EDEFAULT.equals(driverIndex);
      case ConfiguratorPackage.SPI__DATA_STORAGE_MODE:
        return DATA_STORAGE_MODE_EDEFAULT == null ? dataStorageMode != null : !DATA_STORAGE_MODE_EDEFAULT.equals(dataStorageMode);
      case ConfiguratorPackage.SPI__COMMAND:
        return COMMAND_EDEFAULT == null ? command != null : !COMMAND_EDEFAULT.equals(command);
      case ConfiguratorPackage.SPI__DATA_LENGTH:
        return DATA_LENGTH_EDEFAULT == null ? dataLength != null : !DATA_LENGTH_EDEFAULT.equals(dataLength);
      case ConfiguratorPackage.SPI__SPITX_DATA:
        return spitxData != null;
      case ConfiguratorPackage.SPI__MODULE:
        return MODULE_EDEFAULT == null ? module != null : !MODULE_EDEFAULT.equals(module);
      case ConfiguratorPackage.SPI__DESCRIPTION:
        return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", driverIndex: ");
    result.append(driverIndex);
    result.append(", dataStorageMode: ");
    result.append(dataStorageMode);
    result.append(", command: ");
    result.append(command);
    result.append(", dataLength: ");
    result.append(dataLength);
    result.append(", module: ");
    result.append(module);
    result.append(", description: ");
    result.append(description);
    result.append(')');
    return result.toString();
  }

} //SPIImpl
