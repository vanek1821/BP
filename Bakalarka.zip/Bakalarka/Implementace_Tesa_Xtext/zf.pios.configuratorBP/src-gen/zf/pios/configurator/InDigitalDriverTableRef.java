/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>In Digital Driver Table Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.InDigitalDriverTableRef#getDummySignal <em>Dummy Signal</em>}</li>
 *   <li>{@link zf.pios.configurator.InDigitalDriverTableRef#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInDigitalDriverTableRef()
 * @model
 * @generated
 */
public interface InDigitalDriverTableRef extends EObject
{
  /**
   * Returns the value of the '<em><b>Dummy Signal</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dummy Signal</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dummy Signal</em>' attribute.
   * @see #setDummySignal(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getInDigitalDriverTableRef_DummySignal()
   * @model
   * @generated
   */
  String getDummySignal();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InDigitalDriverTableRef#getDummySignal <em>Dummy Signal</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dummy Signal</em>' attribute.
   * @see #getDummySignal()
   * @generated
   */
  void setDummySignal(String value);

  /**
   * Returns the value of the '<em><b>Name</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' reference.
   * @see #setName(InDigDriver)
   * @see zf.pios.configurator.ConfiguratorPackage#getInDigitalDriverTableRef_Name()
   * @model
   * @generated
   */
  InDigDriver getName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InDigitalDriverTableRef#getName <em>Name</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' reference.
   * @see #getName()
   * @generated
   */
  void setName(InDigDriver value);

} // InDigitalDriverTableRef
