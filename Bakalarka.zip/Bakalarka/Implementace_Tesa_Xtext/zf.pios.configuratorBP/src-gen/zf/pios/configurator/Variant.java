/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Variant</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.Variant#getDefaultVariant <em>Default Variant</em>}</li>
 *   <li>{@link zf.pios.configurator.Variant#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getVariant()
 * @model
 * @generated
 */
public interface Variant extends EObject
{
  /**
   * Returns the value of the '<em><b>Default Variant</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Default Variant</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Default Variant</em>' attribute.
   * @see #setDefaultVariant(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getVariant_DefaultVariant()
   * @model
   * @generated
   */
  String getDefaultVariant();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Variant#getDefaultVariant <em>Default Variant</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Default Variant</em>' attribute.
   * @see #getDefaultVariant()
   * @generated
   */
  void setDefaultVariant(String value);

  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getVariant_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Variant#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

} // Variant
