/**
 */
package zf.pios.configurator;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Configuration</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.Configuration#getConfigurationName <em>Configuration Name</em>}</li>
 *   <li>{@link zf.pios.configurator.Configuration#getVersion <em>Version</em>}</li>
 *   <li>{@link zf.pios.configurator.Configuration#getMainMergeFile <em>Main Merge File</em>}</li>
 *   <li>{@link zf.pios.configurator.Configuration#getImports <em>Imports</em>}</li>
 *   <li>{@link zf.pios.configurator.Configuration#getVariants <em>Variants</em>}</li>
 *   <li>{@link zf.pios.configurator.Configuration#getSystem <em>System</em>}</li>
 *   <li>{@link zf.pios.configurator.Configuration#getHardware <em>Hardware</em>}</li>
 *   <li>{@link zf.pios.configurator.Configuration#getSignals <em>Signals</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getConfiguration()
 * @model
 * @generated
 */
public interface Configuration extends EObject
{
  /**
   * Returns the value of the '<em><b>Configuration Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Configuration Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Configuration Name</em>' attribute.
   * @see #setConfigurationName(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfiguration_ConfigurationName()
   * @model
   * @generated
   */
  String getConfigurationName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Configuration#getConfigurationName <em>Configuration Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Configuration Name</em>' attribute.
   * @see #getConfigurationName()
   * @generated
   */
  void setConfigurationName(String value);

  /**
   * Returns the value of the '<em><b>Version</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Version</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Version</em>' attribute.
   * @see #setVersion(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfiguration_Version()
   * @model
   * @generated
   */
  String getVersion();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Configuration#getVersion <em>Version</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Version</em>' attribute.
   * @see #getVersion()
   * @generated
   */
  void setVersion(String value);

  /**
   * Returns the value of the '<em><b>Main Merge File</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Main Merge File</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Main Merge File</em>' attribute.
   * @see #setMainMergeFile(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfiguration_MainMergeFile()
   * @model
   * @generated
   */
  String getMainMergeFile();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Configuration#getMainMergeFile <em>Main Merge File</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Main Merge File</em>' attribute.
   * @see #getMainMergeFile()
   * @generated
   */
  void setMainMergeFile(String value);

  /**
   * Returns the value of the '<em><b>Imports</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.Imports}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Imports</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Imports</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getConfiguration_Imports()
   * @model containment="true"
   * @generated
   */
  EList<Imports> getImports();

  /**
   * Returns the value of the '<em><b>Variants</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Variants</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Variants</em>' containment reference.
   * @see #setVariants(Variants)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfiguration_Variants()
   * @model containment="true"
   * @generated
   */
  Variants getVariants();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Configuration#getVariants <em>Variants</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Variants</em>' containment reference.
   * @see #getVariants()
   * @generated
   */
  void setVariants(Variants value);

  /**
   * Returns the value of the '<em><b>System</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>System</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>System</em>' containment reference.
   * @see #setSystem(zf.pios.configurator.System)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfiguration_System()
   * @model containment="true"
   * @generated
   */
  zf.pios.configurator.System getSystem();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Configuration#getSystem <em>System</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>System</em>' containment reference.
   * @see #getSystem()
   * @generated
   */
  void setSystem(zf.pios.configurator.System value);

  /**
   * Returns the value of the '<em><b>Hardware</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Hardware</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Hardware</em>' containment reference.
   * @see #setHardware(Hardware)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfiguration_Hardware()
   * @model containment="true"
   * @generated
   */
  Hardware getHardware();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Configuration#getHardware <em>Hardware</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Hardware</em>' containment reference.
   * @see #getHardware()
   * @generated
   */
  void setHardware(Hardware value);

  /**
   * Returns the value of the '<em><b>Signals</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Signals</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Signals</em>' containment reference.
   * @see #setSignals(Signals)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfiguration_Signals()
   * @model containment="true"
   * @generated
   */
  Signals getSignals();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Configuration#getSignals <em>Signals</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Signals</em>' containment reference.
   * @see #getSignals()
   * @generated
   */
  void setSignals(Signals value);

} // Configuration
