/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.FrequencySubsystem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Frequency Subsystem</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FrequencySubsystemImpl extends MinimalEObjectImpl.Container implements FrequencySubsystem
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected FrequencySubsystemImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.FREQUENCY_SUBSYSTEM;
  }

} //FrequencySubsystemImpl
