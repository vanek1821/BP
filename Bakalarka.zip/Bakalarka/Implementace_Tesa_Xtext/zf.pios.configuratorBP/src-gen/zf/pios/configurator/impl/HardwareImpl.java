/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.DriverToECU;
import zf.pios.configurator.ElectricDiagSubsystem;
import zf.pios.configurator.FrequencySubsystem;
import zf.pios.configurator.Hardware;
import zf.pios.configurator.OPWMSubsystem;
import zf.pios.configurator.SPIinputSys;
import zf.pios.configurator.TempSensorSubsystem;
import zf.pios.configurator.UserDefinedSubsystem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Hardware</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.HardwareImpl#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.HardwareImpl#getDriverToECU <em>Driver To ECU</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.HardwareImpl#getTempSensorSubsystem <em>Temp Sensor Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.HardwareImpl#getElectricDiagSubsystem <em>Electric Diag Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.HardwareImpl#getFrequencySubsystem <em>Frequency Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.HardwareImpl#getSpiSubsystem <em>Spi Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.HardwareImpl#getOpwmSubsystem <em>Opwm Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.HardwareImpl#getUserDefinedSubsystem <em>User Defined Subsystem</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HardwareImpl extends MinimalEObjectImpl.Container implements Hardware
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getDriverToECU() <em>Driver To ECU</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverToECU()
   * @generated
   * @ordered
   */
  protected DriverToECU driverToECU;

  /**
   * The cached value of the '{@link #getTempSensorSubsystem() <em>Temp Sensor Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTempSensorSubsystem()
   * @generated
   * @ordered
   */
  protected TempSensorSubsystem tempSensorSubsystem;

  /**
   * The cached value of the '{@link #getElectricDiagSubsystem() <em>Electric Diag Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getElectricDiagSubsystem()
   * @generated
   * @ordered
   */
  protected ElectricDiagSubsystem electricDiagSubsystem;

  /**
   * The cached value of the '{@link #getFrequencySubsystem() <em>Frequency Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFrequencySubsystem()
   * @generated
   * @ordered
   */
  protected FrequencySubsystem frequencySubsystem;

  /**
   * The cached value of the '{@link #getSpiSubsystem() <em>Spi Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSpiSubsystem()
   * @generated
   * @ordered
   */
  protected SPIinputSys spiSubsystem;

  /**
   * The cached value of the '{@link #getOpwmSubsystem() <em>Opwm Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOpwmSubsystem()
   * @generated
   * @ordered
   */
  protected OPWMSubsystem opwmSubsystem;

  /**
   * The cached value of the '{@link #getUserDefinedSubsystem() <em>User Defined Subsystem</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUserDefinedSubsystem()
   * @generated
   * @ordered
   */
  protected EList<UserDefinedSubsystem> userDefinedSubsystem;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected HardwareImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.HARDWARE;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DriverToECU getDriverToECU()
  {
    return driverToECU;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetDriverToECU(DriverToECU newDriverToECU, NotificationChain msgs)
  {
    DriverToECU oldDriverToECU = driverToECU;
    driverToECU = newDriverToECU;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__DRIVER_TO_ECU, oldDriverToECU, newDriverToECU);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDriverToECU(DriverToECU newDriverToECU)
  {
    if (newDriverToECU != driverToECU)
    {
      NotificationChain msgs = null;
      if (driverToECU != null)
        msgs = ((InternalEObject)driverToECU).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__DRIVER_TO_ECU, null, msgs);
      if (newDriverToECU != null)
        msgs = ((InternalEObject)newDriverToECU).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__DRIVER_TO_ECU, null, msgs);
      msgs = basicSetDriverToECU(newDriverToECU, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__DRIVER_TO_ECU, newDriverToECU, newDriverToECU));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TempSensorSubsystem getTempSensorSubsystem()
  {
    return tempSensorSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetTempSensorSubsystem(TempSensorSubsystem newTempSensorSubsystem, NotificationChain msgs)
  {
    TempSensorSubsystem oldTempSensorSubsystem = tempSensorSubsystem;
    tempSensorSubsystem = newTempSensorSubsystem;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__TEMP_SENSOR_SUBSYSTEM, oldTempSensorSubsystem, newTempSensorSubsystem);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTempSensorSubsystem(TempSensorSubsystem newTempSensorSubsystem)
  {
    if (newTempSensorSubsystem != tempSensorSubsystem)
    {
      NotificationChain msgs = null;
      if (tempSensorSubsystem != null)
        msgs = ((InternalEObject)tempSensorSubsystem).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__TEMP_SENSOR_SUBSYSTEM, null, msgs);
      if (newTempSensorSubsystem != null)
        msgs = ((InternalEObject)newTempSensorSubsystem).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__TEMP_SENSOR_SUBSYSTEM, null, msgs);
      msgs = basicSetTempSensorSubsystem(newTempSensorSubsystem, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__TEMP_SENSOR_SUBSYSTEM, newTempSensorSubsystem, newTempSensorSubsystem));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ElectricDiagSubsystem getElectricDiagSubsystem()
  {
    return electricDiagSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetElectricDiagSubsystem(ElectricDiagSubsystem newElectricDiagSubsystem, NotificationChain msgs)
  {
    ElectricDiagSubsystem oldElectricDiagSubsystem = electricDiagSubsystem;
    electricDiagSubsystem = newElectricDiagSubsystem;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__ELECTRIC_DIAG_SUBSYSTEM, oldElectricDiagSubsystem, newElectricDiagSubsystem);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setElectricDiagSubsystem(ElectricDiagSubsystem newElectricDiagSubsystem)
  {
    if (newElectricDiagSubsystem != electricDiagSubsystem)
    {
      NotificationChain msgs = null;
      if (electricDiagSubsystem != null)
        msgs = ((InternalEObject)electricDiagSubsystem).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__ELECTRIC_DIAG_SUBSYSTEM, null, msgs);
      if (newElectricDiagSubsystem != null)
        msgs = ((InternalEObject)newElectricDiagSubsystem).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__ELECTRIC_DIAG_SUBSYSTEM, null, msgs);
      msgs = basicSetElectricDiagSubsystem(newElectricDiagSubsystem, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__ELECTRIC_DIAG_SUBSYSTEM, newElectricDiagSubsystem, newElectricDiagSubsystem));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FrequencySubsystem getFrequencySubsystem()
  {
    return frequencySubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetFrequencySubsystem(FrequencySubsystem newFrequencySubsystem, NotificationChain msgs)
  {
    FrequencySubsystem oldFrequencySubsystem = frequencySubsystem;
    frequencySubsystem = newFrequencySubsystem;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__FREQUENCY_SUBSYSTEM, oldFrequencySubsystem, newFrequencySubsystem);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFrequencySubsystem(FrequencySubsystem newFrequencySubsystem)
  {
    if (newFrequencySubsystem != frequencySubsystem)
    {
      NotificationChain msgs = null;
      if (frequencySubsystem != null)
        msgs = ((InternalEObject)frequencySubsystem).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__FREQUENCY_SUBSYSTEM, null, msgs);
      if (newFrequencySubsystem != null)
        msgs = ((InternalEObject)newFrequencySubsystem).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__FREQUENCY_SUBSYSTEM, null, msgs);
      msgs = basicSetFrequencySubsystem(newFrequencySubsystem, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__FREQUENCY_SUBSYSTEM, newFrequencySubsystem, newFrequencySubsystem));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SPIinputSys getSpiSubsystem()
  {
    return spiSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetSpiSubsystem(SPIinputSys newSpiSubsystem, NotificationChain msgs)
  {
    SPIinputSys oldSpiSubsystem = spiSubsystem;
    spiSubsystem = newSpiSubsystem;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__SPI_SUBSYSTEM, oldSpiSubsystem, newSpiSubsystem);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSpiSubsystem(SPIinputSys newSpiSubsystem)
  {
    if (newSpiSubsystem != spiSubsystem)
    {
      NotificationChain msgs = null;
      if (spiSubsystem != null)
        msgs = ((InternalEObject)spiSubsystem).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__SPI_SUBSYSTEM, null, msgs);
      if (newSpiSubsystem != null)
        msgs = ((InternalEObject)newSpiSubsystem).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__SPI_SUBSYSTEM, null, msgs);
      msgs = basicSetSpiSubsystem(newSpiSubsystem, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__SPI_SUBSYSTEM, newSpiSubsystem, newSpiSubsystem));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OPWMSubsystem getOpwmSubsystem()
  {
    return opwmSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOpwmSubsystem(OPWMSubsystem newOpwmSubsystem, NotificationChain msgs)
  {
    OPWMSubsystem oldOpwmSubsystem = opwmSubsystem;
    opwmSubsystem = newOpwmSubsystem;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__OPWM_SUBSYSTEM, oldOpwmSubsystem, newOpwmSubsystem);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOpwmSubsystem(OPWMSubsystem newOpwmSubsystem)
  {
    if (newOpwmSubsystem != opwmSubsystem)
    {
      NotificationChain msgs = null;
      if (opwmSubsystem != null)
        msgs = ((InternalEObject)opwmSubsystem).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__OPWM_SUBSYSTEM, null, msgs);
      if (newOpwmSubsystem != null)
        msgs = ((InternalEObject)newOpwmSubsystem).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.HARDWARE__OPWM_SUBSYSTEM, null, msgs);
      msgs = basicSetOpwmSubsystem(newOpwmSubsystem, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.HARDWARE__OPWM_SUBSYSTEM, newOpwmSubsystem, newOpwmSubsystem));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<UserDefinedSubsystem> getUserDefinedSubsystem()
  {
    if (userDefinedSubsystem == null)
    {
      userDefinedSubsystem = new EObjectContainmentEList<UserDefinedSubsystem>(UserDefinedSubsystem.class, this, ConfiguratorPackage.HARDWARE__USER_DEFINED_SUBSYSTEM);
    }
    return userDefinedSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.HARDWARE__DRIVER_TO_ECU:
        return basicSetDriverToECU(null, msgs);
      case ConfiguratorPackage.HARDWARE__TEMP_SENSOR_SUBSYSTEM:
        return basicSetTempSensorSubsystem(null, msgs);
      case ConfiguratorPackage.HARDWARE__ELECTRIC_DIAG_SUBSYSTEM:
        return basicSetElectricDiagSubsystem(null, msgs);
      case ConfiguratorPackage.HARDWARE__FREQUENCY_SUBSYSTEM:
        return basicSetFrequencySubsystem(null, msgs);
      case ConfiguratorPackage.HARDWARE__SPI_SUBSYSTEM:
        return basicSetSpiSubsystem(null, msgs);
      case ConfiguratorPackage.HARDWARE__OPWM_SUBSYSTEM:
        return basicSetOpwmSubsystem(null, msgs);
      case ConfiguratorPackage.HARDWARE__USER_DEFINED_SUBSYSTEM:
        return ((InternalEList<?>)getUserDefinedSubsystem()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.HARDWARE__NAME:
        return getName();
      case ConfiguratorPackage.HARDWARE__DRIVER_TO_ECU:
        return getDriverToECU();
      case ConfiguratorPackage.HARDWARE__TEMP_SENSOR_SUBSYSTEM:
        return getTempSensorSubsystem();
      case ConfiguratorPackage.HARDWARE__ELECTRIC_DIAG_SUBSYSTEM:
        return getElectricDiagSubsystem();
      case ConfiguratorPackage.HARDWARE__FREQUENCY_SUBSYSTEM:
        return getFrequencySubsystem();
      case ConfiguratorPackage.HARDWARE__SPI_SUBSYSTEM:
        return getSpiSubsystem();
      case ConfiguratorPackage.HARDWARE__OPWM_SUBSYSTEM:
        return getOpwmSubsystem();
      case ConfiguratorPackage.HARDWARE__USER_DEFINED_SUBSYSTEM:
        return getUserDefinedSubsystem();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.HARDWARE__NAME:
        setName((String)newValue);
        return;
      case ConfiguratorPackage.HARDWARE__DRIVER_TO_ECU:
        setDriverToECU((DriverToECU)newValue);
        return;
      case ConfiguratorPackage.HARDWARE__TEMP_SENSOR_SUBSYSTEM:
        setTempSensorSubsystem((TempSensorSubsystem)newValue);
        return;
      case ConfiguratorPackage.HARDWARE__ELECTRIC_DIAG_SUBSYSTEM:
        setElectricDiagSubsystem((ElectricDiagSubsystem)newValue);
        return;
      case ConfiguratorPackage.HARDWARE__FREQUENCY_SUBSYSTEM:
        setFrequencySubsystem((FrequencySubsystem)newValue);
        return;
      case ConfiguratorPackage.HARDWARE__SPI_SUBSYSTEM:
        setSpiSubsystem((SPIinputSys)newValue);
        return;
      case ConfiguratorPackage.HARDWARE__OPWM_SUBSYSTEM:
        setOpwmSubsystem((OPWMSubsystem)newValue);
        return;
      case ConfiguratorPackage.HARDWARE__USER_DEFINED_SUBSYSTEM:
        getUserDefinedSubsystem().clear();
        getUserDefinedSubsystem().addAll((Collection<? extends UserDefinedSubsystem>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.HARDWARE__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.HARDWARE__DRIVER_TO_ECU:
        setDriverToECU((DriverToECU)null);
        return;
      case ConfiguratorPackage.HARDWARE__TEMP_SENSOR_SUBSYSTEM:
        setTempSensorSubsystem((TempSensorSubsystem)null);
        return;
      case ConfiguratorPackage.HARDWARE__ELECTRIC_DIAG_SUBSYSTEM:
        setElectricDiagSubsystem((ElectricDiagSubsystem)null);
        return;
      case ConfiguratorPackage.HARDWARE__FREQUENCY_SUBSYSTEM:
        setFrequencySubsystem((FrequencySubsystem)null);
        return;
      case ConfiguratorPackage.HARDWARE__SPI_SUBSYSTEM:
        setSpiSubsystem((SPIinputSys)null);
        return;
      case ConfiguratorPackage.HARDWARE__OPWM_SUBSYSTEM:
        setOpwmSubsystem((OPWMSubsystem)null);
        return;
      case ConfiguratorPackage.HARDWARE__USER_DEFINED_SUBSYSTEM:
        getUserDefinedSubsystem().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.HARDWARE__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ConfiguratorPackage.HARDWARE__DRIVER_TO_ECU:
        return driverToECU != null;
      case ConfiguratorPackage.HARDWARE__TEMP_SENSOR_SUBSYSTEM:
        return tempSensorSubsystem != null;
      case ConfiguratorPackage.HARDWARE__ELECTRIC_DIAG_SUBSYSTEM:
        return electricDiagSubsystem != null;
      case ConfiguratorPackage.HARDWARE__FREQUENCY_SUBSYSTEM:
        return frequencySubsystem != null;
      case ConfiguratorPackage.HARDWARE__SPI_SUBSYSTEM:
        return spiSubsystem != null;
      case ConfiguratorPackage.HARDWARE__OPWM_SUBSYSTEM:
        return opwmSubsystem != null;
      case ConfiguratorPackage.HARDWARE__USER_DEFINED_SUBSYSTEM:
        return userDefinedSubsystem != null && !userDefinedSubsystem.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(')');
    return result.toString();
  }

} //HardwareImpl
