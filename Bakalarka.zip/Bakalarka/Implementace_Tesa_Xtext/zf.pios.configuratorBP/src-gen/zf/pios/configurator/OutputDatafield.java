/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Datafield</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.OutputDatafield#getSubSystem <em>Sub System</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputDatafield()
 * @model
 * @generated
 */
public interface OutputDatafield extends Datafield
{
  /**
   * Returns the value of the '<em><b>Sub System</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Sub System</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Sub System</em>' reference.
   * @see #setSubSystem(OutputDriverType)
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputDatafield_SubSystem()
   * @model
   * @generated
   */
  OutputDriverType getSubSystem();

  /**
   * Sets the value of the '{@link zf.pios.configurator.OutputDatafield#getSubSystem <em>Sub System</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Sub System</em>' reference.
   * @see #getSubSystem()
   * @generated
   */
  void setSubSystem(OutputDriverType value);

} // OutputDatafield
