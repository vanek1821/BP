/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Config Subsystem Input</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.ConfigSubsystemInput#getMaximalNumberInputSubsystems <em>Maximal Number Input Subsystems</em>}</li>
 *   <li>{@link zf.pios.configurator.ConfigSubsystemInput#getInputSubsystems <em>Input Subsystems</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystemInput()
 * @model
 * @generated
 */
public interface ConfigSubsystemInput extends EObject
{
  /**
   * Returns the value of the '<em><b>Maximal Number Input Subsystems</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Maximal Number Input Subsystems</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Maximal Number Input Subsystems</em>' attribute.
   * @see #setMaximalNumberInputSubsystems(int)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystemInput_MaximalNumberInputSubsystems()
   * @model
   * @generated
   */
  int getMaximalNumberInputSubsystems();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ConfigSubsystemInput#getMaximalNumberInputSubsystems <em>Maximal Number Input Subsystems</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Maximal Number Input Subsystems</em>' attribute.
   * @see #getMaximalNumberInputSubsystems()
   * @generated
   */
  void setMaximalNumberInputSubsystems(int value);

  /**
   * Returns the value of the '<em><b>Input Subsystems</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Subsystems</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Subsystems</em>' containment reference.
   * @see #setInputSubsystems(InputSubsystems)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystemInput_InputSubsystems()
   * @model containment="true"
   * @generated
   */
  InputSubsystems getInputSubsystems();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ConfigSubsystemInput#getInputSubsystems <em>Input Subsystems</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Subsystems</em>' containment reference.
   * @see #getInputSubsystems()
   * @generated
   */
  void setInputSubsystems(InputSubsystems value);

} // ConfigSubsystemInput
