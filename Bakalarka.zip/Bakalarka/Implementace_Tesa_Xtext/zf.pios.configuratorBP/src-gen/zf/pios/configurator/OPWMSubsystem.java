/**
 */
package zf.pios.configurator;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>OPWM Subsystem</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.OPWMSubsystem#getOpwm <em>Opwm</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOPWMSubsystem()
 * @model
 * @generated
 */
public interface OPWMSubsystem extends EObject
{
  /**
   * Returns the value of the '<em><b>Opwm</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.OPWM}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Opwm</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Opwm</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getOPWMSubsystem_Opwm()
   * @model containment="true"
   * @generated
   */
  EList<OPWM> getOpwm();

} // OPWMSubsystem
