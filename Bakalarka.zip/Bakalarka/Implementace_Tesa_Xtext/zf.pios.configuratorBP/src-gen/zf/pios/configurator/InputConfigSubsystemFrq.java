/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Config Subsystem Frq</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputConfigSubsystemFrq()
 * @model
 * @generated
 */
public interface InputConfigSubsystemFrq extends InputDriverType
{
} // InputConfigSubsystemFrq
