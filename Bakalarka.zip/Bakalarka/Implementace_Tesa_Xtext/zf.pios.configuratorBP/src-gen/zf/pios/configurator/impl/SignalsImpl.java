/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.GeneralSignals;
import zf.pios.configurator.Signals;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Signals</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.SignalsImpl#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SignalsImpl#getPiosSignals <em>Pios Signals</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SignalsImpl extends MinimalEObjectImpl.Container implements Signals
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getPiosSignals() <em>Pios Signals</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPiosSignals()
   * @generated
   * @ordered
   */
  protected GeneralSignals piosSignals;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SignalsImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.SIGNALS;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SIGNALS__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GeneralSignals getPiosSignals()
  {
    return piosSignals;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetPiosSignals(GeneralSignals newPiosSignals, NotificationChain msgs)
  {
    GeneralSignals oldPiosSignals = piosSignals;
    piosSignals = newPiosSignals;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SIGNALS__PIOS_SIGNALS, oldPiosSignals, newPiosSignals);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPiosSignals(GeneralSignals newPiosSignals)
  {
    if (newPiosSignals != piosSignals)
    {
      NotificationChain msgs = null;
      if (piosSignals != null)
        msgs = ((InternalEObject)piosSignals).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.SIGNALS__PIOS_SIGNALS, null, msgs);
      if (newPiosSignals != null)
        msgs = ((InternalEObject)newPiosSignals).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.SIGNALS__PIOS_SIGNALS, null, msgs);
      msgs = basicSetPiosSignals(newPiosSignals, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SIGNALS__PIOS_SIGNALS, newPiosSignals, newPiosSignals));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNALS__PIOS_SIGNALS:
        return basicSetPiosSignals(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNALS__NAME:
        return getName();
      case ConfiguratorPackage.SIGNALS__PIOS_SIGNALS:
        return getPiosSignals();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNALS__NAME:
        setName((String)newValue);
        return;
      case ConfiguratorPackage.SIGNALS__PIOS_SIGNALS:
        setPiosSignals((GeneralSignals)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNALS__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.SIGNALS__PIOS_SIGNALS:
        setPiosSignals((GeneralSignals)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNALS__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ConfiguratorPackage.SIGNALS__PIOS_SIGNALS:
        return piosSignals != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(')');
    return result.toString();
  }

} //SignalsImpl
