/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutputDatafield;
import zf.pios.configurator.OutputSignal;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Signal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.OutputSignalImpl#getPullUpResistorSignal <em>Pull Up Resistor Signal</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.OutputSignalImpl#getDatafield <em>Datafield</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutputSignalImpl extends GeneralSignalImpl implements OutputSignal
{
  /**
   * The default value of the '{@link #getPullUpResistorSignal() <em>Pull Up Resistor Signal</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPullUpResistorSignal()
   * @generated
   * @ordered
   */
  protected static final String PULL_UP_RESISTOR_SIGNAL_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getPullUpResistorSignal() <em>Pull Up Resistor Signal</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPullUpResistorSignal()
   * @generated
   * @ordered
   */
  protected String pullUpResistorSignal = PULL_UP_RESISTOR_SIGNAL_EDEFAULT;

  /**
   * The cached value of the '{@link #getDatafield() <em>Datafield</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDatafield()
   * @generated
   * @ordered
   */
  protected EList<OutputDatafield> datafield;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutputSignalImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUTPUT_SIGNAL;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getPullUpResistorSignal()
  {
    return pullUpResistorSignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPullUpResistorSignal(String newPullUpResistorSignal)
  {
    String oldPullUpResistorSignal = pullUpResistorSignal;
    pullUpResistorSignal = newPullUpResistorSignal;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_SIGNAL__PULL_UP_RESISTOR_SIGNAL, oldPullUpResistorSignal, pullUpResistorSignal));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<OutputDatafield> getDatafield()
  {
    if (datafield == null)
    {
      datafield = new EObjectContainmentEList<OutputDatafield>(OutputDatafield.class, this, ConfiguratorPackage.OUTPUT_SIGNAL__DATAFIELD);
    }
    return datafield;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SIGNAL__DATAFIELD:
        return ((InternalEList<?>)getDatafield()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SIGNAL__PULL_UP_RESISTOR_SIGNAL:
        return getPullUpResistorSignal();
      case ConfiguratorPackage.OUTPUT_SIGNAL__DATAFIELD:
        return getDatafield();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SIGNAL__PULL_UP_RESISTOR_SIGNAL:
        setPullUpResistorSignal((String)newValue);
        return;
      case ConfiguratorPackage.OUTPUT_SIGNAL__DATAFIELD:
        getDatafield().clear();
        getDatafield().addAll((Collection<? extends OutputDatafield>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SIGNAL__PULL_UP_RESISTOR_SIGNAL:
        setPullUpResistorSignal(PULL_UP_RESISTOR_SIGNAL_EDEFAULT);
        return;
      case ConfiguratorPackage.OUTPUT_SIGNAL__DATAFIELD:
        getDatafield().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SIGNAL__PULL_UP_RESISTOR_SIGNAL:
        return PULL_UP_RESISTOR_SIGNAL_EDEFAULT == null ? pullUpResistorSignal != null : !PULL_UP_RESISTOR_SIGNAL_EDEFAULT.equals(pullUpResistorSignal);
      case ConfiguratorPackage.OUTPUT_SIGNAL__DATAFIELD:
        return datafield != null && !datafield.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (pullUpResistorSignal: ");
    result.append(pullUpResistorSignal);
    result.append(')');
    return result.toString();
  }

} //OutputSignalImpl
