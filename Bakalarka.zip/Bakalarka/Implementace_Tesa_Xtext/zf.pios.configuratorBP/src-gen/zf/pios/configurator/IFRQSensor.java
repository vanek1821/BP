/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IFRQ Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.IFRQSensor#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.IFRQSensor#getInitialWaitingTime <em>Initial Waiting Time</em>}</li>
 *   <li>{@link zf.pios.configurator.IFRQSensor#getDirChangeMinPeriods <em>Dir Change Min Periods</em>}</li>
 *   <li>{@link zf.pios.configurator.IFRQSensor#getDirectionChangeDebounceTime <em>Direction Change Debounce Time</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getIFRQSensor()
 * @model
 * @generated
 */
public interface IFRQSensor extends EObject
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIFRQSensor_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IFRQSensor#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Initial Waiting Time</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Initial Waiting Time</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Initial Waiting Time</em>' attribute.
   * @see #setInitialWaitingTime(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIFRQSensor_InitialWaitingTime()
   * @model
   * @generated
   */
  String getInitialWaitingTime();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IFRQSensor#getInitialWaitingTime <em>Initial Waiting Time</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Initial Waiting Time</em>' attribute.
   * @see #getInitialWaitingTime()
   * @generated
   */
  void setInitialWaitingTime(String value);

  /**
   * Returns the value of the '<em><b>Dir Change Min Periods</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Dir Change Min Periods</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Dir Change Min Periods</em>' attribute.
   * @see #setDirChangeMinPeriods(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIFRQSensor_DirChangeMinPeriods()
   * @model
   * @generated
   */
  String getDirChangeMinPeriods();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IFRQSensor#getDirChangeMinPeriods <em>Dir Change Min Periods</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Dir Change Min Periods</em>' attribute.
   * @see #getDirChangeMinPeriods()
   * @generated
   */
  void setDirChangeMinPeriods(String value);

  /**
   * Returns the value of the '<em><b>Direction Change Debounce Time</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Direction Change Debounce Time</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Direction Change Debounce Time</em>' attribute.
   * @see #setDirectionChangeDebounceTime(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIFRQSensor_DirectionChangeDebounceTime()
   * @model
   * @generated
   */
  String getDirectionChangeDebounceTime();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IFRQSensor#getDirectionChangeDebounceTime <em>Direction Change Debounce Time</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Direction Change Debounce Time</em>' attribute.
   * @see #getDirectionChangeDebounceTime()
   * @generated
   */
  void setDirectionChangeDebounceTime(String value);

} // IFRQSensor
