/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputConfigSubsystemAnalog;
import zf.pios.configurator.InputConfigSubsystemDigital;
import zf.pios.configurator.InputConfigSubsystemFrq;
import zf.pios.configurator.InputConfigSubsystemItem;
import zf.pios.configurator.InputConfigSubsystemNull;
import zf.pios.configurator.InputConfigSubsystemSPI;
import zf.pios.configurator.InputConfigSubsystemTemperature;
import zf.pios.configurator.InputSubsystems;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Subsystems</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.InputSubsystemsImpl#getInputNull <em>Input Null</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.InputSubsystemsImpl#getInputAnalog <em>Input Analog</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.InputSubsystemsImpl#getInputTemperature <em>Input Temperature</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.InputSubsystemsImpl#getInputDigital <em>Input Digital</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.InputSubsystemsImpl#getInputFrq <em>Input Frq</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.InputSubsystemsImpl#getInputSPI <em>Input SPI</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.InputSubsystemsImpl#getInputConfigSubsystem <em>Input Config Subsystem</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InputSubsystemsImpl extends MinimalEObjectImpl.Container implements InputSubsystems
{
  /**
   * The cached value of the '{@link #getInputNull() <em>Input Null</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputNull()
   * @generated
   * @ordered
   */
  protected InputConfigSubsystemNull inputNull;

  /**
   * The cached value of the '{@link #getInputAnalog() <em>Input Analog</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputAnalog()
   * @generated
   * @ordered
   */
  protected InputConfigSubsystemAnalog inputAnalog;

  /**
   * The cached value of the '{@link #getInputTemperature() <em>Input Temperature</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputTemperature()
   * @generated
   * @ordered
   */
  protected InputConfigSubsystemTemperature inputTemperature;

  /**
   * The cached value of the '{@link #getInputDigital() <em>Input Digital</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputDigital()
   * @generated
   * @ordered
   */
  protected InputConfigSubsystemDigital inputDigital;

  /**
   * The cached value of the '{@link #getInputFrq() <em>Input Frq</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputFrq()
   * @generated
   * @ordered
   */
  protected InputConfigSubsystemFrq inputFrq;

  /**
   * The cached value of the '{@link #getInputSPI() <em>Input SPI</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputSPI()
   * @generated
   * @ordered
   */
  protected InputConfigSubsystemSPI inputSPI;

  /**
   * The cached value of the '{@link #getInputConfigSubsystem() <em>Input Config Subsystem</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputConfigSubsystem()
   * @generated
   * @ordered
   */
  protected EList<InputConfigSubsystemItem> inputConfigSubsystem;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputSubsystemsImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.INPUT_SUBSYSTEMS;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemNull getInputNull()
  {
    return inputNull;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputNull(InputConfigSubsystemNull newInputNull, NotificationChain msgs)
  {
    InputConfigSubsystemNull oldInputNull = inputNull;
    inputNull = newInputNull;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_NULL, oldInputNull, newInputNull);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputNull(InputConfigSubsystemNull newInputNull)
  {
    if (newInputNull != inputNull)
    {
      NotificationChain msgs = null;
      if (inputNull != null)
        msgs = ((InternalEObject)inputNull).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_NULL, null, msgs);
      if (newInputNull != null)
        msgs = ((InternalEObject)newInputNull).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_NULL, null, msgs);
      msgs = basicSetInputNull(newInputNull, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_NULL, newInputNull, newInputNull));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemAnalog getInputAnalog()
  {
    return inputAnalog;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputAnalog(InputConfigSubsystemAnalog newInputAnalog, NotificationChain msgs)
  {
    InputConfigSubsystemAnalog oldInputAnalog = inputAnalog;
    inputAnalog = newInputAnalog;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_ANALOG, oldInputAnalog, newInputAnalog);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputAnalog(InputConfigSubsystemAnalog newInputAnalog)
  {
    if (newInputAnalog != inputAnalog)
    {
      NotificationChain msgs = null;
      if (inputAnalog != null)
        msgs = ((InternalEObject)inputAnalog).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_ANALOG, null, msgs);
      if (newInputAnalog != null)
        msgs = ((InternalEObject)newInputAnalog).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_ANALOG, null, msgs);
      msgs = basicSetInputAnalog(newInputAnalog, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_ANALOG, newInputAnalog, newInputAnalog));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemTemperature getInputTemperature()
  {
    return inputTemperature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputTemperature(InputConfigSubsystemTemperature newInputTemperature, NotificationChain msgs)
  {
    InputConfigSubsystemTemperature oldInputTemperature = inputTemperature;
    inputTemperature = newInputTemperature;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_TEMPERATURE, oldInputTemperature, newInputTemperature);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputTemperature(InputConfigSubsystemTemperature newInputTemperature)
  {
    if (newInputTemperature != inputTemperature)
    {
      NotificationChain msgs = null;
      if (inputTemperature != null)
        msgs = ((InternalEObject)inputTemperature).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_TEMPERATURE, null, msgs);
      if (newInputTemperature != null)
        msgs = ((InternalEObject)newInputTemperature).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_TEMPERATURE, null, msgs);
      msgs = basicSetInputTemperature(newInputTemperature, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_TEMPERATURE, newInputTemperature, newInputTemperature));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemDigital getInputDigital()
  {
    return inputDigital;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputDigital(InputConfigSubsystemDigital newInputDigital, NotificationChain msgs)
  {
    InputConfigSubsystemDigital oldInputDigital = inputDigital;
    inputDigital = newInputDigital;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_DIGITAL, oldInputDigital, newInputDigital);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputDigital(InputConfigSubsystemDigital newInputDigital)
  {
    if (newInputDigital != inputDigital)
    {
      NotificationChain msgs = null;
      if (inputDigital != null)
        msgs = ((InternalEObject)inputDigital).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_DIGITAL, null, msgs);
      if (newInputDigital != null)
        msgs = ((InternalEObject)newInputDigital).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_DIGITAL, null, msgs);
      msgs = basicSetInputDigital(newInputDigital, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_DIGITAL, newInputDigital, newInputDigital));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemFrq getInputFrq()
  {
    return inputFrq;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputFrq(InputConfigSubsystemFrq newInputFrq, NotificationChain msgs)
  {
    InputConfigSubsystemFrq oldInputFrq = inputFrq;
    inputFrq = newInputFrq;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_FRQ, oldInputFrq, newInputFrq);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputFrq(InputConfigSubsystemFrq newInputFrq)
  {
    if (newInputFrq != inputFrq)
    {
      NotificationChain msgs = null;
      if (inputFrq != null)
        msgs = ((InternalEObject)inputFrq).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_FRQ, null, msgs);
      if (newInputFrq != null)
        msgs = ((InternalEObject)newInputFrq).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_FRQ, null, msgs);
      msgs = basicSetInputFrq(newInputFrq, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_FRQ, newInputFrq, newInputFrq));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputConfigSubsystemSPI getInputSPI()
  {
    return inputSPI;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputSPI(InputConfigSubsystemSPI newInputSPI, NotificationChain msgs)
  {
    InputConfigSubsystemSPI oldInputSPI = inputSPI;
    inputSPI = newInputSPI;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_SPI, oldInputSPI, newInputSPI);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputSPI(InputConfigSubsystemSPI newInputSPI)
  {
    if (newInputSPI != inputSPI)
    {
      NotificationChain msgs = null;
      if (inputSPI != null)
        msgs = ((InternalEObject)inputSPI).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_SPI, null, msgs);
      if (newInputSPI != null)
        msgs = ((InternalEObject)newInputSPI).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_SPI, null, msgs);
      msgs = basicSetInputSPI(newInputSPI, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_SPI, newInputSPI, newInputSPI));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<InputConfigSubsystemItem> getInputConfigSubsystem()
  {
    if (inputConfigSubsystem == null)
    {
      inputConfigSubsystem = new EObjectContainmentEList<InputConfigSubsystemItem>(InputConfigSubsystemItem.class, this, ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_CONFIG_SUBSYSTEM);
    }
    return inputConfigSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_NULL:
        return basicSetInputNull(null, msgs);
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_ANALOG:
        return basicSetInputAnalog(null, msgs);
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_TEMPERATURE:
        return basicSetInputTemperature(null, msgs);
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_DIGITAL:
        return basicSetInputDigital(null, msgs);
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_FRQ:
        return basicSetInputFrq(null, msgs);
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_SPI:
        return basicSetInputSPI(null, msgs);
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_CONFIG_SUBSYSTEM:
        return ((InternalEList<?>)getInputConfigSubsystem()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_NULL:
        return getInputNull();
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_ANALOG:
        return getInputAnalog();
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_TEMPERATURE:
        return getInputTemperature();
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_DIGITAL:
        return getInputDigital();
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_FRQ:
        return getInputFrq();
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_SPI:
        return getInputSPI();
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_CONFIG_SUBSYSTEM:
        return getInputConfigSubsystem();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_NULL:
        setInputNull((InputConfigSubsystemNull)newValue);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_ANALOG:
        setInputAnalog((InputConfigSubsystemAnalog)newValue);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_TEMPERATURE:
        setInputTemperature((InputConfigSubsystemTemperature)newValue);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_DIGITAL:
        setInputDigital((InputConfigSubsystemDigital)newValue);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_FRQ:
        setInputFrq((InputConfigSubsystemFrq)newValue);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_SPI:
        setInputSPI((InputConfigSubsystemSPI)newValue);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_CONFIG_SUBSYSTEM:
        getInputConfigSubsystem().clear();
        getInputConfigSubsystem().addAll((Collection<? extends InputConfigSubsystemItem>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_NULL:
        setInputNull((InputConfigSubsystemNull)null);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_ANALOG:
        setInputAnalog((InputConfigSubsystemAnalog)null);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_TEMPERATURE:
        setInputTemperature((InputConfigSubsystemTemperature)null);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_DIGITAL:
        setInputDigital((InputConfigSubsystemDigital)null);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_FRQ:
        setInputFrq((InputConfigSubsystemFrq)null);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_SPI:
        setInputSPI((InputConfigSubsystemSPI)null);
        return;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_CONFIG_SUBSYSTEM:
        getInputConfigSubsystem().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_NULL:
        return inputNull != null;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_ANALOG:
        return inputAnalog != null;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_TEMPERATURE:
        return inputTemperature != null;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_DIGITAL:
        return inputDigital != null;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_FRQ:
        return inputFrq != null;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_SPI:
        return inputSPI != null;
      case ConfiguratorPackage.INPUT_SUBSYSTEMS__INPUT_CONFIG_SUBSYSTEM:
        return inputConfigSubsystem != null && !inputConfigSubsystem.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //InputSubsystemsImpl
