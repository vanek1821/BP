/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Config Subsystem Analog</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputConfigSubsystemAnalog()
 * @model
 * @generated
 */
public interface InputConfigSubsystemAnalog extends InputDriverType
{
} // InputConfigSubsystemAnalog
