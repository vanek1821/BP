/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ASAPMeasurment;
import zf.pios.configurator.ConfiguratorPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ASAP Measurment</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.ASAPMeasurmentImpl#getLowerLimit <em>Lower Limit</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ASAPMeasurmentImpl#getUpperLimit <em>Upper Limit</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ASAPMeasurmentImpl extends MinimalEObjectImpl.Container implements ASAPMeasurment
{
  /**
   * The default value of the '{@link #getLowerLimit() <em>Lower Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLowerLimit()
   * @generated
   * @ordered
   */
  protected static final String LOWER_LIMIT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLowerLimit() <em>Lower Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLowerLimit()
   * @generated
   * @ordered
   */
  protected String lowerLimit = LOWER_LIMIT_EDEFAULT;

  /**
   * The default value of the '{@link #getUpperLimit() <em>Upper Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUpperLimit()
   * @generated
   * @ordered
   */
  protected static final String UPPER_LIMIT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getUpperLimit() <em>Upper Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUpperLimit()
   * @generated
   * @ordered
   */
  protected String upperLimit = UPPER_LIMIT_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ASAPMeasurmentImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.ASAP_MEASURMENT;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLowerLimit()
  {
    return lowerLimit;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLowerLimit(String newLowerLimit)
  {
    String oldLowerLimit = lowerLimit;
    lowerLimit = newLowerLimit;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.ASAP_MEASURMENT__LOWER_LIMIT, oldLowerLimit, lowerLimit));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getUpperLimit()
  {
    return upperLimit;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUpperLimit(String newUpperLimit)
  {
    String oldUpperLimit = upperLimit;
    upperLimit = newUpperLimit;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.ASAP_MEASURMENT__UPPER_LIMIT, oldUpperLimit, upperLimit));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.ASAP_MEASURMENT__LOWER_LIMIT:
        return getLowerLimit();
      case ConfiguratorPackage.ASAP_MEASURMENT__UPPER_LIMIT:
        return getUpperLimit();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.ASAP_MEASURMENT__LOWER_LIMIT:
        setLowerLimit((String)newValue);
        return;
      case ConfiguratorPackage.ASAP_MEASURMENT__UPPER_LIMIT:
        setUpperLimit((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.ASAP_MEASURMENT__LOWER_LIMIT:
        setLowerLimit(LOWER_LIMIT_EDEFAULT);
        return;
      case ConfiguratorPackage.ASAP_MEASURMENT__UPPER_LIMIT:
        setUpperLimit(UPPER_LIMIT_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.ASAP_MEASURMENT__LOWER_LIMIT:
        return LOWER_LIMIT_EDEFAULT == null ? lowerLimit != null : !LOWER_LIMIT_EDEFAULT.equals(lowerLimit);
      case ConfiguratorPackage.ASAP_MEASURMENT__UPPER_LIMIT:
        return UPPER_LIMIT_EDEFAULT == null ? upperLimit != null : !UPPER_LIMIT_EDEFAULT.equals(upperLimit);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (lowerLimit: ");
    result.append(lowerLimit);
    result.append(", upperLimit: ");
    result.append(upperLimit);
    result.append(')');
    return result.toString();
  }

} //ASAPMeasurmentImpl
