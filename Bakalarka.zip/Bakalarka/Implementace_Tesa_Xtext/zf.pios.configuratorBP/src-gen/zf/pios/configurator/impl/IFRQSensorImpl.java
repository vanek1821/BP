/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.IFRQSensor;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>IFRQ Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.IFRQSensorImpl#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IFRQSensorImpl#getInitialWaitingTime <em>Initial Waiting Time</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IFRQSensorImpl#getDirChangeMinPeriods <em>Dir Change Min Periods</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IFRQSensorImpl#getDirectionChangeDebounceTime <em>Direction Change Debounce Time</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IFRQSensorImpl extends MinimalEObjectImpl.Container implements IFRQSensor
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getInitialWaitingTime() <em>Initial Waiting Time</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInitialWaitingTime()
   * @generated
   * @ordered
   */
  protected static final String INITIAL_WAITING_TIME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getInitialWaitingTime() <em>Initial Waiting Time</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInitialWaitingTime()
   * @generated
   * @ordered
   */
  protected String initialWaitingTime = INITIAL_WAITING_TIME_EDEFAULT;

  /**
   * The default value of the '{@link #getDirChangeMinPeriods() <em>Dir Change Min Periods</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDirChangeMinPeriods()
   * @generated
   * @ordered
   */
  protected static final String DIR_CHANGE_MIN_PERIODS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDirChangeMinPeriods() <em>Dir Change Min Periods</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDirChangeMinPeriods()
   * @generated
   * @ordered
   */
  protected String dirChangeMinPeriods = DIR_CHANGE_MIN_PERIODS_EDEFAULT;

  /**
   * The default value of the '{@link #getDirectionChangeDebounceTime() <em>Direction Change Debounce Time</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDirectionChangeDebounceTime()
   * @generated
   * @ordered
   */
  protected static final String DIRECTION_CHANGE_DEBOUNCE_TIME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDirectionChangeDebounceTime() <em>Direction Change Debounce Time</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDirectionChangeDebounceTime()
   * @generated
   * @ordered
   */
  protected String directionChangeDebounceTime = DIRECTION_CHANGE_DEBOUNCE_TIME_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected IFRQSensorImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.IFRQ_SENSOR;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IFRQ_SENSOR__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getInitialWaitingTime()
  {
    return initialWaitingTime;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInitialWaitingTime(String newInitialWaitingTime)
  {
    String oldInitialWaitingTime = initialWaitingTime;
    initialWaitingTime = newInitialWaitingTime;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IFRQ_SENSOR__INITIAL_WAITING_TIME, oldInitialWaitingTime, initialWaitingTime));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDirChangeMinPeriods()
  {
    return dirChangeMinPeriods;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDirChangeMinPeriods(String newDirChangeMinPeriods)
  {
    String oldDirChangeMinPeriods = dirChangeMinPeriods;
    dirChangeMinPeriods = newDirChangeMinPeriods;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IFRQ_SENSOR__DIR_CHANGE_MIN_PERIODS, oldDirChangeMinPeriods, dirChangeMinPeriods));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDirectionChangeDebounceTime()
  {
    return directionChangeDebounceTime;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDirectionChangeDebounceTime(String newDirectionChangeDebounceTime)
  {
    String oldDirectionChangeDebounceTime = directionChangeDebounceTime;
    directionChangeDebounceTime = newDirectionChangeDebounceTime;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IFRQ_SENSOR__DIRECTION_CHANGE_DEBOUNCE_TIME, oldDirectionChangeDebounceTime, directionChangeDebounceTime));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IFRQ_SENSOR__NAME:
        return getName();
      case ConfiguratorPackage.IFRQ_SENSOR__INITIAL_WAITING_TIME:
        return getInitialWaitingTime();
      case ConfiguratorPackage.IFRQ_SENSOR__DIR_CHANGE_MIN_PERIODS:
        return getDirChangeMinPeriods();
      case ConfiguratorPackage.IFRQ_SENSOR__DIRECTION_CHANGE_DEBOUNCE_TIME:
        return getDirectionChangeDebounceTime();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IFRQ_SENSOR__NAME:
        setName((String)newValue);
        return;
      case ConfiguratorPackage.IFRQ_SENSOR__INITIAL_WAITING_TIME:
        setInitialWaitingTime((String)newValue);
        return;
      case ConfiguratorPackage.IFRQ_SENSOR__DIR_CHANGE_MIN_PERIODS:
        setDirChangeMinPeriods((String)newValue);
        return;
      case ConfiguratorPackage.IFRQ_SENSOR__DIRECTION_CHANGE_DEBOUNCE_TIME:
        setDirectionChangeDebounceTime((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IFRQ_SENSOR__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.IFRQ_SENSOR__INITIAL_WAITING_TIME:
        setInitialWaitingTime(INITIAL_WAITING_TIME_EDEFAULT);
        return;
      case ConfiguratorPackage.IFRQ_SENSOR__DIR_CHANGE_MIN_PERIODS:
        setDirChangeMinPeriods(DIR_CHANGE_MIN_PERIODS_EDEFAULT);
        return;
      case ConfiguratorPackage.IFRQ_SENSOR__DIRECTION_CHANGE_DEBOUNCE_TIME:
        setDirectionChangeDebounceTime(DIRECTION_CHANGE_DEBOUNCE_TIME_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IFRQ_SENSOR__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ConfiguratorPackage.IFRQ_SENSOR__INITIAL_WAITING_TIME:
        return INITIAL_WAITING_TIME_EDEFAULT == null ? initialWaitingTime != null : !INITIAL_WAITING_TIME_EDEFAULT.equals(initialWaitingTime);
      case ConfiguratorPackage.IFRQ_SENSOR__DIR_CHANGE_MIN_PERIODS:
        return DIR_CHANGE_MIN_PERIODS_EDEFAULT == null ? dirChangeMinPeriods != null : !DIR_CHANGE_MIN_PERIODS_EDEFAULT.equals(dirChangeMinPeriods);
      case ConfiguratorPackage.IFRQ_SENSOR__DIRECTION_CHANGE_DEBOUNCE_TIME:
        return DIRECTION_CHANGE_DEBOUNCE_TIME_EDEFAULT == null ? directionChangeDebounceTime != null : !DIRECTION_CHANGE_DEBOUNCE_TIME_EDEFAULT.equals(directionChangeDebounceTime);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", initialWaitingTime: ");
    result.append(initialWaitingTime);
    result.append(", dirChangeMinPeriods: ");
    result.append(dirChangeMinPeriods);
    result.append(", directionChangeDebounceTime: ");
    result.append(directionChangeDebounceTime);
    result.append(')');
    return result.toString();
  }

} //IFRQSensorImpl
