/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SPITX Data</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.SPITXData#getByteOne <em>Byte One</em>}</li>
 *   <li>{@link zf.pios.configurator.SPITXData#getByteTwo <em>Byte Two</em>}</li>
 *   <li>{@link zf.pios.configurator.SPITXData#getByteThree <em>Byte Three</em>}</li>
 *   <li>{@link zf.pios.configurator.SPITXData#getByteFour <em>Byte Four</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getSPITXData()
 * @model
 * @generated
 */
public interface SPITXData extends EObject
{
  /**
   * Returns the value of the '<em><b>Byte One</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Byte One</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Byte One</em>' attribute.
   * @see #setByteOne(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPITXData_ByteOne()
   * @model
   * @generated
   */
  String getByteOne();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPITXData#getByteOne <em>Byte One</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Byte One</em>' attribute.
   * @see #getByteOne()
   * @generated
   */
  void setByteOne(String value);

  /**
   * Returns the value of the '<em><b>Byte Two</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Byte Two</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Byte Two</em>' attribute.
   * @see #setByteTwo(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPITXData_ByteTwo()
   * @model
   * @generated
   */
  String getByteTwo();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPITXData#getByteTwo <em>Byte Two</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Byte Two</em>' attribute.
   * @see #getByteTwo()
   * @generated
   */
  void setByteTwo(String value);

  /**
   * Returns the value of the '<em><b>Byte Three</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Byte Three</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Byte Three</em>' attribute.
   * @see #setByteThree(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPITXData_ByteThree()
   * @model
   * @generated
   */
  String getByteThree();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPITXData#getByteThree <em>Byte Three</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Byte Three</em>' attribute.
   * @see #getByteThree()
   * @generated
   */
  void setByteThree(String value);

  /**
   * Returns the value of the '<em><b>Byte Four</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Byte Four</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Byte Four</em>' attribute.
   * @see #setByteFour(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPITXData_ByteFour()
   * @model
   * @generated
   */
  String getByteFour();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPITXData#getByteFour <em>Byte Four</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Byte Four</em>' attribute.
   * @see #getByteFour()
   * @generated
   */
  void setByteFour(String value);

} // SPITXData
