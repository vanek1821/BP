/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.Configuration;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.Hardware;
import zf.pios.configurator.Imports;
import zf.pios.configurator.Signals;
import zf.pios.configurator.Variants;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Configuration</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.ConfigurationImpl#getConfigurationName <em>Configuration Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigurationImpl#getVersion <em>Version</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigurationImpl#getMainMergeFile <em>Main Merge File</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigurationImpl#getImports <em>Imports</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigurationImpl#getVariants <em>Variants</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigurationImpl#getSystem <em>System</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigurationImpl#getHardware <em>Hardware</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigurationImpl#getSignals <em>Signals</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConfigurationImpl extends MinimalEObjectImpl.Container implements Configuration
{
  /**
   * The default value of the '{@link #getConfigurationName() <em>Configuration Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConfigurationName()
   * @generated
   * @ordered
   */
  protected static final String CONFIGURATION_NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getConfigurationName() <em>Configuration Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConfigurationName()
   * @generated
   * @ordered
   */
  protected String configurationName = CONFIGURATION_NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getVersion() <em>Version</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVersion()
   * @generated
   * @ordered
   */
  protected static final String VERSION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getVersion() <em>Version</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVersion()
   * @generated
   * @ordered
   */
  protected String version = VERSION_EDEFAULT;

  /**
   * The default value of the '{@link #getMainMergeFile() <em>Main Merge File</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMainMergeFile()
   * @generated
   * @ordered
   */
  protected static final String MAIN_MERGE_FILE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getMainMergeFile() <em>Main Merge File</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMainMergeFile()
   * @generated
   * @ordered
   */
  protected String mainMergeFile = MAIN_MERGE_FILE_EDEFAULT;

  /**
   * The cached value of the '{@link #getImports() <em>Imports</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getImports()
   * @generated
   * @ordered
   */
  protected EList<Imports> imports;

  /**
   * The cached value of the '{@link #getVariants() <em>Variants</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVariants()
   * @generated
   * @ordered
   */
  protected Variants variants;

  /**
   * The cached value of the '{@link #getSystem() <em>System</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSystem()
   * @generated
   * @ordered
   */
  protected zf.pios.configurator.System system;

  /**
   * The cached value of the '{@link #getHardware() <em>Hardware</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHardware()
   * @generated
   * @ordered
   */
  protected Hardware hardware;

  /**
   * The cached value of the '{@link #getSignals() <em>Signals</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSignals()
   * @generated
   * @ordered
   */
  protected Signals signals;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ConfigurationImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.CONFIGURATION;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getConfigurationName()
  {
    return configurationName;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setConfigurationName(String newConfigurationName)
  {
    String oldConfigurationName = configurationName;
    configurationName = newConfigurationName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__CONFIGURATION_NAME, oldConfigurationName, configurationName));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getVersion()
  {
    return version;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setVersion(String newVersion)
  {
    String oldVersion = version;
    version = newVersion;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__VERSION, oldVersion, version));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getMainMergeFile()
  {
    return mainMergeFile;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMainMergeFile(String newMainMergeFile)
  {
    String oldMainMergeFile = mainMergeFile;
    mainMergeFile = newMainMergeFile;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__MAIN_MERGE_FILE, oldMainMergeFile, mainMergeFile));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Imports> getImports()
  {
    if (imports == null)
    {
      imports = new EObjectContainmentEList<Imports>(Imports.class, this, ConfiguratorPackage.CONFIGURATION__IMPORTS);
    }
    return imports;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Variants getVariants()
  {
    return variants;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetVariants(Variants newVariants, NotificationChain msgs)
  {
    Variants oldVariants = variants;
    variants = newVariants;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__VARIANTS, oldVariants, newVariants);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setVariants(Variants newVariants)
  {
    if (newVariants != variants)
    {
      NotificationChain msgs = null;
      if (variants != null)
        msgs = ((InternalEObject)variants).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIGURATION__VARIANTS, null, msgs);
      if (newVariants != null)
        msgs = ((InternalEObject)newVariants).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIGURATION__VARIANTS, null, msgs);
      msgs = basicSetVariants(newVariants, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__VARIANTS, newVariants, newVariants));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public zf.pios.configurator.System getSystem()
  {
    return system;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetSystem(zf.pios.configurator.System newSystem, NotificationChain msgs)
  {
    zf.pios.configurator.System oldSystem = system;
    system = newSystem;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__SYSTEM, oldSystem, newSystem);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSystem(zf.pios.configurator.System newSystem)
  {
    if (newSystem != system)
    {
      NotificationChain msgs = null;
      if (system != null)
        msgs = ((InternalEObject)system).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIGURATION__SYSTEM, null, msgs);
      if (newSystem != null)
        msgs = ((InternalEObject)newSystem).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIGURATION__SYSTEM, null, msgs);
      msgs = basicSetSystem(newSystem, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__SYSTEM, newSystem, newSystem));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Hardware getHardware()
  {
    return hardware;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetHardware(Hardware newHardware, NotificationChain msgs)
  {
    Hardware oldHardware = hardware;
    hardware = newHardware;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__HARDWARE, oldHardware, newHardware);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHardware(Hardware newHardware)
  {
    if (newHardware != hardware)
    {
      NotificationChain msgs = null;
      if (hardware != null)
        msgs = ((InternalEObject)hardware).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIGURATION__HARDWARE, null, msgs);
      if (newHardware != null)
        msgs = ((InternalEObject)newHardware).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIGURATION__HARDWARE, null, msgs);
      msgs = basicSetHardware(newHardware, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__HARDWARE, newHardware, newHardware));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Signals getSignals()
  {
    return signals;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetSignals(Signals newSignals, NotificationChain msgs)
  {
    Signals oldSignals = signals;
    signals = newSignals;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__SIGNALS, oldSignals, newSignals);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSignals(Signals newSignals)
  {
    if (newSignals != signals)
    {
      NotificationChain msgs = null;
      if (signals != null)
        msgs = ((InternalEObject)signals).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIGURATION__SIGNALS, null, msgs);
      if (newSignals != null)
        msgs = ((InternalEObject)newSignals).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIGURATION__SIGNALS, null, msgs);
      msgs = basicSetSignals(newSignals, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIGURATION__SIGNALS, newSignals, newSignals));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIGURATION__IMPORTS:
        return ((InternalEList<?>)getImports()).basicRemove(otherEnd, msgs);
      case ConfiguratorPackage.CONFIGURATION__VARIANTS:
        return basicSetVariants(null, msgs);
      case ConfiguratorPackage.CONFIGURATION__SYSTEM:
        return basicSetSystem(null, msgs);
      case ConfiguratorPackage.CONFIGURATION__HARDWARE:
        return basicSetHardware(null, msgs);
      case ConfiguratorPackage.CONFIGURATION__SIGNALS:
        return basicSetSignals(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIGURATION__CONFIGURATION_NAME:
        return getConfigurationName();
      case ConfiguratorPackage.CONFIGURATION__VERSION:
        return getVersion();
      case ConfiguratorPackage.CONFIGURATION__MAIN_MERGE_FILE:
        return getMainMergeFile();
      case ConfiguratorPackage.CONFIGURATION__IMPORTS:
        return getImports();
      case ConfiguratorPackage.CONFIGURATION__VARIANTS:
        return getVariants();
      case ConfiguratorPackage.CONFIGURATION__SYSTEM:
        return getSystem();
      case ConfiguratorPackage.CONFIGURATION__HARDWARE:
        return getHardware();
      case ConfiguratorPackage.CONFIGURATION__SIGNALS:
        return getSignals();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIGURATION__CONFIGURATION_NAME:
        setConfigurationName((String)newValue);
        return;
      case ConfiguratorPackage.CONFIGURATION__VERSION:
        setVersion((String)newValue);
        return;
      case ConfiguratorPackage.CONFIGURATION__MAIN_MERGE_FILE:
        setMainMergeFile((String)newValue);
        return;
      case ConfiguratorPackage.CONFIGURATION__IMPORTS:
        getImports().clear();
        getImports().addAll((Collection<? extends Imports>)newValue);
        return;
      case ConfiguratorPackage.CONFIGURATION__VARIANTS:
        setVariants((Variants)newValue);
        return;
      case ConfiguratorPackage.CONFIGURATION__SYSTEM:
        setSystem((zf.pios.configurator.System)newValue);
        return;
      case ConfiguratorPackage.CONFIGURATION__HARDWARE:
        setHardware((Hardware)newValue);
        return;
      case ConfiguratorPackage.CONFIGURATION__SIGNALS:
        setSignals((Signals)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIGURATION__CONFIGURATION_NAME:
        setConfigurationName(CONFIGURATION_NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.CONFIGURATION__VERSION:
        setVersion(VERSION_EDEFAULT);
        return;
      case ConfiguratorPackage.CONFIGURATION__MAIN_MERGE_FILE:
        setMainMergeFile(MAIN_MERGE_FILE_EDEFAULT);
        return;
      case ConfiguratorPackage.CONFIGURATION__IMPORTS:
        getImports().clear();
        return;
      case ConfiguratorPackage.CONFIGURATION__VARIANTS:
        setVariants((Variants)null);
        return;
      case ConfiguratorPackage.CONFIGURATION__SYSTEM:
        setSystem((zf.pios.configurator.System)null);
        return;
      case ConfiguratorPackage.CONFIGURATION__HARDWARE:
        setHardware((Hardware)null);
        return;
      case ConfiguratorPackage.CONFIGURATION__SIGNALS:
        setSignals((Signals)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIGURATION__CONFIGURATION_NAME:
        return CONFIGURATION_NAME_EDEFAULT == null ? configurationName != null : !CONFIGURATION_NAME_EDEFAULT.equals(configurationName);
      case ConfiguratorPackage.CONFIGURATION__VERSION:
        return VERSION_EDEFAULT == null ? version != null : !VERSION_EDEFAULT.equals(version);
      case ConfiguratorPackage.CONFIGURATION__MAIN_MERGE_FILE:
        return MAIN_MERGE_FILE_EDEFAULT == null ? mainMergeFile != null : !MAIN_MERGE_FILE_EDEFAULT.equals(mainMergeFile);
      case ConfiguratorPackage.CONFIGURATION__IMPORTS:
        return imports != null && !imports.isEmpty();
      case ConfiguratorPackage.CONFIGURATION__VARIANTS:
        return variants != null;
      case ConfiguratorPackage.CONFIGURATION__SYSTEM:
        return system != null;
      case ConfiguratorPackage.CONFIGURATION__HARDWARE:
        return hardware != null;
      case ConfiguratorPackage.CONFIGURATION__SIGNALS:
        return signals != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (configurationName: ");
    result.append(configurationName);
    result.append(", version: ");
    result.append(version);
    result.append(", mainMergeFile: ");
    result.append(mainMergeFile);
    result.append(')');
    return result.toString();
  }

} //ConfigurationImpl
