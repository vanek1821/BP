/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputConfigSubsystemNull;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Config Subsystem Null</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InputConfigSubsystemNullImpl extends InputDriverTypeImpl implements InputConfigSubsystemNull
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputConfigSubsystemNullImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.INPUT_CONFIG_SUBSYSTEM_NULL;
  }

} //InputConfigSubsystemNullImpl
