/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Signal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.Signal#getDataType <em>Data Type</em>}</li>
 *   <li>{@link zf.pios.configurator.Signal#getDescription <em>Description</em>}</li>
 *   <li>{@link zf.pios.configurator.Signal#getAsapMeasurment <em>Asap Measurment</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getSignal()
 * @model
 * @generated
 */
public interface Signal extends EObject
{
  /**
   * Returns the value of the '<em><b>Data Type</b></em>' attribute.
   * The literals are from the enumeration {@link zf.pios.configurator.dataTypeEnumeration}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Data Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Data Type</em>' attribute.
   * @see zf.pios.configurator.dataTypeEnumeration
   * @see #setDataType(dataTypeEnumeration)
   * @see zf.pios.configurator.ConfiguratorPackage#getSignal_DataType()
   * @model
   * @generated
   */
  dataTypeEnumeration getDataType();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Signal#getDataType <em>Data Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Data Type</em>' attribute.
   * @see zf.pios.configurator.dataTypeEnumeration
   * @see #getDataType()
   * @generated
   */
  void setDataType(dataTypeEnumeration value);

  /**
   * Returns the value of the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Description</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Description</em>' attribute.
   * @see #setDescription(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSignal_Description()
   * @model
   * @generated
   */
  String getDescription();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Signal#getDescription <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Description</em>' attribute.
   * @see #getDescription()
   * @generated
   */
  void setDescription(String value);

  /**
   * Returns the value of the '<em><b>Asap Measurment</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Asap Measurment</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Asap Measurment</em>' containment reference.
   * @see #setAsapMeasurment(ASAPMeasurment)
   * @see zf.pios.configurator.ConfiguratorPackage#getSignal_AsapMeasurment()
   * @model containment="true"
   * @generated
   */
  ASAPMeasurment getAsapMeasurment();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Signal#getAsapMeasurment <em>Asap Measurment</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Asap Measurment</em>' containment reference.
   * @see #getAsapMeasurment()
   * @generated
   */
  void setAsapMeasurment(ASAPMeasurment value);

} // Signal
