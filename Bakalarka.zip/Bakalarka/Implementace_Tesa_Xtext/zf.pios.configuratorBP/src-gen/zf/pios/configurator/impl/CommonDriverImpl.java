/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.CommonDriver;
import zf.pios.configurator.ConfiguratorPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Common Driver</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.CommonDriverImpl#getDriverIndex <em>Driver Index</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.CommonDriverImpl#getControllerPinName <em>Controller Pin Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.CommonDriverImpl#getDescription <em>Description</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CommonDriverImpl extends MinimalEObjectImpl.Container implements CommonDriver
{
  /**
   * The default value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected static final String DRIVER_INDEX_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected String driverIndex = DRIVER_INDEX_EDEFAULT;

  /**
   * The default value of the '{@link #getControllerPinName() <em>Controller Pin Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getControllerPinName()
   * @generated
   * @ordered
   */
  protected static final String CONTROLLER_PIN_NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getControllerPinName() <em>Controller Pin Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getControllerPinName()
   * @generated
   * @ordered
   */
  protected String controllerPinName = CONTROLLER_PIN_NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected static final String DESCRIPTION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected String description = DESCRIPTION_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected CommonDriverImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.COMMON_DRIVER;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDriverIndex()
  {
    return driverIndex;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDriverIndex(String newDriverIndex)
  {
    String oldDriverIndex = driverIndex;
    driverIndex = newDriverIndex;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.COMMON_DRIVER__DRIVER_INDEX, oldDriverIndex, driverIndex));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getControllerPinName()
  {
    return controllerPinName;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setControllerPinName(String newControllerPinName)
  {
    String oldControllerPinName = controllerPinName;
    controllerPinName = newControllerPinName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.COMMON_DRIVER__CONTROLLER_PIN_NAME, oldControllerPinName, controllerPinName));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDescription()
  {
    return description;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDescription(String newDescription)
  {
    String oldDescription = description;
    description = newDescription;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.COMMON_DRIVER__DESCRIPTION, oldDescription, description));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.COMMON_DRIVER__DRIVER_INDEX:
        return getDriverIndex();
      case ConfiguratorPackage.COMMON_DRIVER__CONTROLLER_PIN_NAME:
        return getControllerPinName();
      case ConfiguratorPackage.COMMON_DRIVER__DESCRIPTION:
        return getDescription();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.COMMON_DRIVER__DRIVER_INDEX:
        setDriverIndex((String)newValue);
        return;
      case ConfiguratorPackage.COMMON_DRIVER__CONTROLLER_PIN_NAME:
        setControllerPinName((String)newValue);
        return;
      case ConfiguratorPackage.COMMON_DRIVER__DESCRIPTION:
        setDescription((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.COMMON_DRIVER__DRIVER_INDEX:
        setDriverIndex(DRIVER_INDEX_EDEFAULT);
        return;
      case ConfiguratorPackage.COMMON_DRIVER__CONTROLLER_PIN_NAME:
        setControllerPinName(CONTROLLER_PIN_NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.COMMON_DRIVER__DESCRIPTION:
        setDescription(DESCRIPTION_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.COMMON_DRIVER__DRIVER_INDEX:
        return DRIVER_INDEX_EDEFAULT == null ? driverIndex != null : !DRIVER_INDEX_EDEFAULT.equals(driverIndex);
      case ConfiguratorPackage.COMMON_DRIVER__CONTROLLER_PIN_NAME:
        return CONTROLLER_PIN_NAME_EDEFAULT == null ? controllerPinName != null : !CONTROLLER_PIN_NAME_EDEFAULT.equals(controllerPinName);
      case ConfiguratorPackage.COMMON_DRIVER__DESCRIPTION:
        return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (driverIndex: ");
    result.append(driverIndex);
    result.append(", controllerPinName: ");
    result.append(controllerPinName);
    result.append(", description: ");
    result.append(description);
    result.append(')');
    return result.toString();
  }

} //CommonDriverImpl
