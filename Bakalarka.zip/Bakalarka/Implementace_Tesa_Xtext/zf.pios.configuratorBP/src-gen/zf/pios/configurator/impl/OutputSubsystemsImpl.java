/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutputConfigSubsystemDigital;
import zf.pios.configurator.OutputConfigSubsystemElDiag;
import zf.pios.configurator.OutputConfigSubsystemItem;
import zf.pios.configurator.OutputConfigSubsystemNull;
import zf.pios.configurator.OutputConfigSubsystemPWM;
import zf.pios.configurator.OutputSubsystems;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Subsystems</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.OutputSubsystemsImpl#getOutputNull <em>Output Null</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.OutputSubsystemsImpl#getOutputDigital <em>Output Digital</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.OutputSubsystemsImpl#getOutputPWM <em>Output PWM</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.OutputSubsystemsImpl#getOutputElDiag <em>Output El Diag</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.OutputSubsystemsImpl#getOutputConfigSubsystem <em>Output Config Subsystem</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutputSubsystemsImpl extends MinimalEObjectImpl.Container implements OutputSubsystems
{
  /**
   * The cached value of the '{@link #getOutputNull() <em>Output Null</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputNull()
   * @generated
   * @ordered
   */
  protected OutputConfigSubsystemNull outputNull;

  /**
   * The cached value of the '{@link #getOutputDigital() <em>Output Digital</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputDigital()
   * @generated
   * @ordered
   */
  protected OutputConfigSubsystemDigital outputDigital;

  /**
   * The cached value of the '{@link #getOutputPWM() <em>Output PWM</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputPWM()
   * @generated
   * @ordered
   */
  protected OutputConfigSubsystemPWM outputPWM;

  /**
   * The cached value of the '{@link #getOutputElDiag() <em>Output El Diag</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputElDiag()
   * @generated
   * @ordered
   */
  protected OutputConfigSubsystemElDiag outputElDiag;

  /**
   * The cached value of the '{@link #getOutputConfigSubsystem() <em>Output Config Subsystem</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputConfigSubsystem()
   * @generated
   * @ordered
   */
  protected EList<OutputConfigSubsystemItem> outputConfigSubsystem;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutputSubsystemsImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUTPUT_SUBSYSTEMS;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputConfigSubsystemNull getOutputNull()
  {
    return outputNull;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOutputNull(OutputConfigSubsystemNull newOutputNull, NotificationChain msgs)
  {
    OutputConfigSubsystemNull oldOutputNull = outputNull;
    outputNull = newOutputNull;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_NULL, oldOutputNull, newOutputNull);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOutputNull(OutputConfigSubsystemNull newOutputNull)
  {
    if (newOutputNull != outputNull)
    {
      NotificationChain msgs = null;
      if (outputNull != null)
        msgs = ((InternalEObject)outputNull).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_NULL, null, msgs);
      if (newOutputNull != null)
        msgs = ((InternalEObject)newOutputNull).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_NULL, null, msgs);
      msgs = basicSetOutputNull(newOutputNull, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_NULL, newOutputNull, newOutputNull));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputConfigSubsystemDigital getOutputDigital()
  {
    return outputDigital;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOutputDigital(OutputConfigSubsystemDigital newOutputDigital, NotificationChain msgs)
  {
    OutputConfigSubsystemDigital oldOutputDigital = outputDigital;
    outputDigital = newOutputDigital;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL, oldOutputDigital, newOutputDigital);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOutputDigital(OutputConfigSubsystemDigital newOutputDigital)
  {
    if (newOutputDigital != outputDigital)
    {
      NotificationChain msgs = null;
      if (outputDigital != null)
        msgs = ((InternalEObject)outputDigital).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL, null, msgs);
      if (newOutputDigital != null)
        msgs = ((InternalEObject)newOutputDigital).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL, null, msgs);
      msgs = basicSetOutputDigital(newOutputDigital, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL, newOutputDigital, newOutputDigital));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputConfigSubsystemPWM getOutputPWM()
  {
    return outputPWM;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOutputPWM(OutputConfigSubsystemPWM newOutputPWM, NotificationChain msgs)
  {
    OutputConfigSubsystemPWM oldOutputPWM = outputPWM;
    outputPWM = newOutputPWM;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_PWM, oldOutputPWM, newOutputPWM);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOutputPWM(OutputConfigSubsystemPWM newOutputPWM)
  {
    if (newOutputPWM != outputPWM)
    {
      NotificationChain msgs = null;
      if (outputPWM != null)
        msgs = ((InternalEObject)outputPWM).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_PWM, null, msgs);
      if (newOutputPWM != null)
        msgs = ((InternalEObject)newOutputPWM).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_PWM, null, msgs);
      msgs = basicSetOutputPWM(newOutputPWM, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_PWM, newOutputPWM, newOutputPWM));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputConfigSubsystemElDiag getOutputElDiag()
  {
    return outputElDiag;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOutputElDiag(OutputConfigSubsystemElDiag newOutputElDiag, NotificationChain msgs)
  {
    OutputConfigSubsystemElDiag oldOutputElDiag = outputElDiag;
    outputElDiag = newOutputElDiag;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG, oldOutputElDiag, newOutputElDiag);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOutputElDiag(OutputConfigSubsystemElDiag newOutputElDiag)
  {
    if (newOutputElDiag != outputElDiag)
    {
      NotificationChain msgs = null;
      if (outputElDiag != null)
        msgs = ((InternalEObject)outputElDiag).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG, null, msgs);
      if (newOutputElDiag != null)
        msgs = ((InternalEObject)newOutputElDiag).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG, null, msgs);
      msgs = basicSetOutputElDiag(newOutputElDiag, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG, newOutputElDiag, newOutputElDiag));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<OutputConfigSubsystemItem> getOutputConfigSubsystem()
  {
    if (outputConfigSubsystem == null)
    {
      outputConfigSubsystem = new EObjectContainmentEList<OutputConfigSubsystemItem>(OutputConfigSubsystemItem.class, this, ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_CONFIG_SUBSYSTEM);
    }
    return outputConfigSubsystem;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_NULL:
        return basicSetOutputNull(null, msgs);
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL:
        return basicSetOutputDigital(null, msgs);
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_PWM:
        return basicSetOutputPWM(null, msgs);
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG:
        return basicSetOutputElDiag(null, msgs);
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_CONFIG_SUBSYSTEM:
        return ((InternalEList<?>)getOutputConfigSubsystem()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_NULL:
        return getOutputNull();
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL:
        return getOutputDigital();
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_PWM:
        return getOutputPWM();
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG:
        return getOutputElDiag();
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_CONFIG_SUBSYSTEM:
        return getOutputConfigSubsystem();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_NULL:
        setOutputNull((OutputConfigSubsystemNull)newValue);
        return;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL:
        setOutputDigital((OutputConfigSubsystemDigital)newValue);
        return;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_PWM:
        setOutputPWM((OutputConfigSubsystemPWM)newValue);
        return;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG:
        setOutputElDiag((OutputConfigSubsystemElDiag)newValue);
        return;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_CONFIG_SUBSYSTEM:
        getOutputConfigSubsystem().clear();
        getOutputConfigSubsystem().addAll((Collection<? extends OutputConfigSubsystemItem>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_NULL:
        setOutputNull((OutputConfigSubsystemNull)null);
        return;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL:
        setOutputDigital((OutputConfigSubsystemDigital)null);
        return;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_PWM:
        setOutputPWM((OutputConfigSubsystemPWM)null);
        return;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG:
        setOutputElDiag((OutputConfigSubsystemElDiag)null);
        return;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_CONFIG_SUBSYSTEM:
        getOutputConfigSubsystem().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_NULL:
        return outputNull != null;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL:
        return outputDigital != null;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_PWM:
        return outputPWM != null;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG:
        return outputElDiag != null;
      case ConfiguratorPackage.OUTPUT_SUBSYSTEMS__OUTPUT_CONFIG_SUBSYSTEM:
        return outputConfigSubsystem != null && !outputConfigSubsystem.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //OutputSubsystemsImpl
