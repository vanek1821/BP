/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>El Diag</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.ElDiag#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.ElDiag#getEnable <em>Enable</em>}</li>
 *   <li>{@link zf.pios.configurator.ElDiag#getDiagnosisEnable <em>Diagnosis Enable</em>}</li>
 *   <li>{@link zf.pios.configurator.ElDiag#getDriverIndex <em>Driver Index</em>}</li>
 *   <li>{@link zf.pios.configurator.ElDiag#getPwmDiagnosis <em>Pwm Diagnosis</em>}</li>
 *   <li>{@link zf.pios.configurator.ElDiag#getPowerSupplySignal <em>Power Supply Signal</em>}</li>
 *   <li>{@link zf.pios.configurator.ElDiag#getDescription <em>Description</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getElDiag()
 * @model
 * @generated
 */
public interface ElDiag extends EObject
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getElDiag_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ElDiag#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Enable</b></em>' attribute.
   * The literals are from the enumeration {@link zf.pios.configurator.BOOLfalseDefault}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Enable</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Enable</em>' attribute.
   * @see zf.pios.configurator.BOOLfalseDefault
   * @see #setEnable(BOOLfalseDefault)
   * @see zf.pios.configurator.ConfiguratorPackage#getElDiag_Enable()
   * @model
   * @generated
   */
  BOOLfalseDefault getEnable();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ElDiag#getEnable <em>Enable</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Enable</em>' attribute.
   * @see zf.pios.configurator.BOOLfalseDefault
   * @see #getEnable()
   * @generated
   */
  void setEnable(BOOLfalseDefault value);

  /**
   * Returns the value of the '<em><b>Diagnosis Enable</b></em>' attribute.
   * The literals are from the enumeration {@link zf.pios.configurator.BOOLfalseDefault}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Diagnosis Enable</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Diagnosis Enable</em>' attribute.
   * @see zf.pios.configurator.BOOLfalseDefault
   * @see #setDiagnosisEnable(BOOLfalseDefault)
   * @see zf.pios.configurator.ConfiguratorPackage#getElDiag_DiagnosisEnable()
   * @model
   * @generated
   */
  BOOLfalseDefault getDiagnosisEnable();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ElDiag#getDiagnosisEnable <em>Diagnosis Enable</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Diagnosis Enable</em>' attribute.
   * @see zf.pios.configurator.BOOLfalseDefault
   * @see #getDiagnosisEnable()
   * @generated
   */
  void setDiagnosisEnable(BOOLfalseDefault value);

  /**
   * Returns the value of the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Driver Index</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Driver Index</em>' attribute.
   * @see #setDriverIndex(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getElDiag_DriverIndex()
   * @model
   * @generated
   */
  String getDriverIndex();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ElDiag#getDriverIndex <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Driver Index</em>' attribute.
   * @see #getDriverIndex()
   * @generated
   */
  void setDriverIndex(String value);

  /**
   * Returns the value of the '<em><b>Pwm Diagnosis</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Pwm Diagnosis</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Pwm Diagnosis</em>' attribute.
   * @see #setPwmDiagnosis(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getElDiag_PwmDiagnosis()
   * @model
   * @generated
   */
  String getPwmDiagnosis();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ElDiag#getPwmDiagnosis <em>Pwm Diagnosis</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Pwm Diagnosis</em>' attribute.
   * @see #getPwmDiagnosis()
   * @generated
   */
  void setPwmDiagnosis(String value);

  /**
   * Returns the value of the '<em><b>Power Supply Signal</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Power Supply Signal</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Power Supply Signal</em>' reference.
   * @see #setPowerSupplySignal(InputSignal)
   * @see zf.pios.configurator.ConfiguratorPackage#getElDiag_PowerSupplySignal()
   * @model
   * @generated
   */
  InputSignal getPowerSupplySignal();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ElDiag#getPowerSupplySignal <em>Power Supply Signal</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Power Supply Signal</em>' reference.
   * @see #getPowerSupplySignal()
   * @generated
   */
  void setPowerSupplySignal(InputSignal value);

  /**
   * Returns the value of the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Description</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Description</em>' attribute.
   * @see #setDescription(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getElDiag_Description()
   * @model
   * @generated
   */
  String getDescription();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ElDiag#getDescription <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Description</em>' attribute.
   * @see #getDescription()
   * @generated
   */
  void setDescription(String value);

} // ElDiag
