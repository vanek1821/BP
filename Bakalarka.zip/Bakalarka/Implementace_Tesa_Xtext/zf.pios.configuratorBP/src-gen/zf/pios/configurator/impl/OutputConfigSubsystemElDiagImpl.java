/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputSignal;
import zf.pios.configurator.OutputConfigSubsystemElDiag;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Config Subsystem El Diag</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.OutputConfigSubsystemElDiagImpl#getTempSensor <em>Temp Sensor</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutputConfigSubsystemElDiagImpl extends OutputDriverTypeImpl implements OutputConfigSubsystemElDiag
{
  /**
   * The cached value of the '{@link #getTempSensor() <em>Temp Sensor</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTempSensor()
   * @generated
   * @ordered
   */
  protected InputSignal tempSensor;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutputConfigSubsystemElDiagImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSignal getTempSensor()
  {
    if (tempSensor != null && tempSensor.eIsProxy())
    {
      InternalEObject oldTempSensor = (InternalEObject)tempSensor;
      tempSensor = (InputSignal)eResolveProxy(oldTempSensor);
      if (tempSensor != oldTempSensor)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__TEMP_SENSOR, oldTempSensor, tempSensor));
      }
    }
    return tempSensor;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSignal basicGetTempSensor()
  {
    return tempSensor;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTempSensor(InputSignal newTempSensor)
  {
    InputSignal oldTempSensor = tempSensor;
    tempSensor = newTempSensor;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__TEMP_SENSOR, oldTempSensor, tempSensor));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__TEMP_SENSOR:
        if (resolve) return getTempSensor();
        return basicGetTempSensor();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__TEMP_SENSOR:
        setTempSensor((InputSignal)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__TEMP_SENSOR:
        setTempSensor((InputSignal)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__TEMP_SENSOR:
        return tempSensor != null;
    }
    return super.eIsSet(featureID);
  }

} //OutputConfigSubsystemElDiagImpl
