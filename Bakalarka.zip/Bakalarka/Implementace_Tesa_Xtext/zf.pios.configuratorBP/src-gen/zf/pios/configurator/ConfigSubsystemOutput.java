/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Config Subsystem Output</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.ConfigSubsystemOutput#getMaximalNumberOutputSubsystems <em>Maximal Number Output Subsystems</em>}</li>
 *   <li>{@link zf.pios.configurator.ConfigSubsystemOutput#getOutputSubsystems <em>Output Subsystems</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystemOutput()
 * @model
 * @generated
 */
public interface ConfigSubsystemOutput extends EObject
{
  /**
   * Returns the value of the '<em><b>Maximal Number Output Subsystems</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Maximal Number Output Subsystems</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Maximal Number Output Subsystems</em>' attribute.
   * @see #setMaximalNumberOutputSubsystems(int)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystemOutput_MaximalNumberOutputSubsystems()
   * @model
   * @generated
   */
  int getMaximalNumberOutputSubsystems();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ConfigSubsystemOutput#getMaximalNumberOutputSubsystems <em>Maximal Number Output Subsystems</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Maximal Number Output Subsystems</em>' attribute.
   * @see #getMaximalNumberOutputSubsystems()
   * @generated
   */
  void setMaximalNumberOutputSubsystems(int value);

  /**
   * Returns the value of the '<em><b>Output Subsystems</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output Subsystems</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Output Subsystems</em>' containment reference.
   * @see #setOutputSubsystems(OutputSubsystems)
   * @see zf.pios.configurator.ConfiguratorPackage#getConfigSubsystemOutput_OutputSubsystems()
   * @model containment="true"
   * @generated
   */
  OutputSubsystems getOutputSubsystems();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ConfigSubsystemOutput#getOutputSubsystems <em>Output Subsystems</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Output Subsystems</em>' containment reference.
   * @see #getOutputSubsystems()
   * @generated
   */
  void setOutputSubsystems(OutputSubsystems value);

} // ConfigSubsystemOutput
