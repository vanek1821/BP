/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutDigDriver;
import zf.pios.configurator.OutDigitalDriverTableRef;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Out Digital Driver Table Ref</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.OutDigitalDriverTableRefImpl#getDummySignal <em>Dummy Signal</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.OutDigitalDriverTableRefImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutDigitalDriverTableRefImpl extends MinimalEObjectImpl.Container implements OutDigitalDriverTableRef
{
  /**
   * The default value of the '{@link #getDummySignal() <em>Dummy Signal</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDummySignal()
   * @generated
   * @ordered
   */
  protected static final String DUMMY_SIGNAL_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDummySignal() <em>Dummy Signal</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDummySignal()
   * @generated
   * @ordered
   */
  protected String dummySignal = DUMMY_SIGNAL_EDEFAULT;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected OutDigDriver name;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutDigitalDriverTableRefImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUT_DIGITAL_DRIVER_TABLE_REF;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDummySignal()
  {
    return dummySignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDummySignal(String newDummySignal)
  {
    String oldDummySignal = dummySignal;
    dummySignal = newDummySignal;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL, oldDummySignal, dummySignal));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutDigDriver getName()
  {
    if (name != null && name.eIsProxy())
    {
      InternalEObject oldName = (InternalEObject)name;
      name = (OutDigDriver)eResolveProxy(oldName);
      if (name != oldName)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__NAME, oldName, name));
      }
    }
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutDigDriver basicGetName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(OutDigDriver newName)
  {
    OutDigDriver oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL:
        return getDummySignal();
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__NAME:
        if (resolve) return getName();
        return basicGetName();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL:
        setDummySignal((String)newValue);
        return;
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__NAME:
        setName((OutDigDriver)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL:
        setDummySignal(DUMMY_SIGNAL_EDEFAULT);
        return;
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__NAME:
        setName((OutDigDriver)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL:
        return DUMMY_SIGNAL_EDEFAULT == null ? dummySignal != null : !DUMMY_SIGNAL_EDEFAULT.equals(dummySignal);
      case ConfiguratorPackage.OUT_DIGITAL_DRIVER_TABLE_REF__NAME:
        return name != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (dummySignal: ");
    result.append(dummySignal);
    result.append(')');
    return result.toString();
  }

} //OutDigitalDriverTableRefImpl
