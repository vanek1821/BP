/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutputDriverType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Driver Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class OutputDriverTypeImpl extends GenericSubsystemImpl implements OutputDriverType
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutputDriverTypeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUTPUT_DRIVER_TYPE;
  }

} //OutputDriverTypeImpl
