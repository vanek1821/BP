/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.IADC;
import zf.pios.configurator.InputSignal;
import zf.pios.configurator.iadcEnableEnumeration;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>IADC</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.IADCImpl#getDriverIndex <em>Driver Index</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IADCImpl#getEnable <em>Enable</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IADCImpl#getPowerSupplySignal <em>Power Supply Signal</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IADCImpl#getEnableElDiagPowerSupplyOff <em>Enable El Diag Power Supply Off</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IADCImpl#getElDiagInstanceIdx <em>El Diag Instance Idx</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IADCImpl#getControllerPinName <em>Controller Pin Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IADCImpl#getDescription <em>Description</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IADCImpl extends MinimalEObjectImpl.Container implements IADC
{
  /**
   * The default value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected static final String DRIVER_INDEX_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected String driverIndex = DRIVER_INDEX_EDEFAULT;

  /**
   * The default value of the '{@link #getEnable() <em>Enable</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEnable()
   * @generated
   * @ordered
   */
  protected static final iadcEnableEnumeration ENABLE_EDEFAULT = iadcEnableEnumeration.ADC_CHANNEL_DISABLED;

  /**
   * The cached value of the '{@link #getEnable() <em>Enable</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEnable()
   * @generated
   * @ordered
   */
  protected iadcEnableEnumeration enable = ENABLE_EDEFAULT;

  /**
   * The cached value of the '{@link #getPowerSupplySignal() <em>Power Supply Signal</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPowerSupplySignal()
   * @generated
   * @ordered
   */
  protected InputSignal powerSupplySignal;

  /**
   * The default value of the '{@link #getEnableElDiagPowerSupplyOff() <em>Enable El Diag Power Supply Off</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEnableElDiagPowerSupplyOff()
   * @generated
   * @ordered
   */
  protected static final String ENABLE_EL_DIAG_POWER_SUPPLY_OFF_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getEnableElDiagPowerSupplyOff() <em>Enable El Diag Power Supply Off</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEnableElDiagPowerSupplyOff()
   * @generated
   * @ordered
   */
  protected String enableElDiagPowerSupplyOff = ENABLE_EL_DIAG_POWER_SUPPLY_OFF_EDEFAULT;

  /**
   * The default value of the '{@link #getElDiagInstanceIdx() <em>El Diag Instance Idx</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getElDiagInstanceIdx()
   * @generated
   * @ordered
   */
  protected static final String EL_DIAG_INSTANCE_IDX_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getElDiagInstanceIdx() <em>El Diag Instance Idx</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getElDiagInstanceIdx()
   * @generated
   * @ordered
   */
  protected String elDiagInstanceIdx = EL_DIAG_INSTANCE_IDX_EDEFAULT;

  /**
   * The default value of the '{@link #getControllerPinName() <em>Controller Pin Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getControllerPinName()
   * @generated
   * @ordered
   */
  protected static final String CONTROLLER_PIN_NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getControllerPinName() <em>Controller Pin Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getControllerPinName()
   * @generated
   * @ordered
   */
  protected String controllerPinName = CONTROLLER_PIN_NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected static final String DESCRIPTION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected String description = DESCRIPTION_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected IADCImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.IADC;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDriverIndex()
  {
    return driverIndex;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDriverIndex(String newDriverIndex)
  {
    String oldDriverIndex = driverIndex;
    driverIndex = newDriverIndex;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IADC__DRIVER_INDEX, oldDriverIndex, driverIndex));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public iadcEnableEnumeration getEnable()
  {
    return enable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEnable(iadcEnableEnumeration newEnable)
  {
    iadcEnableEnumeration oldEnable = enable;
    enable = newEnable == null ? ENABLE_EDEFAULT : newEnable;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IADC__ENABLE, oldEnable, enable));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSignal getPowerSupplySignal()
  {
    if (powerSupplySignal != null && powerSupplySignal.eIsProxy())
    {
      InternalEObject oldPowerSupplySignal = (InternalEObject)powerSupplySignal;
      powerSupplySignal = (InputSignal)eResolveProxy(oldPowerSupplySignal);
      if (powerSupplySignal != oldPowerSupplySignal)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ConfiguratorPackage.IADC__POWER_SUPPLY_SIGNAL, oldPowerSupplySignal, powerSupplySignal));
      }
    }
    return powerSupplySignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSignal basicGetPowerSupplySignal()
  {
    return powerSupplySignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPowerSupplySignal(InputSignal newPowerSupplySignal)
  {
    InputSignal oldPowerSupplySignal = powerSupplySignal;
    powerSupplySignal = newPowerSupplySignal;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IADC__POWER_SUPPLY_SIGNAL, oldPowerSupplySignal, powerSupplySignal));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getEnableElDiagPowerSupplyOff()
  {
    return enableElDiagPowerSupplyOff;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEnableElDiagPowerSupplyOff(String newEnableElDiagPowerSupplyOff)
  {
    String oldEnableElDiagPowerSupplyOff = enableElDiagPowerSupplyOff;
    enableElDiagPowerSupplyOff = newEnableElDiagPowerSupplyOff;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IADC__ENABLE_EL_DIAG_POWER_SUPPLY_OFF, oldEnableElDiagPowerSupplyOff, enableElDiagPowerSupplyOff));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getElDiagInstanceIdx()
  {
    return elDiagInstanceIdx;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setElDiagInstanceIdx(String newElDiagInstanceIdx)
  {
    String oldElDiagInstanceIdx = elDiagInstanceIdx;
    elDiagInstanceIdx = newElDiagInstanceIdx;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IADC__EL_DIAG_INSTANCE_IDX, oldElDiagInstanceIdx, elDiagInstanceIdx));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getControllerPinName()
  {
    return controllerPinName;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setControllerPinName(String newControllerPinName)
  {
    String oldControllerPinName = controllerPinName;
    controllerPinName = newControllerPinName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IADC__CONTROLLER_PIN_NAME, oldControllerPinName, controllerPinName));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDescription()
  {
    return description;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDescription(String newDescription)
  {
    String oldDescription = description;
    description = newDescription;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IADC__DESCRIPTION, oldDescription, description));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IADC__DRIVER_INDEX:
        return getDriverIndex();
      case ConfiguratorPackage.IADC__ENABLE:
        return getEnable();
      case ConfiguratorPackage.IADC__POWER_SUPPLY_SIGNAL:
        if (resolve) return getPowerSupplySignal();
        return basicGetPowerSupplySignal();
      case ConfiguratorPackage.IADC__ENABLE_EL_DIAG_POWER_SUPPLY_OFF:
        return getEnableElDiagPowerSupplyOff();
      case ConfiguratorPackage.IADC__EL_DIAG_INSTANCE_IDX:
        return getElDiagInstanceIdx();
      case ConfiguratorPackage.IADC__CONTROLLER_PIN_NAME:
        return getControllerPinName();
      case ConfiguratorPackage.IADC__DESCRIPTION:
        return getDescription();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IADC__DRIVER_INDEX:
        setDriverIndex((String)newValue);
        return;
      case ConfiguratorPackage.IADC__ENABLE:
        setEnable((iadcEnableEnumeration)newValue);
        return;
      case ConfiguratorPackage.IADC__POWER_SUPPLY_SIGNAL:
        setPowerSupplySignal((InputSignal)newValue);
        return;
      case ConfiguratorPackage.IADC__ENABLE_EL_DIAG_POWER_SUPPLY_OFF:
        setEnableElDiagPowerSupplyOff((String)newValue);
        return;
      case ConfiguratorPackage.IADC__EL_DIAG_INSTANCE_IDX:
        setElDiagInstanceIdx((String)newValue);
        return;
      case ConfiguratorPackage.IADC__CONTROLLER_PIN_NAME:
        setControllerPinName((String)newValue);
        return;
      case ConfiguratorPackage.IADC__DESCRIPTION:
        setDescription((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IADC__DRIVER_INDEX:
        setDriverIndex(DRIVER_INDEX_EDEFAULT);
        return;
      case ConfiguratorPackage.IADC__ENABLE:
        setEnable(ENABLE_EDEFAULT);
        return;
      case ConfiguratorPackage.IADC__POWER_SUPPLY_SIGNAL:
        setPowerSupplySignal((InputSignal)null);
        return;
      case ConfiguratorPackage.IADC__ENABLE_EL_DIAG_POWER_SUPPLY_OFF:
        setEnableElDiagPowerSupplyOff(ENABLE_EL_DIAG_POWER_SUPPLY_OFF_EDEFAULT);
        return;
      case ConfiguratorPackage.IADC__EL_DIAG_INSTANCE_IDX:
        setElDiagInstanceIdx(EL_DIAG_INSTANCE_IDX_EDEFAULT);
        return;
      case ConfiguratorPackage.IADC__CONTROLLER_PIN_NAME:
        setControllerPinName(CONTROLLER_PIN_NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.IADC__DESCRIPTION:
        setDescription(DESCRIPTION_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IADC__DRIVER_INDEX:
        return DRIVER_INDEX_EDEFAULT == null ? driverIndex != null : !DRIVER_INDEX_EDEFAULT.equals(driverIndex);
      case ConfiguratorPackage.IADC__ENABLE:
        return enable != ENABLE_EDEFAULT;
      case ConfiguratorPackage.IADC__POWER_SUPPLY_SIGNAL:
        return powerSupplySignal != null;
      case ConfiguratorPackage.IADC__ENABLE_EL_DIAG_POWER_SUPPLY_OFF:
        return ENABLE_EL_DIAG_POWER_SUPPLY_OFF_EDEFAULT == null ? enableElDiagPowerSupplyOff != null : !ENABLE_EL_DIAG_POWER_SUPPLY_OFF_EDEFAULT.equals(enableElDiagPowerSupplyOff);
      case ConfiguratorPackage.IADC__EL_DIAG_INSTANCE_IDX:
        return EL_DIAG_INSTANCE_IDX_EDEFAULT == null ? elDiagInstanceIdx != null : !EL_DIAG_INSTANCE_IDX_EDEFAULT.equals(elDiagInstanceIdx);
      case ConfiguratorPackage.IADC__CONTROLLER_PIN_NAME:
        return CONTROLLER_PIN_NAME_EDEFAULT == null ? controllerPinName != null : !CONTROLLER_PIN_NAME_EDEFAULT.equals(controllerPinName);
      case ConfiguratorPackage.IADC__DESCRIPTION:
        return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (driverIndex: ");
    result.append(driverIndex);
    result.append(", enable: ");
    result.append(enable);
    result.append(", enableElDiagPowerSupplyOff: ");
    result.append(enableElDiagPowerSupplyOff);
    result.append(", elDiagInstanceIdx: ");
    result.append(elDiagInstanceIdx);
    result.append(", controllerPinName: ");
    result.append(controllerPinName);
    result.append(", description: ");
    result.append(description);
    result.append(')');
    return result.toString();
  }

} //IADCImpl
