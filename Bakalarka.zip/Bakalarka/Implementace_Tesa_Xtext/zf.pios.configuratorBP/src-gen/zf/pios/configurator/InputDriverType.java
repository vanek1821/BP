/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Driver Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputDriverType()
 * @model
 * @generated
 */
public interface InputDriverType extends GenericSubsystem
{
} // InputDriverType
