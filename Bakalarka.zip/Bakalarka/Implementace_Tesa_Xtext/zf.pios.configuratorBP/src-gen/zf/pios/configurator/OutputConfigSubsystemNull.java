/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Config Subsystem Null</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputConfigSubsystemNull()
 * @model
 * @generated
 */
public interface OutputConfigSubsystemNull extends OutputDriverType
{
} // OutputConfigSubsystemNull
