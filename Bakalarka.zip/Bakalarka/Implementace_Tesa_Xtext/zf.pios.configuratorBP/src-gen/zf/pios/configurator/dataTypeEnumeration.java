/**
 */
package zf.pios.configurator;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>data Type Enumeration</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see zf.pios.configurator.ConfiguratorPackage#getdataTypeEnumeration()
 * @model
 * @generated
 */
public enum dataTypeEnumeration implements Enumerator
{
  /**
   * The '<em><b>FL32</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #FL32_VALUE
   * @generated
   * @ordered
   */
  FL32(0, "FL32", "fl32"),

  /**
   * The '<em><b>SI8</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #SI8_VALUE
   * @generated
   * @ordered
   */
  SI8(1, "SI8", "si8"),

  /**
   * The '<em><b>SI16</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #SI16_VALUE
   * @generated
   * @ordered
   */
  SI16(2, "SI16", "si16"),

  /**
   * The '<em><b>SI32</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #SI32_VALUE
   * @generated
   * @ordered
   */
  SI32(3, "SI32", "si32"),

  /**
   * The '<em><b>UI8</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #UI8_VALUE
   * @generated
   * @ordered
   */
  UI8(4, "UI8", "ui8"),

  /**
   * The '<em><b>UI16</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #UI16_VALUE
   * @generated
   * @ordered
   */
  UI16(5, "UI16", "ui16");

  /**
   * The '<em><b>FL32</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>FL32</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #FL32
   * @model literal="fl32"
   * @generated
   * @ordered
   */
  public static final int FL32_VALUE = 0;

  /**
   * The '<em><b>SI8</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>SI8</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #SI8
   * @model literal="si8"
   * @generated
   * @ordered
   */
  public static final int SI8_VALUE = 1;

  /**
   * The '<em><b>SI16</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>SI16</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #SI16
   * @model literal="si16"
   * @generated
   * @ordered
   */
  public static final int SI16_VALUE = 2;

  /**
   * The '<em><b>SI32</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>SI32</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #SI32
   * @model literal="si32"
   * @generated
   * @ordered
   */
  public static final int SI32_VALUE = 3;

  /**
   * The '<em><b>UI8</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>UI8</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #UI8
   * @model literal="ui8"
   * @generated
   * @ordered
   */
  public static final int UI8_VALUE = 4;

  /**
   * The '<em><b>UI16</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>UI16</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #UI16
   * @model literal="ui16"
   * @generated
   * @ordered
   */
  public static final int UI16_VALUE = 5;

  /**
   * An array of all the '<em><b>data Type Enumeration</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final dataTypeEnumeration[] VALUES_ARRAY =
    new dataTypeEnumeration[]
    {
      FL32,
      SI8,
      SI16,
      SI32,
      UI8,
      UI16,
    };

  /**
   * A public read-only list of all the '<em><b>data Type Enumeration</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List<dataTypeEnumeration> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>data Type Enumeration</b></em>' literal with the specified literal value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param literal the literal.
   * @return the matching enumerator or <code>null</code>.
   * @generated
   */
  public static dataTypeEnumeration get(String literal)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      dataTypeEnumeration result = VALUES_ARRAY[i];
      if (result.toString().equals(literal))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>data Type Enumeration</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param name the name.
   * @return the matching enumerator or <code>null</code>.
   * @generated
   */
  public static dataTypeEnumeration getByName(String name)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      dataTypeEnumeration result = VALUES_ARRAY[i];
      if (result.getName().equals(name))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>data Type Enumeration</b></em>' literal with the specified integer value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the integer value.
   * @return the matching enumerator or <code>null</code>.
   * @generated
   */
  public static dataTypeEnumeration get(int value)
  {
    switch (value)
    {
      case FL32_VALUE: return FL32;
      case SI8_VALUE: return SI8;
      case SI16_VALUE: return SI16;
      case SI32_VALUE: return SI32;
      case UI8_VALUE: return UI8;
      case UI16_VALUE: return UI16;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final int value;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String name;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String literal;

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private dataTypeEnumeration(int value, String name, String literal)
  {
    this.value = value;
    this.name = name;
    this.literal = literal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLiteral()
  {
    return literal;
  }

  /**
   * Returns the literal value of the enumerator, which is its string representation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    return literal;
  }
  
} //dataTypeEnumeration
