/**
 */
package zf.pios.configurator;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Subsystems</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.OutputSubsystems#getOutputNull <em>Output Null</em>}</li>
 *   <li>{@link zf.pios.configurator.OutputSubsystems#getOutputDigital <em>Output Digital</em>}</li>
 *   <li>{@link zf.pios.configurator.OutputSubsystems#getOutputPWM <em>Output PWM</em>}</li>
 *   <li>{@link zf.pios.configurator.OutputSubsystems#getOutputElDiag <em>Output El Diag</em>}</li>
 *   <li>{@link zf.pios.configurator.OutputSubsystems#getOutputConfigSubsystem <em>Output Config Subsystem</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputSubsystems()
 * @model
 * @generated
 */
public interface OutputSubsystems extends EObject
{
  /**
   * Returns the value of the '<em><b>Output Null</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output Null</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Output Null</em>' containment reference.
   * @see #setOutputNull(OutputConfigSubsystemNull)
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputSubsystems_OutputNull()
   * @model containment="true"
   * @generated
   */
  OutputConfigSubsystemNull getOutputNull();

  /**
   * Sets the value of the '{@link zf.pios.configurator.OutputSubsystems#getOutputNull <em>Output Null</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Output Null</em>' containment reference.
   * @see #getOutputNull()
   * @generated
   */
  void setOutputNull(OutputConfigSubsystemNull value);

  /**
   * Returns the value of the '<em><b>Output Digital</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output Digital</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Output Digital</em>' containment reference.
   * @see #setOutputDigital(OutputConfigSubsystemDigital)
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputSubsystems_OutputDigital()
   * @model containment="true"
   * @generated
   */
  OutputConfigSubsystemDigital getOutputDigital();

  /**
   * Sets the value of the '{@link zf.pios.configurator.OutputSubsystems#getOutputDigital <em>Output Digital</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Output Digital</em>' containment reference.
   * @see #getOutputDigital()
   * @generated
   */
  void setOutputDigital(OutputConfigSubsystemDigital value);

  /**
   * Returns the value of the '<em><b>Output PWM</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output PWM</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Output PWM</em>' containment reference.
   * @see #setOutputPWM(OutputConfigSubsystemPWM)
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputSubsystems_OutputPWM()
   * @model containment="true"
   * @generated
   */
  OutputConfigSubsystemPWM getOutputPWM();

  /**
   * Sets the value of the '{@link zf.pios.configurator.OutputSubsystems#getOutputPWM <em>Output PWM</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Output PWM</em>' containment reference.
   * @see #getOutputPWM()
   * @generated
   */
  void setOutputPWM(OutputConfigSubsystemPWM value);

  /**
   * Returns the value of the '<em><b>Output El Diag</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output El Diag</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Output El Diag</em>' containment reference.
   * @see #setOutputElDiag(OutputConfigSubsystemElDiag)
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputSubsystems_OutputElDiag()
   * @model containment="true"
   * @generated
   */
  OutputConfigSubsystemElDiag getOutputElDiag();

  /**
   * Sets the value of the '{@link zf.pios.configurator.OutputSubsystems#getOutputElDiag <em>Output El Diag</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Output El Diag</em>' containment reference.
   * @see #getOutputElDiag()
   * @generated
   */
  void setOutputElDiag(OutputConfigSubsystemElDiag value);

  /**
   * Returns the value of the '<em><b>Output Config Subsystem</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.OutputConfigSubsystemItem}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output Config Subsystem</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Output Config Subsystem</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputSubsystems_OutputConfigSubsystem()
   * @model containment="true"
   * @generated
   */
  EList<OutputConfigSubsystemItem> getOutputConfigSubsystem();

} // OutputSubsystems
