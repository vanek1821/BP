/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutputConfigSubsystemDigital;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Config Subsystem Digital</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class OutputConfigSubsystemDigitalImpl extends OutputDriverTypeImpl implements OutputConfigSubsystemDigital
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutputConfigSubsystemDigitalImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUTPUT_CONFIG_SUBSYSTEM_DIGITAL;
  }

} //OutputConfigSubsystemDigitalImpl
