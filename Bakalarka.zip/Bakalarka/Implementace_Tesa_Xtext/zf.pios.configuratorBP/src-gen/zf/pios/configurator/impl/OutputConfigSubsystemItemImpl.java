/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutputConfigSubsystemItem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Config Subsystem Item</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class OutputConfigSubsystemItemImpl extends OutputDriverTypeImpl implements OutputConfigSubsystemItem
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutputConfigSubsystemItemImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUTPUT_CONFIG_SUBSYSTEM_ITEM;
  }

} //OutputConfigSubsystemItemImpl
