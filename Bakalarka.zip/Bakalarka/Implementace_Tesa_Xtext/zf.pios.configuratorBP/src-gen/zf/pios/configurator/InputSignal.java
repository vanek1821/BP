/**
 */
package zf.pios.configurator;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Signal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.InputSignal#getPowerSupply <em>Power Supply</em>}</li>
 *   <li>{@link zf.pios.configurator.InputSignal#getDatafield <em>Datafield</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputSignal()
 * @model
 * @generated
 */
public interface InputSignal extends GeneralSignal
{
  /**
   * Returns the value of the '<em><b>Power Supply</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Power Supply</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Power Supply</em>' attribute.
   * @see #setPowerSupply(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getInputSignal_PowerSupply()
   * @model
   * @generated
   */
  String getPowerSupply();

  /**
   * Sets the value of the '{@link zf.pios.configurator.InputSignal#getPowerSupply <em>Power Supply</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Power Supply</em>' attribute.
   * @see #getPowerSupply()
   * @generated
   */
  void setPowerSupply(String value);

  /**
   * Returns the value of the '<em><b>Datafield</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.InputDatafield}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Datafield</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Datafield</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getInputSignal_Datafield()
   * @model containment="true"
   * @generated
   */
  EList<InputDatafield> getDatafield();

} // InputSignal
