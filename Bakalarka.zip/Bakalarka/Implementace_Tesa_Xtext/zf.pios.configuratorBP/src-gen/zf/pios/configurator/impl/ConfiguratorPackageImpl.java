/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import zf.pios.configurator.ASAPMeasurment;
import zf.pios.configurator.AnalogDriver;
import zf.pios.configurator.BOOLfalseDefault;
import zf.pios.configurator.CommonDriver;
import zf.pios.configurator.ConfigSubsystem;
import zf.pios.configurator.ConfigSubsystemInput;
import zf.pios.configurator.ConfigSubsystemItem;
import zf.pios.configurator.ConfigSubsystemOutput;
import zf.pios.configurator.Configuration;
import zf.pios.configurator.ConfiguratorFactory;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.Datafield;
import zf.pios.configurator.DriverToECU;
import zf.pios.configurator.ElDiag;
import zf.pios.configurator.ElectricDiagSubsystem;
import zf.pios.configurator.FRQSubsystem;
import zf.pios.configurator.FrequencySubsystem;
import zf.pios.configurator.GeneralSignal;
import zf.pios.configurator.GeneralSignals;
import zf.pios.configurator.GenericSubsystem;
import zf.pios.configurator.Hardware;
import zf.pios.configurator.IFRQSensor;
import zf.pios.configurator.Import;
import zf.pios.configurator.Imports;
import zf.pios.configurator.InDigDriver;
import zf.pios.configurator.InDigitalDriverTableRef;
import zf.pios.configurator.InputAnalogDrivers;
import zf.pios.configurator.InputConfigSubsystemAnalog;
import zf.pios.configurator.InputConfigSubsystemDigital;
import zf.pios.configurator.InputConfigSubsystemFrq;
import zf.pios.configurator.InputConfigSubsystemItem;
import zf.pios.configurator.InputConfigSubsystemNull;
import zf.pios.configurator.InputConfigSubsystemSPI;
import zf.pios.configurator.InputConfigSubsystemTemperature;
import zf.pios.configurator.InputDatafield;
import zf.pios.configurator.InputDigDriversTable;
import zf.pios.configurator.InputDigitalDrivers;
import zf.pios.configurator.InputDriverType;
import zf.pios.configurator.InputSignal;
import zf.pios.configurator.InputSubsystems;
import zf.pios.configurator.OPWMSubsystem;
import zf.pios.configurator.OutDigDriver;
import zf.pios.configurator.OutDigitalDriverTableRef;
import zf.pios.configurator.OutputConfigSubsystemDigital;
import zf.pios.configurator.OutputConfigSubsystemElDiag;
import zf.pios.configurator.OutputConfigSubsystemItem;
import zf.pios.configurator.OutputConfigSubsystemNull;
import zf.pios.configurator.OutputConfigSubsystemPWM;
import zf.pios.configurator.OutputDatafield;
import zf.pios.configurator.OutputDigDriversTable;
import zf.pios.configurator.OutputDigitalDrivers;
import zf.pios.configurator.OutputDriverType;
import zf.pios.configurator.OutputSignal;
import zf.pios.configurator.OutputSubsystems;
import zf.pios.configurator.Portname;
import zf.pios.configurator.SPITXData;
import zf.pios.configurator.SPIinputSys;
import zf.pios.configurator.Signal;
import zf.pios.configurator.Signals;
import zf.pios.configurator.TempSensorSubsystem;
import zf.pios.configurator.UserDefinedSubsystem;
import zf.pios.configurator.UserPort;
import zf.pios.configurator.Variant;
import zf.pios.configurator.Variants;
import zf.pios.configurator.dataTypeEnumeration;
import zf.pios.configurator.iadcEnableEnumeration;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ConfiguratorPackageImpl extends EPackageImpl implements ConfiguratorPackage
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configurationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass systemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass signalsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass generalSignalsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass generalSignalEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputSignalEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputSignalEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass datafieldEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputDatafieldEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputDatafieldEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass portnameEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass variantsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass variantEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass signalEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass asapMeasurmentEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass hardwareEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configSubsystemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configSubsystemInputEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configSubsystemOutputEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputSubsystemsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputSubsystemsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputConfigSubsystemNullEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputConfigSubsystemNullEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genericSubsystemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputDriverTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputDriverTypeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputConfigSubsystemAnalogEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputConfigSubsystemTemperatureEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputConfigSubsystemElDiagEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputConfigSubsystemSPIEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputConfigSubsystemDigitalEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputConfigSubsystemFrqEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputConfigSubsystemPWMEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputConfigSubsystemDigitalEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputConfigSubsystemItemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputConfigSubsystemItemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass driverToECUEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass tempSensorSubsystemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputAnalogDriversEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputDigitalDriversEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputDigitalDriversEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass analogDriverEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inDigDriverEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outDigDriverEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass commonDriverEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputDigDriversTableEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outputDigDriversTableEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inDigitalDriverTableRefEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass outDigitalDriverTableRefEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass electricDiagSubsystemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass elDiagEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass frequencySubsystemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass ifrqEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass ifrqSensorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass spIinputSysEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass spiEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass spitxDataEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass opwmSubsystemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass opwmEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass iadcEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass userDefinedSubsystemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass configSubsystemItemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass userPortEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass importEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass importsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass frqSubsystemEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum dataTypeEnumerationEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum iadcEnableEnumerationEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum booLfalseDefaultEEnum = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see zf.pios.configurator.ConfiguratorPackage#eNS_URI
   * @see #init()
   * @generated
   */
  private ConfiguratorPackageImpl()
  {
    super(eNS_URI, ConfiguratorFactory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
   * 
   * <p>This method is used to initialize {@link ConfiguratorPackage#eINSTANCE} when that field is accessed.
   * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #eNS_URI
   * @see #createPackageContents()
   * @see #initializePackageContents()
   * @generated
   */
  public static ConfiguratorPackage init()
  {
    if (isInited) return (ConfiguratorPackage)EPackage.Registry.INSTANCE.getEPackage(ConfiguratorPackage.eNS_URI);

    // Obtain or create and register package
    ConfiguratorPackageImpl theConfiguratorPackage = (ConfiguratorPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof ConfiguratorPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new ConfiguratorPackageImpl());

    isInited = true;

    // Create package meta-data objects
    theConfiguratorPackage.createPackageContents();

    // Initialize created meta-data
    theConfiguratorPackage.initializePackageContents();

    // Mark meta-data to indicate it can't be changed
    theConfiguratorPackage.freeze();

  
    // Update the registry and return the package
    EPackage.Registry.INSTANCE.put(ConfiguratorPackage.eNS_URI, theConfiguratorPackage);
    return theConfiguratorPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfiguration()
  {
    return configurationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getConfiguration_ConfigurationName()
  {
    return (EAttribute)configurationEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getConfiguration_Version()
  {
    return (EAttribute)configurationEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getConfiguration_MainMergeFile()
  {
    return (EAttribute)configurationEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfiguration_Imports()
  {
    return (EReference)configurationEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfiguration_Variants()
  {
    return (EReference)configurationEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfiguration_System()
  {
    return (EReference)configurationEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfiguration_Hardware()
  {
    return (EReference)configurationEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfiguration_Signals()
  {
    return (EReference)configurationEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSystem()
  {
    return systemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSystem_Name()
  {
    return (EAttribute)systemEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSystem_ConfigSubsystem()
  {
    return (EReference)systemEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSignals()
  {
    return signalsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSignals_Name()
  {
    return (EAttribute)signalsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSignals_PiosSignals()
  {
    return (EReference)signalsEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGeneralSignals()
  {
    return generalSignalsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGeneralSignals_GeneralSignal()
  {
    return (EReference)generalSignalsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGeneralSignal()
  {
    return generalSignalEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGeneralSignal_Name()
  {
    return (EAttribute)generalSignalEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGeneralSignal_Signal()
  {
    return (EReference)generalSignalEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputSignal()
  {
    return inputSignalEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInputSignal_PowerSupply()
  {
    return (EAttribute)inputSignalEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSignal_Datafield()
  {
    return (EReference)inputSignalEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputSignal()
  {
    return outputSignalEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOutputSignal_PullUpResistorSignal()
  {
    return (EAttribute)outputSignalEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputSignal_Datafield()
  {
    return (EReference)outputSignalEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDatafield()
  {
    return datafieldEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDatafield_VariantName()
  {
    return (EReference)datafieldEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDatafield_LowerLimit()
  {
    return (EAttribute)datafieldEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDatafield_UpperLimit()
  {
    return (EAttribute)datafieldEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getDatafield_InitValue()
  {
    return (EAttribute)datafieldEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDatafield_Portname()
  {
    return (EReference)datafieldEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputDatafield()
  {
    return inputDatafieldEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputDatafield_SubSystem()
  {
    return (EReference)inputDatafieldEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputDatafield()
  {
    return outputDatafieldEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputDatafield_SubSystem()
  {
    return (EReference)outputDatafieldEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getPortname()
  {
    return portnameEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getPortname_Number()
  {
    return (EAttribute)portnameEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getPortname_Port()
  {
    return (EReference)portnameEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVariants()
  {
    return variantsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getVariants_Variants()
  {
    return (EReference)variantsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVariant()
  {
    return variantEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVariant_DefaultVariant()
  {
    return (EAttribute)variantEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVariant_Name()
  {
    return (EAttribute)variantEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSignal()
  {
    return signalEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSignal_DataType()
  {
    return (EAttribute)signalEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSignal_Description()
  {
    return (EAttribute)signalEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSignal_AsapMeasurment()
  {
    return (EReference)signalEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getASAPMeasurment()
  {
    return asapMeasurmentEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getASAPMeasurment_LowerLimit()
  {
    return (EAttribute)asapMeasurmentEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getASAPMeasurment_UpperLimit()
  {
    return (EAttribute)asapMeasurmentEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHardware()
  {
    return hardwareEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHardware_Name()
  {
    return (EAttribute)hardwareEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardware_DriverToECU()
  {
    return (EReference)hardwareEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardware_TempSensorSubsystem()
  {
    return (EReference)hardwareEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardware_ElectricDiagSubsystem()
  {
    return (EReference)hardwareEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardware_FrequencySubsystem()
  {
    return (EReference)hardwareEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardware_SpiSubsystem()
  {
    return (EReference)hardwareEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardware_OpwmSubsystem()
  {
    return (EReference)hardwareEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getHardware_UserDefinedSubsystem()
  {
    return (EReference)hardwareEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfigSubsystem()
  {
    return configSubsystemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigSubsystem_ConfigSubsystemInput()
  {
    return (EReference)configSubsystemEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigSubsystem_ConfigSubsystemOutput()
  {
    return (EReference)configSubsystemEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfigSubsystemInput()
  {
    return configSubsystemInputEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getConfigSubsystemInput_MaximalNumberInputSubsystems()
  {
    return (EAttribute)configSubsystemInputEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigSubsystemInput_InputSubsystems()
  {
    return (EReference)configSubsystemInputEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfigSubsystemOutput()
  {
    return configSubsystemOutputEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getConfigSubsystemOutput_MaximalNumberOutputSubsystems()
  {
    return (EAttribute)configSubsystemOutputEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getConfigSubsystemOutput_OutputSubsystems()
  {
    return (EReference)configSubsystemOutputEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputSubsystems()
  {
    return inputSubsystemsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSubsystems_InputNull()
  {
    return (EReference)inputSubsystemsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSubsystems_InputAnalog()
  {
    return (EReference)inputSubsystemsEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSubsystems_InputTemperature()
  {
    return (EReference)inputSubsystemsEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSubsystems_InputDigital()
  {
    return (EReference)inputSubsystemsEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSubsystems_InputFrq()
  {
    return (EReference)inputSubsystemsEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSubsystems_InputSPI()
  {
    return (EReference)inputSubsystemsEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputSubsystems_InputConfigSubsystem()
  {
    return (EReference)inputSubsystemsEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputSubsystems()
  {
    return outputSubsystemsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputSubsystems_OutputNull()
  {
    return (EReference)outputSubsystemsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputSubsystems_OutputDigital()
  {
    return (EReference)outputSubsystemsEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputSubsystems_OutputPWM()
  {
    return (EReference)outputSubsystemsEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputSubsystems_OutputElDiag()
  {
    return (EReference)outputSubsystemsEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputSubsystems_OutputConfigSubsystem()
  {
    return (EReference)outputSubsystemsEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputConfigSubsystemNull()
  {
    return inputConfigSubsystemNullEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputConfigSubsystemNull()
  {
    return outputConfigSubsystemNullEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenericSubsystem()
  {
    return genericSubsystemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenericSubsystem_Name()
  {
    return (EAttribute)genericSubsystemEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenericSubsystem_SortingIndex()
  {
    return (EAttribute)genericSubsystemEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputDriverType()
  {
    return inputDriverTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputDriverType()
  {
    return outputDriverTypeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputConfigSubsystemAnalog()
  {
    return inputConfigSubsystemAnalogEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputConfigSubsystemTemperature()
  {
    return inputConfigSubsystemTemperatureEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputConfigSubsystemElDiag()
  {
    return outputConfigSubsystemElDiagEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputConfigSubsystemElDiag_TempSensor()
  {
    return (EReference)outputConfigSubsystemElDiagEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputConfigSubsystemSPI()
  {
    return inputConfigSubsystemSPIEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputConfigSubsystemDigital()
  {
    return inputConfigSubsystemDigitalEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputConfigSubsystemFrq()
  {
    return inputConfigSubsystemFrqEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputConfigSubsystemPWM()
  {
    return outputConfigSubsystemPWMEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputConfigSubsystemDigital()
  {
    return outputConfigSubsystemDigitalEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputConfigSubsystemItem()
  {
    return inputConfigSubsystemItemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputConfigSubsystemItem()
  {
    return outputConfigSubsystemItemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getDriverToECU()
  {
    return driverToECUEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDriverToECU_InputAnalogDrivers()
  {
    return (EReference)driverToECUEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDriverToECU_InputDigitalDrivers()
  {
    return (EReference)driverToECUEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDriverToECU_InputDigDriversTable()
  {
    return (EReference)driverToECUEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDriverToECU_OutputDigitalDrivers()
  {
    return (EReference)driverToECUEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getDriverToECU_OutputDigDriversTable()
  {
    return (EReference)driverToECUEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTempSensorSubsystem()
  {
    return tempSensorSubsystemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTempSensorSubsystem_Driver()
  {
    return (EReference)tempSensorSubsystemEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputAnalogDrivers()
  {
    return inputAnalogDriversEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputAnalogDrivers_Driver()
  {
    return (EReference)inputAnalogDriversEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputDigitalDrivers()
  {
    return inputDigitalDriversEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputDigitalDrivers_Driver()
  {
    return (EReference)inputDigitalDriversEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputDigitalDrivers()
  {
    return outputDigitalDriversEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputDigitalDrivers_Driver()
  {
    return (EReference)outputDigitalDriversEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAnalogDriver()
  {
    return analogDriverEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAnalogDriver_Name()
  {
    return (EAttribute)analogDriverEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAnalogDriver_DriverSetup()
  {
    return (EReference)analogDriverEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInDigDriver()
  {
    return inDigDriverEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInDigDriver_Name()
  {
    return (EAttribute)inDigDriverEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInDigDriver_DriverSetup()
  {
    return (EReference)inDigDriverEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutDigDriver()
  {
    return outDigDriverEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOutDigDriver_Name()
  {
    return (EAttribute)outDigDriverEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutDigDriver_DriverSetup()
  {
    return (EReference)outDigDriverEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getCommonDriver()
  {
    return commonDriverEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCommonDriver_DriverIndex()
  {
    return (EAttribute)commonDriverEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCommonDriver_ControllerPinName()
  {
    return (EAttribute)commonDriverEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCommonDriver_Description()
  {
    return (EAttribute)commonDriverEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInputDigDriversTable()
  {
    return inputDigDriversTableEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInputDigDriversTable_DigitalDriverTableRef()
  {
    return (EReference)inputDigDriversTableEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutputDigDriversTable()
  {
    return outputDigDriversTableEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutputDigDriversTable_DigitalDriverTableRef()
  {
    return (EReference)outputDigDriversTableEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInDigitalDriverTableRef()
  {
    return inDigitalDriverTableRefEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getInDigitalDriverTableRef_DummySignal()
  {
    return (EAttribute)inDigitalDriverTableRefEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInDigitalDriverTableRef_Name()
  {
    return (EReference)inDigitalDriverTableRefEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOutDigitalDriverTableRef()
  {
    return outDigitalDriverTableRefEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOutDigitalDriverTableRef_DummySignal()
  {
    return (EAttribute)outDigitalDriverTableRefEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOutDigitalDriverTableRef_Name()
  {
    return (EReference)outDigitalDriverTableRefEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getElectricDiagSubsystem()
  {
    return electricDiagSubsystemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getElectricDiagSubsystem_ElDiag()
  {
    return (EReference)electricDiagSubsystemEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getElDiag()
  {
    return elDiagEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getElDiag_Name()
  {
    return (EAttribute)elDiagEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getElDiag_Enable()
  {
    return (EAttribute)elDiagEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getElDiag_DiagnosisEnable()
  {
    return (EAttribute)elDiagEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getElDiag_DriverIndex()
  {
    return (EAttribute)elDiagEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getElDiag_PwmDiagnosis()
  {
    return (EAttribute)elDiagEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getElDiag_PowerSupplySignal()
  {
    return (EReference)elDiagEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getElDiag_Description()
  {
    return (EAttribute)elDiagEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFrequencySubsystem()
  {
    return frequencySubsystemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getIFRQ()
  {
    return ifrqEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIFRQ_Name()
  {
    return (EAttribute)ifrqEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIFRQ_DriverIndex()
  {
    return (EAttribute)ifrqEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getIFRQ_SensorIndex()
  {
    return (EReference)ifrqEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIFRQ_UpdateTime()
  {
    return (EAttribute)ifrqEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIFRQ_Active()
  {
    return (EAttribute)ifrqEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getIFRQSensor()
  {
    return ifrqSensorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIFRQSensor_Name()
  {
    return (EAttribute)ifrqSensorEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIFRQSensor_InitialWaitingTime()
  {
    return (EAttribute)ifrqSensorEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIFRQSensor_DirChangeMinPeriods()
  {
    return (EAttribute)ifrqSensorEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIFRQSensor_DirectionChangeDebounceTime()
  {
    return (EAttribute)ifrqSensorEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSPIinputSys()
  {
    return spIinputSysEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSPIinputSys_Spi()
  {
    return (EReference)spIinputSysEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSPI()
  {
    return spiEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPI_Name()
  {
    return (EAttribute)spiEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPI_DriverIndex()
  {
    return (EAttribute)spiEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPI_DataStorageMode()
  {
    return (EAttribute)spiEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPI_Command()
  {
    return (EAttribute)spiEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPI_DataLength()
  {
    return (EAttribute)spiEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSPI_SpitxData()
  {
    return (EReference)spiEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPI_Module()
  {
    return (EAttribute)spiEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPI_Description()
  {
    return (EAttribute)spiEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSPITXData()
  {
    return spitxDataEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPITXData_ByteOne()
  {
    return (EAttribute)spitxDataEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPITXData_ByteTwo()
  {
    return (EAttribute)spitxDataEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPITXData_ByteThree()
  {
    return (EAttribute)spitxDataEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSPITXData_ByteFour()
  {
    return (EAttribute)spitxDataEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOPWMSubsystem()
  {
    return opwmSubsystemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getOPWMSubsystem_Opwm()
  {
    return (EReference)opwmSubsystemEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getOPWM()
  {
    return opwmEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOPWM_Name()
  {
    return (EAttribute)opwmEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOPWM_DriverIndex()
  {
    return (EAttribute)opwmEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOPWM_Period()
  {
    return (EAttribute)opwmEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getOPWM_Description()
  {
    return (EAttribute)opwmEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getIADC()
  {
    return iadcEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIADC_DriverIndex()
  {
    return (EAttribute)iadcEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIADC_Enable()
  {
    return (EAttribute)iadcEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getIADC_PowerSupplySignal()
  {
    return (EReference)iadcEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIADC_EnableElDiagPowerSupplyOff()
  {
    return (EAttribute)iadcEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIADC_ElDiagInstanceIdx()
  {
    return (EAttribute)iadcEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIADC_ControllerPinName()
  {
    return (EAttribute)iadcEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIADC_Description()
  {
    return (EAttribute)iadcEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getUserDefinedSubsystem()
  {
    return userDefinedSubsystemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUserDefinedSubsystem_Name()
  {
    return (EReference)userDefinedSubsystemEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getUserDefinedSubsystem_UserPort()
  {
    return (EReference)userDefinedSubsystemEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getConfigSubsystemItem()
  {
    return configSubsystemItemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getUserPort()
  {
    return userPortEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getUserPort_Name()
  {
    return (EAttribute)userPortEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getUserPort_DriverIndex()
  {
    return (EAttribute)userPortEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getUserPort_Description()
  {
    return (EAttribute)userPortEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getImport()
  {
    return importEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getImport_ImportURI()
  {
    return (EAttribute)importEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getImport_Name()
  {
    return (EAttribute)importEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getImports()
  {
    return importsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getImports_ImportedNamespace()
  {
    return (EAttribute)importsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFRQSubsystem()
  {
    return frqSubsystemEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFRQSubsystem_IfrqSensor()
  {
    return (EReference)frqSubsystemEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getFRQSubsystem_Ifrq()
  {
    return (EReference)frqSubsystemEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getdataTypeEnumeration()
  {
    return dataTypeEnumerationEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getiadcEnableEnumeration()
  {
    return iadcEnableEnumerationEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getBOOLfalseDefault()
  {
    return booLfalseDefaultEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ConfiguratorFactory getConfiguratorFactory()
  {
    return (ConfiguratorFactory)getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isCreated = false;

  /**
   * Creates the meta-model objects for the package.  This method is
   * guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void createPackageContents()
  {
    if (isCreated) return;
    isCreated = true;

    // Create classes and their features
    configurationEClass = createEClass(CONFIGURATION);
    createEAttribute(configurationEClass, CONFIGURATION__CONFIGURATION_NAME);
    createEAttribute(configurationEClass, CONFIGURATION__VERSION);
    createEAttribute(configurationEClass, CONFIGURATION__MAIN_MERGE_FILE);
    createEReference(configurationEClass, CONFIGURATION__IMPORTS);
    createEReference(configurationEClass, CONFIGURATION__VARIANTS);
    createEReference(configurationEClass, CONFIGURATION__SYSTEM);
    createEReference(configurationEClass, CONFIGURATION__HARDWARE);
    createEReference(configurationEClass, CONFIGURATION__SIGNALS);

    systemEClass = createEClass(SYSTEM);
    createEAttribute(systemEClass, SYSTEM__NAME);
    createEReference(systemEClass, SYSTEM__CONFIG_SUBSYSTEM);

    signalsEClass = createEClass(SIGNALS);
    createEAttribute(signalsEClass, SIGNALS__NAME);
    createEReference(signalsEClass, SIGNALS__PIOS_SIGNALS);

    generalSignalsEClass = createEClass(GENERAL_SIGNALS);
    createEReference(generalSignalsEClass, GENERAL_SIGNALS__GENERAL_SIGNAL);

    generalSignalEClass = createEClass(GENERAL_SIGNAL);
    createEAttribute(generalSignalEClass, GENERAL_SIGNAL__NAME);
    createEReference(generalSignalEClass, GENERAL_SIGNAL__SIGNAL);

    inputSignalEClass = createEClass(INPUT_SIGNAL);
    createEAttribute(inputSignalEClass, INPUT_SIGNAL__POWER_SUPPLY);
    createEReference(inputSignalEClass, INPUT_SIGNAL__DATAFIELD);

    outputSignalEClass = createEClass(OUTPUT_SIGNAL);
    createEAttribute(outputSignalEClass, OUTPUT_SIGNAL__PULL_UP_RESISTOR_SIGNAL);
    createEReference(outputSignalEClass, OUTPUT_SIGNAL__DATAFIELD);

    datafieldEClass = createEClass(DATAFIELD);
    createEReference(datafieldEClass, DATAFIELD__VARIANT_NAME);
    createEAttribute(datafieldEClass, DATAFIELD__LOWER_LIMIT);
    createEAttribute(datafieldEClass, DATAFIELD__UPPER_LIMIT);
    createEAttribute(datafieldEClass, DATAFIELD__INIT_VALUE);
    createEReference(datafieldEClass, DATAFIELD__PORTNAME);

    inputDatafieldEClass = createEClass(INPUT_DATAFIELD);
    createEReference(inputDatafieldEClass, INPUT_DATAFIELD__SUB_SYSTEM);

    outputDatafieldEClass = createEClass(OUTPUT_DATAFIELD);
    createEReference(outputDatafieldEClass, OUTPUT_DATAFIELD__SUB_SYSTEM);

    portnameEClass = createEClass(PORTNAME);
    createEAttribute(portnameEClass, PORTNAME__NUMBER);
    createEReference(portnameEClass, PORTNAME__PORT);

    variantsEClass = createEClass(VARIANTS);
    createEReference(variantsEClass, VARIANTS__VARIANTS);

    variantEClass = createEClass(VARIANT);
    createEAttribute(variantEClass, VARIANT__DEFAULT_VARIANT);
    createEAttribute(variantEClass, VARIANT__NAME);

    signalEClass = createEClass(SIGNAL);
    createEAttribute(signalEClass, SIGNAL__DATA_TYPE);
    createEAttribute(signalEClass, SIGNAL__DESCRIPTION);
    createEReference(signalEClass, SIGNAL__ASAP_MEASURMENT);

    asapMeasurmentEClass = createEClass(ASAP_MEASURMENT);
    createEAttribute(asapMeasurmentEClass, ASAP_MEASURMENT__LOWER_LIMIT);
    createEAttribute(asapMeasurmentEClass, ASAP_MEASURMENT__UPPER_LIMIT);

    hardwareEClass = createEClass(HARDWARE);
    createEAttribute(hardwareEClass, HARDWARE__NAME);
    createEReference(hardwareEClass, HARDWARE__DRIVER_TO_ECU);
    createEReference(hardwareEClass, HARDWARE__TEMP_SENSOR_SUBSYSTEM);
    createEReference(hardwareEClass, HARDWARE__ELECTRIC_DIAG_SUBSYSTEM);
    createEReference(hardwareEClass, HARDWARE__FREQUENCY_SUBSYSTEM);
    createEReference(hardwareEClass, HARDWARE__SPI_SUBSYSTEM);
    createEReference(hardwareEClass, HARDWARE__OPWM_SUBSYSTEM);
    createEReference(hardwareEClass, HARDWARE__USER_DEFINED_SUBSYSTEM);

    configSubsystemEClass = createEClass(CONFIG_SUBSYSTEM);
    createEReference(configSubsystemEClass, CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_INPUT);
    createEReference(configSubsystemEClass, CONFIG_SUBSYSTEM__CONFIG_SUBSYSTEM_OUTPUT);

    configSubsystemInputEClass = createEClass(CONFIG_SUBSYSTEM_INPUT);
    createEAttribute(configSubsystemInputEClass, CONFIG_SUBSYSTEM_INPUT__MAXIMAL_NUMBER_INPUT_SUBSYSTEMS);
    createEReference(configSubsystemInputEClass, CONFIG_SUBSYSTEM_INPUT__INPUT_SUBSYSTEMS);

    configSubsystemOutputEClass = createEClass(CONFIG_SUBSYSTEM_OUTPUT);
    createEAttribute(configSubsystemOutputEClass, CONFIG_SUBSYSTEM_OUTPUT__MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS);
    createEReference(configSubsystemOutputEClass, CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS);

    inputSubsystemsEClass = createEClass(INPUT_SUBSYSTEMS);
    createEReference(inputSubsystemsEClass, INPUT_SUBSYSTEMS__INPUT_NULL);
    createEReference(inputSubsystemsEClass, INPUT_SUBSYSTEMS__INPUT_ANALOG);
    createEReference(inputSubsystemsEClass, INPUT_SUBSYSTEMS__INPUT_TEMPERATURE);
    createEReference(inputSubsystemsEClass, INPUT_SUBSYSTEMS__INPUT_DIGITAL);
    createEReference(inputSubsystemsEClass, INPUT_SUBSYSTEMS__INPUT_FRQ);
    createEReference(inputSubsystemsEClass, INPUT_SUBSYSTEMS__INPUT_SPI);
    createEReference(inputSubsystemsEClass, INPUT_SUBSYSTEMS__INPUT_CONFIG_SUBSYSTEM);

    outputSubsystemsEClass = createEClass(OUTPUT_SUBSYSTEMS);
    createEReference(outputSubsystemsEClass, OUTPUT_SUBSYSTEMS__OUTPUT_NULL);
    createEReference(outputSubsystemsEClass, OUTPUT_SUBSYSTEMS__OUTPUT_DIGITAL);
    createEReference(outputSubsystemsEClass, OUTPUT_SUBSYSTEMS__OUTPUT_PWM);
    createEReference(outputSubsystemsEClass, OUTPUT_SUBSYSTEMS__OUTPUT_EL_DIAG);
    createEReference(outputSubsystemsEClass, OUTPUT_SUBSYSTEMS__OUTPUT_CONFIG_SUBSYSTEM);

    inputConfigSubsystemNullEClass = createEClass(INPUT_CONFIG_SUBSYSTEM_NULL);

    outputConfigSubsystemNullEClass = createEClass(OUTPUT_CONFIG_SUBSYSTEM_NULL);

    genericSubsystemEClass = createEClass(GENERIC_SUBSYSTEM);
    createEAttribute(genericSubsystemEClass, GENERIC_SUBSYSTEM__NAME);
    createEAttribute(genericSubsystemEClass, GENERIC_SUBSYSTEM__SORTING_INDEX);

    inputDriverTypeEClass = createEClass(INPUT_DRIVER_TYPE);

    outputDriverTypeEClass = createEClass(OUTPUT_DRIVER_TYPE);

    inputConfigSubsystemAnalogEClass = createEClass(INPUT_CONFIG_SUBSYSTEM_ANALOG);

    inputConfigSubsystemTemperatureEClass = createEClass(INPUT_CONFIG_SUBSYSTEM_TEMPERATURE);

    outputConfigSubsystemElDiagEClass = createEClass(OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG);
    createEReference(outputConfigSubsystemElDiagEClass, OUTPUT_CONFIG_SUBSYSTEM_EL_DIAG__TEMP_SENSOR);

    inputConfigSubsystemSPIEClass = createEClass(INPUT_CONFIG_SUBSYSTEM_SPI);

    inputConfigSubsystemDigitalEClass = createEClass(INPUT_CONFIG_SUBSYSTEM_DIGITAL);

    inputConfigSubsystemFrqEClass = createEClass(INPUT_CONFIG_SUBSYSTEM_FRQ);

    outputConfigSubsystemPWMEClass = createEClass(OUTPUT_CONFIG_SUBSYSTEM_PWM);

    outputConfigSubsystemDigitalEClass = createEClass(OUTPUT_CONFIG_SUBSYSTEM_DIGITAL);

    inputConfigSubsystemItemEClass = createEClass(INPUT_CONFIG_SUBSYSTEM_ITEM);

    outputConfigSubsystemItemEClass = createEClass(OUTPUT_CONFIG_SUBSYSTEM_ITEM);

    driverToECUEClass = createEClass(DRIVER_TO_ECU);
    createEReference(driverToECUEClass, DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS);
    createEReference(driverToECUEClass, DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS);
    createEReference(driverToECUEClass, DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE);
    createEReference(driverToECUEClass, DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS);
    createEReference(driverToECUEClass, DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE);

    tempSensorSubsystemEClass = createEClass(TEMP_SENSOR_SUBSYSTEM);
    createEReference(tempSensorSubsystemEClass, TEMP_SENSOR_SUBSYSTEM__DRIVER);

    inputAnalogDriversEClass = createEClass(INPUT_ANALOG_DRIVERS);
    createEReference(inputAnalogDriversEClass, INPUT_ANALOG_DRIVERS__DRIVER);

    inputDigitalDriversEClass = createEClass(INPUT_DIGITAL_DRIVERS);
    createEReference(inputDigitalDriversEClass, INPUT_DIGITAL_DRIVERS__DRIVER);

    outputDigitalDriversEClass = createEClass(OUTPUT_DIGITAL_DRIVERS);
    createEReference(outputDigitalDriversEClass, OUTPUT_DIGITAL_DRIVERS__DRIVER);

    analogDriverEClass = createEClass(ANALOG_DRIVER);
    createEAttribute(analogDriverEClass, ANALOG_DRIVER__NAME);
    createEReference(analogDriverEClass, ANALOG_DRIVER__DRIVER_SETUP);

    inDigDriverEClass = createEClass(IN_DIG_DRIVER);
    createEAttribute(inDigDriverEClass, IN_DIG_DRIVER__NAME);
    createEReference(inDigDriverEClass, IN_DIG_DRIVER__DRIVER_SETUP);

    outDigDriverEClass = createEClass(OUT_DIG_DRIVER);
    createEAttribute(outDigDriverEClass, OUT_DIG_DRIVER__NAME);
    createEReference(outDigDriverEClass, OUT_DIG_DRIVER__DRIVER_SETUP);

    commonDriverEClass = createEClass(COMMON_DRIVER);
    createEAttribute(commonDriverEClass, COMMON_DRIVER__DRIVER_INDEX);
    createEAttribute(commonDriverEClass, COMMON_DRIVER__CONTROLLER_PIN_NAME);
    createEAttribute(commonDriverEClass, COMMON_DRIVER__DESCRIPTION);

    inputDigDriversTableEClass = createEClass(INPUT_DIG_DRIVERS_TABLE);
    createEReference(inputDigDriversTableEClass, INPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF);

    outputDigDriversTableEClass = createEClass(OUTPUT_DIG_DRIVERS_TABLE);
    createEReference(outputDigDriversTableEClass, OUTPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF);

    inDigitalDriverTableRefEClass = createEClass(IN_DIGITAL_DRIVER_TABLE_REF);
    createEAttribute(inDigitalDriverTableRefEClass, IN_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL);
    createEReference(inDigitalDriverTableRefEClass, IN_DIGITAL_DRIVER_TABLE_REF__NAME);

    outDigitalDriverTableRefEClass = createEClass(OUT_DIGITAL_DRIVER_TABLE_REF);
    createEAttribute(outDigitalDriverTableRefEClass, OUT_DIGITAL_DRIVER_TABLE_REF__DUMMY_SIGNAL);
    createEReference(outDigitalDriverTableRefEClass, OUT_DIGITAL_DRIVER_TABLE_REF__NAME);

    electricDiagSubsystemEClass = createEClass(ELECTRIC_DIAG_SUBSYSTEM);
    createEReference(electricDiagSubsystemEClass, ELECTRIC_DIAG_SUBSYSTEM__EL_DIAG);

    elDiagEClass = createEClass(EL_DIAG);
    createEAttribute(elDiagEClass, EL_DIAG__NAME);
    createEAttribute(elDiagEClass, EL_DIAG__ENABLE);
    createEAttribute(elDiagEClass, EL_DIAG__DIAGNOSIS_ENABLE);
    createEAttribute(elDiagEClass, EL_DIAG__DRIVER_INDEX);
    createEAttribute(elDiagEClass, EL_DIAG__PWM_DIAGNOSIS);
    createEReference(elDiagEClass, EL_DIAG__POWER_SUPPLY_SIGNAL);
    createEAttribute(elDiagEClass, EL_DIAG__DESCRIPTION);

    frequencySubsystemEClass = createEClass(FREQUENCY_SUBSYSTEM);

    ifrqEClass = createEClass(IFRQ);
    createEAttribute(ifrqEClass, IFRQ__NAME);
    createEAttribute(ifrqEClass, IFRQ__DRIVER_INDEX);
    createEReference(ifrqEClass, IFRQ__SENSOR_INDEX);
    createEAttribute(ifrqEClass, IFRQ__UPDATE_TIME);
    createEAttribute(ifrqEClass, IFRQ__ACTIVE);

    ifrqSensorEClass = createEClass(IFRQ_SENSOR);
    createEAttribute(ifrqSensorEClass, IFRQ_SENSOR__NAME);
    createEAttribute(ifrqSensorEClass, IFRQ_SENSOR__INITIAL_WAITING_TIME);
    createEAttribute(ifrqSensorEClass, IFRQ_SENSOR__DIR_CHANGE_MIN_PERIODS);
    createEAttribute(ifrqSensorEClass, IFRQ_SENSOR__DIRECTION_CHANGE_DEBOUNCE_TIME);

    spIinputSysEClass = createEClass(SP_IINPUT_SYS);
    createEReference(spIinputSysEClass, SP_IINPUT_SYS__SPI);

    spiEClass = createEClass(SPI);
    createEAttribute(spiEClass, SPI__NAME);
    createEAttribute(spiEClass, SPI__DRIVER_INDEX);
    createEAttribute(spiEClass, SPI__DATA_STORAGE_MODE);
    createEAttribute(spiEClass, SPI__COMMAND);
    createEAttribute(spiEClass, SPI__DATA_LENGTH);
    createEReference(spiEClass, SPI__SPITX_DATA);
    createEAttribute(spiEClass, SPI__MODULE);
    createEAttribute(spiEClass, SPI__DESCRIPTION);

    spitxDataEClass = createEClass(SPITX_DATA);
    createEAttribute(spitxDataEClass, SPITX_DATA__BYTE_ONE);
    createEAttribute(spitxDataEClass, SPITX_DATA__BYTE_TWO);
    createEAttribute(spitxDataEClass, SPITX_DATA__BYTE_THREE);
    createEAttribute(spitxDataEClass, SPITX_DATA__BYTE_FOUR);

    opwmSubsystemEClass = createEClass(OPWM_SUBSYSTEM);
    createEReference(opwmSubsystemEClass, OPWM_SUBSYSTEM__OPWM);

    opwmEClass = createEClass(OPWM);
    createEAttribute(opwmEClass, OPWM__NAME);
    createEAttribute(opwmEClass, OPWM__DRIVER_INDEX);
    createEAttribute(opwmEClass, OPWM__PERIOD);
    createEAttribute(opwmEClass, OPWM__DESCRIPTION);

    iadcEClass = createEClass(IADC);
    createEAttribute(iadcEClass, IADC__DRIVER_INDEX);
    createEAttribute(iadcEClass, IADC__ENABLE);
    createEReference(iadcEClass, IADC__POWER_SUPPLY_SIGNAL);
    createEAttribute(iadcEClass, IADC__ENABLE_EL_DIAG_POWER_SUPPLY_OFF);
    createEAttribute(iadcEClass, IADC__EL_DIAG_INSTANCE_IDX);
    createEAttribute(iadcEClass, IADC__CONTROLLER_PIN_NAME);
    createEAttribute(iadcEClass, IADC__DESCRIPTION);

    userDefinedSubsystemEClass = createEClass(USER_DEFINED_SUBSYSTEM);
    createEReference(userDefinedSubsystemEClass, USER_DEFINED_SUBSYSTEM__NAME);
    createEReference(userDefinedSubsystemEClass, USER_DEFINED_SUBSYSTEM__USER_PORT);

    configSubsystemItemEClass = createEClass(CONFIG_SUBSYSTEM_ITEM);

    userPortEClass = createEClass(USER_PORT);
    createEAttribute(userPortEClass, USER_PORT__NAME);
    createEAttribute(userPortEClass, USER_PORT__DRIVER_INDEX);
    createEAttribute(userPortEClass, USER_PORT__DESCRIPTION);

    importEClass = createEClass(IMPORT);
    createEAttribute(importEClass, IMPORT__IMPORT_URI);
    createEAttribute(importEClass, IMPORT__NAME);

    importsEClass = createEClass(IMPORTS);
    createEAttribute(importsEClass, IMPORTS__IMPORTED_NAMESPACE);

    frqSubsystemEClass = createEClass(FRQ_SUBSYSTEM);
    createEReference(frqSubsystemEClass, FRQ_SUBSYSTEM__IFRQ_SENSOR);
    createEReference(frqSubsystemEClass, FRQ_SUBSYSTEM__IFRQ);

    // Create enums
    dataTypeEnumerationEEnum = createEEnum(DATA_TYPE_ENUMERATION);
    iadcEnableEnumerationEEnum = createEEnum(IADC_ENABLE_ENUMERATION);
    booLfalseDefaultEEnum = createEEnum(BOO_LFALSE_DEFAULT);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isInitialized = false;

  /**
   * Complete the initialization of the package and its meta-model.  This
   * method is guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void initializePackageContents()
  {
    if (isInitialized) return;
    isInitialized = true;

    // Initialize package
    setName(eNAME);
    setNsPrefix(eNS_PREFIX);
    setNsURI(eNS_URI);

    // Create type parameters

    // Set bounds for type parameters

    // Add supertypes to classes
    inputSignalEClass.getESuperTypes().add(this.getGeneralSignal());
    outputSignalEClass.getESuperTypes().add(this.getGeneralSignal());
    inputDatafieldEClass.getESuperTypes().add(this.getDatafield());
    outputDatafieldEClass.getESuperTypes().add(this.getDatafield());
    inputConfigSubsystemNullEClass.getESuperTypes().add(this.getInputDriverType());
    outputConfigSubsystemNullEClass.getESuperTypes().add(this.getOutputDriverType());
    inputDriverTypeEClass.getESuperTypes().add(this.getGenericSubsystem());
    outputDriverTypeEClass.getESuperTypes().add(this.getGenericSubsystem());
    inputConfigSubsystemAnalogEClass.getESuperTypes().add(this.getInputDriverType());
    inputConfigSubsystemTemperatureEClass.getESuperTypes().add(this.getInputDriverType());
    outputConfigSubsystemElDiagEClass.getESuperTypes().add(this.getOutputDriverType());
    inputConfigSubsystemSPIEClass.getESuperTypes().add(this.getInputDriverType());
    inputConfigSubsystemDigitalEClass.getESuperTypes().add(this.getInputDriverType());
    inputConfigSubsystemFrqEClass.getESuperTypes().add(this.getInputDriverType());
    outputConfigSubsystemPWMEClass.getESuperTypes().add(this.getOutputDriverType());
    outputConfigSubsystemDigitalEClass.getESuperTypes().add(this.getOutputDriverType());
    inputConfigSubsystemItemEClass.getESuperTypes().add(this.getInputDriverType());
    inputConfigSubsystemItemEClass.getESuperTypes().add(this.getConfigSubsystemItem());
    outputConfigSubsystemItemEClass.getESuperTypes().add(this.getOutputDriverType());
    outputConfigSubsystemItemEClass.getESuperTypes().add(this.getConfigSubsystemItem());
    frqSubsystemEClass.getESuperTypes().add(this.getFrequencySubsystem());

    // Initialize classes and features; add operations and parameters
    initEClass(configurationEClass, Configuration.class, "Configuration", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getConfiguration_ConfigurationName(), ecorePackage.getEString(), "configurationName", null, 0, 1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getConfiguration_Version(), ecorePackage.getEString(), "version", null, 0, 1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getConfiguration_MainMergeFile(), ecorePackage.getEString(), "mainMergeFile", null, 0, 1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getConfiguration_Imports(), this.getImports(), null, "imports", null, 0, -1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getConfiguration_Variants(), this.getVariants(), null, "variants", null, 0, 1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getConfiguration_System(), this.getSystem(), null, "system", null, 0, 1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getConfiguration_Hardware(), this.getHardware(), null, "hardware", null, 0, 1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getConfiguration_Signals(), this.getSignals(), null, "signals", null, 0, 1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(systemEClass, zf.pios.configurator.System.class, "System", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getSystem_Name(), ecorePackage.getEString(), "name", null, 0, 1, zf.pios.configurator.System.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSystem_ConfigSubsystem(), this.getConfigSubsystem(), null, "configSubsystem", null, 0, 1, zf.pios.configurator.System.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(signalsEClass, Signals.class, "Signals", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getSignals_Name(), ecorePackage.getEString(), "name", null, 0, 1, Signals.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSignals_PiosSignals(), this.getGeneralSignals(), null, "piosSignals", null, 0, 1, Signals.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(generalSignalsEClass, GeneralSignals.class, "GeneralSignals", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getGeneralSignals_GeneralSignal(), this.getGeneralSignal(), null, "generalSignal", null, 0, -1, GeneralSignals.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(generalSignalEClass, GeneralSignal.class, "GeneralSignal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getGeneralSignal_Name(), ecorePackage.getEString(), "name", null, 0, 1, GeneralSignal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGeneralSignal_Signal(), this.getSignal(), null, "signal", null, 0, 1, GeneralSignal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputSignalEClass, InputSignal.class, "InputSignal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getInputSignal_PowerSupply(), ecorePackage.getEString(), "powerSupply", null, 0, 1, InputSignal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getInputSignal_Datafield(), this.getInputDatafield(), null, "datafield", null, 0, -1, InputSignal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(outputSignalEClass, OutputSignal.class, "OutputSignal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getOutputSignal_PullUpResistorSignal(), ecorePackage.getEString(), "pullUpResistorSignal", null, 0, 1, OutputSignal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getOutputSignal_Datafield(), this.getOutputDatafield(), null, "datafield", null, 0, -1, OutputSignal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(datafieldEClass, Datafield.class, "Datafield", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getDatafield_VariantName(), this.getVariant(), null, "variantName", null, 0, 1, Datafield.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getDatafield_LowerLimit(), ecorePackage.getEString(), "lowerLimit", null, 0, 1, Datafield.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getDatafield_UpperLimit(), ecorePackage.getEString(), "upperLimit", null, 0, 1, Datafield.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getDatafield_InitValue(), ecorePackage.getEString(), "initValue", null, 0, 1, Datafield.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getDatafield_Portname(), this.getPortname(), null, "portname", null, 0, 1, Datafield.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputDatafieldEClass, InputDatafield.class, "InputDatafield", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getInputDatafield_SubSystem(), this.getInputDriverType(), null, "subSystem", null, 0, 1, InputDatafield.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(outputDatafieldEClass, OutputDatafield.class, "OutputDatafield", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getOutputDatafield_SubSystem(), this.getOutputDriverType(), null, "subSystem", null, 0, 1, OutputDatafield.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(portnameEClass, Portname.class, "Portname", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getPortname_Number(), ecorePackage.getEString(), "number", null, 0, 1, Portname.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getPortname_Port(), ecorePackage.getEObject(), null, "port", null, 0, 1, Portname.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(variantsEClass, Variants.class, "Variants", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getVariants_Variants(), this.getVariant(), null, "variants", null, 0, -1, Variants.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(variantEClass, Variant.class, "Variant", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getVariant_DefaultVariant(), ecorePackage.getEString(), "defaultVariant", null, 0, 1, Variant.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getVariant_Name(), ecorePackage.getEString(), "name", null, 0, 1, Variant.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(signalEClass, Signal.class, "Signal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getSignal_DataType(), this.getdataTypeEnumeration(), "dataType", null, 0, 1, Signal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSignal_Description(), ecorePackage.getEString(), "description", null, 0, 1, Signal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSignal_AsapMeasurment(), this.getASAPMeasurment(), null, "asapMeasurment", null, 0, 1, Signal.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(asapMeasurmentEClass, ASAPMeasurment.class, "ASAPMeasurment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getASAPMeasurment_LowerLimit(), ecorePackage.getEString(), "lowerLimit", null, 0, 1, ASAPMeasurment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getASAPMeasurment_UpperLimit(), ecorePackage.getEString(), "upperLimit", null, 0, 1, ASAPMeasurment.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(hardwareEClass, Hardware.class, "Hardware", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getHardware_Name(), ecorePackage.getEString(), "name", null, 0, 1, Hardware.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getHardware_DriverToECU(), this.getDriverToECU(), null, "driverToECU", null, 0, 1, Hardware.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getHardware_TempSensorSubsystem(), this.getTempSensorSubsystem(), null, "tempSensorSubsystem", null, 0, 1, Hardware.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getHardware_ElectricDiagSubsystem(), this.getElectricDiagSubsystem(), null, "electricDiagSubsystem", null, 0, 1, Hardware.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getHardware_FrequencySubsystem(), this.getFrequencySubsystem(), null, "frequencySubsystem", null, 0, 1, Hardware.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getHardware_SpiSubsystem(), this.getSPIinputSys(), null, "spiSubsystem", null, 0, 1, Hardware.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getHardware_OpwmSubsystem(), this.getOPWMSubsystem(), null, "opwmSubsystem", null, 0, 1, Hardware.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getHardware_UserDefinedSubsystem(), this.getUserDefinedSubsystem(), null, "userDefinedSubsystem", null, 0, -1, Hardware.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(configSubsystemEClass, ConfigSubsystem.class, "ConfigSubsystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getConfigSubsystem_ConfigSubsystemInput(), this.getConfigSubsystemInput(), null, "configSubsystemInput", null, 0, 1, ConfigSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getConfigSubsystem_ConfigSubsystemOutput(), this.getConfigSubsystemOutput(), null, "configSubsystemOutput", null, 0, 1, ConfigSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(configSubsystemInputEClass, ConfigSubsystemInput.class, "ConfigSubsystemInput", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getConfigSubsystemInput_MaximalNumberInputSubsystems(), ecorePackage.getEInt(), "maximalNumberInputSubsystems", null, 0, 1, ConfigSubsystemInput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getConfigSubsystemInput_InputSubsystems(), this.getInputSubsystems(), null, "inputSubsystems", null, 0, 1, ConfigSubsystemInput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(configSubsystemOutputEClass, ConfigSubsystemOutput.class, "ConfigSubsystemOutput", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getConfigSubsystemOutput_MaximalNumberOutputSubsystems(), ecorePackage.getEInt(), "maximalNumberOutputSubsystems", null, 0, 1, ConfigSubsystemOutput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getConfigSubsystemOutput_OutputSubsystems(), this.getOutputSubsystems(), null, "outputSubsystems", null, 0, 1, ConfigSubsystemOutput.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputSubsystemsEClass, InputSubsystems.class, "InputSubsystems", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getInputSubsystems_InputNull(), this.getInputConfigSubsystemNull(), null, "inputNull", null, 0, 1, InputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getInputSubsystems_InputAnalog(), this.getInputConfigSubsystemAnalog(), null, "inputAnalog", null, 0, 1, InputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getInputSubsystems_InputTemperature(), this.getInputConfigSubsystemTemperature(), null, "inputTemperature", null, 0, 1, InputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getInputSubsystems_InputDigital(), this.getInputConfigSubsystemDigital(), null, "inputDigital", null, 0, 1, InputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getInputSubsystems_InputFrq(), this.getInputConfigSubsystemFrq(), null, "inputFrq", null, 0, 1, InputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getInputSubsystems_InputSPI(), this.getInputConfigSubsystemSPI(), null, "inputSPI", null, 0, 1, InputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getInputSubsystems_InputConfigSubsystem(), this.getInputConfigSubsystemItem(), null, "inputConfigSubsystem", null, 0, -1, InputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(outputSubsystemsEClass, OutputSubsystems.class, "OutputSubsystems", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getOutputSubsystems_OutputNull(), this.getOutputConfigSubsystemNull(), null, "outputNull", null, 0, 1, OutputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getOutputSubsystems_OutputDigital(), this.getOutputConfigSubsystemDigital(), null, "outputDigital", null, 0, 1, OutputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getOutputSubsystems_OutputPWM(), this.getOutputConfigSubsystemPWM(), null, "outputPWM", null, 0, 1, OutputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getOutputSubsystems_OutputElDiag(), this.getOutputConfigSubsystemElDiag(), null, "outputElDiag", null, 0, 1, OutputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getOutputSubsystems_OutputConfigSubsystem(), this.getOutputConfigSubsystemItem(), null, "outputConfigSubsystem", null, 0, -1, OutputSubsystems.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputConfigSubsystemNullEClass, InputConfigSubsystemNull.class, "InputConfigSubsystemNull", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(outputConfigSubsystemNullEClass, OutputConfigSubsystemNull.class, "OutputConfigSubsystemNull", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(genericSubsystemEClass, GenericSubsystem.class, "GenericSubsystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getGenericSubsystem_Name(), ecorePackage.getEString(), "name", null, 0, 1, GenericSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenericSubsystem_SortingIndex(), ecorePackage.getEInt(), "sortingIndex", null, 0, 1, GenericSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputDriverTypeEClass, InputDriverType.class, "InputDriverType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(outputDriverTypeEClass, OutputDriverType.class, "OutputDriverType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(inputConfigSubsystemAnalogEClass, InputConfigSubsystemAnalog.class, "InputConfigSubsystemAnalog", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(inputConfigSubsystemTemperatureEClass, InputConfigSubsystemTemperature.class, "InputConfigSubsystemTemperature", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(outputConfigSubsystemElDiagEClass, OutputConfigSubsystemElDiag.class, "OutputConfigSubsystemElDiag", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getOutputConfigSubsystemElDiag_TempSensor(), this.getInputSignal(), null, "tempSensor", null, 0, 1, OutputConfigSubsystemElDiag.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputConfigSubsystemSPIEClass, InputConfigSubsystemSPI.class, "InputConfigSubsystemSPI", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(inputConfigSubsystemDigitalEClass, InputConfigSubsystemDigital.class, "InputConfigSubsystemDigital", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(inputConfigSubsystemFrqEClass, InputConfigSubsystemFrq.class, "InputConfigSubsystemFrq", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(outputConfigSubsystemPWMEClass, OutputConfigSubsystemPWM.class, "OutputConfigSubsystemPWM", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(outputConfigSubsystemDigitalEClass, OutputConfigSubsystemDigital.class, "OutputConfigSubsystemDigital", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(inputConfigSubsystemItemEClass, InputConfigSubsystemItem.class, "InputConfigSubsystemItem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(outputConfigSubsystemItemEClass, OutputConfigSubsystemItem.class, "OutputConfigSubsystemItem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(driverToECUEClass, DriverToECU.class, "DriverToECU", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getDriverToECU_InputAnalogDrivers(), this.getInputAnalogDrivers(), null, "inputAnalogDrivers", null, 0, 1, DriverToECU.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getDriverToECU_InputDigitalDrivers(), this.getInputDigitalDrivers(), null, "inputDigitalDrivers", null, 0, 1, DriverToECU.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getDriverToECU_InputDigDriversTable(), this.getInputDigDriversTable(), null, "inputDigDriversTable", null, 0, 1, DriverToECU.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getDriverToECU_OutputDigitalDrivers(), this.getOutputDigitalDrivers(), null, "outputDigitalDrivers", null, 0, 1, DriverToECU.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getDriverToECU_OutputDigDriversTable(), this.getOutputDigDriversTable(), null, "outputDigDriversTable", null, 0, 1, DriverToECU.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(tempSensorSubsystemEClass, TempSensorSubsystem.class, "TempSensorSubsystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getTempSensorSubsystem_Driver(), this.getAnalogDriver(), null, "driver", null, 0, -1, TempSensorSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputAnalogDriversEClass, InputAnalogDrivers.class, "InputAnalogDrivers", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getInputAnalogDrivers_Driver(), this.getAnalogDriver(), null, "driver", null, 0, -1, InputAnalogDrivers.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputDigitalDriversEClass, InputDigitalDrivers.class, "InputDigitalDrivers", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getInputDigitalDrivers_Driver(), this.getInDigDriver(), null, "driver", null, 0, -1, InputDigitalDrivers.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(outputDigitalDriversEClass, OutputDigitalDrivers.class, "OutputDigitalDrivers", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getOutputDigitalDrivers_Driver(), this.getOutDigDriver(), null, "driver", null, 0, -1, OutputDigitalDrivers.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(analogDriverEClass, AnalogDriver.class, "AnalogDriver", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getAnalogDriver_Name(), ecorePackage.getEString(), "name", null, 0, 1, AnalogDriver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getAnalogDriver_DriverSetup(), this.getIADC(), null, "driverSetup", null, 0, 1, AnalogDriver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inDigDriverEClass, InDigDriver.class, "InDigDriver", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getInDigDriver_Name(), ecorePackage.getEString(), "name", null, 0, 1, InDigDriver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getInDigDriver_DriverSetup(), this.getCommonDriver(), null, "driverSetup", null, 0, 1, InDigDriver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(outDigDriverEClass, OutDigDriver.class, "OutDigDriver", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getOutDigDriver_Name(), ecorePackage.getEString(), "name", null, 0, 1, OutDigDriver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getOutDigDriver_DriverSetup(), this.getCommonDriver(), null, "driverSetup", null, 0, 1, OutDigDriver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(commonDriverEClass, CommonDriver.class, "CommonDriver", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getCommonDriver_DriverIndex(), ecorePackage.getEString(), "driverIndex", null, 0, 1, CommonDriver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCommonDriver_ControllerPinName(), ecorePackage.getEString(), "controllerPinName", null, 0, 1, CommonDriver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCommonDriver_Description(), ecorePackage.getEString(), "description", null, 0, 1, CommonDriver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputDigDriversTableEClass, InputDigDriversTable.class, "InputDigDriversTable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getInputDigDriversTable_DigitalDriverTableRef(), this.getInDigitalDriverTableRef(), null, "digitalDriverTableRef", null, 0, -1, InputDigDriversTable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(outputDigDriversTableEClass, OutputDigDriversTable.class, "OutputDigDriversTable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getOutputDigDriversTable_DigitalDriverTableRef(), this.getOutDigitalDriverTableRef(), null, "digitalDriverTableRef", null, 0, -1, OutputDigDriversTable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inDigitalDriverTableRefEClass, InDigitalDriverTableRef.class, "InDigitalDriverTableRef", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getInDigitalDriverTableRef_DummySignal(), ecorePackage.getEString(), "dummySignal", null, 0, 1, InDigitalDriverTableRef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getInDigitalDriverTableRef_Name(), this.getInDigDriver(), null, "name", null, 0, 1, InDigitalDriverTableRef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(outDigitalDriverTableRefEClass, OutDigitalDriverTableRef.class, "OutDigitalDriverTableRef", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getOutDigitalDriverTableRef_DummySignal(), ecorePackage.getEString(), "dummySignal", null, 0, 1, OutDigitalDriverTableRef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getOutDigitalDriverTableRef_Name(), this.getOutDigDriver(), null, "name", null, 0, 1, OutDigitalDriverTableRef.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(electricDiagSubsystemEClass, ElectricDiagSubsystem.class, "ElectricDiagSubsystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getElectricDiagSubsystem_ElDiag(), this.getElDiag(), null, "elDiag", null, 0, -1, ElectricDiagSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(elDiagEClass, ElDiag.class, "ElDiag", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getElDiag_Name(), ecorePackage.getEString(), "name", null, 0, 1, ElDiag.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getElDiag_Enable(), this.getBOOLfalseDefault(), "enable", null, 0, 1, ElDiag.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getElDiag_DiagnosisEnable(), this.getBOOLfalseDefault(), "diagnosisEnable", null, 0, 1, ElDiag.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getElDiag_DriverIndex(), ecorePackage.getEString(), "driverIndex", null, 0, 1, ElDiag.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getElDiag_PwmDiagnosis(), ecorePackage.getEString(), "pwmDiagnosis", null, 0, 1, ElDiag.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getElDiag_PowerSupplySignal(), this.getInputSignal(), null, "powerSupplySignal", null, 0, 1, ElDiag.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getElDiag_Description(), ecorePackage.getEString(), "description", null, 0, 1, ElDiag.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(frequencySubsystemEClass, FrequencySubsystem.class, "FrequencySubsystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(ifrqEClass, zf.pios.configurator.IFRQ.class, "IFRQ", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getIFRQ_Name(), ecorePackage.getEString(), "name", null, 0, 1, zf.pios.configurator.IFRQ.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIFRQ_DriverIndex(), ecorePackage.getEString(), "driverIndex", null, 0, 1, zf.pios.configurator.IFRQ.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getIFRQ_SensorIndex(), this.getIFRQSensor(), null, "sensorIndex", null, 0, 1, zf.pios.configurator.IFRQ.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIFRQ_UpdateTime(), ecorePackage.getEString(), "updateTime", null, 0, 1, zf.pios.configurator.IFRQ.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIFRQ_Active(), ecorePackage.getEString(), "active", null, 0, 1, zf.pios.configurator.IFRQ.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(ifrqSensorEClass, IFRQSensor.class, "IFRQSensor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getIFRQSensor_Name(), ecorePackage.getEString(), "name", null, 0, 1, IFRQSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIFRQSensor_InitialWaitingTime(), ecorePackage.getEString(), "initialWaitingTime", null, 0, 1, IFRQSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIFRQSensor_DirChangeMinPeriods(), ecorePackage.getEString(), "dirChangeMinPeriods", null, 0, 1, IFRQSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIFRQSensor_DirectionChangeDebounceTime(), ecorePackage.getEString(), "directionChangeDebounceTime", null, 0, 1, IFRQSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(spIinputSysEClass, SPIinputSys.class, "SPIinputSys", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getSPIinputSys_Spi(), this.getSPI(), null, "spi", null, 0, -1, SPIinputSys.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(spiEClass, zf.pios.configurator.SPI.class, "SPI", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getSPI_Name(), ecorePackage.getEString(), "name", null, 0, 1, zf.pios.configurator.SPI.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSPI_DriverIndex(), ecorePackage.getEString(), "driverIndex", null, 0, 1, zf.pios.configurator.SPI.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSPI_DataStorageMode(), ecorePackage.getEString(), "dataStorageMode", null, 0, 1, zf.pios.configurator.SPI.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSPI_Command(), ecorePackage.getEString(), "command", null, 0, 1, zf.pios.configurator.SPI.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSPI_DataLength(), ecorePackage.getEString(), "dataLength", null, 0, 1, zf.pios.configurator.SPI.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSPI_SpitxData(), this.getSPITXData(), null, "spitxData", null, 0, 1, zf.pios.configurator.SPI.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSPI_Module(), ecorePackage.getEString(), "module", null, 0, 1, zf.pios.configurator.SPI.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSPI_Description(), ecorePackage.getEString(), "description", null, 0, 1, zf.pios.configurator.SPI.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(spitxDataEClass, SPITXData.class, "SPITXData", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getSPITXData_ByteOne(), ecorePackage.getEString(), "byteOne", null, 0, 1, SPITXData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSPITXData_ByteTwo(), ecorePackage.getEString(), "byteTwo", null, 0, 1, SPITXData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSPITXData_ByteThree(), ecorePackage.getEString(), "byteThree", null, 0, 1, SPITXData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSPITXData_ByteFour(), ecorePackage.getEString(), "byteFour", null, 0, 1, SPITXData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(opwmSubsystemEClass, OPWMSubsystem.class, "OPWMSubsystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getOPWMSubsystem_Opwm(), this.getOPWM(), null, "opwm", null, 0, -1, OPWMSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(opwmEClass, zf.pios.configurator.OPWM.class, "OPWM", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getOPWM_Name(), ecorePackage.getEString(), "name", null, 0, 1, zf.pios.configurator.OPWM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getOPWM_DriverIndex(), ecorePackage.getEString(), "driverIndex", null, 0, 1, zf.pios.configurator.OPWM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getOPWM_Period(), ecorePackage.getEInt(), "Period", null, 0, 1, zf.pios.configurator.OPWM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getOPWM_Description(), ecorePackage.getEString(), "description", null, 0, 1, zf.pios.configurator.OPWM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(iadcEClass, zf.pios.configurator.IADC.class, "IADC", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getIADC_DriverIndex(), ecorePackage.getEString(), "driverIndex", null, 0, 1, zf.pios.configurator.IADC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIADC_Enable(), this.getiadcEnableEnumeration(), "enable", null, 0, 1, zf.pios.configurator.IADC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getIADC_PowerSupplySignal(), this.getInputSignal(), null, "powerSupplySignal", null, 0, 1, zf.pios.configurator.IADC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIADC_EnableElDiagPowerSupplyOff(), ecorePackage.getEString(), "enableElDiagPowerSupplyOff", null, 0, 1, zf.pios.configurator.IADC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIADC_ElDiagInstanceIdx(), ecorePackage.getEString(), "elDiagInstanceIdx", null, 0, 1, zf.pios.configurator.IADC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIADC_ControllerPinName(), ecorePackage.getEString(), "controllerPinName", null, 0, 1, zf.pios.configurator.IADC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIADC_Description(), ecorePackage.getEString(), "description", null, 0, 1, zf.pios.configurator.IADC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(userDefinedSubsystemEClass, UserDefinedSubsystem.class, "UserDefinedSubsystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getUserDefinedSubsystem_Name(), this.getConfigSubsystemItem(), null, "name", null, 0, 1, UserDefinedSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getUserDefinedSubsystem_UserPort(), this.getUserPort(), null, "userPort", null, 0, -1, UserDefinedSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(configSubsystemItemEClass, ConfigSubsystemItem.class, "ConfigSubsystemItem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(userPortEClass, UserPort.class, "UserPort", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getUserPort_Name(), ecorePackage.getEString(), "name", null, 0, 1, UserPort.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getUserPort_DriverIndex(), ecorePackage.getEString(), "driverIndex", null, 0, 1, UserPort.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getUserPort_Description(), ecorePackage.getEString(), "description", null, 0, 1, UserPort.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(importEClass, Import.class, "Import", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getImport_ImportURI(), ecorePackage.getEString(), "importURI", null, 0, 1, Import.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getImport_Name(), ecorePackage.getEString(), "name", null, 0, 1, Import.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(importsEClass, Imports.class, "Imports", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getImports_ImportedNamespace(), ecorePackage.getEString(), "importedNamespace", null, 0, 1, Imports.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(frqSubsystemEClass, FRQSubsystem.class, "FRQSubsystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getFRQSubsystem_IfrqSensor(), this.getIFRQSensor(), null, "ifrqSensor", null, 0, -1, FRQSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getFRQSubsystem_Ifrq(), this.getIFRQ(), null, "ifrq", null, 0, -1, FRQSubsystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    // Initialize enums and add enum literals
    initEEnum(dataTypeEnumerationEEnum, dataTypeEnumeration.class, "dataTypeEnumeration");
    addEEnumLiteral(dataTypeEnumerationEEnum, dataTypeEnumeration.FL32);
    addEEnumLiteral(dataTypeEnumerationEEnum, dataTypeEnumeration.SI8);
    addEEnumLiteral(dataTypeEnumerationEEnum, dataTypeEnumeration.SI16);
    addEEnumLiteral(dataTypeEnumerationEEnum, dataTypeEnumeration.SI32);
    addEEnumLiteral(dataTypeEnumerationEEnum, dataTypeEnumeration.UI8);
    addEEnumLiteral(dataTypeEnumerationEEnum, dataTypeEnumeration.UI16);

    initEEnum(iadcEnableEnumerationEEnum, iadcEnableEnumeration.class, "iadcEnableEnumeration");
    addEEnumLiteral(iadcEnableEnumerationEEnum, iadcEnableEnumeration.ADC_CHANNEL_DISABLED);
    addEEnumLiteral(iadcEnableEnumerationEEnum, iadcEnableEnumeration.ADC_CHANNEL_ENABLED);

    initEEnum(booLfalseDefaultEEnum, BOOLfalseDefault.class, "BOOLfalseDefault");
    addEEnumLiteral(booLfalseDefaultEEnum, BOOLfalseDefault.FALSE);
    addEEnumLiteral(booLfalseDefaultEEnum, BOOLfalseDefault.TRUE);

    // Create resource
    createResource(eNS_URI);
  }

} //ConfiguratorPackageImpl
