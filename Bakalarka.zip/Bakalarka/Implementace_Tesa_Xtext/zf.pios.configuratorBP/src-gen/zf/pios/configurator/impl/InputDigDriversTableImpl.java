/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InDigitalDriverTableRef;
import zf.pios.configurator.InputDigDriversTable;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Dig Drivers Table</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.InputDigDriversTableImpl#getDigitalDriverTableRef <em>Digital Driver Table Ref</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InputDigDriversTableImpl extends MinimalEObjectImpl.Container implements InputDigDriversTable
{
  /**
   * The cached value of the '{@link #getDigitalDriverTableRef() <em>Digital Driver Table Ref</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDigitalDriverTableRef()
   * @generated
   * @ordered
   */
  protected EList<InDigitalDriverTableRef> digitalDriverTableRef;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputDigDriversTableImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.INPUT_DIG_DRIVERS_TABLE;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<InDigitalDriverTableRef> getDigitalDriverTableRef()
  {
    if (digitalDriverTableRef == null)
    {
      digitalDriverTableRef = new EObjectContainmentEList<InDigitalDriverTableRef>(InDigitalDriverTableRef.class, this, ConfiguratorPackage.INPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF);
    }
    return digitalDriverTableRef;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF:
        return ((InternalEList<?>)getDigitalDriverTableRef()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF:
        return getDigitalDriverTableRef();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF:
        getDigitalDriverTableRef().clear();
        getDigitalDriverTableRef().addAll((Collection<? extends InDigitalDriverTableRef>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF:
        getDigitalDriverTableRef().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_DIG_DRIVERS_TABLE__DIGITAL_DRIVER_TABLE_REF:
        return digitalDriverTableRef != null && !digitalDriverTableRef.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //InputDigDriversTableImpl
