/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Driver To ECU</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.DriverToECU#getInputAnalogDrivers <em>Input Analog Drivers</em>}</li>
 *   <li>{@link zf.pios.configurator.DriverToECU#getInputDigitalDrivers <em>Input Digital Drivers</em>}</li>
 *   <li>{@link zf.pios.configurator.DriverToECU#getInputDigDriversTable <em>Input Dig Drivers Table</em>}</li>
 *   <li>{@link zf.pios.configurator.DriverToECU#getOutputDigitalDrivers <em>Output Digital Drivers</em>}</li>
 *   <li>{@link zf.pios.configurator.DriverToECU#getOutputDigDriversTable <em>Output Dig Drivers Table</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getDriverToECU()
 * @model
 * @generated
 */
public interface DriverToECU extends EObject
{
  /**
   * Returns the value of the '<em><b>Input Analog Drivers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Analog Drivers</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Analog Drivers</em>' containment reference.
   * @see #setInputAnalogDrivers(InputAnalogDrivers)
   * @see zf.pios.configurator.ConfiguratorPackage#getDriverToECU_InputAnalogDrivers()
   * @model containment="true"
   * @generated
   */
  InputAnalogDrivers getInputAnalogDrivers();

  /**
   * Sets the value of the '{@link zf.pios.configurator.DriverToECU#getInputAnalogDrivers <em>Input Analog Drivers</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Analog Drivers</em>' containment reference.
   * @see #getInputAnalogDrivers()
   * @generated
   */
  void setInputAnalogDrivers(InputAnalogDrivers value);

  /**
   * Returns the value of the '<em><b>Input Digital Drivers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Digital Drivers</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Digital Drivers</em>' containment reference.
   * @see #setInputDigitalDrivers(InputDigitalDrivers)
   * @see zf.pios.configurator.ConfiguratorPackage#getDriverToECU_InputDigitalDrivers()
   * @model containment="true"
   * @generated
   */
  InputDigitalDrivers getInputDigitalDrivers();

  /**
   * Sets the value of the '{@link zf.pios.configurator.DriverToECU#getInputDigitalDrivers <em>Input Digital Drivers</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Digital Drivers</em>' containment reference.
   * @see #getInputDigitalDrivers()
   * @generated
   */
  void setInputDigitalDrivers(InputDigitalDrivers value);

  /**
   * Returns the value of the '<em><b>Input Dig Drivers Table</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Input Dig Drivers Table</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Input Dig Drivers Table</em>' containment reference.
   * @see #setInputDigDriversTable(InputDigDriversTable)
   * @see zf.pios.configurator.ConfiguratorPackage#getDriverToECU_InputDigDriversTable()
   * @model containment="true"
   * @generated
   */
  InputDigDriversTable getInputDigDriversTable();

  /**
   * Sets the value of the '{@link zf.pios.configurator.DriverToECU#getInputDigDriversTable <em>Input Dig Drivers Table</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Input Dig Drivers Table</em>' containment reference.
   * @see #getInputDigDriversTable()
   * @generated
   */
  void setInputDigDriversTable(InputDigDriversTable value);

  /**
   * Returns the value of the '<em><b>Output Digital Drivers</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output Digital Drivers</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Output Digital Drivers</em>' containment reference.
   * @see #setOutputDigitalDrivers(OutputDigitalDrivers)
   * @see zf.pios.configurator.ConfiguratorPackage#getDriverToECU_OutputDigitalDrivers()
   * @model containment="true"
   * @generated
   */
  OutputDigitalDrivers getOutputDigitalDrivers();

  /**
   * Sets the value of the '{@link zf.pios.configurator.DriverToECU#getOutputDigitalDrivers <em>Output Digital Drivers</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Output Digital Drivers</em>' containment reference.
   * @see #getOutputDigitalDrivers()
   * @generated
   */
  void setOutputDigitalDrivers(OutputDigitalDrivers value);

  /**
   * Returns the value of the '<em><b>Output Dig Drivers Table</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output Dig Drivers Table</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Output Dig Drivers Table</em>' containment reference.
   * @see #setOutputDigDriversTable(OutputDigDriversTable)
   * @see zf.pios.configurator.ConfiguratorPackage#getDriverToECU_OutputDigDriversTable()
   * @model containment="true"
   * @generated
   */
  OutputDigDriversTable getOutputDigDriversTable();

  /**
   * Sets the value of the '{@link zf.pios.configurator.DriverToECU#getOutputDigDriversTable <em>Output Dig Drivers Table</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Output Dig Drivers Table</em>' containment reference.
   * @see #getOutputDigDriversTable()
   * @generated
   */
  void setOutputDigDriversTable(OutputDigDriversTable value);

} // DriverToECU
