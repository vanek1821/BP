/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Config Subsystem Item</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputConfigSubsystemItem()
 * @model
 * @generated
 */
public interface InputConfigSubsystemItem extends InputDriverType, ConfigSubsystemItem
{
} // InputConfigSubsystemItem
