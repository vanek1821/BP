/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfigSubsystemOutput;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutputSubsystems;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Config Subsystem Output</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.ConfigSubsystemOutputImpl#getMaximalNumberOutputSubsystems <em>Maximal Number Output Subsystems</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ConfigSubsystemOutputImpl#getOutputSubsystems <em>Output Subsystems</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConfigSubsystemOutputImpl extends MinimalEObjectImpl.Container implements ConfigSubsystemOutput
{
  /**
   * The default value of the '{@link #getMaximalNumberOutputSubsystems() <em>Maximal Number Output Subsystems</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMaximalNumberOutputSubsystems()
   * @generated
   * @ordered
   */
  protected static final int MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS_EDEFAULT = 0;

  /**
   * The cached value of the '{@link #getMaximalNumberOutputSubsystems() <em>Maximal Number Output Subsystems</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMaximalNumberOutputSubsystems()
   * @generated
   * @ordered
   */
  protected int maximalNumberOutputSubsystems = MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS_EDEFAULT;

  /**
   * The cached value of the '{@link #getOutputSubsystems() <em>Output Subsystems</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputSubsystems()
   * @generated
   * @ordered
   */
  protected OutputSubsystems outputSubsystems;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ConfigSubsystemOutputImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.CONFIG_SUBSYSTEM_OUTPUT;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getMaximalNumberOutputSubsystems()
  {
    return maximalNumberOutputSubsystems;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMaximalNumberOutputSubsystems(int newMaximalNumberOutputSubsystems)
  {
    int oldMaximalNumberOutputSubsystems = maximalNumberOutputSubsystems;
    maximalNumberOutputSubsystems = newMaximalNumberOutputSubsystems;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS, oldMaximalNumberOutputSubsystems, maximalNumberOutputSubsystems));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputSubsystems getOutputSubsystems()
  {
    return outputSubsystems;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOutputSubsystems(OutputSubsystems newOutputSubsystems, NotificationChain msgs)
  {
    OutputSubsystems oldOutputSubsystems = outputSubsystems;
    outputSubsystems = newOutputSubsystems;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS, oldOutputSubsystems, newOutputSubsystems);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOutputSubsystems(OutputSubsystems newOutputSubsystems)
  {
    if (newOutputSubsystems != outputSubsystems)
    {
      NotificationChain msgs = null;
      if (outputSubsystems != null)
        msgs = ((InternalEObject)outputSubsystems).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS, null, msgs);
      if (newOutputSubsystems != null)
        msgs = ((InternalEObject)newOutputSubsystems).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS, null, msgs);
      msgs = basicSetOutputSubsystems(newOutputSubsystems, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS, newOutputSubsystems, newOutputSubsystems));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS:
        return basicSetOutputSubsystems(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS:
        return getMaximalNumberOutputSubsystems();
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS:
        return getOutputSubsystems();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS:
        setMaximalNumberOutputSubsystems((Integer)newValue);
        return;
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS:
        setOutputSubsystems((OutputSubsystems)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS:
        setMaximalNumberOutputSubsystems(MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS_EDEFAULT);
        return;
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS:
        setOutputSubsystems((OutputSubsystems)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS:
        return maximalNumberOutputSubsystems != MAXIMAL_NUMBER_OUTPUT_SUBSYSTEMS_EDEFAULT;
      case ConfiguratorPackage.CONFIG_SUBSYSTEM_OUTPUT__OUTPUT_SUBSYSTEMS:
        return outputSubsystems != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (maximalNumberOutputSubsystems: ");
    result.append(maximalNumberOutputSubsystems);
    result.append(')');
    return result.toString();
  }

} //ConfigSubsystemOutputImpl
