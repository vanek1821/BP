/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Driver Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputDriverType()
 * @model
 * @generated
 */
public interface OutputDriverType extends GenericSubsystem
{
} // OutputDriverType
