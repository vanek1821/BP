/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IFRQ</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.IFRQ#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.IFRQ#getDriverIndex <em>Driver Index</em>}</li>
 *   <li>{@link zf.pios.configurator.IFRQ#getSensorIndex <em>Sensor Index</em>}</li>
 *   <li>{@link zf.pios.configurator.IFRQ#getUpdateTime <em>Update Time</em>}</li>
 *   <li>{@link zf.pios.configurator.IFRQ#getActive <em>Active</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getIFRQ()
 * @model
 * @generated
 */
public interface IFRQ extends EObject
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIFRQ_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IFRQ#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Driver Index</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Driver Index</em>' attribute.
   * @see #setDriverIndex(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIFRQ_DriverIndex()
   * @model
   * @generated
   */
  String getDriverIndex();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IFRQ#getDriverIndex <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Driver Index</em>' attribute.
   * @see #getDriverIndex()
   * @generated
   */
  void setDriverIndex(String value);

  /**
   * Returns the value of the '<em><b>Sensor Index</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Sensor Index</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Sensor Index</em>' reference.
   * @see #setSensorIndex(IFRQSensor)
   * @see zf.pios.configurator.ConfiguratorPackage#getIFRQ_SensorIndex()
   * @model
   * @generated
   */
  IFRQSensor getSensorIndex();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IFRQ#getSensorIndex <em>Sensor Index</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Sensor Index</em>' reference.
   * @see #getSensorIndex()
   * @generated
   */
  void setSensorIndex(IFRQSensor value);

  /**
   * Returns the value of the '<em><b>Update Time</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Update Time</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Update Time</em>' attribute.
   * @see #setUpdateTime(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIFRQ_UpdateTime()
   * @model
   * @generated
   */
  String getUpdateTime();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IFRQ#getUpdateTime <em>Update Time</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Update Time</em>' attribute.
   * @see #getUpdateTime()
   * @generated
   */
  void setUpdateTime(String value);

  /**
   * Returns the value of the '<em><b>Active</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Active</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Active</em>' attribute.
   * @see #setActive(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getIFRQ_Active()
   * @model
   * @generated
   */
  String getActive();

  /**
   * Sets the value of the '{@link zf.pios.configurator.IFRQ#getActive <em>Active</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Active</em>' attribute.
   * @see #getActive()
   * @generated
   */
  void setActive(String value);

} // IFRQ
