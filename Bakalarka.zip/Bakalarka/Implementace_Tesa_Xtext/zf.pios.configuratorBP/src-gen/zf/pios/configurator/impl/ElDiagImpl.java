/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.BOOLfalseDefault;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.ElDiag;
import zf.pios.configurator.InputSignal;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>El Diag</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.ElDiagImpl#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ElDiagImpl#getEnable <em>Enable</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ElDiagImpl#getDiagnosisEnable <em>Diagnosis Enable</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ElDiagImpl#getDriverIndex <em>Driver Index</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ElDiagImpl#getPwmDiagnosis <em>Pwm Diagnosis</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ElDiagImpl#getPowerSupplySignal <em>Power Supply Signal</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.ElDiagImpl#getDescription <em>Description</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElDiagImpl extends MinimalEObjectImpl.Container implements ElDiag
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getEnable() <em>Enable</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEnable()
   * @generated
   * @ordered
   */
  protected static final BOOLfalseDefault ENABLE_EDEFAULT = BOOLfalseDefault.FALSE;

  /**
   * The cached value of the '{@link #getEnable() <em>Enable</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEnable()
   * @generated
   * @ordered
   */
  protected BOOLfalseDefault enable = ENABLE_EDEFAULT;

  /**
   * The default value of the '{@link #getDiagnosisEnable() <em>Diagnosis Enable</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDiagnosisEnable()
   * @generated
   * @ordered
   */
  protected static final BOOLfalseDefault DIAGNOSIS_ENABLE_EDEFAULT = BOOLfalseDefault.FALSE;

  /**
   * The cached value of the '{@link #getDiagnosisEnable() <em>Diagnosis Enable</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDiagnosisEnable()
   * @generated
   * @ordered
   */
  protected BOOLfalseDefault diagnosisEnable = DIAGNOSIS_ENABLE_EDEFAULT;

  /**
   * The default value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected static final String DRIVER_INDEX_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected String driverIndex = DRIVER_INDEX_EDEFAULT;

  /**
   * The default value of the '{@link #getPwmDiagnosis() <em>Pwm Diagnosis</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPwmDiagnosis()
   * @generated
   * @ordered
   */
  protected static final String PWM_DIAGNOSIS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getPwmDiagnosis() <em>Pwm Diagnosis</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPwmDiagnosis()
   * @generated
   * @ordered
   */
  protected String pwmDiagnosis = PWM_DIAGNOSIS_EDEFAULT;

  /**
   * The cached value of the '{@link #getPowerSupplySignal() <em>Power Supply Signal</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPowerSupplySignal()
   * @generated
   * @ordered
   */
  protected InputSignal powerSupplySignal;

  /**
   * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected static final String DESCRIPTION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected String description = DESCRIPTION_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ElDiagImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.EL_DIAG;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.EL_DIAG__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BOOLfalseDefault getEnable()
  {
    return enable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEnable(BOOLfalseDefault newEnable)
  {
    BOOLfalseDefault oldEnable = enable;
    enable = newEnable == null ? ENABLE_EDEFAULT : newEnable;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.EL_DIAG__ENABLE, oldEnable, enable));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BOOLfalseDefault getDiagnosisEnable()
  {
    return diagnosisEnable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDiagnosisEnable(BOOLfalseDefault newDiagnosisEnable)
  {
    BOOLfalseDefault oldDiagnosisEnable = diagnosisEnable;
    diagnosisEnable = newDiagnosisEnable == null ? DIAGNOSIS_ENABLE_EDEFAULT : newDiagnosisEnable;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.EL_DIAG__DIAGNOSIS_ENABLE, oldDiagnosisEnable, diagnosisEnable));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDriverIndex()
  {
    return driverIndex;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDriverIndex(String newDriverIndex)
  {
    String oldDriverIndex = driverIndex;
    driverIndex = newDriverIndex;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.EL_DIAG__DRIVER_INDEX, oldDriverIndex, driverIndex));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getPwmDiagnosis()
  {
    return pwmDiagnosis;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPwmDiagnosis(String newPwmDiagnosis)
  {
    String oldPwmDiagnosis = pwmDiagnosis;
    pwmDiagnosis = newPwmDiagnosis;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.EL_DIAG__PWM_DIAGNOSIS, oldPwmDiagnosis, pwmDiagnosis));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSignal getPowerSupplySignal()
  {
    if (powerSupplySignal != null && powerSupplySignal.eIsProxy())
    {
      InternalEObject oldPowerSupplySignal = (InternalEObject)powerSupplySignal;
      powerSupplySignal = (InputSignal)eResolveProxy(oldPowerSupplySignal);
      if (powerSupplySignal != oldPowerSupplySignal)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ConfiguratorPackage.EL_DIAG__POWER_SUPPLY_SIGNAL, oldPowerSupplySignal, powerSupplySignal));
      }
    }
    return powerSupplySignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputSignal basicGetPowerSupplySignal()
  {
    return powerSupplySignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPowerSupplySignal(InputSignal newPowerSupplySignal)
  {
    InputSignal oldPowerSupplySignal = powerSupplySignal;
    powerSupplySignal = newPowerSupplySignal;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.EL_DIAG__POWER_SUPPLY_SIGNAL, oldPowerSupplySignal, powerSupplySignal));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDescription()
  {
    return description;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDescription(String newDescription)
  {
    String oldDescription = description;
    description = newDescription;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.EL_DIAG__DESCRIPTION, oldDescription, description));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.EL_DIAG__NAME:
        return getName();
      case ConfiguratorPackage.EL_DIAG__ENABLE:
        return getEnable();
      case ConfiguratorPackage.EL_DIAG__DIAGNOSIS_ENABLE:
        return getDiagnosisEnable();
      case ConfiguratorPackage.EL_DIAG__DRIVER_INDEX:
        return getDriverIndex();
      case ConfiguratorPackage.EL_DIAG__PWM_DIAGNOSIS:
        return getPwmDiagnosis();
      case ConfiguratorPackage.EL_DIAG__POWER_SUPPLY_SIGNAL:
        if (resolve) return getPowerSupplySignal();
        return basicGetPowerSupplySignal();
      case ConfiguratorPackage.EL_DIAG__DESCRIPTION:
        return getDescription();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.EL_DIAG__NAME:
        setName((String)newValue);
        return;
      case ConfiguratorPackage.EL_DIAG__ENABLE:
        setEnable((BOOLfalseDefault)newValue);
        return;
      case ConfiguratorPackage.EL_DIAG__DIAGNOSIS_ENABLE:
        setDiagnosisEnable((BOOLfalseDefault)newValue);
        return;
      case ConfiguratorPackage.EL_DIAG__DRIVER_INDEX:
        setDriverIndex((String)newValue);
        return;
      case ConfiguratorPackage.EL_DIAG__PWM_DIAGNOSIS:
        setPwmDiagnosis((String)newValue);
        return;
      case ConfiguratorPackage.EL_DIAG__POWER_SUPPLY_SIGNAL:
        setPowerSupplySignal((InputSignal)newValue);
        return;
      case ConfiguratorPackage.EL_DIAG__DESCRIPTION:
        setDescription((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.EL_DIAG__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.EL_DIAG__ENABLE:
        setEnable(ENABLE_EDEFAULT);
        return;
      case ConfiguratorPackage.EL_DIAG__DIAGNOSIS_ENABLE:
        setDiagnosisEnable(DIAGNOSIS_ENABLE_EDEFAULT);
        return;
      case ConfiguratorPackage.EL_DIAG__DRIVER_INDEX:
        setDriverIndex(DRIVER_INDEX_EDEFAULT);
        return;
      case ConfiguratorPackage.EL_DIAG__PWM_DIAGNOSIS:
        setPwmDiagnosis(PWM_DIAGNOSIS_EDEFAULT);
        return;
      case ConfiguratorPackage.EL_DIAG__POWER_SUPPLY_SIGNAL:
        setPowerSupplySignal((InputSignal)null);
        return;
      case ConfiguratorPackage.EL_DIAG__DESCRIPTION:
        setDescription(DESCRIPTION_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.EL_DIAG__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ConfiguratorPackage.EL_DIAG__ENABLE:
        return enable != ENABLE_EDEFAULT;
      case ConfiguratorPackage.EL_DIAG__DIAGNOSIS_ENABLE:
        return diagnosisEnable != DIAGNOSIS_ENABLE_EDEFAULT;
      case ConfiguratorPackage.EL_DIAG__DRIVER_INDEX:
        return DRIVER_INDEX_EDEFAULT == null ? driverIndex != null : !DRIVER_INDEX_EDEFAULT.equals(driverIndex);
      case ConfiguratorPackage.EL_DIAG__PWM_DIAGNOSIS:
        return PWM_DIAGNOSIS_EDEFAULT == null ? pwmDiagnosis != null : !PWM_DIAGNOSIS_EDEFAULT.equals(pwmDiagnosis);
      case ConfiguratorPackage.EL_DIAG__POWER_SUPPLY_SIGNAL:
        return powerSupplySignal != null;
      case ConfiguratorPackage.EL_DIAG__DESCRIPTION:
        return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", enable: ");
    result.append(enable);
    result.append(", diagnosisEnable: ");
    result.append(diagnosisEnable);
    result.append(", driverIndex: ");
    result.append(driverIndex);
    result.append(", pwmDiagnosis: ");
    result.append(pwmDiagnosis);
    result.append(", description: ");
    result.append(description);
    result.append(')');
    return result.toString();
  }

} //ElDiagImpl
