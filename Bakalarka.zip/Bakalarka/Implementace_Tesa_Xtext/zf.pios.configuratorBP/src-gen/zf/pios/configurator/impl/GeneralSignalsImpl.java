/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.GeneralSignal;
import zf.pios.configurator.GeneralSignals;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>General Signals</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.GeneralSignalsImpl#getGeneralSignal <em>General Signal</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GeneralSignalsImpl extends MinimalEObjectImpl.Container implements GeneralSignals
{
  /**
   * The cached value of the '{@link #getGeneralSignal() <em>General Signal</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGeneralSignal()
   * @generated
   * @ordered
   */
  protected EList<GeneralSignal> generalSignal;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GeneralSignalsImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.GENERAL_SIGNALS;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<GeneralSignal> getGeneralSignal()
  {
    if (generalSignal == null)
    {
      generalSignal = new EObjectContainmentEList<GeneralSignal>(GeneralSignal.class, this, ConfiguratorPackage.GENERAL_SIGNALS__GENERAL_SIGNAL);
    }
    return generalSignal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.GENERAL_SIGNALS__GENERAL_SIGNAL:
        return ((InternalEList<?>)getGeneralSignal()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.GENERAL_SIGNALS__GENERAL_SIGNAL:
        return getGeneralSignal();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.GENERAL_SIGNALS__GENERAL_SIGNAL:
        getGeneralSignal().clear();
        getGeneralSignal().addAll((Collection<? extends GeneralSignal>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.GENERAL_SIGNALS__GENERAL_SIGNAL:
        getGeneralSignal().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.GENERAL_SIGNALS__GENERAL_SIGNAL:
        return generalSignal != null && !generalSignal.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //GeneralSignalsImpl
