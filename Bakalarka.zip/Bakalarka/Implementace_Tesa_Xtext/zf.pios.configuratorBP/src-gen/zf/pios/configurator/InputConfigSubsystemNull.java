/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Config Subsystem Null</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputConfigSubsystemNull()
 * @model
 * @generated
 */
public interface InputConfigSubsystemNull extends InputDriverType
{
} // InputConfigSubsystemNull
