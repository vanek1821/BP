/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Config Subsystem El Diag</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.OutputConfigSubsystemElDiag#getTempSensor <em>Temp Sensor</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputConfigSubsystemElDiag()
 * @model
 * @generated
 */
public interface OutputConfigSubsystemElDiag extends OutputDriverType
{
  /**
   * Returns the value of the '<em><b>Temp Sensor</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Temp Sensor</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Temp Sensor</em>' reference.
   * @see #setTempSensor(InputSignal)
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputConfigSubsystemElDiag_TempSensor()
   * @model
   * @generated
   */
  InputSignal getTempSensor();

  /**
   * Sets the value of the '{@link zf.pios.configurator.OutputConfigSubsystemElDiag#getTempSensor <em>Temp Sensor</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Temp Sensor</em>' reference.
   * @see #getTempSensor()
   * @generated
   */
  void setTempSensor(InputSignal value);

} // OutputConfigSubsystemElDiag
