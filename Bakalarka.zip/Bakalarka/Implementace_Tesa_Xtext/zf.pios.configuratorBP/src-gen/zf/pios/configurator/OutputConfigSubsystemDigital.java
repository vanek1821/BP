/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Config Subsystem Digital</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputConfigSubsystemDigital()
 * @model
 * @generated
 */
public interface OutputConfigSubsystemDigital extends OutputDriverType
{
} // OutputConfigSubsystemDigital
