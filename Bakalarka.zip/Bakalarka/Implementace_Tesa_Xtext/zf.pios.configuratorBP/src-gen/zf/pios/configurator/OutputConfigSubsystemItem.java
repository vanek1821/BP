/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Config Subsystem Item</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputConfigSubsystemItem()
 * @model
 * @generated
 */
public interface OutputConfigSubsystemItem extends OutputDriverType, ConfigSubsystemItem
{
} // OutputConfigSubsystemItem
