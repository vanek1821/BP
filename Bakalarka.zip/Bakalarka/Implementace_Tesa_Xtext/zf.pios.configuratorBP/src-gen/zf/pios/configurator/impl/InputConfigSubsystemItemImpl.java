/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputConfigSubsystemItem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Config Subsystem Item</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InputConfigSubsystemItemImpl extends InputDriverTypeImpl implements InputConfigSubsystemItem
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputConfigSubsystemItemImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.INPUT_CONFIG_SUBSYSTEM_ITEM;
  }

} //InputConfigSubsystemItemImpl
