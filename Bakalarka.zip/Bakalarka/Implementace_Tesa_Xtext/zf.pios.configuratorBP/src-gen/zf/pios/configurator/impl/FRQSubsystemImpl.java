/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.FRQSubsystem;
import zf.pios.configurator.IFRQ;
import zf.pios.configurator.IFRQSensor;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>FRQ Subsystem</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.FRQSubsystemImpl#getIfrqSensor <em>Ifrq Sensor</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.FRQSubsystemImpl#getIfrq <em>Ifrq</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FRQSubsystemImpl extends FrequencySubsystemImpl implements FRQSubsystem
{
  /**
   * The cached value of the '{@link #getIfrqSensor() <em>Ifrq Sensor</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIfrqSensor()
   * @generated
   * @ordered
   */
  protected EList<IFRQSensor> ifrqSensor;

  /**
   * The cached value of the '{@link #getIfrq() <em>Ifrq</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIfrq()
   * @generated
   * @ordered
   */
  protected EList<IFRQ> ifrq;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected FRQSubsystemImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.FRQ_SUBSYSTEM;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<IFRQSensor> getIfrqSensor()
  {
    if (ifrqSensor == null)
    {
      ifrqSensor = new EObjectContainmentEList<IFRQSensor>(IFRQSensor.class, this, ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ_SENSOR);
    }
    return ifrqSensor;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<IFRQ> getIfrq()
  {
    if (ifrq == null)
    {
      ifrq = new EObjectContainmentEList<IFRQ>(IFRQ.class, this, ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ);
    }
    return ifrq;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ_SENSOR:
        return ((InternalEList<?>)getIfrqSensor()).basicRemove(otherEnd, msgs);
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ:
        return ((InternalEList<?>)getIfrq()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ_SENSOR:
        return getIfrqSensor();
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ:
        return getIfrq();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ_SENSOR:
        getIfrqSensor().clear();
        getIfrqSensor().addAll((Collection<? extends IFRQSensor>)newValue);
        return;
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ:
        getIfrq().clear();
        getIfrq().addAll((Collection<? extends IFRQ>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ_SENSOR:
        getIfrqSensor().clear();
        return;
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ:
        getIfrq().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ_SENSOR:
        return ifrqSensor != null && !ifrqSensor.isEmpty();
      case ConfiguratorPackage.FRQ_SUBSYSTEM__IFRQ:
        return ifrq != null && !ifrq.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //FRQSubsystemImpl
