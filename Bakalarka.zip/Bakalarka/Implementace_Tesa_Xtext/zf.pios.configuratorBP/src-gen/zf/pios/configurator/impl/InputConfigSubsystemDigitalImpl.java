/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputConfigSubsystemDigital;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Config Subsystem Digital</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InputConfigSubsystemDigitalImpl extends InputDriverTypeImpl implements InputConfigSubsystemDigital
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputConfigSubsystemDigitalImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.INPUT_CONFIG_SUBSYSTEM_DIGITAL;
  }

} //InputConfigSubsystemDigitalImpl
