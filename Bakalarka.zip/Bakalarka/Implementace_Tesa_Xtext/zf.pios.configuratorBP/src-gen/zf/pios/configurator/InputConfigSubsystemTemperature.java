/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Config Subsystem Temperature</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputConfigSubsystemTemperature()
 * @model
 * @generated
 */
public interface InputConfigSubsystemTemperature extends InputDriverType
{
} // InputConfigSubsystemTemperature
