/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.DriverToECU;
import zf.pios.configurator.InputAnalogDrivers;
import zf.pios.configurator.InputDigDriversTable;
import zf.pios.configurator.InputDigitalDrivers;
import zf.pios.configurator.OutputDigDriversTable;
import zf.pios.configurator.OutputDigitalDrivers;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Driver To ECU</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.DriverToECUImpl#getInputAnalogDrivers <em>Input Analog Drivers</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.DriverToECUImpl#getInputDigitalDrivers <em>Input Digital Drivers</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.DriverToECUImpl#getInputDigDriversTable <em>Input Dig Drivers Table</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.DriverToECUImpl#getOutputDigitalDrivers <em>Output Digital Drivers</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.DriverToECUImpl#getOutputDigDriversTable <em>Output Dig Drivers Table</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DriverToECUImpl extends MinimalEObjectImpl.Container implements DriverToECU
{
  /**
   * The cached value of the '{@link #getInputAnalogDrivers() <em>Input Analog Drivers</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputAnalogDrivers()
   * @generated
   * @ordered
   */
  protected InputAnalogDrivers inputAnalogDrivers;

  /**
   * The cached value of the '{@link #getInputDigitalDrivers() <em>Input Digital Drivers</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputDigitalDrivers()
   * @generated
   * @ordered
   */
  protected InputDigitalDrivers inputDigitalDrivers;

  /**
   * The cached value of the '{@link #getInputDigDriversTable() <em>Input Dig Drivers Table</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInputDigDriversTable()
   * @generated
   * @ordered
   */
  protected InputDigDriversTable inputDigDriversTable;

  /**
   * The cached value of the '{@link #getOutputDigitalDrivers() <em>Output Digital Drivers</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputDigitalDrivers()
   * @generated
   * @ordered
   */
  protected OutputDigitalDrivers outputDigitalDrivers;

  /**
   * The cached value of the '{@link #getOutputDigDriversTable() <em>Output Dig Drivers Table</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputDigDriversTable()
   * @generated
   * @ordered
   */
  protected OutputDigDriversTable outputDigDriversTable;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected DriverToECUImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.DRIVER_TO_ECU;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputAnalogDrivers getInputAnalogDrivers()
  {
    return inputAnalogDrivers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputAnalogDrivers(InputAnalogDrivers newInputAnalogDrivers, NotificationChain msgs)
  {
    InputAnalogDrivers oldInputAnalogDrivers = inputAnalogDrivers;
    inputAnalogDrivers = newInputAnalogDrivers;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS, oldInputAnalogDrivers, newInputAnalogDrivers);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputAnalogDrivers(InputAnalogDrivers newInputAnalogDrivers)
  {
    if (newInputAnalogDrivers != inputAnalogDrivers)
    {
      NotificationChain msgs = null;
      if (inputAnalogDrivers != null)
        msgs = ((InternalEObject)inputAnalogDrivers).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS, null, msgs);
      if (newInputAnalogDrivers != null)
        msgs = ((InternalEObject)newInputAnalogDrivers).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS, null, msgs);
      msgs = basicSetInputAnalogDrivers(newInputAnalogDrivers, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS, newInputAnalogDrivers, newInputAnalogDrivers));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputDigitalDrivers getInputDigitalDrivers()
  {
    return inputDigitalDrivers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputDigitalDrivers(InputDigitalDrivers newInputDigitalDrivers, NotificationChain msgs)
  {
    InputDigitalDrivers oldInputDigitalDrivers = inputDigitalDrivers;
    inputDigitalDrivers = newInputDigitalDrivers;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS, oldInputDigitalDrivers, newInputDigitalDrivers);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputDigitalDrivers(InputDigitalDrivers newInputDigitalDrivers)
  {
    if (newInputDigitalDrivers != inputDigitalDrivers)
    {
      NotificationChain msgs = null;
      if (inputDigitalDrivers != null)
        msgs = ((InternalEObject)inputDigitalDrivers).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS, null, msgs);
      if (newInputDigitalDrivers != null)
        msgs = ((InternalEObject)newInputDigitalDrivers).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS, null, msgs);
      msgs = basicSetInputDigitalDrivers(newInputDigitalDrivers, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS, newInputDigitalDrivers, newInputDigitalDrivers));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public InputDigDriversTable getInputDigDriversTable()
  {
    return inputDigDriversTable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetInputDigDriversTable(InputDigDriversTable newInputDigDriversTable, NotificationChain msgs)
  {
    InputDigDriversTable oldInputDigDriversTable = inputDigDriversTable;
    inputDigDriversTable = newInputDigDriversTable;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE, oldInputDigDriversTable, newInputDigDriversTable);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInputDigDriversTable(InputDigDriversTable newInputDigDriversTable)
  {
    if (newInputDigDriversTable != inputDigDriversTable)
    {
      NotificationChain msgs = null;
      if (inputDigDriversTable != null)
        msgs = ((InternalEObject)inputDigDriversTable).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE, null, msgs);
      if (newInputDigDriversTable != null)
        msgs = ((InternalEObject)newInputDigDriversTable).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE, null, msgs);
      msgs = basicSetInputDigDriversTable(newInputDigDriversTable, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE, newInputDigDriversTable, newInputDigDriversTable));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputDigitalDrivers getOutputDigitalDrivers()
  {
    return outputDigitalDrivers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOutputDigitalDrivers(OutputDigitalDrivers newOutputDigitalDrivers, NotificationChain msgs)
  {
    OutputDigitalDrivers oldOutputDigitalDrivers = outputDigitalDrivers;
    outputDigitalDrivers = newOutputDigitalDrivers;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS, oldOutputDigitalDrivers, newOutputDigitalDrivers);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOutputDigitalDrivers(OutputDigitalDrivers newOutputDigitalDrivers)
  {
    if (newOutputDigitalDrivers != outputDigitalDrivers)
    {
      NotificationChain msgs = null;
      if (outputDigitalDrivers != null)
        msgs = ((InternalEObject)outputDigitalDrivers).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS, null, msgs);
      if (newOutputDigitalDrivers != null)
        msgs = ((InternalEObject)newOutputDigitalDrivers).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS, null, msgs);
      msgs = basicSetOutputDigitalDrivers(newOutputDigitalDrivers, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS, newOutputDigitalDrivers, newOutputDigitalDrivers));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OutputDigDriversTable getOutputDigDriversTable()
  {
    return outputDigDriversTable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetOutputDigDriversTable(OutputDigDriversTable newOutputDigDriversTable, NotificationChain msgs)
  {
    OutputDigDriversTable oldOutputDigDriversTable = outputDigDriversTable;
    outputDigDriversTable = newOutputDigDriversTable;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE, oldOutputDigDriversTable, newOutputDigDriversTable);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOutputDigDriversTable(OutputDigDriversTable newOutputDigDriversTable)
  {
    if (newOutputDigDriversTable != outputDigDriversTable)
    {
      NotificationChain msgs = null;
      if (outputDigDriversTable != null)
        msgs = ((InternalEObject)outputDigDriversTable).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE, null, msgs);
      if (newOutputDigDriversTable != null)
        msgs = ((InternalEObject)newOutputDigDriversTable).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE, null, msgs);
      msgs = basicSetOutputDigDriversTable(newOutputDigDriversTable, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE, newOutputDigDriversTable, newOutputDigDriversTable));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS:
        return basicSetInputAnalogDrivers(null, msgs);
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS:
        return basicSetInputDigitalDrivers(null, msgs);
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE:
        return basicSetInputDigDriversTable(null, msgs);
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS:
        return basicSetOutputDigitalDrivers(null, msgs);
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE:
        return basicSetOutputDigDriversTable(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS:
        return getInputAnalogDrivers();
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS:
        return getInputDigitalDrivers();
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE:
        return getInputDigDriversTable();
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS:
        return getOutputDigitalDrivers();
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE:
        return getOutputDigDriversTable();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS:
        setInputAnalogDrivers((InputAnalogDrivers)newValue);
        return;
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS:
        setInputDigitalDrivers((InputDigitalDrivers)newValue);
        return;
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE:
        setInputDigDriversTable((InputDigDriversTable)newValue);
        return;
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS:
        setOutputDigitalDrivers((OutputDigitalDrivers)newValue);
        return;
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE:
        setOutputDigDriversTable((OutputDigDriversTable)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS:
        setInputAnalogDrivers((InputAnalogDrivers)null);
        return;
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS:
        setInputDigitalDrivers((InputDigitalDrivers)null);
        return;
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE:
        setInputDigDriversTable((InputDigDriversTable)null);
        return;
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS:
        setOutputDigitalDrivers((OutputDigitalDrivers)null);
        return;
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE:
        setOutputDigDriversTable((OutputDigDriversTable)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_ANALOG_DRIVERS:
        return inputAnalogDrivers != null;
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIGITAL_DRIVERS:
        return inputDigitalDrivers != null;
      case ConfiguratorPackage.DRIVER_TO_ECU__INPUT_DIG_DRIVERS_TABLE:
        return inputDigDriversTable != null;
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIGITAL_DRIVERS:
        return outputDigitalDrivers != null;
      case ConfiguratorPackage.DRIVER_TO_ECU__OUTPUT_DIG_DRIVERS_TABLE:
        return outputDigDriversTable != null;
    }
    return super.eIsSet(featureID);
  }

} //DriverToECUImpl
