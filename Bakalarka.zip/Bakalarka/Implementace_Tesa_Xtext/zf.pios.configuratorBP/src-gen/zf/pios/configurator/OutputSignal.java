/**
 */
package zf.pios.configurator;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Signal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.OutputSignal#getPullUpResistorSignal <em>Pull Up Resistor Signal</em>}</li>
 *   <li>{@link zf.pios.configurator.OutputSignal#getDatafield <em>Datafield</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputSignal()
 * @model
 * @generated
 */
public interface OutputSignal extends GeneralSignal
{
  /**
   * Returns the value of the '<em><b>Pull Up Resistor Signal</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Pull Up Resistor Signal</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Pull Up Resistor Signal</em>' attribute.
   * @see #setPullUpResistorSignal(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputSignal_PullUpResistorSignal()
   * @model
   * @generated
   */
  String getPullUpResistorSignal();

  /**
   * Sets the value of the '{@link zf.pios.configurator.OutputSignal#getPullUpResistorSignal <em>Pull Up Resistor Signal</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Pull Up Resistor Signal</em>' attribute.
   * @see #getPullUpResistorSignal()
   * @generated
   */
  void setPullUpResistorSignal(String value);

  /**
   * Returns the value of the '<em><b>Datafield</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.OutputDatafield}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Datafield</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Datafield</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getOutputSignal_Datafield()
   * @model containment="true"
   * @generated
   */
  EList<OutputDatafield> getDatafield();

} // OutputSignal
