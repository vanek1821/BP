/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see zf.pios.configurator.ConfiguratorPackage
 * @generated
 */
public interface ConfiguratorFactory extends EFactory
{
  /**
   * The singleton instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  ConfiguratorFactory eINSTANCE = zf.pios.configurator.impl.ConfiguratorFactoryImpl.init();

  /**
   * Returns a new object of class '<em>Configuration</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Configuration</em>'.
   * @generated
   */
  Configuration createConfiguration();

  /**
   * Returns a new object of class '<em>System</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>System</em>'.
   * @generated
   */
  System createSystem();

  /**
   * Returns a new object of class '<em>Signals</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Signals</em>'.
   * @generated
   */
  Signals createSignals();

  /**
   * Returns a new object of class '<em>General Signals</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>General Signals</em>'.
   * @generated
   */
  GeneralSignals createGeneralSignals();

  /**
   * Returns a new object of class '<em>General Signal</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>General Signal</em>'.
   * @generated
   */
  GeneralSignal createGeneralSignal();

  /**
   * Returns a new object of class '<em>Input Signal</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Signal</em>'.
   * @generated
   */
  InputSignal createInputSignal();

  /**
   * Returns a new object of class '<em>Output Signal</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Signal</em>'.
   * @generated
   */
  OutputSignal createOutputSignal();

  /**
   * Returns a new object of class '<em>Datafield</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Datafield</em>'.
   * @generated
   */
  Datafield createDatafield();

  /**
   * Returns a new object of class '<em>Input Datafield</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Datafield</em>'.
   * @generated
   */
  InputDatafield createInputDatafield();

  /**
   * Returns a new object of class '<em>Output Datafield</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Datafield</em>'.
   * @generated
   */
  OutputDatafield createOutputDatafield();

  /**
   * Returns a new object of class '<em>Portname</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Portname</em>'.
   * @generated
   */
  Portname createPortname();

  /**
   * Returns a new object of class '<em>Variants</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Variants</em>'.
   * @generated
   */
  Variants createVariants();

  /**
   * Returns a new object of class '<em>Variant</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Variant</em>'.
   * @generated
   */
  Variant createVariant();

  /**
   * Returns a new object of class '<em>Signal</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Signal</em>'.
   * @generated
   */
  Signal createSignal();

  /**
   * Returns a new object of class '<em>ASAP Measurment</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>ASAP Measurment</em>'.
   * @generated
   */
  ASAPMeasurment createASAPMeasurment();

  /**
   * Returns a new object of class '<em>Hardware</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Hardware</em>'.
   * @generated
   */
  Hardware createHardware();

  /**
   * Returns a new object of class '<em>Config Subsystem</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Config Subsystem</em>'.
   * @generated
   */
  ConfigSubsystem createConfigSubsystem();

  /**
   * Returns a new object of class '<em>Config Subsystem Input</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Config Subsystem Input</em>'.
   * @generated
   */
  ConfigSubsystemInput createConfigSubsystemInput();

  /**
   * Returns a new object of class '<em>Config Subsystem Output</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Config Subsystem Output</em>'.
   * @generated
   */
  ConfigSubsystemOutput createConfigSubsystemOutput();

  /**
   * Returns a new object of class '<em>Input Subsystems</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Subsystems</em>'.
   * @generated
   */
  InputSubsystems createInputSubsystems();

  /**
   * Returns a new object of class '<em>Output Subsystems</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Subsystems</em>'.
   * @generated
   */
  OutputSubsystems createOutputSubsystems();

  /**
   * Returns a new object of class '<em>Input Config Subsystem Null</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Config Subsystem Null</em>'.
   * @generated
   */
  InputConfigSubsystemNull createInputConfigSubsystemNull();

  /**
   * Returns a new object of class '<em>Output Config Subsystem Null</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Config Subsystem Null</em>'.
   * @generated
   */
  OutputConfigSubsystemNull createOutputConfigSubsystemNull();

  /**
   * Returns a new object of class '<em>Generic Subsystem</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Generic Subsystem</em>'.
   * @generated
   */
  GenericSubsystem createGenericSubsystem();

  /**
   * Returns a new object of class '<em>Input Driver Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Driver Type</em>'.
   * @generated
   */
  InputDriverType createInputDriverType();

  /**
   * Returns a new object of class '<em>Output Driver Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Driver Type</em>'.
   * @generated
   */
  OutputDriverType createOutputDriverType();

  /**
   * Returns a new object of class '<em>Input Config Subsystem Analog</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Config Subsystem Analog</em>'.
   * @generated
   */
  InputConfigSubsystemAnalog createInputConfigSubsystemAnalog();

  /**
   * Returns a new object of class '<em>Input Config Subsystem Temperature</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Config Subsystem Temperature</em>'.
   * @generated
   */
  InputConfigSubsystemTemperature createInputConfigSubsystemTemperature();

  /**
   * Returns a new object of class '<em>Output Config Subsystem El Diag</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Config Subsystem El Diag</em>'.
   * @generated
   */
  OutputConfigSubsystemElDiag createOutputConfigSubsystemElDiag();

  /**
   * Returns a new object of class '<em>Input Config Subsystem SPI</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Config Subsystem SPI</em>'.
   * @generated
   */
  InputConfigSubsystemSPI createInputConfigSubsystemSPI();

  /**
   * Returns a new object of class '<em>Input Config Subsystem Digital</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Config Subsystem Digital</em>'.
   * @generated
   */
  InputConfigSubsystemDigital createInputConfigSubsystemDigital();

  /**
   * Returns a new object of class '<em>Input Config Subsystem Frq</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Config Subsystem Frq</em>'.
   * @generated
   */
  InputConfigSubsystemFrq createInputConfigSubsystemFrq();

  /**
   * Returns a new object of class '<em>Output Config Subsystem PWM</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Config Subsystem PWM</em>'.
   * @generated
   */
  OutputConfigSubsystemPWM createOutputConfigSubsystemPWM();

  /**
   * Returns a new object of class '<em>Output Config Subsystem Digital</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Config Subsystem Digital</em>'.
   * @generated
   */
  OutputConfigSubsystemDigital createOutputConfigSubsystemDigital();

  /**
   * Returns a new object of class '<em>Input Config Subsystem Item</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Config Subsystem Item</em>'.
   * @generated
   */
  InputConfigSubsystemItem createInputConfigSubsystemItem();

  /**
   * Returns a new object of class '<em>Output Config Subsystem Item</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Config Subsystem Item</em>'.
   * @generated
   */
  OutputConfigSubsystemItem createOutputConfigSubsystemItem();

  /**
   * Returns a new object of class '<em>Driver To ECU</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Driver To ECU</em>'.
   * @generated
   */
  DriverToECU createDriverToECU();

  /**
   * Returns a new object of class '<em>Temp Sensor Subsystem</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Temp Sensor Subsystem</em>'.
   * @generated
   */
  TempSensorSubsystem createTempSensorSubsystem();

  /**
   * Returns a new object of class '<em>Input Analog Drivers</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Analog Drivers</em>'.
   * @generated
   */
  InputAnalogDrivers createInputAnalogDrivers();

  /**
   * Returns a new object of class '<em>Input Digital Drivers</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Digital Drivers</em>'.
   * @generated
   */
  InputDigitalDrivers createInputDigitalDrivers();

  /**
   * Returns a new object of class '<em>Output Digital Drivers</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Digital Drivers</em>'.
   * @generated
   */
  OutputDigitalDrivers createOutputDigitalDrivers();

  /**
   * Returns a new object of class '<em>Analog Driver</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Analog Driver</em>'.
   * @generated
   */
  AnalogDriver createAnalogDriver();

  /**
   * Returns a new object of class '<em>In Dig Driver</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>In Dig Driver</em>'.
   * @generated
   */
  InDigDriver createInDigDriver();

  /**
   * Returns a new object of class '<em>Out Dig Driver</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Out Dig Driver</em>'.
   * @generated
   */
  OutDigDriver createOutDigDriver();

  /**
   * Returns a new object of class '<em>Common Driver</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Common Driver</em>'.
   * @generated
   */
  CommonDriver createCommonDriver();

  /**
   * Returns a new object of class '<em>Input Dig Drivers Table</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input Dig Drivers Table</em>'.
   * @generated
   */
  InputDigDriversTable createInputDigDriversTable();

  /**
   * Returns a new object of class '<em>Output Dig Drivers Table</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Output Dig Drivers Table</em>'.
   * @generated
   */
  OutputDigDriversTable createOutputDigDriversTable();

  /**
   * Returns a new object of class '<em>In Digital Driver Table Ref</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>In Digital Driver Table Ref</em>'.
   * @generated
   */
  InDigitalDriverTableRef createInDigitalDriverTableRef();

  /**
   * Returns a new object of class '<em>Out Digital Driver Table Ref</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Out Digital Driver Table Ref</em>'.
   * @generated
   */
  OutDigitalDriverTableRef createOutDigitalDriverTableRef();

  /**
   * Returns a new object of class '<em>Electric Diag Subsystem</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Electric Diag Subsystem</em>'.
   * @generated
   */
  ElectricDiagSubsystem createElectricDiagSubsystem();

  /**
   * Returns a new object of class '<em>El Diag</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>El Diag</em>'.
   * @generated
   */
  ElDiag createElDiag();

  /**
   * Returns a new object of class '<em>Frequency Subsystem</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Frequency Subsystem</em>'.
   * @generated
   */
  FrequencySubsystem createFrequencySubsystem();

  /**
   * Returns a new object of class '<em>IFRQ</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>IFRQ</em>'.
   * @generated
   */
  IFRQ createIFRQ();

  /**
   * Returns a new object of class '<em>IFRQ Sensor</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>IFRQ Sensor</em>'.
   * @generated
   */
  IFRQSensor createIFRQSensor();

  /**
   * Returns a new object of class '<em>SP Iinput Sys</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>SP Iinput Sys</em>'.
   * @generated
   */
  SPIinputSys createSPIinputSys();

  /**
   * Returns a new object of class '<em>SPI</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>SPI</em>'.
   * @generated
   */
  SPI createSPI();

  /**
   * Returns a new object of class '<em>SPITX Data</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>SPITX Data</em>'.
   * @generated
   */
  SPITXData createSPITXData();

  /**
   * Returns a new object of class '<em>OPWM Subsystem</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>OPWM Subsystem</em>'.
   * @generated
   */
  OPWMSubsystem createOPWMSubsystem();

  /**
   * Returns a new object of class '<em>OPWM</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>OPWM</em>'.
   * @generated
   */
  OPWM createOPWM();

  /**
   * Returns a new object of class '<em>IADC</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>IADC</em>'.
   * @generated
   */
  IADC createIADC();

  /**
   * Returns a new object of class '<em>User Defined Subsystem</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>User Defined Subsystem</em>'.
   * @generated
   */
  UserDefinedSubsystem createUserDefinedSubsystem();

  /**
   * Returns a new object of class '<em>Config Subsystem Item</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Config Subsystem Item</em>'.
   * @generated
   */
  ConfigSubsystemItem createConfigSubsystemItem();

  /**
   * Returns a new object of class '<em>User Port</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>User Port</em>'.
   * @generated
   */
  UserPort createUserPort();

  /**
   * Returns a new object of class '<em>Import</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Import</em>'.
   * @generated
   */
  Import createImport();

  /**
   * Returns a new object of class '<em>Imports</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Imports</em>'.
   * @generated
   */
  Imports createImports();

  /**
   * Returns a new object of class '<em>FRQ Subsystem</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>FRQ Subsystem</em>'.
   * @generated
   */
  FRQSubsystem createFRQSubsystem();

  /**
   * Returns the package supported by this factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the package supported by this factory.
   * @generated
   */
  ConfiguratorPackage getConfiguratorPackage();

} //ConfiguratorFactory
