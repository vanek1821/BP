/**
 */
package zf.pios.configurator;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hardware</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.Hardware#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.Hardware#getDriverToECU <em>Driver To ECU</em>}</li>
 *   <li>{@link zf.pios.configurator.Hardware#getTempSensorSubsystem <em>Temp Sensor Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.Hardware#getElectricDiagSubsystem <em>Electric Diag Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.Hardware#getFrequencySubsystem <em>Frequency Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.Hardware#getSpiSubsystem <em>Spi Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.Hardware#getOpwmSubsystem <em>Opwm Subsystem</em>}</li>
 *   <li>{@link zf.pios.configurator.Hardware#getUserDefinedSubsystem <em>User Defined Subsystem</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getHardware()
 * @model
 * @generated
 */
public interface Hardware extends EObject
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getHardware_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Hardware#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Driver To ECU</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Driver To ECU</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Driver To ECU</em>' containment reference.
   * @see #setDriverToECU(DriverToECU)
   * @see zf.pios.configurator.ConfiguratorPackage#getHardware_DriverToECU()
   * @model containment="true"
   * @generated
   */
  DriverToECU getDriverToECU();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Hardware#getDriverToECU <em>Driver To ECU</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Driver To ECU</em>' containment reference.
   * @see #getDriverToECU()
   * @generated
   */
  void setDriverToECU(DriverToECU value);

  /**
   * Returns the value of the '<em><b>Temp Sensor Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Temp Sensor Subsystem</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Temp Sensor Subsystem</em>' containment reference.
   * @see #setTempSensorSubsystem(TempSensorSubsystem)
   * @see zf.pios.configurator.ConfiguratorPackage#getHardware_TempSensorSubsystem()
   * @model containment="true"
   * @generated
   */
  TempSensorSubsystem getTempSensorSubsystem();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Hardware#getTempSensorSubsystem <em>Temp Sensor Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Temp Sensor Subsystem</em>' containment reference.
   * @see #getTempSensorSubsystem()
   * @generated
   */
  void setTempSensorSubsystem(TempSensorSubsystem value);

  /**
   * Returns the value of the '<em><b>Electric Diag Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Electric Diag Subsystem</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Electric Diag Subsystem</em>' containment reference.
   * @see #setElectricDiagSubsystem(ElectricDiagSubsystem)
   * @see zf.pios.configurator.ConfiguratorPackage#getHardware_ElectricDiagSubsystem()
   * @model containment="true"
   * @generated
   */
  ElectricDiagSubsystem getElectricDiagSubsystem();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Hardware#getElectricDiagSubsystem <em>Electric Diag Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Electric Diag Subsystem</em>' containment reference.
   * @see #getElectricDiagSubsystem()
   * @generated
   */
  void setElectricDiagSubsystem(ElectricDiagSubsystem value);

  /**
   * Returns the value of the '<em><b>Frequency Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Frequency Subsystem</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Frequency Subsystem</em>' containment reference.
   * @see #setFrequencySubsystem(FrequencySubsystem)
   * @see zf.pios.configurator.ConfiguratorPackage#getHardware_FrequencySubsystem()
   * @model containment="true"
   * @generated
   */
  FrequencySubsystem getFrequencySubsystem();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Hardware#getFrequencySubsystem <em>Frequency Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Frequency Subsystem</em>' containment reference.
   * @see #getFrequencySubsystem()
   * @generated
   */
  void setFrequencySubsystem(FrequencySubsystem value);

  /**
   * Returns the value of the '<em><b>Spi Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Spi Subsystem</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Spi Subsystem</em>' containment reference.
   * @see #setSpiSubsystem(SPIinputSys)
   * @see zf.pios.configurator.ConfiguratorPackage#getHardware_SpiSubsystem()
   * @model containment="true"
   * @generated
   */
  SPIinputSys getSpiSubsystem();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Hardware#getSpiSubsystem <em>Spi Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Spi Subsystem</em>' containment reference.
   * @see #getSpiSubsystem()
   * @generated
   */
  void setSpiSubsystem(SPIinputSys value);

  /**
   * Returns the value of the '<em><b>Opwm Subsystem</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Opwm Subsystem</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Opwm Subsystem</em>' containment reference.
   * @see #setOpwmSubsystem(OPWMSubsystem)
   * @see zf.pios.configurator.ConfiguratorPackage#getHardware_OpwmSubsystem()
   * @model containment="true"
   * @generated
   */
  OPWMSubsystem getOpwmSubsystem();

  /**
   * Sets the value of the '{@link zf.pios.configurator.Hardware#getOpwmSubsystem <em>Opwm Subsystem</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Opwm Subsystem</em>' containment reference.
   * @see #getOpwmSubsystem()
   * @generated
   */
  void setOpwmSubsystem(OPWMSubsystem value);

  /**
   * Returns the value of the '<em><b>User Defined Subsystem</b></em>' containment reference list.
   * The list contents are of type {@link zf.pios.configurator.UserDefinedSubsystem}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>User Defined Subsystem</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>User Defined Subsystem</em>' containment reference list.
   * @see zf.pios.configurator.ConfiguratorPackage#getHardware_UserDefinedSubsystem()
   * @model containment="true"
   * @generated
   */
  EList<UserDefinedSubsystem> getUserDefinedSubsystem();

} // Hardware
