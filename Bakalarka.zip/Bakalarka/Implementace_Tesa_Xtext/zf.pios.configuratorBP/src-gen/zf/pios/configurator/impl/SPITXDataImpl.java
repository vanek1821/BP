/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.SPITXData;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SPITX Data</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.SPITXDataImpl#getByteOne <em>Byte One</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPITXDataImpl#getByteTwo <em>Byte Two</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPITXDataImpl#getByteThree <em>Byte Three</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SPITXDataImpl#getByteFour <em>Byte Four</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SPITXDataImpl extends MinimalEObjectImpl.Container implements SPITXData
{
  /**
   * The default value of the '{@link #getByteOne() <em>Byte One</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getByteOne()
   * @generated
   * @ordered
   */
  protected static final String BYTE_ONE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getByteOne() <em>Byte One</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getByteOne()
   * @generated
   * @ordered
   */
  protected String byteOne = BYTE_ONE_EDEFAULT;

  /**
   * The default value of the '{@link #getByteTwo() <em>Byte Two</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getByteTwo()
   * @generated
   * @ordered
   */
  protected static final String BYTE_TWO_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getByteTwo() <em>Byte Two</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getByteTwo()
   * @generated
   * @ordered
   */
  protected String byteTwo = BYTE_TWO_EDEFAULT;

  /**
   * The default value of the '{@link #getByteThree() <em>Byte Three</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getByteThree()
   * @generated
   * @ordered
   */
  protected static final String BYTE_THREE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getByteThree() <em>Byte Three</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getByteThree()
   * @generated
   * @ordered
   */
  protected String byteThree = BYTE_THREE_EDEFAULT;

  /**
   * The default value of the '{@link #getByteFour() <em>Byte Four</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getByteFour()
   * @generated
   * @ordered
   */
  protected static final String BYTE_FOUR_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getByteFour() <em>Byte Four</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getByteFour()
   * @generated
   * @ordered
   */
  protected String byteFour = BYTE_FOUR_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SPITXDataImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.SPITX_DATA;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getByteOne()
  {
    return byteOne;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setByteOne(String newByteOne)
  {
    String oldByteOne = byteOne;
    byteOne = newByteOne;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPITX_DATA__BYTE_ONE, oldByteOne, byteOne));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getByteTwo()
  {
    return byteTwo;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setByteTwo(String newByteTwo)
  {
    String oldByteTwo = byteTwo;
    byteTwo = newByteTwo;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPITX_DATA__BYTE_TWO, oldByteTwo, byteTwo));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getByteThree()
  {
    return byteThree;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setByteThree(String newByteThree)
  {
    String oldByteThree = byteThree;
    byteThree = newByteThree;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPITX_DATA__BYTE_THREE, oldByteThree, byteThree));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getByteFour()
  {
    return byteFour;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setByteFour(String newByteFour)
  {
    String oldByteFour = byteFour;
    byteFour = newByteFour;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SPITX_DATA__BYTE_FOUR, oldByteFour, byteFour));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SPITX_DATA__BYTE_ONE:
        return getByteOne();
      case ConfiguratorPackage.SPITX_DATA__BYTE_TWO:
        return getByteTwo();
      case ConfiguratorPackage.SPITX_DATA__BYTE_THREE:
        return getByteThree();
      case ConfiguratorPackage.SPITX_DATA__BYTE_FOUR:
        return getByteFour();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SPITX_DATA__BYTE_ONE:
        setByteOne((String)newValue);
        return;
      case ConfiguratorPackage.SPITX_DATA__BYTE_TWO:
        setByteTwo((String)newValue);
        return;
      case ConfiguratorPackage.SPITX_DATA__BYTE_THREE:
        setByteThree((String)newValue);
        return;
      case ConfiguratorPackage.SPITX_DATA__BYTE_FOUR:
        setByteFour((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SPITX_DATA__BYTE_ONE:
        setByteOne(BYTE_ONE_EDEFAULT);
        return;
      case ConfiguratorPackage.SPITX_DATA__BYTE_TWO:
        setByteTwo(BYTE_TWO_EDEFAULT);
        return;
      case ConfiguratorPackage.SPITX_DATA__BYTE_THREE:
        setByteThree(BYTE_THREE_EDEFAULT);
        return;
      case ConfiguratorPackage.SPITX_DATA__BYTE_FOUR:
        setByteFour(BYTE_FOUR_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SPITX_DATA__BYTE_ONE:
        return BYTE_ONE_EDEFAULT == null ? byteOne != null : !BYTE_ONE_EDEFAULT.equals(byteOne);
      case ConfiguratorPackage.SPITX_DATA__BYTE_TWO:
        return BYTE_TWO_EDEFAULT == null ? byteTwo != null : !BYTE_TWO_EDEFAULT.equals(byteTwo);
      case ConfiguratorPackage.SPITX_DATA__BYTE_THREE:
        return BYTE_THREE_EDEFAULT == null ? byteThree != null : !BYTE_THREE_EDEFAULT.equals(byteThree);
      case ConfiguratorPackage.SPITX_DATA__BYTE_FOUR:
        return BYTE_FOUR_EDEFAULT == null ? byteFour != null : !BYTE_FOUR_EDEFAULT.equals(byteFour);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (byteOne: ");
    result.append(byteOne);
    result.append(", byteTwo: ");
    result.append(byteTwo);
    result.append(", byteThree: ");
    result.append(byteThree);
    result.append(", byteFour: ");
    result.append(byteFour);
    result.append(')');
    return result.toString();
  }

} //SPITXDataImpl
