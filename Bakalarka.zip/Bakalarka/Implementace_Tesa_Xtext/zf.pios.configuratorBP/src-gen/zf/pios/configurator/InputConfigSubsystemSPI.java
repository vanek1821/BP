/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Config Subsystem SPI</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getInputConfigSubsystemSPI()
 * @model
 * @generated
 */
public interface InputConfigSubsystemSPI extends InputDriverType
{
} // InputConfigSubsystemSPI
