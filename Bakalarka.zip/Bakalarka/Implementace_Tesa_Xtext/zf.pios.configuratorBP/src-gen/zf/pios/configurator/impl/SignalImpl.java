/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ASAPMeasurment;
import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.Signal;
import zf.pios.configurator.dataTypeEnumeration;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Signal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.SignalImpl#getDataType <em>Data Type</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SignalImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.SignalImpl#getAsapMeasurment <em>Asap Measurment</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SignalImpl extends MinimalEObjectImpl.Container implements Signal
{
  /**
   * The default value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDataType()
   * @generated
   * @ordered
   */
  protected static final dataTypeEnumeration DATA_TYPE_EDEFAULT = dataTypeEnumeration.FL32;

  /**
   * The cached value of the '{@link #getDataType() <em>Data Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDataType()
   * @generated
   * @ordered
   */
  protected dataTypeEnumeration dataType = DATA_TYPE_EDEFAULT;

  /**
   * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected static final String DESCRIPTION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDescription()
   * @generated
   * @ordered
   */
  protected String description = DESCRIPTION_EDEFAULT;

  /**
   * The cached value of the '{@link #getAsapMeasurment() <em>Asap Measurment</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAsapMeasurment()
   * @generated
   * @ordered
   */
  protected ASAPMeasurment asapMeasurment;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SignalImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.SIGNAL;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public dataTypeEnumeration getDataType()
  {
    return dataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDataType(dataTypeEnumeration newDataType)
  {
    dataTypeEnumeration oldDataType = dataType;
    dataType = newDataType == null ? DATA_TYPE_EDEFAULT : newDataType;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SIGNAL__DATA_TYPE, oldDataType, dataType));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDescription()
  {
    return description;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDescription(String newDescription)
  {
    String oldDescription = description;
    description = newDescription;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SIGNAL__DESCRIPTION, oldDescription, description));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ASAPMeasurment getAsapMeasurment()
  {
    return asapMeasurment;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetAsapMeasurment(ASAPMeasurment newAsapMeasurment, NotificationChain msgs)
  {
    ASAPMeasurment oldAsapMeasurment = asapMeasurment;
    asapMeasurment = newAsapMeasurment;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SIGNAL__ASAP_MEASURMENT, oldAsapMeasurment, newAsapMeasurment);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAsapMeasurment(ASAPMeasurment newAsapMeasurment)
  {
    if (newAsapMeasurment != asapMeasurment)
    {
      NotificationChain msgs = null;
      if (asapMeasurment != null)
        msgs = ((InternalEObject)asapMeasurment).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.SIGNAL__ASAP_MEASURMENT, null, msgs);
      if (newAsapMeasurment != null)
        msgs = ((InternalEObject)newAsapMeasurment).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ConfiguratorPackage.SIGNAL__ASAP_MEASURMENT, null, msgs);
      msgs = basicSetAsapMeasurment(newAsapMeasurment, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.SIGNAL__ASAP_MEASURMENT, newAsapMeasurment, newAsapMeasurment));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNAL__ASAP_MEASURMENT:
        return basicSetAsapMeasurment(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNAL__DATA_TYPE:
        return getDataType();
      case ConfiguratorPackage.SIGNAL__DESCRIPTION:
        return getDescription();
      case ConfiguratorPackage.SIGNAL__ASAP_MEASURMENT:
        return getAsapMeasurment();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNAL__DATA_TYPE:
        setDataType((dataTypeEnumeration)newValue);
        return;
      case ConfiguratorPackage.SIGNAL__DESCRIPTION:
        setDescription((String)newValue);
        return;
      case ConfiguratorPackage.SIGNAL__ASAP_MEASURMENT:
        setAsapMeasurment((ASAPMeasurment)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNAL__DATA_TYPE:
        setDataType(DATA_TYPE_EDEFAULT);
        return;
      case ConfiguratorPackage.SIGNAL__DESCRIPTION:
        setDescription(DESCRIPTION_EDEFAULT);
        return;
      case ConfiguratorPackage.SIGNAL__ASAP_MEASURMENT:
        setAsapMeasurment((ASAPMeasurment)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.SIGNAL__DATA_TYPE:
        return dataType != DATA_TYPE_EDEFAULT;
      case ConfiguratorPackage.SIGNAL__DESCRIPTION:
        return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
      case ConfiguratorPackage.SIGNAL__ASAP_MEASURMENT:
        return asapMeasurment != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (dataType: ");
    result.append(dataType);
    result.append(", description: ");
    result.append(description);
    result.append(')');
    return result.toString();
  }

} //SignalImpl
