/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ASAP Measurment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.ASAPMeasurment#getLowerLimit <em>Lower Limit</em>}</li>
 *   <li>{@link zf.pios.configurator.ASAPMeasurment#getUpperLimit <em>Upper Limit</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getASAPMeasurment()
 * @model
 * @generated
 */
public interface ASAPMeasurment extends EObject
{
  /**
   * Returns the value of the '<em><b>Lower Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Lower Limit</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Lower Limit</em>' attribute.
   * @see #setLowerLimit(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getASAPMeasurment_LowerLimit()
   * @model
   * @generated
   */
  String getLowerLimit();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ASAPMeasurment#getLowerLimit <em>Lower Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Lower Limit</em>' attribute.
   * @see #getLowerLimit()
   * @generated
   */
  void setLowerLimit(String value);

  /**
   * Returns the value of the '<em><b>Upper Limit</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Upper Limit</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Upper Limit</em>' attribute.
   * @see #setUpperLimit(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getASAPMeasurment_UpperLimit()
   * @model
   * @generated
   */
  String getUpperLimit();

  /**
   * Sets the value of the '{@link zf.pios.configurator.ASAPMeasurment#getUpperLimit <em>Upper Limit</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Upper Limit</em>' attribute.
   * @see #getUpperLimit()
   * @generated
   */
  void setUpperLimit(String value);

} // ASAPMeasurment
