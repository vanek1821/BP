/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.InputDatafield;
import zf.pios.configurator.InputSignal;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Signal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.InputSignalImpl#getPowerSupply <em>Power Supply</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.InputSignalImpl#getDatafield <em>Datafield</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InputSignalImpl extends GeneralSignalImpl implements InputSignal
{
  /**
   * The default value of the '{@link #getPowerSupply() <em>Power Supply</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPowerSupply()
   * @generated
   * @ordered
   */
  protected static final String POWER_SUPPLY_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getPowerSupply() <em>Power Supply</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPowerSupply()
   * @generated
   * @ordered
   */
  protected String powerSupply = POWER_SUPPLY_EDEFAULT;

  /**
   * The cached value of the '{@link #getDatafield() <em>Datafield</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDatafield()
   * @generated
   * @ordered
   */
  protected EList<InputDatafield> datafield;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InputSignalImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.INPUT_SIGNAL;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getPowerSupply()
  {
    return powerSupply;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPowerSupply(String newPowerSupply)
  {
    String oldPowerSupply = powerSupply;
    powerSupply = newPowerSupply;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.INPUT_SIGNAL__POWER_SUPPLY, oldPowerSupply, powerSupply));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<InputDatafield> getDatafield()
  {
    if (datafield == null)
    {
      datafield = new EObjectContainmentEList<InputDatafield>(InputDatafield.class, this, ConfiguratorPackage.INPUT_SIGNAL__DATAFIELD);
    }
    return datafield;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SIGNAL__DATAFIELD:
        return ((InternalEList<?>)getDatafield()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SIGNAL__POWER_SUPPLY:
        return getPowerSupply();
      case ConfiguratorPackage.INPUT_SIGNAL__DATAFIELD:
        return getDatafield();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SIGNAL__POWER_SUPPLY:
        setPowerSupply((String)newValue);
        return;
      case ConfiguratorPackage.INPUT_SIGNAL__DATAFIELD:
        getDatafield().clear();
        getDatafield().addAll((Collection<? extends InputDatafield>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SIGNAL__POWER_SUPPLY:
        setPowerSupply(POWER_SUPPLY_EDEFAULT);
        return;
      case ConfiguratorPackage.INPUT_SIGNAL__DATAFIELD:
        getDatafield().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.INPUT_SIGNAL__POWER_SUPPLY:
        return POWER_SUPPLY_EDEFAULT == null ? powerSupply != null : !POWER_SUPPLY_EDEFAULT.equals(powerSupply);
      case ConfiguratorPackage.INPUT_SIGNAL__DATAFIELD:
        return datafield != null && !datafield.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (powerSupply: ");
    result.append(powerSupply);
    result.append(')');
    return result.toString();
  }

} //InputSignalImpl
