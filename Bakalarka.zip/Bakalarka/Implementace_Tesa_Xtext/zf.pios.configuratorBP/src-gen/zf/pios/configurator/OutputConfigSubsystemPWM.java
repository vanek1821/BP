/**
 */
package zf.pios.configurator;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Config Subsystem PWM</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getOutputConfigSubsystemPWM()
 * @model
 * @generated
 */
public interface OutputConfigSubsystemPWM extends OutputDriverType
{
} // OutputConfigSubsystemPWM
