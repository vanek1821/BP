/**
 */
package zf.pios.configurator.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.ElDiag;
import zf.pios.configurator.ElectricDiagSubsystem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Electric Diag Subsystem</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.ElectricDiagSubsystemImpl#getElDiag <em>El Diag</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElectricDiagSubsystemImpl extends MinimalEObjectImpl.Container implements ElectricDiagSubsystem
{
  /**
   * The cached value of the '{@link #getElDiag() <em>El Diag</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getElDiag()
   * @generated
   * @ordered
   */
  protected EList<ElDiag> elDiag;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ElectricDiagSubsystemImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.ELECTRIC_DIAG_SUBSYSTEM;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<ElDiag> getElDiag()
  {
    if (elDiag == null)
    {
      elDiag = new EObjectContainmentEList<ElDiag>(ElDiag.class, this, ConfiguratorPackage.ELECTRIC_DIAG_SUBSYSTEM__EL_DIAG);
    }
    return elDiag;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.ELECTRIC_DIAG_SUBSYSTEM__EL_DIAG:
        return ((InternalEList<?>)getElDiag()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.ELECTRIC_DIAG_SUBSYSTEM__EL_DIAG:
        return getElDiag();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.ELECTRIC_DIAG_SUBSYSTEM__EL_DIAG:
        getElDiag().clear();
        getElDiag().addAll((Collection<? extends ElDiag>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.ELECTRIC_DIAG_SUBSYSTEM__EL_DIAG:
        getElDiag().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.ELECTRIC_DIAG_SUBSYSTEM__EL_DIAG:
        return elDiag != null && !elDiag.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //ElectricDiagSubsystemImpl
