/**
 */
package zf.pios.configurator;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SPI</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.SPI#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.SPI#getDriverIndex <em>Driver Index</em>}</li>
 *   <li>{@link zf.pios.configurator.SPI#getDataStorageMode <em>Data Storage Mode</em>}</li>
 *   <li>{@link zf.pios.configurator.SPI#getCommand <em>Command</em>}</li>
 *   <li>{@link zf.pios.configurator.SPI#getDataLength <em>Data Length</em>}</li>
 *   <li>{@link zf.pios.configurator.SPI#getSpitxData <em>Spitx Data</em>}</li>
 *   <li>{@link zf.pios.configurator.SPI#getModule <em>Module</em>}</li>
 *   <li>{@link zf.pios.configurator.SPI#getDescription <em>Description</em>}</li>
 * </ul>
 *
 * @see zf.pios.configurator.ConfiguratorPackage#getSPI()
 * @model
 * @generated
 */
public interface SPI extends EObject
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPI_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPI#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Driver Index</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Driver Index</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Driver Index</em>' attribute.
   * @see #setDriverIndex(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPI_DriverIndex()
   * @model
   * @generated
   */
  String getDriverIndex();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPI#getDriverIndex <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Driver Index</em>' attribute.
   * @see #getDriverIndex()
   * @generated
   */
  void setDriverIndex(String value);

  /**
   * Returns the value of the '<em><b>Data Storage Mode</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Data Storage Mode</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Data Storage Mode</em>' attribute.
   * @see #setDataStorageMode(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPI_DataStorageMode()
   * @model
   * @generated
   */
  String getDataStorageMode();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPI#getDataStorageMode <em>Data Storage Mode</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Data Storage Mode</em>' attribute.
   * @see #getDataStorageMode()
   * @generated
   */
  void setDataStorageMode(String value);

  /**
   * Returns the value of the '<em><b>Command</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Command</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Command</em>' attribute.
   * @see #setCommand(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPI_Command()
   * @model
   * @generated
   */
  String getCommand();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPI#getCommand <em>Command</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Command</em>' attribute.
   * @see #getCommand()
   * @generated
   */
  void setCommand(String value);

  /**
   * Returns the value of the '<em><b>Data Length</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Data Length</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Data Length</em>' attribute.
   * @see #setDataLength(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPI_DataLength()
   * @model
   * @generated
   */
  String getDataLength();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPI#getDataLength <em>Data Length</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Data Length</em>' attribute.
   * @see #getDataLength()
   * @generated
   */
  void setDataLength(String value);

  /**
   * Returns the value of the '<em><b>Spitx Data</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Spitx Data</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Spitx Data</em>' containment reference.
   * @see #setSpitxData(SPITXData)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPI_SpitxData()
   * @model containment="true"
   * @generated
   */
  SPITXData getSpitxData();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPI#getSpitxData <em>Spitx Data</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Spitx Data</em>' containment reference.
   * @see #getSpitxData()
   * @generated
   */
  void setSpitxData(SPITXData value);

  /**
   * Returns the value of the '<em><b>Module</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Module</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Module</em>' attribute.
   * @see #setModule(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPI_Module()
   * @model
   * @generated
   */
  String getModule();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPI#getModule <em>Module</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Module</em>' attribute.
   * @see #getModule()
   * @generated
   */
  void setModule(String value);

  /**
   * Returns the value of the '<em><b>Description</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Description</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Description</em>' attribute.
   * @see #setDescription(String)
   * @see zf.pios.configurator.ConfiguratorPackage#getSPI_Description()
   * @model
   * @generated
   */
  String getDescription();

  /**
   * Sets the value of the '{@link zf.pios.configurator.SPI#getDescription <em>Description</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Description</em>' attribute.
   * @see #getDescription()
   * @generated
   */
  void setDescription(String value);

} // SPI
