/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutputConfigSubsystemNull;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Config Subsystem Null</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class OutputConfigSubsystemNullImpl extends OutputDriverTypeImpl implements OutputConfigSubsystemNull
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutputConfigSubsystemNullImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUTPUT_CONFIG_SUBSYSTEM_NULL;
  }

} //OutputConfigSubsystemNullImpl
