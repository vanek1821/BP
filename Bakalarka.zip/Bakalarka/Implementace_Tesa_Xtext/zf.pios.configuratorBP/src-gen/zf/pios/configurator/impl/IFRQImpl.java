/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.IFRQ;
import zf.pios.configurator.IFRQSensor;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>IFRQ</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link zf.pios.configurator.impl.IFRQImpl#getName <em>Name</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IFRQImpl#getDriverIndex <em>Driver Index</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IFRQImpl#getSensorIndex <em>Sensor Index</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IFRQImpl#getUpdateTime <em>Update Time</em>}</li>
 *   <li>{@link zf.pios.configurator.impl.IFRQImpl#getActive <em>Active</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IFRQImpl extends MinimalEObjectImpl.Container implements IFRQ
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected static final String DRIVER_INDEX_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDriverIndex() <em>Driver Index</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDriverIndex()
   * @generated
   * @ordered
   */
  protected String driverIndex = DRIVER_INDEX_EDEFAULT;

  /**
   * The cached value of the '{@link #getSensorIndex() <em>Sensor Index</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSensorIndex()
   * @generated
   * @ordered
   */
  protected IFRQSensor sensorIndex;

  /**
   * The default value of the '{@link #getUpdateTime() <em>Update Time</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUpdateTime()
   * @generated
   * @ordered
   */
  protected static final String UPDATE_TIME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getUpdateTime() <em>Update Time</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUpdateTime()
   * @generated
   * @ordered
   */
  protected String updateTime = UPDATE_TIME_EDEFAULT;

  /**
   * The default value of the '{@link #getActive() <em>Active</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getActive()
   * @generated
   * @ordered
   */
  protected static final String ACTIVE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getActive() <em>Active</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getActive()
   * @generated
   * @ordered
   */
  protected String active = ACTIVE_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected IFRQImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.IFRQ;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IFRQ__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getDriverIndex()
  {
    return driverIndex;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDriverIndex(String newDriverIndex)
  {
    String oldDriverIndex = driverIndex;
    driverIndex = newDriverIndex;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IFRQ__DRIVER_INDEX, oldDriverIndex, driverIndex));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IFRQSensor getSensorIndex()
  {
    if (sensorIndex != null && sensorIndex.eIsProxy())
    {
      InternalEObject oldSensorIndex = (InternalEObject)sensorIndex;
      sensorIndex = (IFRQSensor)eResolveProxy(oldSensorIndex);
      if (sensorIndex != oldSensorIndex)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ConfiguratorPackage.IFRQ__SENSOR_INDEX, oldSensorIndex, sensorIndex));
      }
    }
    return sensorIndex;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IFRQSensor basicGetSensorIndex()
  {
    return sensorIndex;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSensorIndex(IFRQSensor newSensorIndex)
  {
    IFRQSensor oldSensorIndex = sensorIndex;
    sensorIndex = newSensorIndex;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IFRQ__SENSOR_INDEX, oldSensorIndex, sensorIndex));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getUpdateTime()
  {
    return updateTime;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUpdateTime(String newUpdateTime)
  {
    String oldUpdateTime = updateTime;
    updateTime = newUpdateTime;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IFRQ__UPDATE_TIME, oldUpdateTime, updateTime));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getActive()
  {
    return active;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setActive(String newActive)
  {
    String oldActive = active;
    active = newActive;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ConfiguratorPackage.IFRQ__ACTIVE, oldActive, active));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IFRQ__NAME:
        return getName();
      case ConfiguratorPackage.IFRQ__DRIVER_INDEX:
        return getDriverIndex();
      case ConfiguratorPackage.IFRQ__SENSOR_INDEX:
        if (resolve) return getSensorIndex();
        return basicGetSensorIndex();
      case ConfiguratorPackage.IFRQ__UPDATE_TIME:
        return getUpdateTime();
      case ConfiguratorPackage.IFRQ__ACTIVE:
        return getActive();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IFRQ__NAME:
        setName((String)newValue);
        return;
      case ConfiguratorPackage.IFRQ__DRIVER_INDEX:
        setDriverIndex((String)newValue);
        return;
      case ConfiguratorPackage.IFRQ__SENSOR_INDEX:
        setSensorIndex((IFRQSensor)newValue);
        return;
      case ConfiguratorPackage.IFRQ__UPDATE_TIME:
        setUpdateTime((String)newValue);
        return;
      case ConfiguratorPackage.IFRQ__ACTIVE:
        setActive((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IFRQ__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ConfiguratorPackage.IFRQ__DRIVER_INDEX:
        setDriverIndex(DRIVER_INDEX_EDEFAULT);
        return;
      case ConfiguratorPackage.IFRQ__SENSOR_INDEX:
        setSensorIndex((IFRQSensor)null);
        return;
      case ConfiguratorPackage.IFRQ__UPDATE_TIME:
        setUpdateTime(UPDATE_TIME_EDEFAULT);
        return;
      case ConfiguratorPackage.IFRQ__ACTIVE:
        setActive(ACTIVE_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case ConfiguratorPackage.IFRQ__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ConfiguratorPackage.IFRQ__DRIVER_INDEX:
        return DRIVER_INDEX_EDEFAULT == null ? driverIndex != null : !DRIVER_INDEX_EDEFAULT.equals(driverIndex);
      case ConfiguratorPackage.IFRQ__SENSOR_INDEX:
        return sensorIndex != null;
      case ConfiguratorPackage.IFRQ__UPDATE_TIME:
        return UPDATE_TIME_EDEFAULT == null ? updateTime != null : !UPDATE_TIME_EDEFAULT.equals(updateTime);
      case ConfiguratorPackage.IFRQ__ACTIVE:
        return ACTIVE_EDEFAULT == null ? active != null : !ACTIVE_EDEFAULT.equals(active);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", driverIndex: ");
    result.append(driverIndex);
    result.append(", updateTime: ");
    result.append(updateTime);
    result.append(", active: ");
    result.append(active);
    result.append(')');
    return result.toString();
  }

} //IFRQImpl
