/**
 */
package zf.pios.configurator.impl;

import org.eclipse.emf.ecore.EClass;

import zf.pios.configurator.ConfiguratorPackage;
import zf.pios.configurator.OutputConfigSubsystemPWM;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output Config Subsystem PWM</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class OutputConfigSubsystemPWMImpl extends OutputDriverTypeImpl implements OutputConfigSubsystemPWM
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected OutputConfigSubsystemPWMImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ConfiguratorPackage.Literals.OUTPUT_CONFIG_SUBSYSTEM_PWM;
  }

} //OutputConfigSubsystemPWMImpl
