package zf.pios.parser.antlr.internal; 

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import zf.pios.services.ConfiguratorGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalConfiguratorParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_UINT", "RULE_HEX", "RULE_NATIVE_FLOAT", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Configuration'", "'{'", "'Version_1.26'", "'mainFileForMerging'", "'}'", "'System'", "'Signals'", "'InputSignal'", "'PowerSupply'", "'OutputSignal'", "'TemperaturePullupResistorSwitch'", "'DatafieldVariant'", "'LowerLimit'", "'UpperLimit'", "'InitValue'", "'SubSystem'", "'PortName'", "'Variants'", "'Default'", "'Variant'", "'DataType'", "'Description'", "'ASAPMeasurement'", "'Hardware'", "'ConfigSubsystem'", "'Input'", "'MaximalNumberInputSubsystems'", "'Output'", "'MaximalNumberOutputSubsystems'", "'NameINull'", "'SortingIndex'", "'NameONull'", "'NameIADC'", "'NameITemperature'", "'NameElDiag'", "'TemperatureSensor'", "'NameSPI'", "'NameIDig'", "'NameIFrq'", "'NamePWM'", "'NameODig'", "'NameIUser'", "'NameOUser'", "'DriverToECU'", "'TemperatureSensorSubsystem'", "'InputAnalogDrivers'", "'InputDigitalDrivers'", "'OutputDigitalDrivers'", "'Port'", "'DriverIndex'", "'ControllerPinName'", "'InputDigDriversTable'", "'OutputDigDriversTable'", "'Null'", "'ElDiagSubsystem'", "'Enable'", "'DiagnosisEnable'", "'PWMDiagnosis'", "'PowerSupplySignal'", "'FrequencySubsystem'", "'Sensor'", "'UpdateTime'", "'Active'", "'InitialWaitingTime'", "'DirChangeMinPeriods'", "'DirectionChangeDebounceTime'", "'SPIinput'", "'DataStorageMode'", "'SPIcommand'", "'DataLength'", "'Module'", "'SPITXData'", "'Byte1'", "'Byte2'", "'Byte3'", "'Byte4'", "'OPWM'", "'Period'", "'EnableDiagnosisPowerSupplyOff'", "'ElDiagInstanceIdx'", "'User'", "'.'", "'use'", "'.*'", "'fl32'", "'si8'", "'si16'", "'si32'", "'ui8'", "'ui16'", "'ADC_CHANNEL_DISABLED'", "'ADC_CHANNEL_ENABLED'", "'False'", "'True'"
    };
    public static final int RULE_HEX=7;
    public static final int T__50=50;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int RULE_INT=9;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=10;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__102=102;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int T__90=90;
    public static final int RULE_NATIVE_FLOAT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int RULE_UINT=6;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__99=99;
    public static final int T__14=14;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=11;
    public static final int T__77=77;
    public static final int T__78=78;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__75=75;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int RULE_WS=12;
    public static final int RULE_ANY_OTHER=13;
    public static final int T__88=88;
    public static final int T__89=89;
    public static final int T__107=107;
    public static final int T__84=84;
    public static final int T__104=104;
    public static final int T__85=85;
    public static final int T__103=103;
    public static final int T__86=86;
    public static final int T__106=106;
    public static final int T__87=87;
    public static final int T__105=105;

    // delegates
    // delegators


        public InternalConfiguratorParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalConfiguratorParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalConfiguratorParser.tokenNames; }
    public String getGrammarFileName() { return "InternalConfigurator.g"; }



     	private ConfiguratorGrammarAccess grammarAccess;
     	
        public InternalConfiguratorParser(TokenStream input, ConfiguratorGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }
        
        @Override
        protected String getFirstRuleName() {
        	return "Configuration";	
       	}
       	
       	@Override
       	protected ConfiguratorGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}



    // $ANTLR start "entryRuleConfiguration"
    // InternalConfigurator.g:68:1: entryRuleConfiguration returns [EObject current=null] : iv_ruleConfiguration= ruleConfiguration EOF ;
    public final EObject entryRuleConfiguration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConfiguration = null;


        try {
            // InternalConfigurator.g:69:2: (iv_ruleConfiguration= ruleConfiguration EOF )
            // InternalConfigurator.g:70:2: iv_ruleConfiguration= ruleConfiguration EOF
            {
             newCompositeNode(grammarAccess.getConfigurationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConfiguration=ruleConfiguration();

            state._fsp--;

             current =iv_ruleConfiguration; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConfiguration"


    // $ANTLR start "ruleConfiguration"
    // InternalConfigurator.g:77:1: ruleConfiguration returns [EObject current=null] : (otherlv_0= 'Configuration' ( (lv_configurationName_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_version_3_0= 'Version_1.26' ) ) ( (lv_mainMergeFile_4_0= 'mainFileForMerging' ) )? ( (lv_imports_5_0= ruleImports ) )* ( (lv_variants_6_0= ruleVariants ) )? ( (lv_system_7_0= ruleSystem ) )? ( (lv_hardware_8_0= ruleHardware ) )? ( (lv_signals_9_0= ruleSignals ) )? otherlv_10= '}' ) ;
    public final EObject ruleConfiguration() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_configurationName_1_0=null;
        Token otherlv_2=null;
        Token lv_version_3_0=null;
        Token lv_mainMergeFile_4_0=null;
        Token otherlv_10=null;
        EObject lv_imports_5_0 = null;

        EObject lv_variants_6_0 = null;

        EObject lv_system_7_0 = null;

        EObject lv_hardware_8_0 = null;

        EObject lv_signals_9_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:80:28: ( (otherlv_0= 'Configuration' ( (lv_configurationName_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_version_3_0= 'Version_1.26' ) ) ( (lv_mainMergeFile_4_0= 'mainFileForMerging' ) )? ( (lv_imports_5_0= ruleImports ) )* ( (lv_variants_6_0= ruleVariants ) )? ( (lv_system_7_0= ruleSystem ) )? ( (lv_hardware_8_0= ruleHardware ) )? ( (lv_signals_9_0= ruleSignals ) )? otherlv_10= '}' ) )
            // InternalConfigurator.g:81:1: (otherlv_0= 'Configuration' ( (lv_configurationName_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_version_3_0= 'Version_1.26' ) ) ( (lv_mainMergeFile_4_0= 'mainFileForMerging' ) )? ( (lv_imports_5_0= ruleImports ) )* ( (lv_variants_6_0= ruleVariants ) )? ( (lv_system_7_0= ruleSystem ) )? ( (lv_hardware_8_0= ruleHardware ) )? ( (lv_signals_9_0= ruleSignals ) )? otherlv_10= '}' )
            {
            // InternalConfigurator.g:81:1: (otherlv_0= 'Configuration' ( (lv_configurationName_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_version_3_0= 'Version_1.26' ) ) ( (lv_mainMergeFile_4_0= 'mainFileForMerging' ) )? ( (lv_imports_5_0= ruleImports ) )* ( (lv_variants_6_0= ruleVariants ) )? ( (lv_system_7_0= ruleSystem ) )? ( (lv_hardware_8_0= ruleHardware ) )? ( (lv_signals_9_0= ruleSignals ) )? otherlv_10= '}' )
            // InternalConfigurator.g:81:3: otherlv_0= 'Configuration' ( (lv_configurationName_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_version_3_0= 'Version_1.26' ) ) ( (lv_mainMergeFile_4_0= 'mainFileForMerging' ) )? ( (lv_imports_5_0= ruleImports ) )* ( (lv_variants_6_0= ruleVariants ) )? ( (lv_system_7_0= ruleSystem ) )? ( (lv_hardware_8_0= ruleHardware ) )? ( (lv_signals_9_0= ruleSignals ) )? otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,14,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getConfigurationAccess().getConfigurationKeyword_0());
                
            // InternalConfigurator.g:85:1: ( (lv_configurationName_1_0= RULE_ID ) )
            // InternalConfigurator.g:86:1: (lv_configurationName_1_0= RULE_ID )
            {
            // InternalConfigurator.g:86:1: (lv_configurationName_1_0= RULE_ID )
            // InternalConfigurator.g:87:3: lv_configurationName_1_0= RULE_ID
            {
            lv_configurationName_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_configurationName_1_0, grammarAccess.getConfigurationAccess().getConfigurationNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getConfigurationRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"configurationName",
                    		lv_configurationName_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_5); 

                	newLeafNode(otherlv_2, grammarAccess.getConfigurationAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:107:1: ( (lv_version_3_0= 'Version_1.26' ) )
            // InternalConfigurator.g:108:1: (lv_version_3_0= 'Version_1.26' )
            {
            // InternalConfigurator.g:108:1: (lv_version_3_0= 'Version_1.26' )
            // InternalConfigurator.g:109:3: lv_version_3_0= 'Version_1.26'
            {
            lv_version_3_0=(Token)match(input,16,FOLLOW_6); 

                    newLeafNode(lv_version_3_0, grammarAccess.getConfigurationAccess().getVersionVersion_126Keyword_3_0());
                

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getConfigurationRule());
            	        }
                   		setWithLastConsumed(current, "version", lv_version_3_0, "Version_1.26");
            	    

            }


            }

            // InternalConfigurator.g:122:2: ( (lv_mainMergeFile_4_0= 'mainFileForMerging' ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==17) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalConfigurator.g:123:1: (lv_mainMergeFile_4_0= 'mainFileForMerging' )
                    {
                    // InternalConfigurator.g:123:1: (lv_mainMergeFile_4_0= 'mainFileForMerging' )
                    // InternalConfigurator.g:124:3: lv_mainMergeFile_4_0= 'mainFileForMerging'
                    {
                    lv_mainMergeFile_4_0=(Token)match(input,17,FOLLOW_7); 

                            newLeafNode(lv_mainMergeFile_4_0, grammarAccess.getConfigurationAccess().getMainMergeFileMainFileForMergingKeyword_4_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getConfigurationRule());
                    	        }
                           		setWithLastConsumed(current, "mainMergeFile", lv_mainMergeFile_4_0, "mainFileForMerging");
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:137:3: ( (lv_imports_5_0= ruleImports ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==96) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalConfigurator.g:138:1: (lv_imports_5_0= ruleImports )
            	    {
            	    // InternalConfigurator.g:138:1: (lv_imports_5_0= ruleImports )
            	    // InternalConfigurator.g:139:3: lv_imports_5_0= ruleImports
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getConfigurationAccess().getImportsImportsParserRuleCall_5_0()); 
            	    	    
            	    pushFollow(FOLLOW_7);
            	    lv_imports_5_0=ruleImports();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getConfigurationRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"imports",
            	            		lv_imports_5_0, 
            	            		"zf.pios.Configurator.Imports");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalConfigurator.g:155:3: ( (lv_variants_6_0= ruleVariants ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==31) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalConfigurator.g:156:1: (lv_variants_6_0= ruleVariants )
                    {
                    // InternalConfigurator.g:156:1: (lv_variants_6_0= ruleVariants )
                    // InternalConfigurator.g:157:3: lv_variants_6_0= ruleVariants
                    {
                     
                    	        newCompositeNode(grammarAccess.getConfigurationAccess().getVariantsVariantsParserRuleCall_6_0()); 
                    	    
                    pushFollow(FOLLOW_8);
                    lv_variants_6_0=ruleVariants();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getConfigurationRule());
                    	        }
                           		set(
                           			current, 
                           			"variants",
                            		lv_variants_6_0, 
                            		"zf.pios.Configurator.Variants");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:173:3: ( (lv_system_7_0= ruleSystem ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==19) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalConfigurator.g:174:1: (lv_system_7_0= ruleSystem )
                    {
                    // InternalConfigurator.g:174:1: (lv_system_7_0= ruleSystem )
                    // InternalConfigurator.g:175:3: lv_system_7_0= ruleSystem
                    {
                     
                    	        newCompositeNode(grammarAccess.getConfigurationAccess().getSystemSystemParserRuleCall_7_0()); 
                    	    
                    pushFollow(FOLLOW_9);
                    lv_system_7_0=ruleSystem();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getConfigurationRule());
                    	        }
                           		set(
                           			current, 
                           			"system",
                            		lv_system_7_0, 
                            		"zf.pios.Configurator.System");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:191:3: ( (lv_hardware_8_0= ruleHardware ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==37) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalConfigurator.g:192:1: (lv_hardware_8_0= ruleHardware )
                    {
                    // InternalConfigurator.g:192:1: (lv_hardware_8_0= ruleHardware )
                    // InternalConfigurator.g:193:3: lv_hardware_8_0= ruleHardware
                    {
                     
                    	        newCompositeNode(grammarAccess.getConfigurationAccess().getHardwareHardwareParserRuleCall_8_0()); 
                    	    
                    pushFollow(FOLLOW_10);
                    lv_hardware_8_0=ruleHardware();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getConfigurationRule());
                    	        }
                           		set(
                           			current, 
                           			"hardware",
                            		lv_hardware_8_0, 
                            		"zf.pios.Configurator.Hardware");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:209:3: ( (lv_signals_9_0= ruleSignals ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==20) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalConfigurator.g:210:1: (lv_signals_9_0= ruleSignals )
                    {
                    // InternalConfigurator.g:210:1: (lv_signals_9_0= ruleSignals )
                    // InternalConfigurator.g:211:3: lv_signals_9_0= ruleSignals
                    {
                     
                    	        newCompositeNode(grammarAccess.getConfigurationAccess().getSignalsSignalsParserRuleCall_9_0()); 
                    	    
                    pushFollow(FOLLOW_11);
                    lv_signals_9_0=ruleSignals();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getConfigurationRule());
                    	        }
                           		set(
                           			current, 
                           			"signals",
                            		lv_signals_9_0, 
                            		"zf.pios.Configurator.Signals");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            otherlv_10=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_10, grammarAccess.getConfigurationAccess().getRightCurlyBracketKeyword_10());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConfiguration"


    // $ANTLR start "entryRuleSystem"
    // InternalConfigurator.g:239:1: entryRuleSystem returns [EObject current=null] : iv_ruleSystem= ruleSystem EOF ;
    public final EObject entryRuleSystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSystem = null;


        try {
            // InternalConfigurator.g:240:2: (iv_ruleSystem= ruleSystem EOF )
            // InternalConfigurator.g:241:2: iv_ruleSystem= ruleSystem EOF
            {
             newCompositeNode(grammarAccess.getSystemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSystem=ruleSystem();

            state._fsp--;

             current =iv_ruleSystem; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSystem"


    // $ANTLR start "ruleSystem"
    // InternalConfigurator.g:248:1: ruleSystem returns [EObject current=null] : (otherlv_0= 'System' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_configSubsystem_3_0= ruleConfigSubsystem ) ) otherlv_4= '}' ) ;
    public final EObject ruleSystem() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_configSubsystem_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:251:28: ( (otherlv_0= 'System' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_configSubsystem_3_0= ruleConfigSubsystem ) ) otherlv_4= '}' ) )
            // InternalConfigurator.g:252:1: (otherlv_0= 'System' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_configSubsystem_3_0= ruleConfigSubsystem ) ) otherlv_4= '}' )
            {
            // InternalConfigurator.g:252:1: (otherlv_0= 'System' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_configSubsystem_3_0= ruleConfigSubsystem ) ) otherlv_4= '}' )
            // InternalConfigurator.g:252:3: otherlv_0= 'System' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_configSubsystem_3_0= ruleConfigSubsystem ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,19,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getSystemAccess().getSystemKeyword_0());
                
            // InternalConfigurator.g:256:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:257:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:257:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:258:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getSystemAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSystemRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_12); 

                	newLeafNode(otherlv_2, grammarAccess.getSystemAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:278:1: ( (lv_configSubsystem_3_0= ruleConfigSubsystem ) )
            // InternalConfigurator.g:279:1: (lv_configSubsystem_3_0= ruleConfigSubsystem )
            {
            // InternalConfigurator.g:279:1: (lv_configSubsystem_3_0= ruleConfigSubsystem )
            // InternalConfigurator.g:280:3: lv_configSubsystem_3_0= ruleConfigSubsystem
            {
             
            	        newCompositeNode(grammarAccess.getSystemAccess().getConfigSubsystemConfigSubsystemParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_configSubsystem_3_0=ruleConfigSubsystem();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getSystemRule());
            	        }
                   		set(
                   			current, 
                   			"configSubsystem",
                    		lv_configSubsystem_3_0, 
                    		"zf.pios.Configurator.ConfigSubsystem");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getSystemAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSystem"


    // $ANTLR start "entryRuleSignals"
    // InternalConfigurator.g:308:1: entryRuleSignals returns [EObject current=null] : iv_ruleSignals= ruleSignals EOF ;
    public final EObject entryRuleSignals() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSignals = null;


        try {
            // InternalConfigurator.g:309:2: (iv_ruleSignals= ruleSignals EOF )
            // InternalConfigurator.g:310:2: iv_ruleSignals= ruleSignals EOF
            {
             newCompositeNode(grammarAccess.getSignalsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSignals=ruleSignals();

            state._fsp--;

             current =iv_ruleSignals; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSignals"


    // $ANTLR start "ruleSignals"
    // InternalConfigurator.g:317:1: ruleSignals returns [EObject current=null] : ( () otherlv_1= 'Signals' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_piosSignals_4_0= ruleGeneralSignals ) )? otherlv_5= '}' ) ;
    public final EObject ruleSignals() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_piosSignals_4_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:320:28: ( ( () otherlv_1= 'Signals' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_piosSignals_4_0= ruleGeneralSignals ) )? otherlv_5= '}' ) )
            // InternalConfigurator.g:321:1: ( () otherlv_1= 'Signals' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_piosSignals_4_0= ruleGeneralSignals ) )? otherlv_5= '}' )
            {
            // InternalConfigurator.g:321:1: ( () otherlv_1= 'Signals' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_piosSignals_4_0= ruleGeneralSignals ) )? otherlv_5= '}' )
            // InternalConfigurator.g:321:2: () otherlv_1= 'Signals' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_piosSignals_4_0= ruleGeneralSignals ) )? otherlv_5= '}'
            {
            // InternalConfigurator.g:321:2: ()
            // InternalConfigurator.g:322:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getSignalsAccess().getSignalsAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,20,FOLLOW_3); 

                	newLeafNode(otherlv_1, grammarAccess.getSignalsAccess().getSignalsKeyword_1());
                
            // InternalConfigurator.g:331:1: ( (lv_name_2_0= RULE_ID ) )
            // InternalConfigurator.g:332:1: (lv_name_2_0= RULE_ID )
            {
            // InternalConfigurator.g:332:1: (lv_name_2_0= RULE_ID )
            // InternalConfigurator.g:333:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_2_0, grammarAccess.getSignalsAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSignalsRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_13); 

                	newLeafNode(otherlv_3, grammarAccess.getSignalsAccess().getLeftCurlyBracketKeyword_3());
                
            // InternalConfigurator.g:353:1: ( (lv_piosSignals_4_0= ruleGeneralSignals ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==21||LA7_0==23) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalConfigurator.g:354:1: (lv_piosSignals_4_0= ruleGeneralSignals )
                    {
                    // InternalConfigurator.g:354:1: (lv_piosSignals_4_0= ruleGeneralSignals )
                    // InternalConfigurator.g:355:3: lv_piosSignals_4_0= ruleGeneralSignals
                    {
                     
                    	        newCompositeNode(grammarAccess.getSignalsAccess().getPiosSignalsGeneralSignalsParserRuleCall_4_0()); 
                    	    
                    pushFollow(FOLLOW_11);
                    lv_piosSignals_4_0=ruleGeneralSignals();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getSignalsRule());
                    	        }
                           		set(
                           			current, 
                           			"piosSignals",
                            		lv_piosSignals_4_0, 
                            		"zf.pios.Configurator.GeneralSignals");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getSignalsAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSignals"


    // $ANTLR start "entryRuleGeneralSignals"
    // InternalConfigurator.g:383:1: entryRuleGeneralSignals returns [EObject current=null] : iv_ruleGeneralSignals= ruleGeneralSignals EOF ;
    public final EObject entryRuleGeneralSignals() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGeneralSignals = null;


        try {
            // InternalConfigurator.g:384:2: (iv_ruleGeneralSignals= ruleGeneralSignals EOF )
            // InternalConfigurator.g:385:2: iv_ruleGeneralSignals= ruleGeneralSignals EOF
            {
             newCompositeNode(grammarAccess.getGeneralSignalsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGeneralSignals=ruleGeneralSignals();

            state._fsp--;

             current =iv_ruleGeneralSignals; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGeneralSignals"


    // $ANTLR start "ruleGeneralSignals"
    // InternalConfigurator.g:392:1: ruleGeneralSignals returns [EObject current=null] : ( () ( (lv_generalSignal_1_0= ruleGeneralSignal ) )+ ) ;
    public final EObject ruleGeneralSignals() throws RecognitionException {
        EObject current = null;

        EObject lv_generalSignal_1_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:395:28: ( ( () ( (lv_generalSignal_1_0= ruleGeneralSignal ) )+ ) )
            // InternalConfigurator.g:396:1: ( () ( (lv_generalSignal_1_0= ruleGeneralSignal ) )+ )
            {
            // InternalConfigurator.g:396:1: ( () ( (lv_generalSignal_1_0= ruleGeneralSignal ) )+ )
            // InternalConfigurator.g:396:2: () ( (lv_generalSignal_1_0= ruleGeneralSignal ) )+
            {
            // InternalConfigurator.g:396:2: ()
            // InternalConfigurator.g:397:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getGeneralSignalsAccess().getGeneralSignalsAction_0(),
                        current);
                

            }

            // InternalConfigurator.g:402:2: ( (lv_generalSignal_1_0= ruleGeneralSignal ) )+
            int cnt8=0;
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==21||LA8_0==23) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalConfigurator.g:403:1: (lv_generalSignal_1_0= ruleGeneralSignal )
            	    {
            	    // InternalConfigurator.g:403:1: (lv_generalSignal_1_0= ruleGeneralSignal )
            	    // InternalConfigurator.g:404:3: lv_generalSignal_1_0= ruleGeneralSignal
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getGeneralSignalsAccess().getGeneralSignalGeneralSignalParserRuleCall_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_14);
            	    lv_generalSignal_1_0=ruleGeneralSignal();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getGeneralSignalsRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"generalSignal",
            	            		lv_generalSignal_1_0, 
            	            		"zf.pios.Configurator.GeneralSignal");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt8 >= 1 ) break loop8;
                        EarlyExitException eee =
                            new EarlyExitException(8, input);
                        throw eee;
                }
                cnt8++;
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGeneralSignals"


    // $ANTLR start "entryRuleGeneralSignal"
    // InternalConfigurator.g:428:1: entryRuleGeneralSignal returns [EObject current=null] : iv_ruleGeneralSignal= ruleGeneralSignal EOF ;
    public final EObject entryRuleGeneralSignal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGeneralSignal = null;


        try {
            // InternalConfigurator.g:429:2: (iv_ruleGeneralSignal= ruleGeneralSignal EOF )
            // InternalConfigurator.g:430:2: iv_ruleGeneralSignal= ruleGeneralSignal EOF
            {
             newCompositeNode(grammarAccess.getGeneralSignalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGeneralSignal=ruleGeneralSignal();

            state._fsp--;

             current =iv_ruleGeneralSignal; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGeneralSignal"


    // $ANTLR start "ruleGeneralSignal"
    // InternalConfigurator.g:437:1: ruleGeneralSignal returns [EObject current=null] : (this_InputSignal_0= ruleInputSignal | this_OutputSignal_1= ruleOutputSignal ) ;
    public final EObject ruleGeneralSignal() throws RecognitionException {
        EObject current = null;

        EObject this_InputSignal_0 = null;

        EObject this_OutputSignal_1 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:440:28: ( (this_InputSignal_0= ruleInputSignal | this_OutputSignal_1= ruleOutputSignal ) )
            // InternalConfigurator.g:441:1: (this_InputSignal_0= ruleInputSignal | this_OutputSignal_1= ruleOutputSignal )
            {
            // InternalConfigurator.g:441:1: (this_InputSignal_0= ruleInputSignal | this_OutputSignal_1= ruleOutputSignal )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==21) ) {
                alt9=1;
            }
            else if ( (LA9_0==23) ) {
                alt9=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalConfigurator.g:442:5: this_InputSignal_0= ruleInputSignal
                    {
                     
                            newCompositeNode(grammarAccess.getGeneralSignalAccess().getInputSignalParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_2);
                    this_InputSignal_0=ruleInputSignal();

                    state._fsp--;

                     
                            current = this_InputSignal_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:452:5: this_OutputSignal_1= ruleOutputSignal
                    {
                     
                            newCompositeNode(grammarAccess.getGeneralSignalAccess().getOutputSignalParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_2);
                    this_OutputSignal_1=ruleOutputSignal();

                    state._fsp--;

                     
                            current = this_OutputSignal_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGeneralSignal"


    // $ANTLR start "entryRuleInputSignal"
    // InternalConfigurator.g:468:1: entryRuleInputSignal returns [EObject current=null] : iv_ruleInputSignal= ruleInputSignal EOF ;
    public final EObject entryRuleInputSignal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputSignal = null;


        try {
            // InternalConfigurator.g:469:2: (iv_ruleInputSignal= ruleInputSignal EOF )
            // InternalConfigurator.g:470:2: iv_ruleInputSignal= ruleInputSignal EOF
            {
             newCompositeNode(grammarAccess.getInputSignalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputSignal=ruleInputSignal();

            state._fsp--;

             current =iv_ruleInputSignal; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputSignal"


    // $ANTLR start "ruleInputSignal"
    // InternalConfigurator.g:477:1: ruleInputSignal returns [EObject current=null] : (otherlv_0= 'InputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_powerSupply_4_0= 'PowerSupply' ) )? ( (lv_datafield_5_0= ruleInputDatafield ) )+ otherlv_6= '}' ) ;
    public final EObject ruleInputSignal() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_powerSupply_4_0=null;
        Token otherlv_6=null;
        EObject lv_signal_3_0 = null;

        EObject lv_datafield_5_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:480:28: ( (otherlv_0= 'InputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_powerSupply_4_0= 'PowerSupply' ) )? ( (lv_datafield_5_0= ruleInputDatafield ) )+ otherlv_6= '}' ) )
            // InternalConfigurator.g:481:1: (otherlv_0= 'InputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_powerSupply_4_0= 'PowerSupply' ) )? ( (lv_datafield_5_0= ruleInputDatafield ) )+ otherlv_6= '}' )
            {
            // InternalConfigurator.g:481:1: (otherlv_0= 'InputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_powerSupply_4_0= 'PowerSupply' ) )? ( (lv_datafield_5_0= ruleInputDatafield ) )+ otherlv_6= '}' )
            // InternalConfigurator.g:481:3: otherlv_0= 'InputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_powerSupply_4_0= 'PowerSupply' ) )? ( (lv_datafield_5_0= ruleInputDatafield ) )+ otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,21,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInputSignalAccess().getInputSignalKeyword_0());
                
            // InternalConfigurator.g:485:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:486:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:486:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:487:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getInputSignalAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputSignalRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_15); 

                	newLeafNode(otherlv_2, grammarAccess.getInputSignalAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:507:1: ( (lv_signal_3_0= ruleSignal ) )
            // InternalConfigurator.g:508:1: (lv_signal_3_0= ruleSignal )
            {
            // InternalConfigurator.g:508:1: (lv_signal_3_0= ruleSignal )
            // InternalConfigurator.g:509:3: lv_signal_3_0= ruleSignal
            {
             
            	        newCompositeNode(grammarAccess.getInputSignalAccess().getSignalSignalParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_16);
            lv_signal_3_0=ruleSignal();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getInputSignalRule());
            	        }
                   		set(
                   			current, 
                   			"signal",
                    		lv_signal_3_0, 
                    		"zf.pios.Configurator.Signal");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:525:2: ( (lv_powerSupply_4_0= 'PowerSupply' ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==22) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalConfigurator.g:526:1: (lv_powerSupply_4_0= 'PowerSupply' )
                    {
                    // InternalConfigurator.g:526:1: (lv_powerSupply_4_0= 'PowerSupply' )
                    // InternalConfigurator.g:527:3: lv_powerSupply_4_0= 'PowerSupply'
                    {
                    lv_powerSupply_4_0=(Token)match(input,22,FOLLOW_16); 

                            newLeafNode(lv_powerSupply_4_0, grammarAccess.getInputSignalAccess().getPowerSupplyPowerSupplyKeyword_4_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getInputSignalRule());
                    	        }
                           		setWithLastConsumed(current, "powerSupply", lv_powerSupply_4_0, "PowerSupply");
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:540:3: ( (lv_datafield_5_0= ruleInputDatafield ) )+
            int cnt11=0;
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==25) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalConfigurator.g:541:1: (lv_datafield_5_0= ruleInputDatafield )
            	    {
            	    // InternalConfigurator.g:541:1: (lv_datafield_5_0= ruleInputDatafield )
            	    // InternalConfigurator.g:542:3: lv_datafield_5_0= ruleInputDatafield
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputSignalAccess().getDatafieldInputDatafieldParserRuleCall_5_0()); 
            	    	    
            	    pushFollow(FOLLOW_17);
            	    lv_datafield_5_0=ruleInputDatafield();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputSignalRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"datafield",
            	            		lv_datafield_5_0, 
            	            		"zf.pios.Configurator.InputDatafield");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt11 >= 1 ) break loop11;
                        EarlyExitException eee =
                            new EarlyExitException(11, input);
                        throw eee;
                }
                cnt11++;
            } while (true);

            otherlv_6=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_6, grammarAccess.getInputSignalAccess().getRightCurlyBracketKeyword_6());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputSignal"


    // $ANTLR start "entryRuleOutputSignal"
    // InternalConfigurator.g:570:1: entryRuleOutputSignal returns [EObject current=null] : iv_ruleOutputSignal= ruleOutputSignal EOF ;
    public final EObject entryRuleOutputSignal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputSignal = null;


        try {
            // InternalConfigurator.g:571:2: (iv_ruleOutputSignal= ruleOutputSignal EOF )
            // InternalConfigurator.g:572:2: iv_ruleOutputSignal= ruleOutputSignal EOF
            {
             newCompositeNode(grammarAccess.getOutputSignalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputSignal=ruleOutputSignal();

            state._fsp--;

             current =iv_ruleOutputSignal; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputSignal"


    // $ANTLR start "ruleOutputSignal"
    // InternalConfigurator.g:579:1: ruleOutputSignal returns [EObject current=null] : (otherlv_0= 'OutputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_pullUpResistorSignal_4_0= 'TemperaturePullupResistorSwitch' ) )? ( (lv_datafield_5_0= ruleOutputDatafield ) )+ otherlv_6= '}' ) ;
    public final EObject ruleOutputSignal() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_pullUpResistorSignal_4_0=null;
        Token otherlv_6=null;
        EObject lv_signal_3_0 = null;

        EObject lv_datafield_5_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:582:28: ( (otherlv_0= 'OutputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_pullUpResistorSignal_4_0= 'TemperaturePullupResistorSwitch' ) )? ( (lv_datafield_5_0= ruleOutputDatafield ) )+ otherlv_6= '}' ) )
            // InternalConfigurator.g:583:1: (otherlv_0= 'OutputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_pullUpResistorSignal_4_0= 'TemperaturePullupResistorSwitch' ) )? ( (lv_datafield_5_0= ruleOutputDatafield ) )+ otherlv_6= '}' )
            {
            // InternalConfigurator.g:583:1: (otherlv_0= 'OutputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_pullUpResistorSignal_4_0= 'TemperaturePullupResistorSwitch' ) )? ( (lv_datafield_5_0= ruleOutputDatafield ) )+ otherlv_6= '}' )
            // InternalConfigurator.g:583:3: otherlv_0= 'OutputSignal' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_signal_3_0= ruleSignal ) ) ( (lv_pullUpResistorSignal_4_0= 'TemperaturePullupResistorSwitch' ) )? ( (lv_datafield_5_0= ruleOutputDatafield ) )+ otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,23,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getOutputSignalAccess().getOutputSignalKeyword_0());
                
            // InternalConfigurator.g:587:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:588:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:588:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:589:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getOutputSignalAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputSignalRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_15); 

                	newLeafNode(otherlv_2, grammarAccess.getOutputSignalAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:609:1: ( (lv_signal_3_0= ruleSignal ) )
            // InternalConfigurator.g:610:1: (lv_signal_3_0= ruleSignal )
            {
            // InternalConfigurator.g:610:1: (lv_signal_3_0= ruleSignal )
            // InternalConfigurator.g:611:3: lv_signal_3_0= ruleSignal
            {
             
            	        newCompositeNode(grammarAccess.getOutputSignalAccess().getSignalSignalParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_18);
            lv_signal_3_0=ruleSignal();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getOutputSignalRule());
            	        }
                   		set(
                   			current, 
                   			"signal",
                    		lv_signal_3_0, 
                    		"zf.pios.Configurator.Signal");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:627:2: ( (lv_pullUpResistorSignal_4_0= 'TemperaturePullupResistorSwitch' ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==24) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalConfigurator.g:628:1: (lv_pullUpResistorSignal_4_0= 'TemperaturePullupResistorSwitch' )
                    {
                    // InternalConfigurator.g:628:1: (lv_pullUpResistorSignal_4_0= 'TemperaturePullupResistorSwitch' )
                    // InternalConfigurator.g:629:3: lv_pullUpResistorSignal_4_0= 'TemperaturePullupResistorSwitch'
                    {
                    lv_pullUpResistorSignal_4_0=(Token)match(input,24,FOLLOW_18); 

                            newLeafNode(lv_pullUpResistorSignal_4_0, grammarAccess.getOutputSignalAccess().getPullUpResistorSignalTemperaturePullupResistorSwitchKeyword_4_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getOutputSignalRule());
                    	        }
                           		setWithLastConsumed(current, "pullUpResistorSignal", lv_pullUpResistorSignal_4_0, "TemperaturePullupResistorSwitch");
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:642:3: ( (lv_datafield_5_0= ruleOutputDatafield ) )+
            int cnt13=0;
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==25) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalConfigurator.g:643:1: (lv_datafield_5_0= ruleOutputDatafield )
            	    {
            	    // InternalConfigurator.g:643:1: (lv_datafield_5_0= ruleOutputDatafield )
            	    // InternalConfigurator.g:644:3: lv_datafield_5_0= ruleOutputDatafield
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOutputSignalAccess().getDatafieldOutputDatafieldParserRuleCall_5_0()); 
            	    	    
            	    pushFollow(FOLLOW_19);
            	    lv_datafield_5_0=ruleOutputDatafield();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOutputSignalRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"datafield",
            	            		lv_datafield_5_0, 
            	            		"zf.pios.Configurator.OutputDatafield");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt13 >= 1 ) break loop13;
                        EarlyExitException eee =
                            new EarlyExitException(13, input);
                        throw eee;
                }
                cnt13++;
            } while (true);

            otherlv_6=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_6, grammarAccess.getOutputSignalAccess().getRightCurlyBracketKeyword_6());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputSignal"


    // $ANTLR start "entryRuleInputDatafield"
    // InternalConfigurator.g:674:1: entryRuleInputDatafield returns [EObject current=null] : iv_ruleInputDatafield= ruleInputDatafield EOF ;
    public final EObject entryRuleInputDatafield() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputDatafield = null;


        try {
            // InternalConfigurator.g:675:2: (iv_ruleInputDatafield= ruleInputDatafield EOF )
            // InternalConfigurator.g:676:2: iv_ruleInputDatafield= ruleInputDatafield EOF
            {
             newCompositeNode(grammarAccess.getInputDatafieldRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputDatafield=ruleInputDatafield();

            state._fsp--;

             current =iv_ruleInputDatafield; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputDatafield"


    // $ANTLR start "ruleInputDatafield"
    // InternalConfigurator.g:683:1: ruleInputDatafield returns [EObject current=null] : (otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}' ) ;
    public final EObject ruleInputDatafield() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        AntlrDatatypeRuleToken lv_lowerLimit_4_0 = null;

        AntlrDatatypeRuleToken lv_upperLimit_6_0 = null;

        AntlrDatatypeRuleToken lv_initValue_8_0 = null;

        EObject lv_portname_12_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:686:28: ( (otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}' ) )
            // InternalConfigurator.g:687:1: (otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}' )
            {
            // InternalConfigurator.g:687:1: (otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}' )
            // InternalConfigurator.g:687:3: otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}'
            {
            otherlv_0=(Token)match(input,25,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInputDatafieldAccess().getDatafieldVariantKeyword_0());
                
            // InternalConfigurator.g:691:1: ( ( ruleQualifiedName ) )
            // InternalConfigurator.g:692:1: ( ruleQualifiedName )
            {
            // InternalConfigurator.g:692:1: ( ruleQualifiedName )
            // InternalConfigurator.g:693:3: ruleQualifiedName
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getInputDatafieldRule());
            	        }
                    
             
            	        newCompositeNode(grammarAccess.getInputDatafieldAccess().getVariantNameVariantCrossReference_1_0()); 
            	    
            pushFollow(FOLLOW_4);
            ruleQualifiedName();

            state._fsp--;

             
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_20); 

                	newLeafNode(otherlv_2, grammarAccess.getInputDatafieldAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:710:1: (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==26) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalConfigurator.g:710:3: otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) )
                    {
                    otherlv_3=(Token)match(input,26,FOLLOW_21); 

                        	newLeafNode(otherlv_3, grammarAccess.getInputDatafieldAccess().getLowerLimitKeyword_3_0());
                        
                    // InternalConfigurator.g:714:1: ( (lv_lowerLimit_4_0= ruleNUMBER ) )
                    // InternalConfigurator.g:715:1: (lv_lowerLimit_4_0= ruleNUMBER )
                    {
                    // InternalConfigurator.g:715:1: (lv_lowerLimit_4_0= ruleNUMBER )
                    // InternalConfigurator.g:716:3: lv_lowerLimit_4_0= ruleNUMBER
                    {
                     
                    	        newCompositeNode(grammarAccess.getInputDatafieldAccess().getLowerLimitNUMBERParserRuleCall_3_1_0()); 
                    	    
                    pushFollow(FOLLOW_22);
                    lv_lowerLimit_4_0=ruleNUMBER();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getInputDatafieldRule());
                    	        }
                           		set(
                           			current, 
                           			"lowerLimit",
                            		lv_lowerLimit_4_0, 
                            		"zf.pios.Configurator.NUMBER");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:732:4: (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==27) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalConfigurator.g:732:6: otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) )
                    {
                    otherlv_5=(Token)match(input,27,FOLLOW_21); 

                        	newLeafNode(otherlv_5, grammarAccess.getInputDatafieldAccess().getUpperLimitKeyword_4_0());
                        
                    // InternalConfigurator.g:736:1: ( (lv_upperLimit_6_0= ruleNUMBER ) )
                    // InternalConfigurator.g:737:1: (lv_upperLimit_6_0= ruleNUMBER )
                    {
                    // InternalConfigurator.g:737:1: (lv_upperLimit_6_0= ruleNUMBER )
                    // InternalConfigurator.g:738:3: lv_upperLimit_6_0= ruleNUMBER
                    {
                     
                    	        newCompositeNode(grammarAccess.getInputDatafieldAccess().getUpperLimitNUMBERParserRuleCall_4_1_0()); 
                    	    
                    pushFollow(FOLLOW_23);
                    lv_upperLimit_6_0=ruleNUMBER();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getInputDatafieldRule());
                    	        }
                           		set(
                           			current, 
                           			"upperLimit",
                            		lv_upperLimit_6_0, 
                            		"zf.pios.Configurator.NUMBER");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:754:4: (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==28) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalConfigurator.g:754:6: otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) )
                    {
                    otherlv_7=(Token)match(input,28,FOLLOW_21); 

                        	newLeafNode(otherlv_7, grammarAccess.getInputDatafieldAccess().getInitValueKeyword_5_0());
                        
                    // InternalConfigurator.g:758:1: ( (lv_initValue_8_0= ruleNUMBER ) )
                    // InternalConfigurator.g:759:1: (lv_initValue_8_0= ruleNUMBER )
                    {
                    // InternalConfigurator.g:759:1: (lv_initValue_8_0= ruleNUMBER )
                    // InternalConfigurator.g:760:3: lv_initValue_8_0= ruleNUMBER
                    {
                     
                    	        newCompositeNode(grammarAccess.getInputDatafieldAccess().getInitValueNUMBERParserRuleCall_5_1_0()); 
                    	    
                    pushFollow(FOLLOW_24);
                    lv_initValue_8_0=ruleNUMBER();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getInputDatafieldRule());
                    	        }
                           		set(
                           			current, 
                           			"initValue",
                            		lv_initValue_8_0, 
                            		"zf.pios.Configurator.NUMBER");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,29,FOLLOW_3); 

                	newLeafNode(otherlv_9, grammarAccess.getInputDatafieldAccess().getSubSystemKeyword_6());
                
            // InternalConfigurator.g:780:1: ( ( ruleQualifiedName ) )
            // InternalConfigurator.g:781:1: ( ruleQualifiedName )
            {
            // InternalConfigurator.g:781:1: ( ruleQualifiedName )
            // InternalConfigurator.g:782:3: ruleQualifiedName
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getInputDatafieldRule());
            	        }
                    
             
            	        newCompositeNode(grammarAccess.getInputDatafieldAccess().getSubSystemInputDriverTypeCrossReference_7_0()); 
            	    
            pushFollow(FOLLOW_25);
            ruleQualifiedName();

            state._fsp--;

             
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_11=(Token)match(input,30,FOLLOW_26); 

                	newLeafNode(otherlv_11, grammarAccess.getInputDatafieldAccess().getPortNameKeyword_8());
                
            // InternalConfigurator.g:799:1: ( (lv_portname_12_0= rulePortname ) )
            // InternalConfigurator.g:800:1: (lv_portname_12_0= rulePortname )
            {
            // InternalConfigurator.g:800:1: (lv_portname_12_0= rulePortname )
            // InternalConfigurator.g:801:3: lv_portname_12_0= rulePortname
            {
             
            	        newCompositeNode(grammarAccess.getInputDatafieldAccess().getPortnamePortnameParserRuleCall_9_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_portname_12_0=rulePortname();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getInputDatafieldRule());
            	        }
                   		set(
                   			current, 
                   			"portname",
                    		lv_portname_12_0, 
                    		"zf.pios.Configurator.Portname");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_13=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_13, grammarAccess.getInputDatafieldAccess().getRightCurlyBracketKeyword_10());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputDatafield"


    // $ANTLR start "entryRuleOutputDatafield"
    // InternalConfigurator.g:829:1: entryRuleOutputDatafield returns [EObject current=null] : iv_ruleOutputDatafield= ruleOutputDatafield EOF ;
    public final EObject entryRuleOutputDatafield() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputDatafield = null;


        try {
            // InternalConfigurator.g:830:2: (iv_ruleOutputDatafield= ruleOutputDatafield EOF )
            // InternalConfigurator.g:831:2: iv_ruleOutputDatafield= ruleOutputDatafield EOF
            {
             newCompositeNode(grammarAccess.getOutputDatafieldRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputDatafield=ruleOutputDatafield();

            state._fsp--;

             current =iv_ruleOutputDatafield; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputDatafield"


    // $ANTLR start "ruleOutputDatafield"
    // InternalConfigurator.g:838:1: ruleOutputDatafield returns [EObject current=null] : (otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}' ) ;
    public final EObject ruleOutputDatafield() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        AntlrDatatypeRuleToken lv_lowerLimit_4_0 = null;

        AntlrDatatypeRuleToken lv_upperLimit_6_0 = null;

        AntlrDatatypeRuleToken lv_initValue_8_0 = null;

        EObject lv_portname_12_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:841:28: ( (otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}' ) )
            // InternalConfigurator.g:842:1: (otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}' )
            {
            // InternalConfigurator.g:842:1: (otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}' )
            // InternalConfigurator.g:842:3: otherlv_0= 'DatafieldVariant' ( ( ruleQualifiedName ) ) otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )? otherlv_9= 'SubSystem' ( ( ruleQualifiedName ) ) otherlv_11= 'PortName' ( (lv_portname_12_0= rulePortname ) ) otherlv_13= '}'
            {
            otherlv_0=(Token)match(input,25,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getOutputDatafieldAccess().getDatafieldVariantKeyword_0());
                
            // InternalConfigurator.g:846:1: ( ( ruleQualifiedName ) )
            // InternalConfigurator.g:847:1: ( ruleQualifiedName )
            {
            // InternalConfigurator.g:847:1: ( ruleQualifiedName )
            // InternalConfigurator.g:848:3: ruleQualifiedName
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputDatafieldRule());
            	        }
                    
             
            	        newCompositeNode(grammarAccess.getOutputDatafieldAccess().getVariantNameVariantCrossReference_1_0()); 
            	    
            pushFollow(FOLLOW_4);
            ruleQualifiedName();

            state._fsp--;

             
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_20); 

                	newLeafNode(otherlv_2, grammarAccess.getOutputDatafieldAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:865:1: (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==26) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalConfigurator.g:865:3: otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) )
                    {
                    otherlv_3=(Token)match(input,26,FOLLOW_21); 

                        	newLeafNode(otherlv_3, grammarAccess.getOutputDatafieldAccess().getLowerLimitKeyword_3_0());
                        
                    // InternalConfigurator.g:869:1: ( (lv_lowerLimit_4_0= ruleNUMBER ) )
                    // InternalConfigurator.g:870:1: (lv_lowerLimit_4_0= ruleNUMBER )
                    {
                    // InternalConfigurator.g:870:1: (lv_lowerLimit_4_0= ruleNUMBER )
                    // InternalConfigurator.g:871:3: lv_lowerLimit_4_0= ruleNUMBER
                    {
                     
                    	        newCompositeNode(grammarAccess.getOutputDatafieldAccess().getLowerLimitNUMBERParserRuleCall_3_1_0()); 
                    	    
                    pushFollow(FOLLOW_22);
                    lv_lowerLimit_4_0=ruleNUMBER();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getOutputDatafieldRule());
                    	        }
                           		set(
                           			current, 
                           			"lowerLimit",
                            		lv_lowerLimit_4_0, 
                            		"zf.pios.Configurator.NUMBER");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:887:4: (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==27) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalConfigurator.g:887:6: otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) )
                    {
                    otherlv_5=(Token)match(input,27,FOLLOW_21); 

                        	newLeafNode(otherlv_5, grammarAccess.getOutputDatafieldAccess().getUpperLimitKeyword_4_0());
                        
                    // InternalConfigurator.g:891:1: ( (lv_upperLimit_6_0= ruleNUMBER ) )
                    // InternalConfigurator.g:892:1: (lv_upperLimit_6_0= ruleNUMBER )
                    {
                    // InternalConfigurator.g:892:1: (lv_upperLimit_6_0= ruleNUMBER )
                    // InternalConfigurator.g:893:3: lv_upperLimit_6_0= ruleNUMBER
                    {
                     
                    	        newCompositeNode(grammarAccess.getOutputDatafieldAccess().getUpperLimitNUMBERParserRuleCall_4_1_0()); 
                    	    
                    pushFollow(FOLLOW_23);
                    lv_upperLimit_6_0=ruleNUMBER();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getOutputDatafieldRule());
                    	        }
                           		set(
                           			current, 
                           			"upperLimit",
                            		lv_upperLimit_6_0, 
                            		"zf.pios.Configurator.NUMBER");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:909:4: (otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) ) )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==28) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalConfigurator.g:909:6: otherlv_7= 'InitValue' ( (lv_initValue_8_0= ruleNUMBER ) )
                    {
                    otherlv_7=(Token)match(input,28,FOLLOW_21); 

                        	newLeafNode(otherlv_7, grammarAccess.getOutputDatafieldAccess().getInitValueKeyword_5_0());
                        
                    // InternalConfigurator.g:913:1: ( (lv_initValue_8_0= ruleNUMBER ) )
                    // InternalConfigurator.g:914:1: (lv_initValue_8_0= ruleNUMBER )
                    {
                    // InternalConfigurator.g:914:1: (lv_initValue_8_0= ruleNUMBER )
                    // InternalConfigurator.g:915:3: lv_initValue_8_0= ruleNUMBER
                    {
                     
                    	        newCompositeNode(grammarAccess.getOutputDatafieldAccess().getInitValueNUMBERParserRuleCall_5_1_0()); 
                    	    
                    pushFollow(FOLLOW_24);
                    lv_initValue_8_0=ruleNUMBER();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getOutputDatafieldRule());
                    	        }
                           		set(
                           			current, 
                           			"initValue",
                            		lv_initValue_8_0, 
                            		"zf.pios.Configurator.NUMBER");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,29,FOLLOW_3); 

                	newLeafNode(otherlv_9, grammarAccess.getOutputDatafieldAccess().getSubSystemKeyword_6());
                
            // InternalConfigurator.g:935:1: ( ( ruleQualifiedName ) )
            // InternalConfigurator.g:936:1: ( ruleQualifiedName )
            {
            // InternalConfigurator.g:936:1: ( ruleQualifiedName )
            // InternalConfigurator.g:937:3: ruleQualifiedName
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputDatafieldRule());
            	        }
                    
             
            	        newCompositeNode(grammarAccess.getOutputDatafieldAccess().getSubSystemOutputDriverTypeCrossReference_7_0()); 
            	    
            pushFollow(FOLLOW_25);
            ruleQualifiedName();

            state._fsp--;

             
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_11=(Token)match(input,30,FOLLOW_26); 

                	newLeafNode(otherlv_11, grammarAccess.getOutputDatafieldAccess().getPortNameKeyword_8());
                
            // InternalConfigurator.g:954:1: ( (lv_portname_12_0= rulePortname ) )
            // InternalConfigurator.g:955:1: (lv_portname_12_0= rulePortname )
            {
            // InternalConfigurator.g:955:1: (lv_portname_12_0= rulePortname )
            // InternalConfigurator.g:956:3: lv_portname_12_0= rulePortname
            {
             
            	        newCompositeNode(grammarAccess.getOutputDatafieldAccess().getPortnamePortnameParserRuleCall_9_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_portname_12_0=rulePortname();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getOutputDatafieldRule());
            	        }
                   		set(
                   			current, 
                   			"portname",
                    		lv_portname_12_0, 
                    		"zf.pios.Configurator.Portname");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_13=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_13, grammarAccess.getOutputDatafieldAccess().getRightCurlyBracketKeyword_10());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputDatafield"


    // $ANTLR start "entryRulePortname"
    // InternalConfigurator.g:984:1: entryRulePortname returns [EObject current=null] : iv_rulePortname= rulePortname EOF ;
    public final EObject entryRulePortname() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePortname = null;


        try {
            // InternalConfigurator.g:985:2: (iv_rulePortname= rulePortname EOF )
            // InternalConfigurator.g:986:2: iv_rulePortname= rulePortname EOF
            {
             newCompositeNode(grammarAccess.getPortnameRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePortname=rulePortname();

            state._fsp--;

             current =iv_rulePortname; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePortname"


    // $ANTLR start "rulePortname"
    // InternalConfigurator.g:993:1: rulePortname returns [EObject current=null] : ( ( (lv_number_0_0= ruleUiInt ) ) | ( ( ruleQualifiedName ) ) ) ;
    public final EObject rulePortname() throws RecognitionException {
        EObject current = null;

        AntlrDatatypeRuleToken lv_number_0_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:996:28: ( ( ( (lv_number_0_0= ruleUiInt ) ) | ( ( ruleQualifiedName ) ) ) )
            // InternalConfigurator.g:997:1: ( ( (lv_number_0_0= ruleUiInt ) ) | ( ( ruleQualifiedName ) ) )
            {
            // InternalConfigurator.g:997:1: ( ( (lv_number_0_0= ruleUiInt ) ) | ( ( ruleQualifiedName ) ) )
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==RULE_UINT) ) {
                alt20=1;
            }
            else if ( (LA20_0==RULE_ID) ) {
                alt20=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // InternalConfigurator.g:997:2: ( (lv_number_0_0= ruleUiInt ) )
                    {
                    // InternalConfigurator.g:997:2: ( (lv_number_0_0= ruleUiInt ) )
                    // InternalConfigurator.g:998:1: (lv_number_0_0= ruleUiInt )
                    {
                    // InternalConfigurator.g:998:1: (lv_number_0_0= ruleUiInt )
                    // InternalConfigurator.g:999:3: lv_number_0_0= ruleUiInt
                    {
                     
                    	        newCompositeNode(grammarAccess.getPortnameAccess().getNumberUiIntParserRuleCall_0_0()); 
                    	    
                    pushFollow(FOLLOW_2);
                    lv_number_0_0=ruleUiInt();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getPortnameRule());
                    	        }
                           		set(
                           			current, 
                           			"number",
                            		lv_number_0_0, 
                            		"zf.pios.Configurator.UiInt");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:1016:6: ( ( ruleQualifiedName ) )
                    {
                    // InternalConfigurator.g:1016:6: ( ( ruleQualifiedName ) )
                    // InternalConfigurator.g:1017:1: ( ruleQualifiedName )
                    {
                    // InternalConfigurator.g:1017:1: ( ruleQualifiedName )
                    // InternalConfigurator.g:1018:3: ruleQualifiedName
                    {

                    			if (current==null) {
                    	            current = createModelElement(grammarAccess.getPortnameRule());
                    	        }
                            
                     
                    	        newCompositeNode(grammarAccess.getPortnameAccess().getPortEObjectCrossReference_1_0()); 
                    	    
                    pushFollow(FOLLOW_2);
                    ruleQualifiedName();

                    state._fsp--;

                     
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePortname"


    // $ANTLR start "entryRuleVariants"
    // InternalConfigurator.g:1039:1: entryRuleVariants returns [EObject current=null] : iv_ruleVariants= ruleVariants EOF ;
    public final EObject entryRuleVariants() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariants = null;


        try {
            // InternalConfigurator.g:1040:2: (iv_ruleVariants= ruleVariants EOF )
            // InternalConfigurator.g:1041:2: iv_ruleVariants= ruleVariants EOF
            {
             newCompositeNode(grammarAccess.getVariantsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariants=ruleVariants();

            state._fsp--;

             current =iv_ruleVariants; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariants"


    // $ANTLR start "ruleVariants"
    // InternalConfigurator.g:1048:1: ruleVariants returns [EObject current=null] : ( () otherlv_1= 'Variants' otherlv_2= '{' ( (lv_variants_3_0= ruleVariant ) )+ otherlv_4= '}' ) ;
    public final EObject ruleVariants() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_variants_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:1051:28: ( ( () otherlv_1= 'Variants' otherlv_2= '{' ( (lv_variants_3_0= ruleVariant ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:1052:1: ( () otherlv_1= 'Variants' otherlv_2= '{' ( (lv_variants_3_0= ruleVariant ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:1052:1: ( () otherlv_1= 'Variants' otherlv_2= '{' ( (lv_variants_3_0= ruleVariant ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:1052:2: () otherlv_1= 'Variants' otherlv_2= '{' ( (lv_variants_3_0= ruleVariant ) )+ otherlv_4= '}'
            {
            // InternalConfigurator.g:1052:2: ()
            // InternalConfigurator.g:1053:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getVariantsAccess().getVariantsAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,31,FOLLOW_4); 

                	newLeafNode(otherlv_1, grammarAccess.getVariantsAccess().getVariantsKeyword_1());
                
            otherlv_2=(Token)match(input,15,FOLLOW_27); 

                	newLeafNode(otherlv_2, grammarAccess.getVariantsAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:1066:1: ( (lv_variants_3_0= ruleVariant ) )+
            int cnt21=0;
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( ((LA21_0>=32 && LA21_0<=33)) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalConfigurator.g:1067:1: (lv_variants_3_0= ruleVariant )
            	    {
            	    // InternalConfigurator.g:1067:1: (lv_variants_3_0= ruleVariant )
            	    // InternalConfigurator.g:1068:3: lv_variants_3_0= ruleVariant
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getVariantsAccess().getVariantsVariantParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_28);
            	    lv_variants_3_0=ruleVariant();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getVariantsRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"variants",
            	            		lv_variants_3_0, 
            	            		"zf.pios.Configurator.Variant");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt21 >= 1 ) break loop21;
                        EarlyExitException eee =
                            new EarlyExitException(21, input);
                        throw eee;
                }
                cnt21++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getVariantsAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariants"


    // $ANTLR start "entryRuleVariant"
    // InternalConfigurator.g:1096:1: entryRuleVariant returns [EObject current=null] : iv_ruleVariant= ruleVariant EOF ;
    public final EObject entryRuleVariant() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariant = null;


        try {
            // InternalConfigurator.g:1097:2: (iv_ruleVariant= ruleVariant EOF )
            // InternalConfigurator.g:1098:2: iv_ruleVariant= ruleVariant EOF
            {
             newCompositeNode(grammarAccess.getVariantRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariant=ruleVariant();

            state._fsp--;

             current =iv_ruleVariant; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariant"


    // $ANTLR start "ruleVariant"
    // InternalConfigurator.g:1105:1: ruleVariant returns [EObject current=null] : ( ( (lv_defaultVariant_0_0= 'Default' ) )? otherlv_1= 'Variant' ( (lv_name_2_0= RULE_ID ) ) ) ;
    public final EObject ruleVariant() throws RecognitionException {
        EObject current = null;

        Token lv_defaultVariant_0_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:1108:28: ( ( ( (lv_defaultVariant_0_0= 'Default' ) )? otherlv_1= 'Variant' ( (lv_name_2_0= RULE_ID ) ) ) )
            // InternalConfigurator.g:1109:1: ( ( (lv_defaultVariant_0_0= 'Default' ) )? otherlv_1= 'Variant' ( (lv_name_2_0= RULE_ID ) ) )
            {
            // InternalConfigurator.g:1109:1: ( ( (lv_defaultVariant_0_0= 'Default' ) )? otherlv_1= 'Variant' ( (lv_name_2_0= RULE_ID ) ) )
            // InternalConfigurator.g:1109:2: ( (lv_defaultVariant_0_0= 'Default' ) )? otherlv_1= 'Variant' ( (lv_name_2_0= RULE_ID ) )
            {
            // InternalConfigurator.g:1109:2: ( (lv_defaultVariant_0_0= 'Default' ) )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==32) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalConfigurator.g:1110:1: (lv_defaultVariant_0_0= 'Default' )
                    {
                    // InternalConfigurator.g:1110:1: (lv_defaultVariant_0_0= 'Default' )
                    // InternalConfigurator.g:1111:3: lv_defaultVariant_0_0= 'Default'
                    {
                    lv_defaultVariant_0_0=(Token)match(input,32,FOLLOW_29); 

                            newLeafNode(lv_defaultVariant_0_0, grammarAccess.getVariantAccess().getDefaultVariantDefaultKeyword_0_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getVariantRule());
                    	        }
                           		setWithLastConsumed(current, "defaultVariant", lv_defaultVariant_0_0, "Default");
                    	    

                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,33,FOLLOW_3); 

                	newLeafNode(otherlv_1, grammarAccess.getVariantAccess().getVariantKeyword_1());
                
            // InternalConfigurator.g:1128:1: ( (lv_name_2_0= RULE_ID ) )
            // InternalConfigurator.g:1129:1: (lv_name_2_0= RULE_ID )
            {
            // InternalConfigurator.g:1129:1: (lv_name_2_0= RULE_ID )
            // InternalConfigurator.g:1130:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            			newLeafNode(lv_name_2_0, grammarAccess.getVariantAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getVariantRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariant"


    // $ANTLR start "entryRuleSignal"
    // InternalConfigurator.g:1154:1: entryRuleSignal returns [EObject current=null] : iv_ruleSignal= ruleSignal EOF ;
    public final EObject entryRuleSignal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSignal = null;


        try {
            // InternalConfigurator.g:1155:2: (iv_ruleSignal= ruleSignal EOF )
            // InternalConfigurator.g:1156:2: iv_ruleSignal= ruleSignal EOF
            {
             newCompositeNode(grammarAccess.getSignalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSignal=ruleSignal();

            state._fsp--;

             current =iv_ruleSignal; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSignal"


    // $ANTLR start "ruleSignal"
    // InternalConfigurator.g:1163:1: ruleSignal returns [EObject current=null] : (otherlv_0= 'DataType' ( (lv_dataType_1_0= ruledataTypeEnumeration ) ) (otherlv_2= 'Description' ( (lv_description_3_0= RULE_STRING ) ) )? ( (lv_asapMeasurment_4_0= ruleASAPMeasurment ) )? ) ;
    public final EObject ruleSignal() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token lv_description_3_0=null;
        Enumerator lv_dataType_1_0 = null;

        EObject lv_asapMeasurment_4_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:1166:28: ( (otherlv_0= 'DataType' ( (lv_dataType_1_0= ruledataTypeEnumeration ) ) (otherlv_2= 'Description' ( (lv_description_3_0= RULE_STRING ) ) )? ( (lv_asapMeasurment_4_0= ruleASAPMeasurment ) )? ) )
            // InternalConfigurator.g:1167:1: (otherlv_0= 'DataType' ( (lv_dataType_1_0= ruledataTypeEnumeration ) ) (otherlv_2= 'Description' ( (lv_description_3_0= RULE_STRING ) ) )? ( (lv_asapMeasurment_4_0= ruleASAPMeasurment ) )? )
            {
            // InternalConfigurator.g:1167:1: (otherlv_0= 'DataType' ( (lv_dataType_1_0= ruledataTypeEnumeration ) ) (otherlv_2= 'Description' ( (lv_description_3_0= RULE_STRING ) ) )? ( (lv_asapMeasurment_4_0= ruleASAPMeasurment ) )? )
            // InternalConfigurator.g:1167:3: otherlv_0= 'DataType' ( (lv_dataType_1_0= ruledataTypeEnumeration ) ) (otherlv_2= 'Description' ( (lv_description_3_0= RULE_STRING ) ) )? ( (lv_asapMeasurment_4_0= ruleASAPMeasurment ) )?
            {
            otherlv_0=(Token)match(input,34,FOLLOW_30); 

                	newLeafNode(otherlv_0, grammarAccess.getSignalAccess().getDataTypeKeyword_0());
                
            // InternalConfigurator.g:1171:1: ( (lv_dataType_1_0= ruledataTypeEnumeration ) )
            // InternalConfigurator.g:1172:1: (lv_dataType_1_0= ruledataTypeEnumeration )
            {
            // InternalConfigurator.g:1172:1: (lv_dataType_1_0= ruledataTypeEnumeration )
            // InternalConfigurator.g:1173:3: lv_dataType_1_0= ruledataTypeEnumeration
            {
             
            	        newCompositeNode(grammarAccess.getSignalAccess().getDataTypeDataTypeEnumerationEnumRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_31);
            lv_dataType_1_0=ruledataTypeEnumeration();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getSignalRule());
            	        }
                   		set(
                   			current, 
                   			"dataType",
                    		lv_dataType_1_0, 
                    		"zf.pios.Configurator.dataTypeEnumeration");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:1189:2: (otherlv_2= 'Description' ( (lv_description_3_0= RULE_STRING ) ) )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==35) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalConfigurator.g:1189:4: otherlv_2= 'Description' ( (lv_description_3_0= RULE_STRING ) )
                    {
                    otherlv_2=(Token)match(input,35,FOLLOW_32); 

                        	newLeafNode(otherlv_2, grammarAccess.getSignalAccess().getDescriptionKeyword_2_0());
                        
                    // InternalConfigurator.g:1193:1: ( (lv_description_3_0= RULE_STRING ) )
                    // InternalConfigurator.g:1194:1: (lv_description_3_0= RULE_STRING )
                    {
                    // InternalConfigurator.g:1194:1: (lv_description_3_0= RULE_STRING )
                    // InternalConfigurator.g:1195:3: lv_description_3_0= RULE_STRING
                    {
                    lv_description_3_0=(Token)match(input,RULE_STRING,FOLLOW_33); 

                    			newLeafNode(lv_description_3_0, grammarAccess.getSignalAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getSignalRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"description",
                            		lv_description_3_0, 
                            		"org.eclipse.xtext.common.Terminals.STRING");
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:1211:4: ( (lv_asapMeasurment_4_0= ruleASAPMeasurment ) )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==36) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalConfigurator.g:1212:1: (lv_asapMeasurment_4_0= ruleASAPMeasurment )
                    {
                    // InternalConfigurator.g:1212:1: (lv_asapMeasurment_4_0= ruleASAPMeasurment )
                    // InternalConfigurator.g:1213:3: lv_asapMeasurment_4_0= ruleASAPMeasurment
                    {
                     
                    	        newCompositeNode(grammarAccess.getSignalAccess().getAsapMeasurmentASAPMeasurmentParserRuleCall_3_0()); 
                    	    
                    pushFollow(FOLLOW_2);
                    lv_asapMeasurment_4_0=ruleASAPMeasurment();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getSignalRule());
                    	        }
                           		set(
                           			current, 
                           			"asapMeasurment",
                            		lv_asapMeasurment_4_0, 
                            		"zf.pios.Configurator.ASAPMeasurment");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSignal"


    // $ANTLR start "entryRuleASAPMeasurment"
    // InternalConfigurator.g:1237:1: entryRuleASAPMeasurment returns [EObject current=null] : iv_ruleASAPMeasurment= ruleASAPMeasurment EOF ;
    public final EObject entryRuleASAPMeasurment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleASAPMeasurment = null;


        try {
            // InternalConfigurator.g:1238:2: (iv_ruleASAPMeasurment= ruleASAPMeasurment EOF )
            // InternalConfigurator.g:1239:2: iv_ruleASAPMeasurment= ruleASAPMeasurment EOF
            {
             newCompositeNode(grammarAccess.getASAPMeasurmentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleASAPMeasurment=ruleASAPMeasurment();

            state._fsp--;

             current =iv_ruleASAPMeasurment; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleASAPMeasurment"


    // $ANTLR start "ruleASAPMeasurment"
    // InternalConfigurator.g:1246:1: ruleASAPMeasurment returns [EObject current=null] : ( () otherlv_1= 'ASAPMeasurement' otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? otherlv_7= '}' ) ;
    public final EObject ruleASAPMeasurment() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        AntlrDatatypeRuleToken lv_lowerLimit_4_0 = null;

        AntlrDatatypeRuleToken lv_upperLimit_6_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:1249:28: ( ( () otherlv_1= 'ASAPMeasurement' otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? otherlv_7= '}' ) )
            // InternalConfigurator.g:1250:1: ( () otherlv_1= 'ASAPMeasurement' otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? otherlv_7= '}' )
            {
            // InternalConfigurator.g:1250:1: ( () otherlv_1= 'ASAPMeasurement' otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? otherlv_7= '}' )
            // InternalConfigurator.g:1250:2: () otherlv_1= 'ASAPMeasurement' otherlv_2= '{' (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )? (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )? otherlv_7= '}'
            {
            // InternalConfigurator.g:1250:2: ()
            // InternalConfigurator.g:1251:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getASAPMeasurmentAccess().getASAPMeasurmentAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,36,FOLLOW_4); 

                	newLeafNode(otherlv_1, grammarAccess.getASAPMeasurmentAccess().getASAPMeasurementKeyword_1());
                
            otherlv_2=(Token)match(input,15,FOLLOW_34); 

                	newLeafNode(otherlv_2, grammarAccess.getASAPMeasurmentAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:1264:1: (otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==26) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalConfigurator.g:1264:3: otherlv_3= 'LowerLimit' ( (lv_lowerLimit_4_0= ruleNUMBER ) )
                    {
                    otherlv_3=(Token)match(input,26,FOLLOW_21); 

                        	newLeafNode(otherlv_3, grammarAccess.getASAPMeasurmentAccess().getLowerLimitKeyword_3_0());
                        
                    // InternalConfigurator.g:1268:1: ( (lv_lowerLimit_4_0= ruleNUMBER ) )
                    // InternalConfigurator.g:1269:1: (lv_lowerLimit_4_0= ruleNUMBER )
                    {
                    // InternalConfigurator.g:1269:1: (lv_lowerLimit_4_0= ruleNUMBER )
                    // InternalConfigurator.g:1270:3: lv_lowerLimit_4_0= ruleNUMBER
                    {
                     
                    	        newCompositeNode(grammarAccess.getASAPMeasurmentAccess().getLowerLimitNUMBERParserRuleCall_3_1_0()); 
                    	    
                    pushFollow(FOLLOW_35);
                    lv_lowerLimit_4_0=ruleNUMBER();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getASAPMeasurmentRule());
                    	        }
                           		set(
                           			current, 
                           			"lowerLimit",
                            		lv_lowerLimit_4_0, 
                            		"zf.pios.Configurator.NUMBER");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:1286:4: (otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) ) )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==27) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalConfigurator.g:1286:6: otherlv_5= 'UpperLimit' ( (lv_upperLimit_6_0= ruleNUMBER ) )
                    {
                    otherlv_5=(Token)match(input,27,FOLLOW_21); 

                        	newLeafNode(otherlv_5, grammarAccess.getASAPMeasurmentAccess().getUpperLimitKeyword_4_0());
                        
                    // InternalConfigurator.g:1290:1: ( (lv_upperLimit_6_0= ruleNUMBER ) )
                    // InternalConfigurator.g:1291:1: (lv_upperLimit_6_0= ruleNUMBER )
                    {
                    // InternalConfigurator.g:1291:1: (lv_upperLimit_6_0= ruleNUMBER )
                    // InternalConfigurator.g:1292:3: lv_upperLimit_6_0= ruleNUMBER
                    {
                     
                    	        newCompositeNode(grammarAccess.getASAPMeasurmentAccess().getUpperLimitNUMBERParserRuleCall_4_1_0()); 
                    	    
                    pushFollow(FOLLOW_11);
                    lv_upperLimit_6_0=ruleNUMBER();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getASAPMeasurmentRule());
                    	        }
                           		set(
                           			current, 
                           			"upperLimit",
                            		lv_upperLimit_6_0, 
                            		"zf.pios.Configurator.NUMBER");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            otherlv_7=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_7, grammarAccess.getASAPMeasurmentAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleASAPMeasurment"


    // $ANTLR start "entryRuleHardware"
    // InternalConfigurator.g:1320:1: entryRuleHardware returns [EObject current=null] : iv_ruleHardware= ruleHardware EOF ;
    public final EObject entryRuleHardware() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleHardware = null;


        try {
            // InternalConfigurator.g:1321:2: (iv_ruleHardware= ruleHardware EOF )
            // InternalConfigurator.g:1322:2: iv_ruleHardware= ruleHardware EOF
            {
             newCompositeNode(grammarAccess.getHardwareRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleHardware=ruleHardware();

            state._fsp--;

             current =iv_ruleHardware; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHardware"


    // $ANTLR start "ruleHardware"
    // InternalConfigurator.g:1329:1: ruleHardware returns [EObject current=null] : ( () otherlv_1= 'Hardware' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_driverToECU_4_0= ruleDriverToECU ) )? ( (lv_tempSensorSubsystem_5_0= ruleTempSensorSubsystem ) )? ( (lv_electricDiagSubsystem_6_0= ruleElectricDiagSubsystem ) )? ( (lv_frequencySubsystem_7_0= ruleFrequencySubsystem ) )? ( (lv_spiSubsystem_8_0= ruleSPIinputSys ) )? ( (lv_opwmSubsystem_9_0= ruleOPWMSubsystem ) )? ( (lv_userDefinedSubsystem_10_0= ruleUserDefinedSubsystem ) )* otherlv_11= '}' ) ;
    public final EObject ruleHardware() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_11=null;
        EObject lv_driverToECU_4_0 = null;

        EObject lv_tempSensorSubsystem_5_0 = null;

        EObject lv_electricDiagSubsystem_6_0 = null;

        EObject lv_frequencySubsystem_7_0 = null;

        EObject lv_spiSubsystem_8_0 = null;

        EObject lv_opwmSubsystem_9_0 = null;

        EObject lv_userDefinedSubsystem_10_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:1332:28: ( ( () otherlv_1= 'Hardware' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_driverToECU_4_0= ruleDriverToECU ) )? ( (lv_tempSensorSubsystem_5_0= ruleTempSensorSubsystem ) )? ( (lv_electricDiagSubsystem_6_0= ruleElectricDiagSubsystem ) )? ( (lv_frequencySubsystem_7_0= ruleFrequencySubsystem ) )? ( (lv_spiSubsystem_8_0= ruleSPIinputSys ) )? ( (lv_opwmSubsystem_9_0= ruleOPWMSubsystem ) )? ( (lv_userDefinedSubsystem_10_0= ruleUserDefinedSubsystem ) )* otherlv_11= '}' ) )
            // InternalConfigurator.g:1333:1: ( () otherlv_1= 'Hardware' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_driverToECU_4_0= ruleDriverToECU ) )? ( (lv_tempSensorSubsystem_5_0= ruleTempSensorSubsystem ) )? ( (lv_electricDiagSubsystem_6_0= ruleElectricDiagSubsystem ) )? ( (lv_frequencySubsystem_7_0= ruleFrequencySubsystem ) )? ( (lv_spiSubsystem_8_0= ruleSPIinputSys ) )? ( (lv_opwmSubsystem_9_0= ruleOPWMSubsystem ) )? ( (lv_userDefinedSubsystem_10_0= ruleUserDefinedSubsystem ) )* otherlv_11= '}' )
            {
            // InternalConfigurator.g:1333:1: ( () otherlv_1= 'Hardware' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_driverToECU_4_0= ruleDriverToECU ) )? ( (lv_tempSensorSubsystem_5_0= ruleTempSensorSubsystem ) )? ( (lv_electricDiagSubsystem_6_0= ruleElectricDiagSubsystem ) )? ( (lv_frequencySubsystem_7_0= ruleFrequencySubsystem ) )? ( (lv_spiSubsystem_8_0= ruleSPIinputSys ) )? ( (lv_opwmSubsystem_9_0= ruleOPWMSubsystem ) )? ( (lv_userDefinedSubsystem_10_0= ruleUserDefinedSubsystem ) )* otherlv_11= '}' )
            // InternalConfigurator.g:1333:2: () otherlv_1= 'Hardware' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' ( (lv_driverToECU_4_0= ruleDriverToECU ) )? ( (lv_tempSensorSubsystem_5_0= ruleTempSensorSubsystem ) )? ( (lv_electricDiagSubsystem_6_0= ruleElectricDiagSubsystem ) )? ( (lv_frequencySubsystem_7_0= ruleFrequencySubsystem ) )? ( (lv_spiSubsystem_8_0= ruleSPIinputSys ) )? ( (lv_opwmSubsystem_9_0= ruleOPWMSubsystem ) )? ( (lv_userDefinedSubsystem_10_0= ruleUserDefinedSubsystem ) )* otherlv_11= '}'
            {
            // InternalConfigurator.g:1333:2: ()
            // InternalConfigurator.g:1334:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getHardwareAccess().getHardwareAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,37,FOLLOW_3); 

                	newLeafNode(otherlv_1, grammarAccess.getHardwareAccess().getHardwareKeyword_1());
                
            // InternalConfigurator.g:1343:1: ( (lv_name_2_0= RULE_ID ) )
            // InternalConfigurator.g:1344:1: (lv_name_2_0= RULE_ID )
            {
            // InternalConfigurator.g:1344:1: (lv_name_2_0= RULE_ID )
            // InternalConfigurator.g:1345:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_2_0, grammarAccess.getHardwareAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getHardwareRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_36); 

                	newLeafNode(otherlv_3, grammarAccess.getHardwareAccess().getLeftCurlyBracketKeyword_3());
                
            // InternalConfigurator.g:1365:1: ( (lv_driverToECU_4_0= ruleDriverToECU ) )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==57) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalConfigurator.g:1366:1: (lv_driverToECU_4_0= ruleDriverToECU )
                    {
                    // InternalConfigurator.g:1366:1: (lv_driverToECU_4_0= ruleDriverToECU )
                    // InternalConfigurator.g:1367:3: lv_driverToECU_4_0= ruleDriverToECU
                    {
                     
                    	        newCompositeNode(grammarAccess.getHardwareAccess().getDriverToECUDriverToECUParserRuleCall_4_0()); 
                    	    
                    pushFollow(FOLLOW_37);
                    lv_driverToECU_4_0=ruleDriverToECU();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getHardwareRule());
                    	        }
                           		set(
                           			current, 
                           			"driverToECU",
                            		lv_driverToECU_4_0, 
                            		"zf.pios.Configurator.DriverToECU");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:1383:3: ( (lv_tempSensorSubsystem_5_0= ruleTempSensorSubsystem ) )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==58) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalConfigurator.g:1384:1: (lv_tempSensorSubsystem_5_0= ruleTempSensorSubsystem )
                    {
                    // InternalConfigurator.g:1384:1: (lv_tempSensorSubsystem_5_0= ruleTempSensorSubsystem )
                    // InternalConfigurator.g:1385:3: lv_tempSensorSubsystem_5_0= ruleTempSensorSubsystem
                    {
                     
                    	        newCompositeNode(grammarAccess.getHardwareAccess().getTempSensorSubsystemTempSensorSubsystemParserRuleCall_5_0()); 
                    	    
                    pushFollow(FOLLOW_38);
                    lv_tempSensorSubsystem_5_0=ruleTempSensorSubsystem();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getHardwareRule());
                    	        }
                           		set(
                           			current, 
                           			"tempSensorSubsystem",
                            		lv_tempSensorSubsystem_5_0, 
                            		"zf.pios.Configurator.TempSensorSubsystem");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:1401:3: ( (lv_electricDiagSubsystem_6_0= ruleElectricDiagSubsystem ) )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==68) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalConfigurator.g:1402:1: (lv_electricDiagSubsystem_6_0= ruleElectricDiagSubsystem )
                    {
                    // InternalConfigurator.g:1402:1: (lv_electricDiagSubsystem_6_0= ruleElectricDiagSubsystem )
                    // InternalConfigurator.g:1403:3: lv_electricDiagSubsystem_6_0= ruleElectricDiagSubsystem
                    {
                     
                    	        newCompositeNode(grammarAccess.getHardwareAccess().getElectricDiagSubsystemElectricDiagSubsystemParserRuleCall_6_0()); 
                    	    
                    pushFollow(FOLLOW_39);
                    lv_electricDiagSubsystem_6_0=ruleElectricDiagSubsystem();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getHardwareRule());
                    	        }
                           		set(
                           			current, 
                           			"electricDiagSubsystem",
                            		lv_electricDiagSubsystem_6_0, 
                            		"zf.pios.Configurator.ElectricDiagSubsystem");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:1419:3: ( (lv_frequencySubsystem_7_0= ruleFrequencySubsystem ) )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==73) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalConfigurator.g:1420:1: (lv_frequencySubsystem_7_0= ruleFrequencySubsystem )
                    {
                    // InternalConfigurator.g:1420:1: (lv_frequencySubsystem_7_0= ruleFrequencySubsystem )
                    // InternalConfigurator.g:1421:3: lv_frequencySubsystem_7_0= ruleFrequencySubsystem
                    {
                     
                    	        newCompositeNode(grammarAccess.getHardwareAccess().getFrequencySubsystemFrequencySubsystemParserRuleCall_7_0()); 
                    	    
                    pushFollow(FOLLOW_40);
                    lv_frequencySubsystem_7_0=ruleFrequencySubsystem();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getHardwareRule());
                    	        }
                           		set(
                           			current, 
                           			"frequencySubsystem",
                            		lv_frequencySubsystem_7_0, 
                            		"zf.pios.Configurator.FrequencySubsystem");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:1437:3: ( (lv_spiSubsystem_8_0= ruleSPIinputSys ) )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==80) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalConfigurator.g:1438:1: (lv_spiSubsystem_8_0= ruleSPIinputSys )
                    {
                    // InternalConfigurator.g:1438:1: (lv_spiSubsystem_8_0= ruleSPIinputSys )
                    // InternalConfigurator.g:1439:3: lv_spiSubsystem_8_0= ruleSPIinputSys
                    {
                     
                    	        newCompositeNode(grammarAccess.getHardwareAccess().getSpiSubsystemSPIinputSysParserRuleCall_8_0()); 
                    	    
                    pushFollow(FOLLOW_41);
                    lv_spiSubsystem_8_0=ruleSPIinputSys();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getHardwareRule());
                    	        }
                           		set(
                           			current, 
                           			"spiSubsystem",
                            		lv_spiSubsystem_8_0, 
                            		"zf.pios.Configurator.SPIinputSys");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:1455:3: ( (lv_opwmSubsystem_9_0= ruleOPWMSubsystem ) )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==90) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalConfigurator.g:1456:1: (lv_opwmSubsystem_9_0= ruleOPWMSubsystem )
                    {
                    // InternalConfigurator.g:1456:1: (lv_opwmSubsystem_9_0= ruleOPWMSubsystem )
                    // InternalConfigurator.g:1457:3: lv_opwmSubsystem_9_0= ruleOPWMSubsystem
                    {
                     
                    	        newCompositeNode(grammarAccess.getHardwareAccess().getOpwmSubsystemOPWMSubsystemParserRuleCall_9_0()); 
                    	    
                    pushFollow(FOLLOW_42);
                    lv_opwmSubsystem_9_0=ruleOPWMSubsystem();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getHardwareRule());
                    	        }
                           		set(
                           			current, 
                           			"opwmSubsystem",
                            		lv_opwmSubsystem_9_0, 
                            		"zf.pios.Configurator.OPWMSubsystem");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:1473:3: ( (lv_userDefinedSubsystem_10_0= ruleUserDefinedSubsystem ) )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==94) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // InternalConfigurator.g:1474:1: (lv_userDefinedSubsystem_10_0= ruleUserDefinedSubsystem )
            	    {
            	    // InternalConfigurator.g:1474:1: (lv_userDefinedSubsystem_10_0= ruleUserDefinedSubsystem )
            	    // InternalConfigurator.g:1475:3: lv_userDefinedSubsystem_10_0= ruleUserDefinedSubsystem
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getHardwareAccess().getUserDefinedSubsystemUserDefinedSubsystemParserRuleCall_10_0()); 
            	    	    
            	    pushFollow(FOLLOW_42);
            	    lv_userDefinedSubsystem_10_0=ruleUserDefinedSubsystem();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getHardwareRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"userDefinedSubsystem",
            	            		lv_userDefinedSubsystem_10_0, 
            	            		"zf.pios.Configurator.UserDefinedSubsystem");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);

            otherlv_11=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_11, grammarAccess.getHardwareAccess().getRightCurlyBracketKeyword_11());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHardware"


    // $ANTLR start "entryRuleConfigSubsystem"
    // InternalConfigurator.g:1503:1: entryRuleConfigSubsystem returns [EObject current=null] : iv_ruleConfigSubsystem= ruleConfigSubsystem EOF ;
    public final EObject entryRuleConfigSubsystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConfigSubsystem = null;


        try {
            // InternalConfigurator.g:1504:2: (iv_ruleConfigSubsystem= ruleConfigSubsystem EOF )
            // InternalConfigurator.g:1505:2: iv_ruleConfigSubsystem= ruleConfigSubsystem EOF
            {
             newCompositeNode(grammarAccess.getConfigSubsystemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConfigSubsystem=ruleConfigSubsystem();

            state._fsp--;

             current =iv_ruleConfigSubsystem; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConfigSubsystem"


    // $ANTLR start "ruleConfigSubsystem"
    // InternalConfigurator.g:1512:1: ruleConfigSubsystem returns [EObject current=null] : (otherlv_0= 'ConfigSubsystem' otherlv_1= '{' ( (lv_configSubsystemInput_2_0= ruleConfigSubsystemInput ) ) ( (lv_configSubsystemOutput_3_0= ruleConfigSubsystemOutput ) ) otherlv_4= '}' ) ;
    public final EObject ruleConfigSubsystem() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_4=null;
        EObject lv_configSubsystemInput_2_0 = null;

        EObject lv_configSubsystemOutput_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:1515:28: ( (otherlv_0= 'ConfigSubsystem' otherlv_1= '{' ( (lv_configSubsystemInput_2_0= ruleConfigSubsystemInput ) ) ( (lv_configSubsystemOutput_3_0= ruleConfigSubsystemOutput ) ) otherlv_4= '}' ) )
            // InternalConfigurator.g:1516:1: (otherlv_0= 'ConfigSubsystem' otherlv_1= '{' ( (lv_configSubsystemInput_2_0= ruleConfigSubsystemInput ) ) ( (lv_configSubsystemOutput_3_0= ruleConfigSubsystemOutput ) ) otherlv_4= '}' )
            {
            // InternalConfigurator.g:1516:1: (otherlv_0= 'ConfigSubsystem' otherlv_1= '{' ( (lv_configSubsystemInput_2_0= ruleConfigSubsystemInput ) ) ( (lv_configSubsystemOutput_3_0= ruleConfigSubsystemOutput ) ) otherlv_4= '}' )
            // InternalConfigurator.g:1516:3: otherlv_0= 'ConfigSubsystem' otherlv_1= '{' ( (lv_configSubsystemInput_2_0= ruleConfigSubsystemInput ) ) ( (lv_configSubsystemOutput_3_0= ruleConfigSubsystemOutput ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,38,FOLLOW_4); 

                	newLeafNode(otherlv_0, grammarAccess.getConfigSubsystemAccess().getConfigSubsystemKeyword_0());
                
            otherlv_1=(Token)match(input,15,FOLLOW_43); 

                	newLeafNode(otherlv_1, grammarAccess.getConfigSubsystemAccess().getLeftCurlyBracketKeyword_1());
                
            // InternalConfigurator.g:1524:1: ( (lv_configSubsystemInput_2_0= ruleConfigSubsystemInput ) )
            // InternalConfigurator.g:1525:1: (lv_configSubsystemInput_2_0= ruleConfigSubsystemInput )
            {
            // InternalConfigurator.g:1525:1: (lv_configSubsystemInput_2_0= ruleConfigSubsystemInput )
            // InternalConfigurator.g:1526:3: lv_configSubsystemInput_2_0= ruleConfigSubsystemInput
            {
             
            	        newCompositeNode(grammarAccess.getConfigSubsystemAccess().getConfigSubsystemInputConfigSubsystemInputParserRuleCall_2_0()); 
            	    
            pushFollow(FOLLOW_44);
            lv_configSubsystemInput_2_0=ruleConfigSubsystemInput();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getConfigSubsystemRule());
            	        }
                   		set(
                   			current, 
                   			"configSubsystemInput",
                    		lv_configSubsystemInput_2_0, 
                    		"zf.pios.Configurator.ConfigSubsystemInput");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:1542:2: ( (lv_configSubsystemOutput_3_0= ruleConfigSubsystemOutput ) )
            // InternalConfigurator.g:1543:1: (lv_configSubsystemOutput_3_0= ruleConfigSubsystemOutput )
            {
            // InternalConfigurator.g:1543:1: (lv_configSubsystemOutput_3_0= ruleConfigSubsystemOutput )
            // InternalConfigurator.g:1544:3: lv_configSubsystemOutput_3_0= ruleConfigSubsystemOutput
            {
             
            	        newCompositeNode(grammarAccess.getConfigSubsystemAccess().getConfigSubsystemOutputConfigSubsystemOutputParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_configSubsystemOutput_3_0=ruleConfigSubsystemOutput();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getConfigSubsystemRule());
            	        }
                   		set(
                   			current, 
                   			"configSubsystemOutput",
                    		lv_configSubsystemOutput_3_0, 
                    		"zf.pios.Configurator.ConfigSubsystemOutput");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getConfigSubsystemAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConfigSubsystem"


    // $ANTLR start "entryRuleConfigSubsystemInput"
    // InternalConfigurator.g:1572:1: entryRuleConfigSubsystemInput returns [EObject current=null] : iv_ruleConfigSubsystemInput= ruleConfigSubsystemInput EOF ;
    public final EObject entryRuleConfigSubsystemInput() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConfigSubsystemInput = null;


        try {
            // InternalConfigurator.g:1573:2: (iv_ruleConfigSubsystemInput= ruleConfigSubsystemInput EOF )
            // InternalConfigurator.g:1574:2: iv_ruleConfigSubsystemInput= ruleConfigSubsystemInput EOF
            {
             newCompositeNode(grammarAccess.getConfigSubsystemInputRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConfigSubsystemInput=ruleConfigSubsystemInput();

            state._fsp--;

             current =iv_ruleConfigSubsystemInput; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConfigSubsystemInput"


    // $ANTLR start "ruleConfigSubsystemInput"
    // InternalConfigurator.g:1581:1: ruleConfigSubsystemInput returns [EObject current=null] : (otherlv_0= 'Input' otherlv_1= '{' otherlv_2= 'MaximalNumberInputSubsystems' ( (lv_maximalNumberInputSubsystems_3_0= RULE_UINT ) ) ( (lv_inputSubsystems_4_0= ruleInputSubsystems ) ) otherlv_5= '}' ) ;
    public final EObject ruleConfigSubsystemInput() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_maximalNumberInputSubsystems_3_0=null;
        Token otherlv_5=null;
        EObject lv_inputSubsystems_4_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:1584:28: ( (otherlv_0= 'Input' otherlv_1= '{' otherlv_2= 'MaximalNumberInputSubsystems' ( (lv_maximalNumberInputSubsystems_3_0= RULE_UINT ) ) ( (lv_inputSubsystems_4_0= ruleInputSubsystems ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:1585:1: (otherlv_0= 'Input' otherlv_1= '{' otherlv_2= 'MaximalNumberInputSubsystems' ( (lv_maximalNumberInputSubsystems_3_0= RULE_UINT ) ) ( (lv_inputSubsystems_4_0= ruleInputSubsystems ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:1585:1: (otherlv_0= 'Input' otherlv_1= '{' otherlv_2= 'MaximalNumberInputSubsystems' ( (lv_maximalNumberInputSubsystems_3_0= RULE_UINT ) ) ( (lv_inputSubsystems_4_0= ruleInputSubsystems ) ) otherlv_5= '}' )
            // InternalConfigurator.g:1585:3: otherlv_0= 'Input' otherlv_1= '{' otherlv_2= 'MaximalNumberInputSubsystems' ( (lv_maximalNumberInputSubsystems_3_0= RULE_UINT ) ) ( (lv_inputSubsystems_4_0= ruleInputSubsystems ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,39,FOLLOW_4); 

                	newLeafNode(otherlv_0, grammarAccess.getConfigSubsystemInputAccess().getInputKeyword_0());
                
            otherlv_1=(Token)match(input,15,FOLLOW_45); 

                	newLeafNode(otherlv_1, grammarAccess.getConfigSubsystemInputAccess().getLeftCurlyBracketKeyword_1());
                
            otherlv_2=(Token)match(input,40,FOLLOW_46); 

                	newLeafNode(otherlv_2, grammarAccess.getConfigSubsystemInputAccess().getMaximalNumberInputSubsystemsKeyword_2());
                
            // InternalConfigurator.g:1597:1: ( (lv_maximalNumberInputSubsystems_3_0= RULE_UINT ) )
            // InternalConfigurator.g:1598:1: (lv_maximalNumberInputSubsystems_3_0= RULE_UINT )
            {
            // InternalConfigurator.g:1598:1: (lv_maximalNumberInputSubsystems_3_0= RULE_UINT )
            // InternalConfigurator.g:1599:3: lv_maximalNumberInputSubsystems_3_0= RULE_UINT
            {
            lv_maximalNumberInputSubsystems_3_0=(Token)match(input,RULE_UINT,FOLLOW_47); 

            			newLeafNode(lv_maximalNumberInputSubsystems_3_0, grammarAccess.getConfigSubsystemInputAccess().getMaximalNumberInputSubsystemsUINTTerminalRuleCall_3_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getConfigSubsystemInputRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"maximalNumberInputSubsystems",
                    		lv_maximalNumberInputSubsystems_3_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            // InternalConfigurator.g:1615:2: ( (lv_inputSubsystems_4_0= ruleInputSubsystems ) )
            // InternalConfigurator.g:1616:1: (lv_inputSubsystems_4_0= ruleInputSubsystems )
            {
            // InternalConfigurator.g:1616:1: (lv_inputSubsystems_4_0= ruleInputSubsystems )
            // InternalConfigurator.g:1617:3: lv_inputSubsystems_4_0= ruleInputSubsystems
            {
             
            	        newCompositeNode(grammarAccess.getConfigSubsystemInputAccess().getInputSubsystemsInputSubsystemsParserRuleCall_4_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_inputSubsystems_4_0=ruleInputSubsystems();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getConfigSubsystemInputRule());
            	        }
                   		set(
                   			current, 
                   			"inputSubsystems",
                    		lv_inputSubsystems_4_0, 
                    		"zf.pios.Configurator.InputSubsystems");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getConfigSubsystemInputAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConfigSubsystemInput"


    // $ANTLR start "entryRuleConfigSubsystemOutput"
    // InternalConfigurator.g:1645:1: entryRuleConfigSubsystemOutput returns [EObject current=null] : iv_ruleConfigSubsystemOutput= ruleConfigSubsystemOutput EOF ;
    public final EObject entryRuleConfigSubsystemOutput() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConfigSubsystemOutput = null;


        try {
            // InternalConfigurator.g:1646:2: (iv_ruleConfigSubsystemOutput= ruleConfigSubsystemOutput EOF )
            // InternalConfigurator.g:1647:2: iv_ruleConfigSubsystemOutput= ruleConfigSubsystemOutput EOF
            {
             newCompositeNode(grammarAccess.getConfigSubsystemOutputRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConfigSubsystemOutput=ruleConfigSubsystemOutput();

            state._fsp--;

             current =iv_ruleConfigSubsystemOutput; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConfigSubsystemOutput"


    // $ANTLR start "ruleConfigSubsystemOutput"
    // InternalConfigurator.g:1654:1: ruleConfigSubsystemOutput returns [EObject current=null] : (otherlv_0= 'Output' otherlv_1= '{' otherlv_2= 'MaximalNumberOutputSubsystems' ( (lv_maximalNumberOutputSubsystems_3_0= RULE_UINT ) ) ( (lv_outputSubsystems_4_0= ruleOutputSubsystems ) ) otherlv_5= '}' ) ;
    public final EObject ruleConfigSubsystemOutput() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_maximalNumberOutputSubsystems_3_0=null;
        Token otherlv_5=null;
        EObject lv_outputSubsystems_4_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:1657:28: ( (otherlv_0= 'Output' otherlv_1= '{' otherlv_2= 'MaximalNumberOutputSubsystems' ( (lv_maximalNumberOutputSubsystems_3_0= RULE_UINT ) ) ( (lv_outputSubsystems_4_0= ruleOutputSubsystems ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:1658:1: (otherlv_0= 'Output' otherlv_1= '{' otherlv_2= 'MaximalNumberOutputSubsystems' ( (lv_maximalNumberOutputSubsystems_3_0= RULE_UINT ) ) ( (lv_outputSubsystems_4_0= ruleOutputSubsystems ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:1658:1: (otherlv_0= 'Output' otherlv_1= '{' otherlv_2= 'MaximalNumberOutputSubsystems' ( (lv_maximalNumberOutputSubsystems_3_0= RULE_UINT ) ) ( (lv_outputSubsystems_4_0= ruleOutputSubsystems ) ) otherlv_5= '}' )
            // InternalConfigurator.g:1658:3: otherlv_0= 'Output' otherlv_1= '{' otherlv_2= 'MaximalNumberOutputSubsystems' ( (lv_maximalNumberOutputSubsystems_3_0= RULE_UINT ) ) ( (lv_outputSubsystems_4_0= ruleOutputSubsystems ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,41,FOLLOW_4); 

                	newLeafNode(otherlv_0, grammarAccess.getConfigSubsystemOutputAccess().getOutputKeyword_0());
                
            otherlv_1=(Token)match(input,15,FOLLOW_48); 

                	newLeafNode(otherlv_1, grammarAccess.getConfigSubsystemOutputAccess().getLeftCurlyBracketKeyword_1());
                
            otherlv_2=(Token)match(input,42,FOLLOW_46); 

                	newLeafNode(otherlv_2, grammarAccess.getConfigSubsystemOutputAccess().getMaximalNumberOutputSubsystemsKeyword_2());
                
            // InternalConfigurator.g:1670:1: ( (lv_maximalNumberOutputSubsystems_3_0= RULE_UINT ) )
            // InternalConfigurator.g:1671:1: (lv_maximalNumberOutputSubsystems_3_0= RULE_UINT )
            {
            // InternalConfigurator.g:1671:1: (lv_maximalNumberOutputSubsystems_3_0= RULE_UINT )
            // InternalConfigurator.g:1672:3: lv_maximalNumberOutputSubsystems_3_0= RULE_UINT
            {
            lv_maximalNumberOutputSubsystems_3_0=(Token)match(input,RULE_UINT,FOLLOW_49); 

            			newLeafNode(lv_maximalNumberOutputSubsystems_3_0, grammarAccess.getConfigSubsystemOutputAccess().getMaximalNumberOutputSubsystemsUINTTerminalRuleCall_3_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getConfigSubsystemOutputRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"maximalNumberOutputSubsystems",
                    		lv_maximalNumberOutputSubsystems_3_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            // InternalConfigurator.g:1688:2: ( (lv_outputSubsystems_4_0= ruleOutputSubsystems ) )
            // InternalConfigurator.g:1689:1: (lv_outputSubsystems_4_0= ruleOutputSubsystems )
            {
            // InternalConfigurator.g:1689:1: (lv_outputSubsystems_4_0= ruleOutputSubsystems )
            // InternalConfigurator.g:1690:3: lv_outputSubsystems_4_0= ruleOutputSubsystems
            {
             
            	        newCompositeNode(grammarAccess.getConfigSubsystemOutputAccess().getOutputSubsystemsOutputSubsystemsParserRuleCall_4_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_outputSubsystems_4_0=ruleOutputSubsystems();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getConfigSubsystemOutputRule());
            	        }
                   		set(
                   			current, 
                   			"outputSubsystems",
                    		lv_outputSubsystems_4_0, 
                    		"zf.pios.Configurator.OutputSubsystems");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getConfigSubsystemOutputAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConfigSubsystemOutput"


    // $ANTLR start "entryRuleInputSubsystems"
    // InternalConfigurator.g:1718:1: entryRuleInputSubsystems returns [EObject current=null] : iv_ruleInputSubsystems= ruleInputSubsystems EOF ;
    public final EObject entryRuleInputSubsystems() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputSubsystems = null;


        try {
            // InternalConfigurator.g:1719:2: (iv_ruleInputSubsystems= ruleInputSubsystems EOF )
            // InternalConfigurator.g:1720:2: iv_ruleInputSubsystems= ruleInputSubsystems EOF
            {
             newCompositeNode(grammarAccess.getInputSubsystemsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputSubsystems=ruleInputSubsystems();

            state._fsp--;

             current =iv_ruleInputSubsystems; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputSubsystems"


    // $ANTLR start "ruleInputSubsystems"
    // InternalConfigurator.g:1727:1: ruleInputSubsystems returns [EObject current=null] : ( () ( ( ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* ) ) ) ( (lv_inputConfigSubsystem_8_0= ruleInputConfigSubsystemItem ) )* ) ;
    public final EObject ruleInputSubsystems() throws RecognitionException {
        EObject current = null;

        EObject lv_inputNull_2_0 = null;

        EObject lv_inputAnalog_3_0 = null;

        EObject lv_inputTemperature_4_0 = null;

        EObject lv_inputDigital_5_0 = null;

        EObject lv_inputFrq_6_0 = null;

        EObject lv_inputSPI_7_0 = null;

        EObject lv_inputConfigSubsystem_8_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:1730:28: ( ( () ( ( ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* ) ) ) ( (lv_inputConfigSubsystem_8_0= ruleInputConfigSubsystemItem ) )* ) )
            // InternalConfigurator.g:1731:1: ( () ( ( ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* ) ) ) ( (lv_inputConfigSubsystem_8_0= ruleInputConfigSubsystemItem ) )* )
            {
            // InternalConfigurator.g:1731:1: ( () ( ( ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* ) ) ) ( (lv_inputConfigSubsystem_8_0= ruleInputConfigSubsystemItem ) )* )
            // InternalConfigurator.g:1731:2: () ( ( ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* ) ) ) ( (lv_inputConfigSubsystem_8_0= ruleInputConfigSubsystemItem ) )*
            {
            // InternalConfigurator.g:1731:2: ()
            // InternalConfigurator.g:1732:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getInputSubsystemsAccess().getInputSubsystemsAction_0(),
                        current);
                

            }

            // InternalConfigurator.g:1737:2: ( ( ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* ) ) )
            // InternalConfigurator.g:1739:1: ( ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* ) )
            {
            // InternalConfigurator.g:1739:1: ( ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* ) )
            // InternalConfigurator.g:1740:2: ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* )
            {
             
            	  getUnorderedGroupHelper().enter(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1());
            	
            // InternalConfigurator.g:1743:2: ( ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )* )
            // InternalConfigurator.g:1744:3: ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )*
            {
            // InternalConfigurator.g:1744:3: ( ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) ) )*
            loop34:
            do {
                int alt34=7;
                int LA34_0 = input.LA(1);

                if ( LA34_0 == 43 && getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 0) ) {
                    alt34=1;
                }
                else if ( LA34_0 == 46 && getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 1) ) {
                    alt34=2;
                }
                else if ( LA34_0 == 47 && getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 2) ) {
                    alt34=3;
                }
                else if ( LA34_0 == 51 && getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 3) ) {
                    alt34=4;
                }
                else if ( LA34_0 == 52 && getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 4) ) {
                    alt34=5;
                }
                else if ( LA34_0 == 50 && getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 5) ) {
                    alt34=6;
                }


                switch (alt34) {
            	case 1 :
            	    // InternalConfigurator.g:1746:4: ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:1746:4: ({...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) ) )
            	    // InternalConfigurator.g:1747:5: {...}? => ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 0) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 0)");
            	    }
            	    // InternalConfigurator.g:1747:112: ( ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) ) )
            	    // InternalConfigurator.g:1748:6: ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 0);
            	    	 				
            	    // InternalConfigurator.g:1751:6: ({...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) ) )
            	    // InternalConfigurator.g:1751:7: {...}? => ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:1751:16: ( (lv_inputNull_2_0= ruleInputConfigSubsystemNull ) )
            	    // InternalConfigurator.g:1752:1: (lv_inputNull_2_0= ruleInputConfigSubsystemNull )
            	    {
            	    // InternalConfigurator.g:1752:1: (lv_inputNull_2_0= ruleInputConfigSubsystemNull )
            	    // InternalConfigurator.g:1753:3: lv_inputNull_2_0= ruleInputConfigSubsystemNull
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputSubsystemsAccess().getInputNullInputConfigSubsystemNullParserRuleCall_1_0_0()); 
            	    	    
            	    pushFollow(FOLLOW_50);
            	    lv_inputNull_2_0=ruleInputConfigSubsystemNull();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"inputNull",
            	            		lv_inputNull_2_0, 
            	            		"zf.pios.Configurator.InputConfigSubsystemNull");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // InternalConfigurator.g:1776:4: ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:1776:4: ({...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) ) )
            	    // InternalConfigurator.g:1777:5: {...}? => ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 1) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 1)");
            	    }
            	    // InternalConfigurator.g:1777:112: ( ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) ) )
            	    // InternalConfigurator.g:1778:6: ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 1);
            	    	 				
            	    // InternalConfigurator.g:1781:6: ({...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) ) )
            	    // InternalConfigurator.g:1781:7: {...}? => ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:1781:16: ( (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog ) )
            	    // InternalConfigurator.g:1782:1: (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog )
            	    {
            	    // InternalConfigurator.g:1782:1: (lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog )
            	    // InternalConfigurator.g:1783:3: lv_inputAnalog_3_0= ruleInputConfigSubsystemAnalog
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputSubsystemsAccess().getInputAnalogInputConfigSubsystemAnalogParserRuleCall_1_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_50);
            	    lv_inputAnalog_3_0=ruleInputConfigSubsystemAnalog();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"inputAnalog",
            	            		lv_inputAnalog_3_0, 
            	            		"zf.pios.Configurator.InputConfigSubsystemAnalog");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 3 :
            	    // InternalConfigurator.g:1806:4: ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:1806:4: ({...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) ) )
            	    // InternalConfigurator.g:1807:5: {...}? => ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 2) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 2)");
            	    }
            	    // InternalConfigurator.g:1807:112: ( ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) ) )
            	    // InternalConfigurator.g:1808:6: ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 2);
            	    	 				
            	    // InternalConfigurator.g:1811:6: ({...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) ) )
            	    // InternalConfigurator.g:1811:7: {...}? => ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:1811:16: ( (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature ) )
            	    // InternalConfigurator.g:1812:1: (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature )
            	    {
            	    // InternalConfigurator.g:1812:1: (lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature )
            	    // InternalConfigurator.g:1813:3: lv_inputTemperature_4_0= ruleInputConfigSubsystemTemperature
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputSubsystemsAccess().getInputTemperatureInputConfigSubsystemTemperatureParserRuleCall_1_2_0()); 
            	    	    
            	    pushFollow(FOLLOW_50);
            	    lv_inputTemperature_4_0=ruleInputConfigSubsystemTemperature();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"inputTemperature",
            	            		lv_inputTemperature_4_0, 
            	            		"zf.pios.Configurator.InputConfigSubsystemTemperature");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 4 :
            	    // InternalConfigurator.g:1836:4: ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:1836:4: ({...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) ) )
            	    // InternalConfigurator.g:1837:5: {...}? => ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 3) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 3)");
            	    }
            	    // InternalConfigurator.g:1837:112: ( ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) ) )
            	    // InternalConfigurator.g:1838:6: ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 3);
            	    	 				
            	    // InternalConfigurator.g:1841:6: ({...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) ) )
            	    // InternalConfigurator.g:1841:7: {...}? => ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:1841:16: ( (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital ) )
            	    // InternalConfigurator.g:1842:1: (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital )
            	    {
            	    // InternalConfigurator.g:1842:1: (lv_inputDigital_5_0= ruleInputConfigSubsystemDigital )
            	    // InternalConfigurator.g:1843:3: lv_inputDigital_5_0= ruleInputConfigSubsystemDigital
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputSubsystemsAccess().getInputDigitalInputConfigSubsystemDigitalParserRuleCall_1_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_50);
            	    lv_inputDigital_5_0=ruleInputConfigSubsystemDigital();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"inputDigital",
            	            		lv_inputDigital_5_0, 
            	            		"zf.pios.Configurator.InputConfigSubsystemDigital");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 5 :
            	    // InternalConfigurator.g:1866:4: ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:1866:4: ({...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) ) )
            	    // InternalConfigurator.g:1867:5: {...}? => ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 4) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 4)");
            	    }
            	    // InternalConfigurator.g:1867:112: ( ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) ) )
            	    // InternalConfigurator.g:1868:6: ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 4);
            	    	 				
            	    // InternalConfigurator.g:1871:6: ({...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) ) )
            	    // InternalConfigurator.g:1871:7: {...}? => ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:1871:16: ( (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq ) )
            	    // InternalConfigurator.g:1872:1: (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq )
            	    {
            	    // InternalConfigurator.g:1872:1: (lv_inputFrq_6_0= ruleInputConfigSubsystemFrq )
            	    // InternalConfigurator.g:1873:3: lv_inputFrq_6_0= ruleInputConfigSubsystemFrq
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputSubsystemsAccess().getInputFrqInputConfigSubsystemFrqParserRuleCall_1_4_0()); 
            	    	    
            	    pushFollow(FOLLOW_50);
            	    lv_inputFrq_6_0=ruleInputConfigSubsystemFrq();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"inputFrq",
            	            		lv_inputFrq_6_0, 
            	            		"zf.pios.Configurator.InputConfigSubsystemFrq");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 6 :
            	    // InternalConfigurator.g:1896:4: ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:1896:4: ({...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) ) )
            	    // InternalConfigurator.g:1897:5: {...}? => ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 5) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 5)");
            	    }
            	    // InternalConfigurator.g:1897:112: ( ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) ) )
            	    // InternalConfigurator.g:1898:6: ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1(), 5);
            	    	 				
            	    // InternalConfigurator.g:1901:6: ({...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) ) )
            	    // InternalConfigurator.g:1901:7: {...}? => ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleInputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:1901:16: ( (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI ) )
            	    // InternalConfigurator.g:1902:1: (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI )
            	    {
            	    // InternalConfigurator.g:1902:1: (lv_inputSPI_7_0= ruleInputConfigSubsystemSPI )
            	    // InternalConfigurator.g:1903:3: lv_inputSPI_7_0= ruleInputConfigSubsystemSPI
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputSubsystemsAccess().getInputSPIInputConfigSubsystemSPIParserRuleCall_1_5_0()); 
            	    	    
            	    pushFollow(FOLLOW_50);
            	    lv_inputSPI_7_0=ruleInputConfigSubsystemSPI();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"inputSPI",
            	            		lv_inputSPI_7_0, 
            	            		"zf.pios.Configurator.InputConfigSubsystemSPI");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop34;
                }
            } while (true);


            }


            }

             
            	  getUnorderedGroupHelper().leave(grammarAccess.getInputSubsystemsAccess().getUnorderedGroup_1());
            	

            }

            // InternalConfigurator.g:1933:2: ( (lv_inputConfigSubsystem_8_0= ruleInputConfigSubsystemItem ) )*
            loop35:
            do {
                int alt35=2;
                int LA35_0 = input.LA(1);

                if ( (LA35_0==55) ) {
                    alt35=1;
                }


                switch (alt35) {
            	case 1 :
            	    // InternalConfigurator.g:1934:1: (lv_inputConfigSubsystem_8_0= ruleInputConfigSubsystemItem )
            	    {
            	    // InternalConfigurator.g:1934:1: (lv_inputConfigSubsystem_8_0= ruleInputConfigSubsystemItem )
            	    // InternalConfigurator.g:1935:3: lv_inputConfigSubsystem_8_0= ruleInputConfigSubsystemItem
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputSubsystemsAccess().getInputConfigSubsystemInputConfigSubsystemItemParserRuleCall_2_0()); 
            	    	    
            	    pushFollow(FOLLOW_51);
            	    lv_inputConfigSubsystem_8_0=ruleInputConfigSubsystemItem();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputSubsystemsRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"inputConfigSubsystem",
            	            		lv_inputConfigSubsystem_8_0, 
            	            		"zf.pios.Configurator.InputConfigSubsystemItem");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop35;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputSubsystems"


    // $ANTLR start "entryRuleOutputSubsystems"
    // InternalConfigurator.g:1959:1: entryRuleOutputSubsystems returns [EObject current=null] : iv_ruleOutputSubsystems= ruleOutputSubsystems EOF ;
    public final EObject entryRuleOutputSubsystems() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputSubsystems = null;


        try {
            // InternalConfigurator.g:1960:2: (iv_ruleOutputSubsystems= ruleOutputSubsystems EOF )
            // InternalConfigurator.g:1961:2: iv_ruleOutputSubsystems= ruleOutputSubsystems EOF
            {
             newCompositeNode(grammarAccess.getOutputSubsystemsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputSubsystems=ruleOutputSubsystems();

            state._fsp--;

             current =iv_ruleOutputSubsystems; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputSubsystems"


    // $ANTLR start "ruleOutputSubsystems"
    // InternalConfigurator.g:1968:1: ruleOutputSubsystems returns [EObject current=null] : ( () ( ( ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* ) ) ) ( (lv_outputConfigSubsystem_6_0= ruleOutputConfigSubsystemItem ) )* ) ;
    public final EObject ruleOutputSubsystems() throws RecognitionException {
        EObject current = null;

        EObject lv_outputNull_2_0 = null;

        EObject lv_outputDigital_3_0 = null;

        EObject lv_outputPWM_4_0 = null;

        EObject lv_outputElDiag_5_0 = null;

        EObject lv_outputConfigSubsystem_6_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:1971:28: ( ( () ( ( ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* ) ) ) ( (lv_outputConfigSubsystem_6_0= ruleOutputConfigSubsystemItem ) )* ) )
            // InternalConfigurator.g:1972:1: ( () ( ( ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* ) ) ) ( (lv_outputConfigSubsystem_6_0= ruleOutputConfigSubsystemItem ) )* )
            {
            // InternalConfigurator.g:1972:1: ( () ( ( ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* ) ) ) ( (lv_outputConfigSubsystem_6_0= ruleOutputConfigSubsystemItem ) )* )
            // InternalConfigurator.g:1972:2: () ( ( ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* ) ) ) ( (lv_outputConfigSubsystem_6_0= ruleOutputConfigSubsystemItem ) )*
            {
            // InternalConfigurator.g:1972:2: ()
            // InternalConfigurator.g:1973:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getOutputSubsystemsAccess().getOutputSubsystemsAction_0(),
                        current);
                

            }

            // InternalConfigurator.g:1978:2: ( ( ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* ) ) )
            // InternalConfigurator.g:1980:1: ( ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* ) )
            {
            // InternalConfigurator.g:1980:1: ( ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* ) )
            // InternalConfigurator.g:1981:2: ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* )
            {
             
            	  getUnorderedGroupHelper().enter(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1());
            	
            // InternalConfigurator.g:1984:2: ( ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )* )
            // InternalConfigurator.g:1985:3: ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )*
            {
            // InternalConfigurator.g:1985:3: ( ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) ) | ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) ) )*
            loop36:
            do {
                int alt36=5;
                int LA36_0 = input.LA(1);

                if ( LA36_0 == 45 && getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 0) ) {
                    alt36=1;
                }
                else if ( LA36_0 == 54 && getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 1) ) {
                    alt36=2;
                }
                else if ( LA36_0 == 53 && getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 2) ) {
                    alt36=3;
                }
                else if ( LA36_0 == 48 && getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 3) ) {
                    alt36=4;
                }


                switch (alt36) {
            	case 1 :
            	    // InternalConfigurator.g:1987:4: ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:1987:4: ({...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) ) )
            	    // InternalConfigurator.g:1988:5: {...}? => ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 0) ) {
            	        throw new FailedPredicateException(input, "ruleOutputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 0)");
            	    }
            	    // InternalConfigurator.g:1988:113: ( ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) ) )
            	    // InternalConfigurator.g:1989:6: ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 0);
            	    	 				
            	    // InternalConfigurator.g:1992:6: ({...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) ) )
            	    // InternalConfigurator.g:1992:7: {...}? => ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleOutputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:1992:16: ( (lv_outputNull_2_0= ruleOutputConfigSubsystemNull ) )
            	    // InternalConfigurator.g:1993:1: (lv_outputNull_2_0= ruleOutputConfigSubsystemNull )
            	    {
            	    // InternalConfigurator.g:1993:1: (lv_outputNull_2_0= ruleOutputConfigSubsystemNull )
            	    // InternalConfigurator.g:1994:3: lv_outputNull_2_0= ruleOutputConfigSubsystemNull
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOutputSubsystemsAccess().getOutputNullOutputConfigSubsystemNullParserRuleCall_1_0_0()); 
            	    	    
            	    pushFollow(FOLLOW_52);
            	    lv_outputNull_2_0=ruleOutputConfigSubsystemNull();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOutputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"outputNull",
            	            		lv_outputNull_2_0, 
            	            		"zf.pios.Configurator.OutputConfigSubsystemNull");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // InternalConfigurator.g:2017:4: ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:2017:4: ({...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) ) )
            	    // InternalConfigurator.g:2018:5: {...}? => ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 1) ) {
            	        throw new FailedPredicateException(input, "ruleOutputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 1)");
            	    }
            	    // InternalConfigurator.g:2018:113: ( ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) ) )
            	    // InternalConfigurator.g:2019:6: ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 1);
            	    	 				
            	    // InternalConfigurator.g:2022:6: ({...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) ) )
            	    // InternalConfigurator.g:2022:7: {...}? => ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleOutputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:2022:16: ( (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital ) )
            	    // InternalConfigurator.g:2023:1: (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital )
            	    {
            	    // InternalConfigurator.g:2023:1: (lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital )
            	    // InternalConfigurator.g:2024:3: lv_outputDigital_3_0= ruleOutputConfigSubsystemDigital
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOutputSubsystemsAccess().getOutputDigitalOutputConfigSubsystemDigitalParserRuleCall_1_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_52);
            	    lv_outputDigital_3_0=ruleOutputConfigSubsystemDigital();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOutputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"outputDigital",
            	            		lv_outputDigital_3_0, 
            	            		"zf.pios.Configurator.OutputConfigSubsystemDigital");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 3 :
            	    // InternalConfigurator.g:2047:4: ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:2047:4: ({...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) ) )
            	    // InternalConfigurator.g:2048:5: {...}? => ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 2) ) {
            	        throw new FailedPredicateException(input, "ruleOutputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 2)");
            	    }
            	    // InternalConfigurator.g:2048:113: ( ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) ) )
            	    // InternalConfigurator.g:2049:6: ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 2);
            	    	 				
            	    // InternalConfigurator.g:2052:6: ({...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) ) )
            	    // InternalConfigurator.g:2052:7: {...}? => ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleOutputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:2052:16: ( (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM ) )
            	    // InternalConfigurator.g:2053:1: (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM )
            	    {
            	    // InternalConfigurator.g:2053:1: (lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM )
            	    // InternalConfigurator.g:2054:3: lv_outputPWM_4_0= ruleOutputConfigSubsystemPWM
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOutputSubsystemsAccess().getOutputPWMOutputConfigSubsystemPWMParserRuleCall_1_2_0()); 
            	    	    
            	    pushFollow(FOLLOW_52);
            	    lv_outputPWM_4_0=ruleOutputConfigSubsystemPWM();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOutputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"outputPWM",
            	            		lv_outputPWM_4_0, 
            	            		"zf.pios.Configurator.OutputConfigSubsystemPWM");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;
            	case 4 :
            	    // InternalConfigurator.g:2077:4: ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) )
            	    {
            	    // InternalConfigurator.g:2077:4: ({...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) ) )
            	    // InternalConfigurator.g:2078:5: {...}? => ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) )
            	    {
            	    if ( ! getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 3) ) {
            	        throw new FailedPredicateException(input, "ruleOutputSubsystems", "getUnorderedGroupHelper().canSelect(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 3)");
            	    }
            	    // InternalConfigurator.g:2078:113: ( ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) ) )
            	    // InternalConfigurator.g:2079:6: ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) )
            	    {
            	     
            	    	 				  getUnorderedGroupHelper().select(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1(), 3);
            	    	 				
            	    // InternalConfigurator.g:2082:6: ({...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) ) )
            	    // InternalConfigurator.g:2082:7: {...}? => ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) )
            	    {
            	    if ( !((true)) ) {
            	        throw new FailedPredicateException(input, "ruleOutputSubsystems", "true");
            	    }
            	    // InternalConfigurator.g:2082:16: ( (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag ) )
            	    // InternalConfigurator.g:2083:1: (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag )
            	    {
            	    // InternalConfigurator.g:2083:1: (lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag )
            	    // InternalConfigurator.g:2084:3: lv_outputElDiag_5_0= ruleOutputConfigSubsystemElDiag
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOutputSubsystemsAccess().getOutputElDiagOutputConfigSubsystemElDiagParserRuleCall_1_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_52);
            	    lv_outputElDiag_5_0=ruleOutputConfigSubsystemElDiag();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOutputSubsystemsRule());
            	    	        }
            	           		set(
            	           			current, 
            	           			"outputElDiag",
            	            		lv_outputElDiag_5_0, 
            	            		"zf.pios.Configurator.OutputConfigSubsystemElDiag");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }

            	     
            	    	 				  getUnorderedGroupHelper().returnFromSelection(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1());
            	    	 				

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop36;
                }
            } while (true);


            }


            }

             
            	  getUnorderedGroupHelper().leave(grammarAccess.getOutputSubsystemsAccess().getUnorderedGroup_1());
            	

            }

            // InternalConfigurator.g:2114:2: ( (lv_outputConfigSubsystem_6_0= ruleOutputConfigSubsystemItem ) )*
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( (LA37_0==56) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // InternalConfigurator.g:2115:1: (lv_outputConfigSubsystem_6_0= ruleOutputConfigSubsystemItem )
            	    {
            	    // InternalConfigurator.g:2115:1: (lv_outputConfigSubsystem_6_0= ruleOutputConfigSubsystemItem )
            	    // InternalConfigurator.g:2116:3: lv_outputConfigSubsystem_6_0= ruleOutputConfigSubsystemItem
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOutputSubsystemsAccess().getOutputConfigSubsystemOutputConfigSubsystemItemParserRuleCall_2_0()); 
            	    	    
            	    pushFollow(FOLLOW_53);
            	    lv_outputConfigSubsystem_6_0=ruleOutputConfigSubsystemItem();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOutputSubsystemsRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"outputConfigSubsystem",
            	            		lv_outputConfigSubsystem_6_0, 
            	            		"zf.pios.Configurator.OutputConfigSubsystemItem");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop37;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputSubsystems"


    // $ANTLR start "entryRuleInputConfigSubsystemNull"
    // InternalConfigurator.g:2140:1: entryRuleInputConfigSubsystemNull returns [EObject current=null] : iv_ruleInputConfigSubsystemNull= ruleInputConfigSubsystemNull EOF ;
    public final EObject entryRuleInputConfigSubsystemNull() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputConfigSubsystemNull = null;


        try {
            // InternalConfigurator.g:2141:2: (iv_ruleInputConfigSubsystemNull= ruleInputConfigSubsystemNull EOF )
            // InternalConfigurator.g:2142:2: iv_ruleInputConfigSubsystemNull= ruleInputConfigSubsystemNull EOF
            {
             newCompositeNode(grammarAccess.getInputConfigSubsystemNullRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputConfigSubsystemNull=ruleInputConfigSubsystemNull();

            state._fsp--;

             current =iv_ruleInputConfigSubsystemNull; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputConfigSubsystemNull"


    // $ANTLR start "ruleInputConfigSubsystemNull"
    // InternalConfigurator.g:2149:1: ruleInputConfigSubsystemNull returns [EObject current=null] : (otherlv_0= 'NameINull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleInputConfigSubsystemNull() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2152:28: ( (otherlv_0= 'NameINull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:2153:1: (otherlv_0= 'NameINull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:2153:1: (otherlv_0= 'NameINull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:2153:3: otherlv_0= 'NameINull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,43,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInputConfigSubsystemNullAccess().getNameINullKeyword_0());
                
            // InternalConfigurator.g:2157:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2158:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2158:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2159:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getInputConfigSubsystemNullAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemNullRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getInputConfigSubsystemNullAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getInputConfigSubsystemNullAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:2183:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:2184:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:2184:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:2185:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getInputConfigSubsystemNullAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemNullRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getInputConfigSubsystemNullAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputConfigSubsystemNull"


    // $ANTLR start "entryRuleOutputConfigSubsystemNull"
    // InternalConfigurator.g:2213:1: entryRuleOutputConfigSubsystemNull returns [EObject current=null] : iv_ruleOutputConfigSubsystemNull= ruleOutputConfigSubsystemNull EOF ;
    public final EObject entryRuleOutputConfigSubsystemNull() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputConfigSubsystemNull = null;


        try {
            // InternalConfigurator.g:2214:2: (iv_ruleOutputConfigSubsystemNull= ruleOutputConfigSubsystemNull EOF )
            // InternalConfigurator.g:2215:2: iv_ruleOutputConfigSubsystemNull= ruleOutputConfigSubsystemNull EOF
            {
             newCompositeNode(grammarAccess.getOutputConfigSubsystemNullRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputConfigSubsystemNull=ruleOutputConfigSubsystemNull();

            state._fsp--;

             current =iv_ruleOutputConfigSubsystemNull; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputConfigSubsystemNull"


    // $ANTLR start "ruleOutputConfigSubsystemNull"
    // InternalConfigurator.g:2222:1: ruleOutputConfigSubsystemNull returns [EObject current=null] : (otherlv_0= 'NameONull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleOutputConfigSubsystemNull() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2225:28: ( (otherlv_0= 'NameONull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:2226:1: (otherlv_0= 'NameONull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:2226:1: (otherlv_0= 'NameONull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:2226:3: otherlv_0= 'NameONull' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,45,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getOutputConfigSubsystemNullAccess().getNameONullKeyword_0());
                
            // InternalConfigurator.g:2230:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2231:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2231:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2232:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getOutputConfigSubsystemNullAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemNullRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getOutputConfigSubsystemNullAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getOutputConfigSubsystemNullAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:2256:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:2257:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:2257:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:2258:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getOutputConfigSubsystemNullAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemNullRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getOutputConfigSubsystemNullAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputConfigSubsystemNull"


    // $ANTLR start "entryRuleInputDriverType"
    // InternalConfigurator.g:2288:1: entryRuleInputDriverType returns [EObject current=null] : iv_ruleInputDriverType= ruleInputDriverType EOF ;
    public final EObject entryRuleInputDriverType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputDriverType = null;


        try {
            // InternalConfigurator.g:2289:2: (iv_ruleInputDriverType= ruleInputDriverType EOF )
            // InternalConfigurator.g:2290:2: iv_ruleInputDriverType= ruleInputDriverType EOF
            {
             newCompositeNode(grammarAccess.getInputDriverTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputDriverType=ruleInputDriverType();

            state._fsp--;

             current =iv_ruleInputDriverType; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputDriverType"


    // $ANTLR start "ruleInputDriverType"
    // InternalConfigurator.g:2297:1: ruleInputDriverType returns [EObject current=null] : (this_InputConfigSubsystemNull_0= ruleInputConfigSubsystemNull | this_InputConfigSubsystemAnalog_1= ruleInputConfigSubsystemAnalog | this_InputConfigSubsystemTemperature_2= ruleInputConfigSubsystemTemperature | this_InputConfigSubsystemSPI_3= ruleInputConfigSubsystemSPI | this_InputConfigSubsystemDigital_4= ruleInputConfigSubsystemDigital | this_InputConfigSubsystemFrq_5= ruleInputConfigSubsystemFrq | this_InputConfigSubsystemItem_6= ruleInputConfigSubsystemItem ) ;
    public final EObject ruleInputDriverType() throws RecognitionException {
        EObject current = null;

        EObject this_InputConfigSubsystemNull_0 = null;

        EObject this_InputConfigSubsystemAnalog_1 = null;

        EObject this_InputConfigSubsystemTemperature_2 = null;

        EObject this_InputConfigSubsystemSPI_3 = null;

        EObject this_InputConfigSubsystemDigital_4 = null;

        EObject this_InputConfigSubsystemFrq_5 = null;

        EObject this_InputConfigSubsystemItem_6 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:2300:28: ( (this_InputConfigSubsystemNull_0= ruleInputConfigSubsystemNull | this_InputConfigSubsystemAnalog_1= ruleInputConfigSubsystemAnalog | this_InputConfigSubsystemTemperature_2= ruleInputConfigSubsystemTemperature | this_InputConfigSubsystemSPI_3= ruleInputConfigSubsystemSPI | this_InputConfigSubsystemDigital_4= ruleInputConfigSubsystemDigital | this_InputConfigSubsystemFrq_5= ruleInputConfigSubsystemFrq | this_InputConfigSubsystemItem_6= ruleInputConfigSubsystemItem ) )
            // InternalConfigurator.g:2301:1: (this_InputConfigSubsystemNull_0= ruleInputConfigSubsystemNull | this_InputConfigSubsystemAnalog_1= ruleInputConfigSubsystemAnalog | this_InputConfigSubsystemTemperature_2= ruleInputConfigSubsystemTemperature | this_InputConfigSubsystemSPI_3= ruleInputConfigSubsystemSPI | this_InputConfigSubsystemDigital_4= ruleInputConfigSubsystemDigital | this_InputConfigSubsystemFrq_5= ruleInputConfigSubsystemFrq | this_InputConfigSubsystemItem_6= ruleInputConfigSubsystemItem )
            {
            // InternalConfigurator.g:2301:1: (this_InputConfigSubsystemNull_0= ruleInputConfigSubsystemNull | this_InputConfigSubsystemAnalog_1= ruleInputConfigSubsystemAnalog | this_InputConfigSubsystemTemperature_2= ruleInputConfigSubsystemTemperature | this_InputConfigSubsystemSPI_3= ruleInputConfigSubsystemSPI | this_InputConfigSubsystemDigital_4= ruleInputConfigSubsystemDigital | this_InputConfigSubsystemFrq_5= ruleInputConfigSubsystemFrq | this_InputConfigSubsystemItem_6= ruleInputConfigSubsystemItem )
            int alt38=7;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt38=1;
                }
                break;
            case 46:
                {
                alt38=2;
                }
                break;
            case 47:
                {
                alt38=3;
                }
                break;
            case 50:
                {
                alt38=4;
                }
                break;
            case 51:
                {
                alt38=5;
                }
                break;
            case 52:
                {
                alt38=6;
                }
                break;
            case 55:
                {
                alt38=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }

            switch (alt38) {
                case 1 :
                    // InternalConfigurator.g:2302:5: this_InputConfigSubsystemNull_0= ruleInputConfigSubsystemNull
                    {
                     
                            newCompositeNode(grammarAccess.getInputDriverTypeAccess().getInputConfigSubsystemNullParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_2);
                    this_InputConfigSubsystemNull_0=ruleInputConfigSubsystemNull();

                    state._fsp--;

                     
                            current = this_InputConfigSubsystemNull_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:2312:5: this_InputConfigSubsystemAnalog_1= ruleInputConfigSubsystemAnalog
                    {
                     
                            newCompositeNode(grammarAccess.getInputDriverTypeAccess().getInputConfigSubsystemAnalogParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_2);
                    this_InputConfigSubsystemAnalog_1=ruleInputConfigSubsystemAnalog();

                    state._fsp--;

                     
                            current = this_InputConfigSubsystemAnalog_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 3 :
                    // InternalConfigurator.g:2322:5: this_InputConfigSubsystemTemperature_2= ruleInputConfigSubsystemTemperature
                    {
                     
                            newCompositeNode(grammarAccess.getInputDriverTypeAccess().getInputConfigSubsystemTemperatureParserRuleCall_2()); 
                        
                    pushFollow(FOLLOW_2);
                    this_InputConfigSubsystemTemperature_2=ruleInputConfigSubsystemTemperature();

                    state._fsp--;

                     
                            current = this_InputConfigSubsystemTemperature_2; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 4 :
                    // InternalConfigurator.g:2332:5: this_InputConfigSubsystemSPI_3= ruleInputConfigSubsystemSPI
                    {
                     
                            newCompositeNode(grammarAccess.getInputDriverTypeAccess().getInputConfigSubsystemSPIParserRuleCall_3()); 
                        
                    pushFollow(FOLLOW_2);
                    this_InputConfigSubsystemSPI_3=ruleInputConfigSubsystemSPI();

                    state._fsp--;

                     
                            current = this_InputConfigSubsystemSPI_3; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 5 :
                    // InternalConfigurator.g:2342:5: this_InputConfigSubsystemDigital_4= ruleInputConfigSubsystemDigital
                    {
                     
                            newCompositeNode(grammarAccess.getInputDriverTypeAccess().getInputConfigSubsystemDigitalParserRuleCall_4()); 
                        
                    pushFollow(FOLLOW_2);
                    this_InputConfigSubsystemDigital_4=ruleInputConfigSubsystemDigital();

                    state._fsp--;

                     
                            current = this_InputConfigSubsystemDigital_4; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 6 :
                    // InternalConfigurator.g:2352:5: this_InputConfigSubsystemFrq_5= ruleInputConfigSubsystemFrq
                    {
                     
                            newCompositeNode(grammarAccess.getInputDriverTypeAccess().getInputConfigSubsystemFrqParserRuleCall_5()); 
                        
                    pushFollow(FOLLOW_2);
                    this_InputConfigSubsystemFrq_5=ruleInputConfigSubsystemFrq();

                    state._fsp--;

                     
                            current = this_InputConfigSubsystemFrq_5; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 7 :
                    // InternalConfigurator.g:2362:5: this_InputConfigSubsystemItem_6= ruleInputConfigSubsystemItem
                    {
                     
                            newCompositeNode(grammarAccess.getInputDriverTypeAccess().getInputConfigSubsystemItemParserRuleCall_6()); 
                        
                    pushFollow(FOLLOW_2);
                    this_InputConfigSubsystemItem_6=ruleInputConfigSubsystemItem();

                    state._fsp--;

                     
                            current = this_InputConfigSubsystemItem_6; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputDriverType"


    // $ANTLR start "entryRuleOutputDriverType"
    // InternalConfigurator.g:2378:1: entryRuleOutputDriverType returns [EObject current=null] : iv_ruleOutputDriverType= ruleOutputDriverType EOF ;
    public final EObject entryRuleOutputDriverType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputDriverType = null;


        try {
            // InternalConfigurator.g:2379:2: (iv_ruleOutputDriverType= ruleOutputDriverType EOF )
            // InternalConfigurator.g:2380:2: iv_ruleOutputDriverType= ruleOutputDriverType EOF
            {
             newCompositeNode(grammarAccess.getOutputDriverTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputDriverType=ruleOutputDriverType();

            state._fsp--;

             current =iv_ruleOutputDriverType; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputDriverType"


    // $ANTLR start "ruleOutputDriverType"
    // InternalConfigurator.g:2387:1: ruleOutputDriverType returns [EObject current=null] : (this_OutputConfigSubsystemNull_0= ruleOutputConfigSubsystemNull | this_OutputConfigSubsystemDigital_1= ruleOutputConfigSubsystemDigital | this_OutputConfigSubsystemItem_2= ruleOutputConfigSubsystemItem | this_OutputConfigSubsystemElDiag_3= ruleOutputConfigSubsystemElDiag | this_OutputConfigSubsystemPWM_4= ruleOutputConfigSubsystemPWM ) ;
    public final EObject ruleOutputDriverType() throws RecognitionException {
        EObject current = null;

        EObject this_OutputConfigSubsystemNull_0 = null;

        EObject this_OutputConfigSubsystemDigital_1 = null;

        EObject this_OutputConfigSubsystemItem_2 = null;

        EObject this_OutputConfigSubsystemElDiag_3 = null;

        EObject this_OutputConfigSubsystemPWM_4 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:2390:28: ( (this_OutputConfigSubsystemNull_0= ruleOutputConfigSubsystemNull | this_OutputConfigSubsystemDigital_1= ruleOutputConfigSubsystemDigital | this_OutputConfigSubsystemItem_2= ruleOutputConfigSubsystemItem | this_OutputConfigSubsystemElDiag_3= ruleOutputConfigSubsystemElDiag | this_OutputConfigSubsystemPWM_4= ruleOutputConfigSubsystemPWM ) )
            // InternalConfigurator.g:2391:1: (this_OutputConfigSubsystemNull_0= ruleOutputConfigSubsystemNull | this_OutputConfigSubsystemDigital_1= ruleOutputConfigSubsystemDigital | this_OutputConfigSubsystemItem_2= ruleOutputConfigSubsystemItem | this_OutputConfigSubsystemElDiag_3= ruleOutputConfigSubsystemElDiag | this_OutputConfigSubsystemPWM_4= ruleOutputConfigSubsystemPWM )
            {
            // InternalConfigurator.g:2391:1: (this_OutputConfigSubsystemNull_0= ruleOutputConfigSubsystemNull | this_OutputConfigSubsystemDigital_1= ruleOutputConfigSubsystemDigital | this_OutputConfigSubsystemItem_2= ruleOutputConfigSubsystemItem | this_OutputConfigSubsystemElDiag_3= ruleOutputConfigSubsystemElDiag | this_OutputConfigSubsystemPWM_4= ruleOutputConfigSubsystemPWM )
            int alt39=5;
            switch ( input.LA(1) ) {
            case 45:
                {
                alt39=1;
                }
                break;
            case 54:
                {
                alt39=2;
                }
                break;
            case 56:
                {
                alt39=3;
                }
                break;
            case 48:
                {
                alt39=4;
                }
                break;
            case 53:
                {
                alt39=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 39, 0, input);

                throw nvae;
            }

            switch (alt39) {
                case 1 :
                    // InternalConfigurator.g:2392:5: this_OutputConfigSubsystemNull_0= ruleOutputConfigSubsystemNull
                    {
                     
                            newCompositeNode(grammarAccess.getOutputDriverTypeAccess().getOutputConfigSubsystemNullParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_2);
                    this_OutputConfigSubsystemNull_0=ruleOutputConfigSubsystemNull();

                    state._fsp--;

                     
                            current = this_OutputConfigSubsystemNull_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:2402:5: this_OutputConfigSubsystemDigital_1= ruleOutputConfigSubsystemDigital
                    {
                     
                            newCompositeNode(grammarAccess.getOutputDriverTypeAccess().getOutputConfigSubsystemDigitalParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_2);
                    this_OutputConfigSubsystemDigital_1=ruleOutputConfigSubsystemDigital();

                    state._fsp--;

                     
                            current = this_OutputConfigSubsystemDigital_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 3 :
                    // InternalConfigurator.g:2412:5: this_OutputConfigSubsystemItem_2= ruleOutputConfigSubsystemItem
                    {
                     
                            newCompositeNode(grammarAccess.getOutputDriverTypeAccess().getOutputConfigSubsystemItemParserRuleCall_2()); 
                        
                    pushFollow(FOLLOW_2);
                    this_OutputConfigSubsystemItem_2=ruleOutputConfigSubsystemItem();

                    state._fsp--;

                     
                            current = this_OutputConfigSubsystemItem_2; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 4 :
                    // InternalConfigurator.g:2422:5: this_OutputConfigSubsystemElDiag_3= ruleOutputConfigSubsystemElDiag
                    {
                     
                            newCompositeNode(grammarAccess.getOutputDriverTypeAccess().getOutputConfigSubsystemElDiagParserRuleCall_3()); 
                        
                    pushFollow(FOLLOW_2);
                    this_OutputConfigSubsystemElDiag_3=ruleOutputConfigSubsystemElDiag();

                    state._fsp--;

                     
                            current = this_OutputConfigSubsystemElDiag_3; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 5 :
                    // InternalConfigurator.g:2432:5: this_OutputConfigSubsystemPWM_4= ruleOutputConfigSubsystemPWM
                    {
                     
                            newCompositeNode(grammarAccess.getOutputDriverTypeAccess().getOutputConfigSubsystemPWMParserRuleCall_4()); 
                        
                    pushFollow(FOLLOW_2);
                    this_OutputConfigSubsystemPWM_4=ruleOutputConfigSubsystemPWM();

                    state._fsp--;

                     
                            current = this_OutputConfigSubsystemPWM_4; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputDriverType"


    // $ANTLR start "entryRuleInputConfigSubsystemAnalog"
    // InternalConfigurator.g:2448:1: entryRuleInputConfigSubsystemAnalog returns [EObject current=null] : iv_ruleInputConfigSubsystemAnalog= ruleInputConfigSubsystemAnalog EOF ;
    public final EObject entryRuleInputConfigSubsystemAnalog() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputConfigSubsystemAnalog = null;


        try {
            // InternalConfigurator.g:2449:2: (iv_ruleInputConfigSubsystemAnalog= ruleInputConfigSubsystemAnalog EOF )
            // InternalConfigurator.g:2450:2: iv_ruleInputConfigSubsystemAnalog= ruleInputConfigSubsystemAnalog EOF
            {
             newCompositeNode(grammarAccess.getInputConfigSubsystemAnalogRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputConfigSubsystemAnalog=ruleInputConfigSubsystemAnalog();

            state._fsp--;

             current =iv_ruleInputConfigSubsystemAnalog; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputConfigSubsystemAnalog"


    // $ANTLR start "ruleInputConfigSubsystemAnalog"
    // InternalConfigurator.g:2457:1: ruleInputConfigSubsystemAnalog returns [EObject current=null] : (otherlv_0= 'NameIADC' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleInputConfigSubsystemAnalog() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2460:28: ( (otherlv_0= 'NameIADC' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:2461:1: (otherlv_0= 'NameIADC' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:2461:1: (otherlv_0= 'NameIADC' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:2461:3: otherlv_0= 'NameIADC' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,46,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInputConfigSubsystemAnalogAccess().getNameIADCKeyword_0());
                
            // InternalConfigurator.g:2465:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2466:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2466:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2467:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getInputConfigSubsystemAnalogAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemAnalogRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getInputConfigSubsystemAnalogAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getInputConfigSubsystemAnalogAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:2491:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:2492:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:2492:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:2493:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getInputConfigSubsystemAnalogAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemAnalogRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getInputConfigSubsystemAnalogAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputConfigSubsystemAnalog"


    // $ANTLR start "entryRuleInputConfigSubsystemTemperature"
    // InternalConfigurator.g:2521:1: entryRuleInputConfigSubsystemTemperature returns [EObject current=null] : iv_ruleInputConfigSubsystemTemperature= ruleInputConfigSubsystemTemperature EOF ;
    public final EObject entryRuleInputConfigSubsystemTemperature() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputConfigSubsystemTemperature = null;


        try {
            // InternalConfigurator.g:2522:2: (iv_ruleInputConfigSubsystemTemperature= ruleInputConfigSubsystemTemperature EOF )
            // InternalConfigurator.g:2523:2: iv_ruleInputConfigSubsystemTemperature= ruleInputConfigSubsystemTemperature EOF
            {
             newCompositeNode(grammarAccess.getInputConfigSubsystemTemperatureRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputConfigSubsystemTemperature=ruleInputConfigSubsystemTemperature();

            state._fsp--;

             current =iv_ruleInputConfigSubsystemTemperature; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputConfigSubsystemTemperature"


    // $ANTLR start "ruleInputConfigSubsystemTemperature"
    // InternalConfigurator.g:2530:1: ruleInputConfigSubsystemTemperature returns [EObject current=null] : (otherlv_0= 'NameITemperature' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleInputConfigSubsystemTemperature() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2533:28: ( (otherlv_0= 'NameITemperature' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:2534:1: (otherlv_0= 'NameITemperature' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:2534:1: (otherlv_0= 'NameITemperature' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:2534:3: otherlv_0= 'NameITemperature' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,47,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInputConfigSubsystemTemperatureAccess().getNameITemperatureKeyword_0());
                
            // InternalConfigurator.g:2538:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2539:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2539:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2540:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getInputConfigSubsystemTemperatureAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemTemperatureRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getInputConfigSubsystemTemperatureAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getInputConfigSubsystemTemperatureAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:2564:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:2565:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:2565:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:2566:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getInputConfigSubsystemTemperatureAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemTemperatureRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getInputConfigSubsystemTemperatureAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputConfigSubsystemTemperature"


    // $ANTLR start "entryRuleOutputConfigSubsystemElDiag"
    // InternalConfigurator.g:2594:1: entryRuleOutputConfigSubsystemElDiag returns [EObject current=null] : iv_ruleOutputConfigSubsystemElDiag= ruleOutputConfigSubsystemElDiag EOF ;
    public final EObject entryRuleOutputConfigSubsystemElDiag() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputConfigSubsystemElDiag = null;


        try {
            // InternalConfigurator.g:2595:2: (iv_ruleOutputConfigSubsystemElDiag= ruleOutputConfigSubsystemElDiag EOF )
            // InternalConfigurator.g:2596:2: iv_ruleOutputConfigSubsystemElDiag= ruleOutputConfigSubsystemElDiag EOF
            {
             newCompositeNode(grammarAccess.getOutputConfigSubsystemElDiagRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputConfigSubsystemElDiag=ruleOutputConfigSubsystemElDiag();

            state._fsp--;

             current =iv_ruleOutputConfigSubsystemElDiag; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputConfigSubsystemElDiag"


    // $ANTLR start "ruleOutputConfigSubsystemElDiag"
    // InternalConfigurator.g:2603:1: ruleOutputConfigSubsystemElDiag returns [EObject current=null] : (otherlv_0= 'NameElDiag' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= 'TemperatureSensor' ( ( ruleQualifiedName ) ) otherlv_7= '}' ) ;
    public final EObject ruleOutputConfigSubsystemElDiag() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;
        Token otherlv_7=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2606:28: ( (otherlv_0= 'NameElDiag' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= 'TemperatureSensor' ( ( ruleQualifiedName ) ) otherlv_7= '}' ) )
            // InternalConfigurator.g:2607:1: (otherlv_0= 'NameElDiag' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= 'TemperatureSensor' ( ( ruleQualifiedName ) ) otherlv_7= '}' )
            {
            // InternalConfigurator.g:2607:1: (otherlv_0= 'NameElDiag' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= 'TemperatureSensor' ( ( ruleQualifiedName ) ) otherlv_7= '}' )
            // InternalConfigurator.g:2607:3: otherlv_0= 'NameElDiag' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= 'TemperatureSensor' ( ( ruleQualifiedName ) ) otherlv_7= '}'
            {
            otherlv_0=(Token)match(input,48,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getOutputConfigSubsystemElDiagAccess().getNameElDiagKeyword_0());
                
            // InternalConfigurator.g:2611:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2612:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2612:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2613:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getOutputConfigSubsystemElDiagAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemElDiagRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getOutputConfigSubsystemElDiagAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getOutputConfigSubsystemElDiagAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:2637:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:2638:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:2638:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:2639:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_55); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getOutputConfigSubsystemElDiagAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemElDiagRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,49,FOLLOW_3); 

                	newLeafNode(otherlv_5, grammarAccess.getOutputConfigSubsystemElDiagAccess().getTemperatureSensorKeyword_5());
                
            // InternalConfigurator.g:2659:1: ( ( ruleQualifiedName ) )
            // InternalConfigurator.g:2660:1: ( ruleQualifiedName )
            {
            // InternalConfigurator.g:2660:1: ( ruleQualifiedName )
            // InternalConfigurator.g:2661:3: ruleQualifiedName
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemElDiagRule());
            	        }
                    
             
            	        newCompositeNode(grammarAccess.getOutputConfigSubsystemElDiagAccess().getTempSensorInputSignalCrossReference_6_0()); 
            	    
            pushFollow(FOLLOW_11);
            ruleQualifiedName();

            state._fsp--;

             
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_7=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_7, grammarAccess.getOutputConfigSubsystemElDiagAccess().getRightCurlyBracketKeyword_7());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputConfigSubsystemElDiag"


    // $ANTLR start "entryRuleInputConfigSubsystemSPI"
    // InternalConfigurator.g:2686:1: entryRuleInputConfigSubsystemSPI returns [EObject current=null] : iv_ruleInputConfigSubsystemSPI= ruleInputConfigSubsystemSPI EOF ;
    public final EObject entryRuleInputConfigSubsystemSPI() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputConfigSubsystemSPI = null;


        try {
            // InternalConfigurator.g:2687:2: (iv_ruleInputConfigSubsystemSPI= ruleInputConfigSubsystemSPI EOF )
            // InternalConfigurator.g:2688:2: iv_ruleInputConfigSubsystemSPI= ruleInputConfigSubsystemSPI EOF
            {
             newCompositeNode(grammarAccess.getInputConfigSubsystemSPIRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputConfigSubsystemSPI=ruleInputConfigSubsystemSPI();

            state._fsp--;

             current =iv_ruleInputConfigSubsystemSPI; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputConfigSubsystemSPI"


    // $ANTLR start "ruleInputConfigSubsystemSPI"
    // InternalConfigurator.g:2695:1: ruleInputConfigSubsystemSPI returns [EObject current=null] : (otherlv_0= 'NameSPI' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleInputConfigSubsystemSPI() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2698:28: ( (otherlv_0= 'NameSPI' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:2699:1: (otherlv_0= 'NameSPI' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:2699:1: (otherlv_0= 'NameSPI' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:2699:3: otherlv_0= 'NameSPI' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,50,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInputConfigSubsystemSPIAccess().getNameSPIKeyword_0());
                
            // InternalConfigurator.g:2703:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2704:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2704:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2705:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getInputConfigSubsystemSPIAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemSPIRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getInputConfigSubsystemSPIAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getInputConfigSubsystemSPIAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:2729:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:2730:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:2730:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:2731:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getInputConfigSubsystemSPIAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemSPIRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getInputConfigSubsystemSPIAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputConfigSubsystemSPI"


    // $ANTLR start "entryRuleInputConfigSubsystemDigital"
    // InternalConfigurator.g:2759:1: entryRuleInputConfigSubsystemDigital returns [EObject current=null] : iv_ruleInputConfigSubsystemDigital= ruleInputConfigSubsystemDigital EOF ;
    public final EObject entryRuleInputConfigSubsystemDigital() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputConfigSubsystemDigital = null;


        try {
            // InternalConfigurator.g:2760:2: (iv_ruleInputConfigSubsystemDigital= ruleInputConfigSubsystemDigital EOF )
            // InternalConfigurator.g:2761:2: iv_ruleInputConfigSubsystemDigital= ruleInputConfigSubsystemDigital EOF
            {
             newCompositeNode(grammarAccess.getInputConfigSubsystemDigitalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputConfigSubsystemDigital=ruleInputConfigSubsystemDigital();

            state._fsp--;

             current =iv_ruleInputConfigSubsystemDigital; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputConfigSubsystemDigital"


    // $ANTLR start "ruleInputConfigSubsystemDigital"
    // InternalConfigurator.g:2768:1: ruleInputConfigSubsystemDigital returns [EObject current=null] : (otherlv_0= 'NameIDig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleInputConfigSubsystemDigital() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2771:28: ( (otherlv_0= 'NameIDig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:2772:1: (otherlv_0= 'NameIDig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:2772:1: (otherlv_0= 'NameIDig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:2772:3: otherlv_0= 'NameIDig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,51,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInputConfigSubsystemDigitalAccess().getNameIDigKeyword_0());
                
            // InternalConfigurator.g:2776:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2777:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2777:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2778:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getInputConfigSubsystemDigitalAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemDigitalRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getInputConfigSubsystemDigitalAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getInputConfigSubsystemDigitalAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:2802:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:2803:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:2803:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:2804:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getInputConfigSubsystemDigitalAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemDigitalRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getInputConfigSubsystemDigitalAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputConfigSubsystemDigital"


    // $ANTLR start "entryRuleInputConfigSubsystemFrq"
    // InternalConfigurator.g:2832:1: entryRuleInputConfigSubsystemFrq returns [EObject current=null] : iv_ruleInputConfigSubsystemFrq= ruleInputConfigSubsystemFrq EOF ;
    public final EObject entryRuleInputConfigSubsystemFrq() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputConfigSubsystemFrq = null;


        try {
            // InternalConfigurator.g:2833:2: (iv_ruleInputConfigSubsystemFrq= ruleInputConfigSubsystemFrq EOF )
            // InternalConfigurator.g:2834:2: iv_ruleInputConfigSubsystemFrq= ruleInputConfigSubsystemFrq EOF
            {
             newCompositeNode(grammarAccess.getInputConfigSubsystemFrqRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputConfigSubsystemFrq=ruleInputConfigSubsystemFrq();

            state._fsp--;

             current =iv_ruleInputConfigSubsystemFrq; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputConfigSubsystemFrq"


    // $ANTLR start "ruleInputConfigSubsystemFrq"
    // InternalConfigurator.g:2841:1: ruleInputConfigSubsystemFrq returns [EObject current=null] : (otherlv_0= 'NameIFrq' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleInputConfigSubsystemFrq() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2844:28: ( (otherlv_0= 'NameIFrq' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:2845:1: (otherlv_0= 'NameIFrq' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:2845:1: (otherlv_0= 'NameIFrq' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:2845:3: otherlv_0= 'NameIFrq' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,52,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInputConfigSubsystemFrqAccess().getNameIFrqKeyword_0());
                
            // InternalConfigurator.g:2849:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2850:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2850:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2851:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getInputConfigSubsystemFrqAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemFrqRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getInputConfigSubsystemFrqAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getInputConfigSubsystemFrqAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:2875:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:2876:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:2876:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:2877:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getInputConfigSubsystemFrqAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemFrqRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getInputConfigSubsystemFrqAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputConfigSubsystemFrq"


    // $ANTLR start "entryRuleOutputConfigSubsystemPWM"
    // InternalConfigurator.g:2905:1: entryRuleOutputConfigSubsystemPWM returns [EObject current=null] : iv_ruleOutputConfigSubsystemPWM= ruleOutputConfigSubsystemPWM EOF ;
    public final EObject entryRuleOutputConfigSubsystemPWM() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputConfigSubsystemPWM = null;


        try {
            // InternalConfigurator.g:2906:2: (iv_ruleOutputConfigSubsystemPWM= ruleOutputConfigSubsystemPWM EOF )
            // InternalConfigurator.g:2907:2: iv_ruleOutputConfigSubsystemPWM= ruleOutputConfigSubsystemPWM EOF
            {
             newCompositeNode(grammarAccess.getOutputConfigSubsystemPWMRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputConfigSubsystemPWM=ruleOutputConfigSubsystemPWM();

            state._fsp--;

             current =iv_ruleOutputConfigSubsystemPWM; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputConfigSubsystemPWM"


    // $ANTLR start "ruleOutputConfigSubsystemPWM"
    // InternalConfigurator.g:2914:1: ruleOutputConfigSubsystemPWM returns [EObject current=null] : (otherlv_0= 'NamePWM' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleOutputConfigSubsystemPWM() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2917:28: ( (otherlv_0= 'NamePWM' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:2918:1: (otherlv_0= 'NamePWM' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:2918:1: (otherlv_0= 'NamePWM' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:2918:3: otherlv_0= 'NamePWM' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,53,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getOutputConfigSubsystemPWMAccess().getNamePWMKeyword_0());
                
            // InternalConfigurator.g:2922:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2923:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2923:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2924:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getOutputConfigSubsystemPWMAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemPWMRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getOutputConfigSubsystemPWMAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getOutputConfigSubsystemPWMAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:2948:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:2949:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:2949:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:2950:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getOutputConfigSubsystemPWMAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemPWMRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getOutputConfigSubsystemPWMAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputConfigSubsystemPWM"


    // $ANTLR start "entryRuleOutputConfigSubsystemDigital"
    // InternalConfigurator.g:2978:1: entryRuleOutputConfigSubsystemDigital returns [EObject current=null] : iv_ruleOutputConfigSubsystemDigital= ruleOutputConfigSubsystemDigital EOF ;
    public final EObject entryRuleOutputConfigSubsystemDigital() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputConfigSubsystemDigital = null;


        try {
            // InternalConfigurator.g:2979:2: (iv_ruleOutputConfigSubsystemDigital= ruleOutputConfigSubsystemDigital EOF )
            // InternalConfigurator.g:2980:2: iv_ruleOutputConfigSubsystemDigital= ruleOutputConfigSubsystemDigital EOF
            {
             newCompositeNode(grammarAccess.getOutputConfigSubsystemDigitalRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputConfigSubsystemDigital=ruleOutputConfigSubsystemDigital();

            state._fsp--;

             current =iv_ruleOutputConfigSubsystemDigital; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputConfigSubsystemDigital"


    // $ANTLR start "ruleOutputConfigSubsystemDigital"
    // InternalConfigurator.g:2987:1: ruleOutputConfigSubsystemDigital returns [EObject current=null] : (otherlv_0= 'NameODig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleOutputConfigSubsystemDigital() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:2990:28: ( (otherlv_0= 'NameODig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:2991:1: (otherlv_0= 'NameODig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:2991:1: (otherlv_0= 'NameODig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:2991:3: otherlv_0= 'NameODig' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,54,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getOutputConfigSubsystemDigitalAccess().getNameODigKeyword_0());
                
            // InternalConfigurator.g:2995:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:2996:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:2996:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:2997:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getOutputConfigSubsystemDigitalAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemDigitalRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getOutputConfigSubsystemDigitalAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getOutputConfigSubsystemDigitalAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:3021:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:3022:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:3022:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:3023:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getOutputConfigSubsystemDigitalAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemDigitalRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getOutputConfigSubsystemDigitalAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputConfigSubsystemDigital"


    // $ANTLR start "entryRuleInputConfigSubsystemItem"
    // InternalConfigurator.g:3051:1: entryRuleInputConfigSubsystemItem returns [EObject current=null] : iv_ruleInputConfigSubsystemItem= ruleInputConfigSubsystemItem EOF ;
    public final EObject entryRuleInputConfigSubsystemItem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputConfigSubsystemItem = null;


        try {
            // InternalConfigurator.g:3052:2: (iv_ruleInputConfigSubsystemItem= ruleInputConfigSubsystemItem EOF )
            // InternalConfigurator.g:3053:2: iv_ruleInputConfigSubsystemItem= ruleInputConfigSubsystemItem EOF
            {
             newCompositeNode(grammarAccess.getInputConfigSubsystemItemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputConfigSubsystemItem=ruleInputConfigSubsystemItem();

            state._fsp--;

             current =iv_ruleInputConfigSubsystemItem; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputConfigSubsystemItem"


    // $ANTLR start "ruleInputConfigSubsystemItem"
    // InternalConfigurator.g:3060:1: ruleInputConfigSubsystemItem returns [EObject current=null] : (otherlv_0= 'NameIUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleInputConfigSubsystemItem() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:3063:28: ( (otherlv_0= 'NameIUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:3064:1: (otherlv_0= 'NameIUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:3064:1: (otherlv_0= 'NameIUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:3064:3: otherlv_0= 'NameIUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,55,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInputConfigSubsystemItemAccess().getNameIUserKeyword_0());
                
            // InternalConfigurator.g:3068:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:3069:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:3069:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:3070:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getInputConfigSubsystemItemAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemItemRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getInputConfigSubsystemItemAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getInputConfigSubsystemItemAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:3094:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:3095:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:3095:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:3096:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getInputConfigSubsystemItemAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInputConfigSubsystemItemRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getInputConfigSubsystemItemAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputConfigSubsystemItem"


    // $ANTLR start "entryRuleOutputConfigSubsystemItem"
    // InternalConfigurator.g:3124:1: entryRuleOutputConfigSubsystemItem returns [EObject current=null] : iv_ruleOutputConfigSubsystemItem= ruleOutputConfigSubsystemItem EOF ;
    public final EObject entryRuleOutputConfigSubsystemItem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputConfigSubsystemItem = null;


        try {
            // InternalConfigurator.g:3125:2: (iv_ruleOutputConfigSubsystemItem= ruleOutputConfigSubsystemItem EOF )
            // InternalConfigurator.g:3126:2: iv_ruleOutputConfigSubsystemItem= ruleOutputConfigSubsystemItem EOF
            {
             newCompositeNode(grammarAccess.getOutputConfigSubsystemItemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputConfigSubsystemItem=ruleOutputConfigSubsystemItem();

            state._fsp--;

             current =iv_ruleOutputConfigSubsystemItem; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputConfigSubsystemItem"


    // $ANTLR start "ruleOutputConfigSubsystemItem"
    // InternalConfigurator.g:3133:1: ruleOutputConfigSubsystemItem returns [EObject current=null] : (otherlv_0= 'NameOUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) ;
    public final EObject ruleOutputConfigSubsystemItem() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_sortingIndex_4_0=null;
        Token otherlv_5=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:3136:28: ( (otherlv_0= 'NameOUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' ) )
            // InternalConfigurator.g:3137:1: (otherlv_0= 'NameOUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            {
            // InternalConfigurator.g:3137:1: (otherlv_0= 'NameOUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}' )
            // InternalConfigurator.g:3137:3: otherlv_0= 'NameOUser' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' otherlv_3= 'SortingIndex' ( (lv_sortingIndex_4_0= RULE_UINT ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,56,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getOutputConfigSubsystemItemAccess().getNameOUserKeyword_0());
                
            // InternalConfigurator.g:3141:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:3142:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:3142:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:3143:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getOutputConfigSubsystemItemAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemItemRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_54); 

                	newLeafNode(otherlv_2, grammarAccess.getOutputConfigSubsystemItemAccess().getLeftCurlyBracketKeyword_2());
                
            otherlv_3=(Token)match(input,44,FOLLOW_46); 

                	newLeafNode(otherlv_3, grammarAccess.getOutputConfigSubsystemItemAccess().getSortingIndexKeyword_3());
                
            // InternalConfigurator.g:3167:1: ( (lv_sortingIndex_4_0= RULE_UINT ) )
            // InternalConfigurator.g:3168:1: (lv_sortingIndex_4_0= RULE_UINT )
            {
            // InternalConfigurator.g:3168:1: (lv_sortingIndex_4_0= RULE_UINT )
            // InternalConfigurator.g:3169:3: lv_sortingIndex_4_0= RULE_UINT
            {
            lv_sortingIndex_4_0=(Token)match(input,RULE_UINT,FOLLOW_11); 

            			newLeafNode(lv_sortingIndex_4_0, grammarAccess.getOutputConfigSubsystemItemAccess().getSortingIndexUINTTerminalRuleCall_4_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutputConfigSubsystemItemRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"sortingIndex",
                    		lv_sortingIndex_4_0, 
                    		"zf.pios.Configurator.UINT");
            	    

            }


            }

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getOutputConfigSubsystemItemAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputConfigSubsystemItem"


    // $ANTLR start "entryRuleDriverToECU"
    // InternalConfigurator.g:3197:1: entryRuleDriverToECU returns [EObject current=null] : iv_ruleDriverToECU= ruleDriverToECU EOF ;
    public final EObject entryRuleDriverToECU() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDriverToECU = null;


        try {
            // InternalConfigurator.g:3198:2: (iv_ruleDriverToECU= ruleDriverToECU EOF )
            // InternalConfigurator.g:3199:2: iv_ruleDriverToECU= ruleDriverToECU EOF
            {
             newCompositeNode(grammarAccess.getDriverToECURule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDriverToECU=ruleDriverToECU();

            state._fsp--;

             current =iv_ruleDriverToECU; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDriverToECU"


    // $ANTLR start "ruleDriverToECU"
    // InternalConfigurator.g:3206:1: ruleDriverToECU returns [EObject current=null] : ( () otherlv_1= 'DriverToECU' otherlv_2= '{' ( (lv_inputAnalogDrivers_3_0= ruleInputAnalogDrivers ) )? ( ( (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers ) ) ( (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable ) ) )? ( ( (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers ) ) ( (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable ) ) )? otherlv_8= '}' ) ;
    public final EObject ruleDriverToECU() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_8=null;
        EObject lv_inputAnalogDrivers_3_0 = null;

        EObject lv_inputDigitalDrivers_4_0 = null;

        EObject lv_inputDigDriversTable_5_0 = null;

        EObject lv_outputDigitalDrivers_6_0 = null;

        EObject lv_outputDigDriversTable_7_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3209:28: ( ( () otherlv_1= 'DriverToECU' otherlv_2= '{' ( (lv_inputAnalogDrivers_3_0= ruleInputAnalogDrivers ) )? ( ( (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers ) ) ( (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable ) ) )? ( ( (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers ) ) ( (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable ) ) )? otherlv_8= '}' ) )
            // InternalConfigurator.g:3210:1: ( () otherlv_1= 'DriverToECU' otherlv_2= '{' ( (lv_inputAnalogDrivers_3_0= ruleInputAnalogDrivers ) )? ( ( (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers ) ) ( (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable ) ) )? ( ( (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers ) ) ( (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable ) ) )? otherlv_8= '}' )
            {
            // InternalConfigurator.g:3210:1: ( () otherlv_1= 'DriverToECU' otherlv_2= '{' ( (lv_inputAnalogDrivers_3_0= ruleInputAnalogDrivers ) )? ( ( (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers ) ) ( (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable ) ) )? ( ( (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers ) ) ( (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable ) ) )? otherlv_8= '}' )
            // InternalConfigurator.g:3210:2: () otherlv_1= 'DriverToECU' otherlv_2= '{' ( (lv_inputAnalogDrivers_3_0= ruleInputAnalogDrivers ) )? ( ( (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers ) ) ( (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable ) ) )? ( ( (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers ) ) ( (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable ) ) )? otherlv_8= '}'
            {
            // InternalConfigurator.g:3210:2: ()
            // InternalConfigurator.g:3211:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getDriverToECUAccess().getDriverToECUAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,57,FOLLOW_4); 

                	newLeafNode(otherlv_1, grammarAccess.getDriverToECUAccess().getDriverToECUKeyword_1());
                
            otherlv_2=(Token)match(input,15,FOLLOW_56); 

                	newLeafNode(otherlv_2, grammarAccess.getDriverToECUAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3224:1: ( (lv_inputAnalogDrivers_3_0= ruleInputAnalogDrivers ) )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==59) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalConfigurator.g:3225:1: (lv_inputAnalogDrivers_3_0= ruleInputAnalogDrivers )
                    {
                    // InternalConfigurator.g:3225:1: (lv_inputAnalogDrivers_3_0= ruleInputAnalogDrivers )
                    // InternalConfigurator.g:3226:3: lv_inputAnalogDrivers_3_0= ruleInputAnalogDrivers
                    {
                     
                    	        newCompositeNode(grammarAccess.getDriverToECUAccess().getInputAnalogDriversInputAnalogDriversParserRuleCall_3_0()); 
                    	    
                    pushFollow(FOLLOW_57);
                    lv_inputAnalogDrivers_3_0=ruleInputAnalogDrivers();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getDriverToECURule());
                    	        }
                           		set(
                           			current, 
                           			"inputAnalogDrivers",
                            		lv_inputAnalogDrivers_3_0, 
                            		"zf.pios.Configurator.InputAnalogDrivers");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:3242:3: ( ( (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers ) ) ( (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable ) ) )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==60) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalConfigurator.g:3242:4: ( (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers ) ) ( (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable ) )
                    {
                    // InternalConfigurator.g:3242:4: ( (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers ) )
                    // InternalConfigurator.g:3243:1: (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers )
                    {
                    // InternalConfigurator.g:3243:1: (lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers )
                    // InternalConfigurator.g:3244:3: lv_inputDigitalDrivers_4_0= ruleInputDigitalDrivers
                    {
                     
                    	        newCompositeNode(grammarAccess.getDriverToECUAccess().getInputDigitalDriversInputDigitalDriversParserRuleCall_4_0_0()); 
                    	    
                    pushFollow(FOLLOW_58);
                    lv_inputDigitalDrivers_4_0=ruleInputDigitalDrivers();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getDriverToECURule());
                    	        }
                           		set(
                           			current, 
                           			"inputDigitalDrivers",
                            		lv_inputDigitalDrivers_4_0, 
                            		"zf.pios.Configurator.InputDigitalDrivers");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }

                    // InternalConfigurator.g:3260:2: ( (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable ) )
                    // InternalConfigurator.g:3261:1: (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable )
                    {
                    // InternalConfigurator.g:3261:1: (lv_inputDigDriversTable_5_0= ruleInputDigDriversTable )
                    // InternalConfigurator.g:3262:3: lv_inputDigDriversTable_5_0= ruleInputDigDriversTable
                    {
                     
                    	        newCompositeNode(grammarAccess.getDriverToECUAccess().getInputDigDriversTableInputDigDriversTableParserRuleCall_4_1_0()); 
                    	    
                    pushFollow(FOLLOW_59);
                    lv_inputDigDriversTable_5_0=ruleInputDigDriversTable();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getDriverToECURule());
                    	        }
                           		set(
                           			current, 
                           			"inputDigDriversTable",
                            		lv_inputDigDriversTable_5_0, 
                            		"zf.pios.Configurator.InputDigDriversTable");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:3278:4: ( ( (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers ) ) ( (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable ) ) )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==61) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalConfigurator.g:3278:5: ( (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers ) ) ( (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable ) )
                    {
                    // InternalConfigurator.g:3278:5: ( (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers ) )
                    // InternalConfigurator.g:3279:1: (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers )
                    {
                    // InternalConfigurator.g:3279:1: (lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers )
                    // InternalConfigurator.g:3280:3: lv_outputDigitalDrivers_6_0= ruleOutputDigitalDrivers
                    {
                     
                    	        newCompositeNode(grammarAccess.getDriverToECUAccess().getOutputDigitalDriversOutputDigitalDriversParserRuleCall_5_0_0()); 
                    	    
                    pushFollow(FOLLOW_60);
                    lv_outputDigitalDrivers_6_0=ruleOutputDigitalDrivers();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getDriverToECURule());
                    	        }
                           		set(
                           			current, 
                           			"outputDigitalDrivers",
                            		lv_outputDigitalDrivers_6_0, 
                            		"zf.pios.Configurator.OutputDigitalDrivers");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }

                    // InternalConfigurator.g:3296:2: ( (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable ) )
                    // InternalConfigurator.g:3297:1: (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable )
                    {
                    // InternalConfigurator.g:3297:1: (lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable )
                    // InternalConfigurator.g:3298:3: lv_outputDigDriversTable_7_0= ruleOutputDigDriversTable
                    {
                     
                    	        newCompositeNode(grammarAccess.getDriverToECUAccess().getOutputDigDriversTableOutputDigDriversTableParserRuleCall_5_1_0()); 
                    	    
                    pushFollow(FOLLOW_11);
                    lv_outputDigDriversTable_7_0=ruleOutputDigDriversTable();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getDriverToECURule());
                    	        }
                           		set(
                           			current, 
                           			"outputDigDriversTable",
                            		lv_outputDigDriversTable_7_0, 
                            		"zf.pios.Configurator.OutputDigDriversTable");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_8, grammarAccess.getDriverToECUAccess().getRightCurlyBracketKeyword_6());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDriverToECU"


    // $ANTLR start "entryRuleTempSensorSubsystem"
    // InternalConfigurator.g:3326:1: entryRuleTempSensorSubsystem returns [EObject current=null] : iv_ruleTempSensorSubsystem= ruleTempSensorSubsystem EOF ;
    public final EObject entryRuleTempSensorSubsystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTempSensorSubsystem = null;


        try {
            // InternalConfigurator.g:3327:2: (iv_ruleTempSensorSubsystem= ruleTempSensorSubsystem EOF )
            // InternalConfigurator.g:3328:2: iv_ruleTempSensorSubsystem= ruleTempSensorSubsystem EOF
            {
             newCompositeNode(grammarAccess.getTempSensorSubsystemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTempSensorSubsystem=ruleTempSensorSubsystem();

            state._fsp--;

             current =iv_ruleTempSensorSubsystem; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTempSensorSubsystem"


    // $ANTLR start "ruleTempSensorSubsystem"
    // InternalConfigurator.g:3335:1: ruleTempSensorSubsystem returns [EObject current=null] : ( () otherlv_1= 'TemperatureSensorSubsystem' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}' ) ;
    public final EObject ruleTempSensorSubsystem() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_driver_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3338:28: ( ( () otherlv_1= 'TemperatureSensorSubsystem' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:3339:1: ( () otherlv_1= 'TemperatureSensorSubsystem' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:3339:1: ( () otherlv_1= 'TemperatureSensorSubsystem' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:3339:2: () otherlv_1= 'TemperatureSensorSubsystem' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}'
            {
            // InternalConfigurator.g:3339:2: ()
            // InternalConfigurator.g:3340:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getTempSensorSubsystemAccess().getTempSensorSubsystemAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,58,FOLLOW_4); 

                	newLeafNode(otherlv_1, grammarAccess.getTempSensorSubsystemAccess().getTemperatureSensorSubsystemKeyword_1());
                
            otherlv_2=(Token)match(input,15,FOLLOW_61); 

                	newLeafNode(otherlv_2, grammarAccess.getTempSensorSubsystemAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3353:1: ( (lv_driver_3_0= ruleAnalogDriver ) )+
            int cnt43=0;
            loop43:
            do {
                int alt43=2;
                int LA43_0 = input.LA(1);

                if ( (LA43_0==62) ) {
                    alt43=1;
                }


                switch (alt43) {
            	case 1 :
            	    // InternalConfigurator.g:3354:1: (lv_driver_3_0= ruleAnalogDriver )
            	    {
            	    // InternalConfigurator.g:3354:1: (lv_driver_3_0= ruleAnalogDriver )
            	    // InternalConfigurator.g:3355:3: lv_driver_3_0= ruleAnalogDriver
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getTempSensorSubsystemAccess().getDriverAnalogDriverParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_62);
            	    lv_driver_3_0=ruleAnalogDriver();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getTempSensorSubsystemRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"driver",
            	            		lv_driver_3_0, 
            	            		"zf.pios.Configurator.AnalogDriver");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt43 >= 1 ) break loop43;
                        EarlyExitException eee =
                            new EarlyExitException(43, input);
                        throw eee;
                }
                cnt43++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getTempSensorSubsystemAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTempSensorSubsystem"


    // $ANTLR start "entryRuleInputAnalogDrivers"
    // InternalConfigurator.g:3383:1: entryRuleInputAnalogDrivers returns [EObject current=null] : iv_ruleInputAnalogDrivers= ruleInputAnalogDrivers EOF ;
    public final EObject entryRuleInputAnalogDrivers() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputAnalogDrivers = null;


        try {
            // InternalConfigurator.g:3384:2: (iv_ruleInputAnalogDrivers= ruleInputAnalogDrivers EOF )
            // InternalConfigurator.g:3385:2: iv_ruleInputAnalogDrivers= ruleInputAnalogDrivers EOF
            {
             newCompositeNode(grammarAccess.getInputAnalogDriversRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputAnalogDrivers=ruleInputAnalogDrivers();

            state._fsp--;

             current =iv_ruleInputAnalogDrivers; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputAnalogDrivers"


    // $ANTLR start "ruleInputAnalogDrivers"
    // InternalConfigurator.g:3392:1: ruleInputAnalogDrivers returns [EObject current=null] : ( () otherlv_1= 'InputAnalogDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}' ) ;
    public final EObject ruleInputAnalogDrivers() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_driver_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3395:28: ( ( () otherlv_1= 'InputAnalogDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:3396:1: ( () otherlv_1= 'InputAnalogDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:3396:1: ( () otherlv_1= 'InputAnalogDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:3396:2: () otherlv_1= 'InputAnalogDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleAnalogDriver ) )+ otherlv_4= '}'
            {
            // InternalConfigurator.g:3396:2: ()
            // InternalConfigurator.g:3397:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getInputAnalogDriversAccess().getInputAnalogDriversAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,59,FOLLOW_4); 

                	newLeafNode(otherlv_1, grammarAccess.getInputAnalogDriversAccess().getInputAnalogDriversKeyword_1());
                
            otherlv_2=(Token)match(input,15,FOLLOW_61); 

                	newLeafNode(otherlv_2, grammarAccess.getInputAnalogDriversAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3410:1: ( (lv_driver_3_0= ruleAnalogDriver ) )+
            int cnt44=0;
            loop44:
            do {
                int alt44=2;
                int LA44_0 = input.LA(1);

                if ( (LA44_0==62) ) {
                    alt44=1;
                }


                switch (alt44) {
            	case 1 :
            	    // InternalConfigurator.g:3411:1: (lv_driver_3_0= ruleAnalogDriver )
            	    {
            	    // InternalConfigurator.g:3411:1: (lv_driver_3_0= ruleAnalogDriver )
            	    // InternalConfigurator.g:3412:3: lv_driver_3_0= ruleAnalogDriver
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputAnalogDriversAccess().getDriverAnalogDriverParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_62);
            	    lv_driver_3_0=ruleAnalogDriver();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputAnalogDriversRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"driver",
            	            		lv_driver_3_0, 
            	            		"zf.pios.Configurator.AnalogDriver");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt44 >= 1 ) break loop44;
                        EarlyExitException eee =
                            new EarlyExitException(44, input);
                        throw eee;
                }
                cnt44++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getInputAnalogDriversAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputAnalogDrivers"


    // $ANTLR start "entryRuleInputDigitalDrivers"
    // InternalConfigurator.g:3440:1: entryRuleInputDigitalDrivers returns [EObject current=null] : iv_ruleInputDigitalDrivers= ruleInputDigitalDrivers EOF ;
    public final EObject entryRuleInputDigitalDrivers() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputDigitalDrivers = null;


        try {
            // InternalConfigurator.g:3441:2: (iv_ruleInputDigitalDrivers= ruleInputDigitalDrivers EOF )
            // InternalConfigurator.g:3442:2: iv_ruleInputDigitalDrivers= ruleInputDigitalDrivers EOF
            {
             newCompositeNode(grammarAccess.getInputDigitalDriversRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputDigitalDrivers=ruleInputDigitalDrivers();

            state._fsp--;

             current =iv_ruleInputDigitalDrivers; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputDigitalDrivers"


    // $ANTLR start "ruleInputDigitalDrivers"
    // InternalConfigurator.g:3449:1: ruleInputDigitalDrivers returns [EObject current=null] : ( () otherlv_1= 'InputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleInDigDriver ) )+ otherlv_4= '}' ) ;
    public final EObject ruleInputDigitalDrivers() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_driver_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3452:28: ( ( () otherlv_1= 'InputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleInDigDriver ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:3453:1: ( () otherlv_1= 'InputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleInDigDriver ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:3453:1: ( () otherlv_1= 'InputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleInDigDriver ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:3453:2: () otherlv_1= 'InputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleInDigDriver ) )+ otherlv_4= '}'
            {
            // InternalConfigurator.g:3453:2: ()
            // InternalConfigurator.g:3454:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getInputDigitalDriversAccess().getInputDigitalDriversAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,60,FOLLOW_4); 

                	newLeafNode(otherlv_1, grammarAccess.getInputDigitalDriversAccess().getInputDigitalDriversKeyword_1());
                
            otherlv_2=(Token)match(input,15,FOLLOW_61); 

                	newLeafNode(otherlv_2, grammarAccess.getInputDigitalDriversAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3467:1: ( (lv_driver_3_0= ruleInDigDriver ) )+
            int cnt45=0;
            loop45:
            do {
                int alt45=2;
                int LA45_0 = input.LA(1);

                if ( (LA45_0==62) ) {
                    alt45=1;
                }


                switch (alt45) {
            	case 1 :
            	    // InternalConfigurator.g:3468:1: (lv_driver_3_0= ruleInDigDriver )
            	    {
            	    // InternalConfigurator.g:3468:1: (lv_driver_3_0= ruleInDigDriver )
            	    // InternalConfigurator.g:3469:3: lv_driver_3_0= ruleInDigDriver
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputDigitalDriversAccess().getDriverInDigDriverParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_62);
            	    lv_driver_3_0=ruleInDigDriver();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputDigitalDriversRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"driver",
            	            		lv_driver_3_0, 
            	            		"zf.pios.Configurator.InDigDriver");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt45 >= 1 ) break loop45;
                        EarlyExitException eee =
                            new EarlyExitException(45, input);
                        throw eee;
                }
                cnt45++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getInputDigitalDriversAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputDigitalDrivers"


    // $ANTLR start "entryRuleOutputDigitalDrivers"
    // InternalConfigurator.g:3497:1: entryRuleOutputDigitalDrivers returns [EObject current=null] : iv_ruleOutputDigitalDrivers= ruleOutputDigitalDrivers EOF ;
    public final EObject entryRuleOutputDigitalDrivers() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputDigitalDrivers = null;


        try {
            // InternalConfigurator.g:3498:2: (iv_ruleOutputDigitalDrivers= ruleOutputDigitalDrivers EOF )
            // InternalConfigurator.g:3499:2: iv_ruleOutputDigitalDrivers= ruleOutputDigitalDrivers EOF
            {
             newCompositeNode(grammarAccess.getOutputDigitalDriversRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputDigitalDrivers=ruleOutputDigitalDrivers();

            state._fsp--;

             current =iv_ruleOutputDigitalDrivers; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputDigitalDrivers"


    // $ANTLR start "ruleOutputDigitalDrivers"
    // InternalConfigurator.g:3506:1: ruleOutputDigitalDrivers returns [EObject current=null] : ( () otherlv_1= 'OutputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleOutDigDriver ) )+ otherlv_4= '}' ) ;
    public final EObject ruleOutputDigitalDrivers() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_driver_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3509:28: ( ( () otherlv_1= 'OutputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleOutDigDriver ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:3510:1: ( () otherlv_1= 'OutputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleOutDigDriver ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:3510:1: ( () otherlv_1= 'OutputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleOutDigDriver ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:3510:2: () otherlv_1= 'OutputDigitalDrivers' otherlv_2= '{' ( (lv_driver_3_0= ruleOutDigDriver ) )+ otherlv_4= '}'
            {
            // InternalConfigurator.g:3510:2: ()
            // InternalConfigurator.g:3511:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getOutputDigitalDriversAccess().getOutputDigitalDriversAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,61,FOLLOW_4); 

                	newLeafNode(otherlv_1, grammarAccess.getOutputDigitalDriversAccess().getOutputDigitalDriversKeyword_1());
                
            otherlv_2=(Token)match(input,15,FOLLOW_61); 

                	newLeafNode(otherlv_2, grammarAccess.getOutputDigitalDriversAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3524:1: ( (lv_driver_3_0= ruleOutDigDriver ) )+
            int cnt46=0;
            loop46:
            do {
                int alt46=2;
                int LA46_0 = input.LA(1);

                if ( (LA46_0==62) ) {
                    alt46=1;
                }


                switch (alt46) {
            	case 1 :
            	    // InternalConfigurator.g:3525:1: (lv_driver_3_0= ruleOutDigDriver )
            	    {
            	    // InternalConfigurator.g:3525:1: (lv_driver_3_0= ruleOutDigDriver )
            	    // InternalConfigurator.g:3526:3: lv_driver_3_0= ruleOutDigDriver
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOutputDigitalDriversAccess().getDriverOutDigDriverParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_62);
            	    lv_driver_3_0=ruleOutDigDriver();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOutputDigitalDriversRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"driver",
            	            		lv_driver_3_0, 
            	            		"zf.pios.Configurator.OutDigDriver");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt46 >= 1 ) break loop46;
                        EarlyExitException eee =
                            new EarlyExitException(46, input);
                        throw eee;
                }
                cnt46++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getOutputDigitalDriversAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputDigitalDrivers"


    // $ANTLR start "entryRuleAnalogDriver"
    // InternalConfigurator.g:3554:1: entryRuleAnalogDriver returns [EObject current=null] : iv_ruleAnalogDriver= ruleAnalogDriver EOF ;
    public final EObject entryRuleAnalogDriver() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAnalogDriver = null;


        try {
            // InternalConfigurator.g:3555:2: (iv_ruleAnalogDriver= ruleAnalogDriver EOF )
            // InternalConfigurator.g:3556:2: iv_ruleAnalogDriver= ruleAnalogDriver EOF
            {
             newCompositeNode(grammarAccess.getAnalogDriverRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAnalogDriver=ruleAnalogDriver();

            state._fsp--;

             current =iv_ruleAnalogDriver; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAnalogDriver"


    // $ANTLR start "ruleAnalogDriver"
    // InternalConfigurator.g:3563:1: ruleAnalogDriver returns [EObject current=null] : (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleIADC ) ) otherlv_4= '}' ) ;
    public final EObject ruleAnalogDriver() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_driverSetup_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3566:28: ( (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleIADC ) ) otherlv_4= '}' ) )
            // InternalConfigurator.g:3567:1: (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleIADC ) ) otherlv_4= '}' )
            {
            // InternalConfigurator.g:3567:1: (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleIADC ) ) otherlv_4= '}' )
            // InternalConfigurator.g:3567:3: otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleIADC ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,62,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getAnalogDriverAccess().getPortKeyword_0());
                
            // InternalConfigurator.g:3571:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:3572:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:3572:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:3573:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getAnalogDriverAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getAnalogDriverRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_63); 

                	newLeafNode(otherlv_2, grammarAccess.getAnalogDriverAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3593:1: ( (lv_driverSetup_3_0= ruleIADC ) )
            // InternalConfigurator.g:3594:1: (lv_driverSetup_3_0= ruleIADC )
            {
            // InternalConfigurator.g:3594:1: (lv_driverSetup_3_0= ruleIADC )
            // InternalConfigurator.g:3595:3: lv_driverSetup_3_0= ruleIADC
            {
             
            	        newCompositeNode(grammarAccess.getAnalogDriverAccess().getDriverSetupIADCParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_driverSetup_3_0=ruleIADC();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getAnalogDriverRule());
            	        }
                   		set(
                   			current, 
                   			"driverSetup",
                    		lv_driverSetup_3_0, 
                    		"zf.pios.Configurator.IADC");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getAnalogDriverAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAnalogDriver"


    // $ANTLR start "entryRuleInDigDriver"
    // InternalConfigurator.g:3623:1: entryRuleInDigDriver returns [EObject current=null] : iv_ruleInDigDriver= ruleInDigDriver EOF ;
    public final EObject entryRuleInDigDriver() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInDigDriver = null;


        try {
            // InternalConfigurator.g:3624:2: (iv_ruleInDigDriver= ruleInDigDriver EOF )
            // InternalConfigurator.g:3625:2: iv_ruleInDigDriver= ruleInDigDriver EOF
            {
             newCompositeNode(grammarAccess.getInDigDriverRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInDigDriver=ruleInDigDriver();

            state._fsp--;

             current =iv_ruleInDigDriver; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInDigDriver"


    // $ANTLR start "ruleInDigDriver"
    // InternalConfigurator.g:3632:1: ruleInDigDriver returns [EObject current=null] : (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}' ) ;
    public final EObject ruleInDigDriver() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_driverSetup_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3635:28: ( (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}' ) )
            // InternalConfigurator.g:3636:1: (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}' )
            {
            // InternalConfigurator.g:3636:1: (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}' )
            // InternalConfigurator.g:3636:3: otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,62,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getInDigDriverAccess().getPortKeyword_0());
                
            // InternalConfigurator.g:3640:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:3641:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:3641:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:3642:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getInDigDriverAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getInDigDriverRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_63); 

                	newLeafNode(otherlv_2, grammarAccess.getInDigDriverAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3662:1: ( (lv_driverSetup_3_0= ruleCommonDriver ) )
            // InternalConfigurator.g:3663:1: (lv_driverSetup_3_0= ruleCommonDriver )
            {
            // InternalConfigurator.g:3663:1: (lv_driverSetup_3_0= ruleCommonDriver )
            // InternalConfigurator.g:3664:3: lv_driverSetup_3_0= ruleCommonDriver
            {
             
            	        newCompositeNode(grammarAccess.getInDigDriverAccess().getDriverSetupCommonDriverParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_driverSetup_3_0=ruleCommonDriver();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getInDigDriverRule());
            	        }
                   		set(
                   			current, 
                   			"driverSetup",
                    		lv_driverSetup_3_0, 
                    		"zf.pios.Configurator.CommonDriver");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getInDigDriverAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInDigDriver"


    // $ANTLR start "entryRuleOutDigDriver"
    // InternalConfigurator.g:3692:1: entryRuleOutDigDriver returns [EObject current=null] : iv_ruleOutDigDriver= ruleOutDigDriver EOF ;
    public final EObject entryRuleOutDigDriver() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutDigDriver = null;


        try {
            // InternalConfigurator.g:3693:2: (iv_ruleOutDigDriver= ruleOutDigDriver EOF )
            // InternalConfigurator.g:3694:2: iv_ruleOutDigDriver= ruleOutDigDriver EOF
            {
             newCompositeNode(grammarAccess.getOutDigDriverRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutDigDriver=ruleOutDigDriver();

            state._fsp--;

             current =iv_ruleOutDigDriver; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutDigDriver"


    // $ANTLR start "ruleOutDigDriver"
    // InternalConfigurator.g:3701:1: ruleOutDigDriver returns [EObject current=null] : (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}' ) ;
    public final EObject ruleOutDigDriver() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_driverSetup_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3704:28: ( (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}' ) )
            // InternalConfigurator.g:3705:1: (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}' )
            {
            // InternalConfigurator.g:3705:1: (otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}' )
            // InternalConfigurator.g:3705:3: otherlv_0= 'Port' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_driverSetup_3_0= ruleCommonDriver ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,62,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getOutDigDriverAccess().getPortKeyword_0());
                
            // InternalConfigurator.g:3709:1: ( (lv_name_1_0= RULE_ID ) )
            // InternalConfigurator.g:3710:1: (lv_name_1_0= RULE_ID )
            {
            // InternalConfigurator.g:3710:1: (lv_name_1_0= RULE_ID )
            // InternalConfigurator.g:3711:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_1_0, grammarAccess.getOutDigDriverAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOutDigDriverRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_2=(Token)match(input,15,FOLLOW_63); 

                	newLeafNode(otherlv_2, grammarAccess.getOutDigDriverAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3731:1: ( (lv_driverSetup_3_0= ruleCommonDriver ) )
            // InternalConfigurator.g:3732:1: (lv_driverSetup_3_0= ruleCommonDriver )
            {
            // InternalConfigurator.g:3732:1: (lv_driverSetup_3_0= ruleCommonDriver )
            // InternalConfigurator.g:3733:3: lv_driverSetup_3_0= ruleCommonDriver
            {
             
            	        newCompositeNode(grammarAccess.getOutDigDriverAccess().getDriverSetupCommonDriverParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_driverSetup_3_0=ruleCommonDriver();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getOutDigDriverRule());
            	        }
                   		set(
                   			current, 
                   			"driverSetup",
                    		lv_driverSetup_3_0, 
                    		"zf.pios.Configurator.CommonDriver");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getOutDigDriverAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutDigDriver"


    // $ANTLR start "entryRuleCommonDriver"
    // InternalConfigurator.g:3761:1: entryRuleCommonDriver returns [EObject current=null] : iv_ruleCommonDriver= ruleCommonDriver EOF ;
    public final EObject entryRuleCommonDriver() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCommonDriver = null;


        try {
            // InternalConfigurator.g:3762:2: (iv_ruleCommonDriver= ruleCommonDriver EOF )
            // InternalConfigurator.g:3763:2: iv_ruleCommonDriver= ruleCommonDriver EOF
            {
             newCompositeNode(grammarAccess.getCommonDriverRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCommonDriver=ruleCommonDriver();

            state._fsp--;

             current =iv_ruleCommonDriver; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCommonDriver"


    // $ANTLR start "ruleCommonDriver"
    // InternalConfigurator.g:3770:1: ruleCommonDriver returns [EObject current=null] : (otherlv_0= 'DriverIndex' ( (lv_driverIndex_1_0= ruleINTORHEX ) ) (otherlv_2= 'ControllerPinName' ( (lv_controllerPinName_3_0= RULE_STRING ) ) )? (otherlv_4= 'Description' ( (lv_description_5_0= RULE_STRING ) ) )? ) ;
    public final EObject ruleCommonDriver() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token lv_controllerPinName_3_0=null;
        Token otherlv_4=null;
        Token lv_description_5_0=null;
        AntlrDatatypeRuleToken lv_driverIndex_1_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3773:28: ( (otherlv_0= 'DriverIndex' ( (lv_driverIndex_1_0= ruleINTORHEX ) ) (otherlv_2= 'ControllerPinName' ( (lv_controllerPinName_3_0= RULE_STRING ) ) )? (otherlv_4= 'Description' ( (lv_description_5_0= RULE_STRING ) ) )? ) )
            // InternalConfigurator.g:3774:1: (otherlv_0= 'DriverIndex' ( (lv_driverIndex_1_0= ruleINTORHEX ) ) (otherlv_2= 'ControllerPinName' ( (lv_controllerPinName_3_0= RULE_STRING ) ) )? (otherlv_4= 'Description' ( (lv_description_5_0= RULE_STRING ) ) )? )
            {
            // InternalConfigurator.g:3774:1: (otherlv_0= 'DriverIndex' ( (lv_driverIndex_1_0= ruleINTORHEX ) ) (otherlv_2= 'ControllerPinName' ( (lv_controllerPinName_3_0= RULE_STRING ) ) )? (otherlv_4= 'Description' ( (lv_description_5_0= RULE_STRING ) ) )? )
            // InternalConfigurator.g:3774:3: otherlv_0= 'DriverIndex' ( (lv_driverIndex_1_0= ruleINTORHEX ) ) (otherlv_2= 'ControllerPinName' ( (lv_controllerPinName_3_0= RULE_STRING ) ) )? (otherlv_4= 'Description' ( (lv_description_5_0= RULE_STRING ) ) )?
            {
            otherlv_0=(Token)match(input,63,FOLLOW_21); 

                	newLeafNode(otherlv_0, grammarAccess.getCommonDriverAccess().getDriverIndexKeyword_0());
                
            // InternalConfigurator.g:3778:1: ( (lv_driverIndex_1_0= ruleINTORHEX ) )
            // InternalConfigurator.g:3779:1: (lv_driverIndex_1_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:3779:1: (lv_driverIndex_1_0= ruleINTORHEX )
            // InternalConfigurator.g:3780:3: lv_driverIndex_1_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getCommonDriverAccess().getDriverIndexINTORHEXParserRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_64);
            lv_driverIndex_1_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getCommonDriverRule());
            	        }
                   		set(
                   			current, 
                   			"driverIndex",
                    		lv_driverIndex_1_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:3796:2: (otherlv_2= 'ControllerPinName' ( (lv_controllerPinName_3_0= RULE_STRING ) ) )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==64) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalConfigurator.g:3796:4: otherlv_2= 'ControllerPinName' ( (lv_controllerPinName_3_0= RULE_STRING ) )
                    {
                    otherlv_2=(Token)match(input,64,FOLLOW_32); 

                        	newLeafNode(otherlv_2, grammarAccess.getCommonDriverAccess().getControllerPinNameKeyword_2_0());
                        
                    // InternalConfigurator.g:3800:1: ( (lv_controllerPinName_3_0= RULE_STRING ) )
                    // InternalConfigurator.g:3801:1: (lv_controllerPinName_3_0= RULE_STRING )
                    {
                    // InternalConfigurator.g:3801:1: (lv_controllerPinName_3_0= RULE_STRING )
                    // InternalConfigurator.g:3802:3: lv_controllerPinName_3_0= RULE_STRING
                    {
                    lv_controllerPinName_3_0=(Token)match(input,RULE_STRING,FOLLOW_65); 

                    			newLeafNode(lv_controllerPinName_3_0, grammarAccess.getCommonDriverAccess().getControllerPinNameSTRINGTerminalRuleCall_2_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getCommonDriverRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"controllerPinName",
                            		lv_controllerPinName_3_0, 
                            		"org.eclipse.xtext.common.Terminals.STRING");
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:3818:4: (otherlv_4= 'Description' ( (lv_description_5_0= RULE_STRING ) ) )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==35) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalConfigurator.g:3818:6: otherlv_4= 'Description' ( (lv_description_5_0= RULE_STRING ) )
                    {
                    otherlv_4=(Token)match(input,35,FOLLOW_32); 

                        	newLeafNode(otherlv_4, grammarAccess.getCommonDriverAccess().getDescriptionKeyword_3_0());
                        
                    // InternalConfigurator.g:3822:1: ( (lv_description_5_0= RULE_STRING ) )
                    // InternalConfigurator.g:3823:1: (lv_description_5_0= RULE_STRING )
                    {
                    // InternalConfigurator.g:3823:1: (lv_description_5_0= RULE_STRING )
                    // InternalConfigurator.g:3824:3: lv_description_5_0= RULE_STRING
                    {
                    lv_description_5_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			newLeafNode(lv_description_5_0, grammarAccess.getCommonDriverAccess().getDescriptionSTRINGTerminalRuleCall_3_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getCommonDriverRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"description",
                            		lv_description_5_0, 
                            		"org.eclipse.xtext.common.Terminals.STRING");
                    	    

                    }


                    }


                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCommonDriver"


    // $ANTLR start "entryRuleInputDigDriversTable"
    // InternalConfigurator.g:3848:1: entryRuleInputDigDriversTable returns [EObject current=null] : iv_ruleInputDigDriversTable= ruleInputDigDriversTable EOF ;
    public final EObject entryRuleInputDigDriversTable() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputDigDriversTable = null;


        try {
            // InternalConfigurator.g:3849:2: (iv_ruleInputDigDriversTable= ruleInputDigDriversTable EOF )
            // InternalConfigurator.g:3850:2: iv_ruleInputDigDriversTable= ruleInputDigDriversTable EOF
            {
             newCompositeNode(grammarAccess.getInputDigDriversTableRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputDigDriversTable=ruleInputDigDriversTable();

            state._fsp--;

             current =iv_ruleInputDigDriversTable; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputDigDriversTable"


    // $ANTLR start "ruleInputDigDriversTable"
    // InternalConfigurator.g:3857:1: ruleInputDigDriversTable returns [EObject current=null] : ( () otherlv_1= 'InputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleInDigitalDriverTableRef ) )+ otherlv_4= '}' ) ;
    public final EObject ruleInputDigDriversTable() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_digitalDriverTableRef_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3860:28: ( ( () otherlv_1= 'InputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleInDigitalDriverTableRef ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:3861:1: ( () otherlv_1= 'InputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleInDigitalDriverTableRef ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:3861:1: ( () otherlv_1= 'InputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleInDigitalDriverTableRef ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:3861:2: () otherlv_1= 'InputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleInDigitalDriverTableRef ) )+ otherlv_4= '}'
            {
            // InternalConfigurator.g:3861:2: ()
            // InternalConfigurator.g:3862:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getInputDigDriversTableAccess().getInputDigDriversTableAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,65,FOLLOW_4); 

                	newLeafNode(otherlv_1, grammarAccess.getInputDigDriversTableAccess().getInputDigDriversTableKeyword_1());
                
            otherlv_2=(Token)match(input,15,FOLLOW_66); 

                	newLeafNode(otherlv_2, grammarAccess.getInputDigDriversTableAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3875:1: ( (lv_digitalDriverTableRef_3_0= ruleInDigitalDriverTableRef ) )+
            int cnt49=0;
            loop49:
            do {
                int alt49=2;
                int LA49_0 = input.LA(1);

                if ( (LA49_0==RULE_ID||LA49_0==67) ) {
                    alt49=1;
                }


                switch (alt49) {
            	case 1 :
            	    // InternalConfigurator.g:3876:1: (lv_digitalDriverTableRef_3_0= ruleInDigitalDriverTableRef )
            	    {
            	    // InternalConfigurator.g:3876:1: (lv_digitalDriverTableRef_3_0= ruleInDigitalDriverTableRef )
            	    // InternalConfigurator.g:3877:3: lv_digitalDriverTableRef_3_0= ruleInDigitalDriverTableRef
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getInputDigDriversTableAccess().getDigitalDriverTableRefInDigitalDriverTableRefParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_67);
            	    lv_digitalDriverTableRef_3_0=ruleInDigitalDriverTableRef();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getInputDigDriversTableRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"digitalDriverTableRef",
            	            		lv_digitalDriverTableRef_3_0, 
            	            		"zf.pios.Configurator.InDigitalDriverTableRef");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt49 >= 1 ) break loop49;
                        EarlyExitException eee =
                            new EarlyExitException(49, input);
                        throw eee;
                }
                cnt49++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getInputDigDriversTableAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputDigDriversTable"


    // $ANTLR start "entryRuleOutputDigDriversTable"
    // InternalConfigurator.g:3905:1: entryRuleOutputDigDriversTable returns [EObject current=null] : iv_ruleOutputDigDriversTable= ruleOutputDigDriversTable EOF ;
    public final EObject entryRuleOutputDigDriversTable() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputDigDriversTable = null;


        try {
            // InternalConfigurator.g:3906:2: (iv_ruleOutputDigDriversTable= ruleOutputDigDriversTable EOF )
            // InternalConfigurator.g:3907:2: iv_ruleOutputDigDriversTable= ruleOutputDigDriversTable EOF
            {
             newCompositeNode(grammarAccess.getOutputDigDriversTableRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputDigDriversTable=ruleOutputDigDriversTable();

            state._fsp--;

             current =iv_ruleOutputDigDriversTable; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputDigDriversTable"


    // $ANTLR start "ruleOutputDigDriversTable"
    // InternalConfigurator.g:3914:1: ruleOutputDigDriversTable returns [EObject current=null] : ( () otherlv_1= 'OutputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleOutDigitalDriverTableRef ) )+ otherlv_4= '}' ) ;
    public final EObject ruleOutputDigDriversTable() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_digitalDriverTableRef_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:3917:28: ( ( () otherlv_1= 'OutputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleOutDigitalDriverTableRef ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:3918:1: ( () otherlv_1= 'OutputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleOutDigitalDriverTableRef ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:3918:1: ( () otherlv_1= 'OutputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleOutDigitalDriverTableRef ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:3918:2: () otherlv_1= 'OutputDigDriversTable' otherlv_2= '{' ( (lv_digitalDriverTableRef_3_0= ruleOutDigitalDriverTableRef ) )+ otherlv_4= '}'
            {
            // InternalConfigurator.g:3918:2: ()
            // InternalConfigurator.g:3919:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getOutputDigDriversTableAccess().getOutputDigDriversTableAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,66,FOLLOW_4); 

                	newLeafNode(otherlv_1, grammarAccess.getOutputDigDriversTableAccess().getOutputDigDriversTableKeyword_1());
                
            otherlv_2=(Token)match(input,15,FOLLOW_66); 

                	newLeafNode(otherlv_2, grammarAccess.getOutputDigDriversTableAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:3932:1: ( (lv_digitalDriverTableRef_3_0= ruleOutDigitalDriverTableRef ) )+
            int cnt50=0;
            loop50:
            do {
                int alt50=2;
                int LA50_0 = input.LA(1);

                if ( (LA50_0==RULE_ID||LA50_0==67) ) {
                    alt50=1;
                }


                switch (alt50) {
            	case 1 :
            	    // InternalConfigurator.g:3933:1: (lv_digitalDriverTableRef_3_0= ruleOutDigitalDriverTableRef )
            	    {
            	    // InternalConfigurator.g:3933:1: (lv_digitalDriverTableRef_3_0= ruleOutDigitalDriverTableRef )
            	    // InternalConfigurator.g:3934:3: lv_digitalDriverTableRef_3_0= ruleOutDigitalDriverTableRef
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOutputDigDriversTableAccess().getDigitalDriverTableRefOutDigitalDriverTableRefParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_67);
            	    lv_digitalDriverTableRef_3_0=ruleOutDigitalDriverTableRef();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOutputDigDriversTableRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"digitalDriverTableRef",
            	            		lv_digitalDriverTableRef_3_0, 
            	            		"zf.pios.Configurator.OutDigitalDriverTableRef");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt50 >= 1 ) break loop50;
                        EarlyExitException eee =
                            new EarlyExitException(50, input);
                        throw eee;
                }
                cnt50++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getOutputDigDriversTableAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputDigDriversTable"


    // $ANTLR start "entryRuleInDigitalDriverTableRef"
    // InternalConfigurator.g:3962:1: entryRuleInDigitalDriverTableRef returns [EObject current=null] : iv_ruleInDigitalDriverTableRef= ruleInDigitalDriverTableRef EOF ;
    public final EObject entryRuleInDigitalDriverTableRef() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInDigitalDriverTableRef = null;


        try {
            // InternalConfigurator.g:3963:2: (iv_ruleInDigitalDriverTableRef= ruleInDigitalDriverTableRef EOF )
            // InternalConfigurator.g:3964:2: iv_ruleInDigitalDriverTableRef= ruleInDigitalDriverTableRef EOF
            {
             newCompositeNode(grammarAccess.getInDigitalDriverTableRefRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInDigitalDriverTableRef=ruleInDigitalDriverTableRef();

            state._fsp--;

             current =iv_ruleInDigitalDriverTableRef; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInDigitalDriverTableRef"


    // $ANTLR start "ruleInDigitalDriverTableRef"
    // InternalConfigurator.g:3971:1: ruleInDigitalDriverTableRef returns [EObject current=null] : ( () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) ) ) ;
    public final EObject ruleInDigitalDriverTableRef() throws RecognitionException {
        EObject current = null;

        Token lv_dummySignal_1_0=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:3974:28: ( ( () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) ) ) )
            // InternalConfigurator.g:3975:1: ( () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) ) )
            {
            // InternalConfigurator.g:3975:1: ( () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) ) )
            // InternalConfigurator.g:3975:2: () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) )
            {
            // InternalConfigurator.g:3975:2: ()
            // InternalConfigurator.g:3976:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getInDigitalDriverTableRefAccess().getInDigitalDriverTableRefAction_0(),
                        current);
                

            }

            // InternalConfigurator.g:3981:2: ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) )
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==67) ) {
                alt51=1;
            }
            else if ( (LA51_0==RULE_ID) ) {
                alt51=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 51, 0, input);

                throw nvae;
            }
            switch (alt51) {
                case 1 :
                    // InternalConfigurator.g:3981:3: ( (lv_dummySignal_1_0= 'Null' ) )
                    {
                    // InternalConfigurator.g:3981:3: ( (lv_dummySignal_1_0= 'Null' ) )
                    // InternalConfigurator.g:3982:1: (lv_dummySignal_1_0= 'Null' )
                    {
                    // InternalConfigurator.g:3982:1: (lv_dummySignal_1_0= 'Null' )
                    // InternalConfigurator.g:3983:3: lv_dummySignal_1_0= 'Null'
                    {
                    lv_dummySignal_1_0=(Token)match(input,67,FOLLOW_2); 

                            newLeafNode(lv_dummySignal_1_0, grammarAccess.getInDigitalDriverTableRefAccess().getDummySignalNullKeyword_1_0_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getInDigitalDriverTableRefRule());
                    	        }
                           		setWithLastConsumed(current, "dummySignal", lv_dummySignal_1_0, "Null");
                    	    

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:3997:6: ( ( ruleQualifiedName ) )
                    {
                    // InternalConfigurator.g:3997:6: ( ( ruleQualifiedName ) )
                    // InternalConfigurator.g:3998:1: ( ruleQualifiedName )
                    {
                    // InternalConfigurator.g:3998:1: ( ruleQualifiedName )
                    // InternalConfigurator.g:3999:3: ruleQualifiedName
                    {

                    			if (current==null) {
                    	            current = createModelElement(grammarAccess.getInDigitalDriverTableRefRule());
                    	        }
                            
                     
                    	        newCompositeNode(grammarAccess.getInDigitalDriverTableRefAccess().getNameInDigDriverCrossReference_1_1_0()); 
                    	    
                    pushFollow(FOLLOW_2);
                    ruleQualifiedName();

                    state._fsp--;

                     
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInDigitalDriverTableRef"


    // $ANTLR start "entryRuleOutDigitalDriverTableRef"
    // InternalConfigurator.g:4020:1: entryRuleOutDigitalDriverTableRef returns [EObject current=null] : iv_ruleOutDigitalDriverTableRef= ruleOutDigitalDriverTableRef EOF ;
    public final EObject entryRuleOutDigitalDriverTableRef() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutDigitalDriverTableRef = null;


        try {
            // InternalConfigurator.g:4021:2: (iv_ruleOutDigitalDriverTableRef= ruleOutDigitalDriverTableRef EOF )
            // InternalConfigurator.g:4022:2: iv_ruleOutDigitalDriverTableRef= ruleOutDigitalDriverTableRef EOF
            {
             newCompositeNode(grammarAccess.getOutDigitalDriverTableRefRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutDigitalDriverTableRef=ruleOutDigitalDriverTableRef();

            state._fsp--;

             current =iv_ruleOutDigitalDriverTableRef; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutDigitalDriverTableRef"


    // $ANTLR start "ruleOutDigitalDriverTableRef"
    // InternalConfigurator.g:4029:1: ruleOutDigitalDriverTableRef returns [EObject current=null] : ( () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) ) ) ;
    public final EObject ruleOutDigitalDriverTableRef() throws RecognitionException {
        EObject current = null;

        Token lv_dummySignal_1_0=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:4032:28: ( ( () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) ) ) )
            // InternalConfigurator.g:4033:1: ( () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) ) )
            {
            // InternalConfigurator.g:4033:1: ( () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) ) )
            // InternalConfigurator.g:4033:2: () ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) )
            {
            // InternalConfigurator.g:4033:2: ()
            // InternalConfigurator.g:4034:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getOutDigitalDriverTableRefAccess().getOutDigitalDriverTableRefAction_0(),
                        current);
                

            }

            // InternalConfigurator.g:4039:2: ( ( (lv_dummySignal_1_0= 'Null' ) ) | ( ( ruleQualifiedName ) ) )
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==67) ) {
                alt52=1;
            }
            else if ( (LA52_0==RULE_ID) ) {
                alt52=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 52, 0, input);

                throw nvae;
            }
            switch (alt52) {
                case 1 :
                    // InternalConfigurator.g:4039:3: ( (lv_dummySignal_1_0= 'Null' ) )
                    {
                    // InternalConfigurator.g:4039:3: ( (lv_dummySignal_1_0= 'Null' ) )
                    // InternalConfigurator.g:4040:1: (lv_dummySignal_1_0= 'Null' )
                    {
                    // InternalConfigurator.g:4040:1: (lv_dummySignal_1_0= 'Null' )
                    // InternalConfigurator.g:4041:3: lv_dummySignal_1_0= 'Null'
                    {
                    lv_dummySignal_1_0=(Token)match(input,67,FOLLOW_2); 

                            newLeafNode(lv_dummySignal_1_0, grammarAccess.getOutDigitalDriverTableRefAccess().getDummySignalNullKeyword_1_0_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getOutDigitalDriverTableRefRule());
                    	        }
                           		setWithLastConsumed(current, "dummySignal", lv_dummySignal_1_0, "Null");
                    	    

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:4055:6: ( ( ruleQualifiedName ) )
                    {
                    // InternalConfigurator.g:4055:6: ( ( ruleQualifiedName ) )
                    // InternalConfigurator.g:4056:1: ( ruleQualifiedName )
                    {
                    // InternalConfigurator.g:4056:1: ( ruleQualifiedName )
                    // InternalConfigurator.g:4057:3: ruleQualifiedName
                    {

                    			if (current==null) {
                    	            current = createModelElement(grammarAccess.getOutDigitalDriverTableRefRule());
                    	        }
                            
                     
                    	        newCompositeNode(grammarAccess.getOutDigitalDriverTableRefAccess().getNameOutDigDriverCrossReference_1_1_0()); 
                    	    
                    pushFollow(FOLLOW_2);
                    ruleQualifiedName();

                    state._fsp--;

                     
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutDigitalDriverTableRef"


    // $ANTLR start "entryRuleElectricDiagSubsystem"
    // InternalConfigurator.g:4078:1: entryRuleElectricDiagSubsystem returns [EObject current=null] : iv_ruleElectricDiagSubsystem= ruleElectricDiagSubsystem EOF ;
    public final EObject entryRuleElectricDiagSubsystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElectricDiagSubsystem = null;


        try {
            // InternalConfigurator.g:4079:2: (iv_ruleElectricDiagSubsystem= ruleElectricDiagSubsystem EOF )
            // InternalConfigurator.g:4080:2: iv_ruleElectricDiagSubsystem= ruleElectricDiagSubsystem EOF
            {
             newCompositeNode(grammarAccess.getElectricDiagSubsystemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElectricDiagSubsystem=ruleElectricDiagSubsystem();

            state._fsp--;

             current =iv_ruleElectricDiagSubsystem; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElectricDiagSubsystem"


    // $ANTLR start "ruleElectricDiagSubsystem"
    // InternalConfigurator.g:4087:1: ruleElectricDiagSubsystem returns [EObject current=null] : (otherlv_0= 'ElDiagSubsystem' () otherlv_2= '{' ( (lv_elDiag_3_0= ruleElDiag ) )+ otherlv_4= '}' ) ;
    public final EObject ruleElectricDiagSubsystem() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_elDiag_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:4090:28: ( (otherlv_0= 'ElDiagSubsystem' () otherlv_2= '{' ( (lv_elDiag_3_0= ruleElDiag ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:4091:1: (otherlv_0= 'ElDiagSubsystem' () otherlv_2= '{' ( (lv_elDiag_3_0= ruleElDiag ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:4091:1: (otherlv_0= 'ElDiagSubsystem' () otherlv_2= '{' ( (lv_elDiag_3_0= ruleElDiag ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:4091:3: otherlv_0= 'ElDiagSubsystem' () otherlv_2= '{' ( (lv_elDiag_3_0= ruleElDiag ) )+ otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,68,FOLLOW_4); 

                	newLeafNode(otherlv_0, grammarAccess.getElectricDiagSubsystemAccess().getElDiagSubsystemKeyword_0());
                
            // InternalConfigurator.g:4095:1: ()
            // InternalConfigurator.g:4096:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getElectricDiagSubsystemAccess().getElectricDiagSubsystemAction_1(),
                        current);
                

            }

            otherlv_2=(Token)match(input,15,FOLLOW_61); 

                	newLeafNode(otherlv_2, grammarAccess.getElectricDiagSubsystemAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:4105:1: ( (lv_elDiag_3_0= ruleElDiag ) )+
            int cnt53=0;
            loop53:
            do {
                int alt53=2;
                int LA53_0 = input.LA(1);

                if ( (LA53_0==62) ) {
                    alt53=1;
                }


                switch (alt53) {
            	case 1 :
            	    // InternalConfigurator.g:4106:1: (lv_elDiag_3_0= ruleElDiag )
            	    {
            	    // InternalConfigurator.g:4106:1: (lv_elDiag_3_0= ruleElDiag )
            	    // InternalConfigurator.g:4107:3: lv_elDiag_3_0= ruleElDiag
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getElectricDiagSubsystemAccess().getElDiagElDiagParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_62);
            	    lv_elDiag_3_0=ruleElDiag();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getElectricDiagSubsystemRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"elDiag",
            	            		lv_elDiag_3_0, 
            	            		"zf.pios.Configurator.ElDiag");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt53 >= 1 ) break loop53;
                        EarlyExitException eee =
                            new EarlyExitException(53, input);
                        throw eee;
                }
                cnt53++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getElectricDiagSubsystemAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElectricDiagSubsystem"


    // $ANTLR start "entryRuleElDiag"
    // InternalConfigurator.g:4135:1: entryRuleElDiag returns [EObject current=null] : iv_ruleElDiag= ruleElDiag EOF ;
    public final EObject entryRuleElDiag() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElDiag = null;


        try {
            // InternalConfigurator.g:4136:2: (iv_ruleElDiag= ruleElDiag EOF )
            // InternalConfigurator.g:4137:2: iv_ruleElDiag= ruleElDiag EOF
            {
             newCompositeNode(grammarAccess.getElDiagRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElDiag=ruleElDiag();

            state._fsp--;

             current =iv_ruleElDiag; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElDiag"


    // $ANTLR start "ruleElDiag"
    // InternalConfigurator.g:4144:1: ruleElDiag returns [EObject current=null] : (otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' (otherlv_4= 'Enable' ( (lv_enable_5_0= ruleBOOLfalseDefault ) ) )? (otherlv_6= 'DiagnosisEnable' ( (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault ) ) )? otherlv_8= 'DriverIndex' ( (lv_driverIndex_9_0= ruleINTORHEX ) ) otherlv_10= 'PWMDiagnosis' ( (lv_pwmDiagnosis_11_0= ruleINTORHEX ) ) otherlv_12= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) (otherlv_14= 'Description' ( (lv_description_15_0= RULE_STRING ) ) )? otherlv_16= '}' ) ;
    public final EObject ruleElDiag() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token lv_description_15_0=null;
        Token otherlv_16=null;
        Enumerator lv_enable_5_0 = null;

        Enumerator lv_diagnosisEnable_7_0 = null;

        AntlrDatatypeRuleToken lv_driverIndex_9_0 = null;

        AntlrDatatypeRuleToken lv_pwmDiagnosis_11_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:4147:28: ( (otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' (otherlv_4= 'Enable' ( (lv_enable_5_0= ruleBOOLfalseDefault ) ) )? (otherlv_6= 'DiagnosisEnable' ( (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault ) ) )? otherlv_8= 'DriverIndex' ( (lv_driverIndex_9_0= ruleINTORHEX ) ) otherlv_10= 'PWMDiagnosis' ( (lv_pwmDiagnosis_11_0= ruleINTORHEX ) ) otherlv_12= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) (otherlv_14= 'Description' ( (lv_description_15_0= RULE_STRING ) ) )? otherlv_16= '}' ) )
            // InternalConfigurator.g:4148:1: (otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' (otherlv_4= 'Enable' ( (lv_enable_5_0= ruleBOOLfalseDefault ) ) )? (otherlv_6= 'DiagnosisEnable' ( (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault ) ) )? otherlv_8= 'DriverIndex' ( (lv_driverIndex_9_0= ruleINTORHEX ) ) otherlv_10= 'PWMDiagnosis' ( (lv_pwmDiagnosis_11_0= ruleINTORHEX ) ) otherlv_12= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) (otherlv_14= 'Description' ( (lv_description_15_0= RULE_STRING ) ) )? otherlv_16= '}' )
            {
            // InternalConfigurator.g:4148:1: (otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' (otherlv_4= 'Enable' ( (lv_enable_5_0= ruleBOOLfalseDefault ) ) )? (otherlv_6= 'DiagnosisEnable' ( (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault ) ) )? otherlv_8= 'DriverIndex' ( (lv_driverIndex_9_0= ruleINTORHEX ) ) otherlv_10= 'PWMDiagnosis' ( (lv_pwmDiagnosis_11_0= ruleINTORHEX ) ) otherlv_12= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) (otherlv_14= 'Description' ( (lv_description_15_0= RULE_STRING ) ) )? otherlv_16= '}' )
            // InternalConfigurator.g:4148:3: otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' (otherlv_4= 'Enable' ( (lv_enable_5_0= ruleBOOLfalseDefault ) ) )? (otherlv_6= 'DiagnosisEnable' ( (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault ) ) )? otherlv_8= 'DriverIndex' ( (lv_driverIndex_9_0= ruleINTORHEX ) ) otherlv_10= 'PWMDiagnosis' ( (lv_pwmDiagnosis_11_0= ruleINTORHEX ) ) otherlv_12= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) (otherlv_14= 'Description' ( (lv_description_15_0= RULE_STRING ) ) )? otherlv_16= '}'
            {
            otherlv_0=(Token)match(input,62,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getElDiagAccess().getPortKeyword_0());
                
            // InternalConfigurator.g:4152:1: ()
            // InternalConfigurator.g:4153:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getElDiagAccess().getElDiagAction_1(),
                        current);
                

            }

            // InternalConfigurator.g:4158:2: ( (lv_name_2_0= RULE_ID ) )
            // InternalConfigurator.g:4159:1: (lv_name_2_0= RULE_ID )
            {
            // InternalConfigurator.g:4159:1: (lv_name_2_0= RULE_ID )
            // InternalConfigurator.g:4160:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_2_0, grammarAccess.getElDiagAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getElDiagRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_68); 

                	newLeafNode(otherlv_3, grammarAccess.getElDiagAccess().getLeftCurlyBracketKeyword_3());
                
            // InternalConfigurator.g:4180:1: (otherlv_4= 'Enable' ( (lv_enable_5_0= ruleBOOLfalseDefault ) ) )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==69) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalConfigurator.g:4180:3: otherlv_4= 'Enable' ( (lv_enable_5_0= ruleBOOLfalseDefault ) )
                    {
                    otherlv_4=(Token)match(input,69,FOLLOW_69); 

                        	newLeafNode(otherlv_4, grammarAccess.getElDiagAccess().getEnableKeyword_4_0());
                        
                    // InternalConfigurator.g:4184:1: ( (lv_enable_5_0= ruleBOOLfalseDefault ) )
                    // InternalConfigurator.g:4185:1: (lv_enable_5_0= ruleBOOLfalseDefault )
                    {
                    // InternalConfigurator.g:4185:1: (lv_enable_5_0= ruleBOOLfalseDefault )
                    // InternalConfigurator.g:4186:3: lv_enable_5_0= ruleBOOLfalseDefault
                    {
                     
                    	        newCompositeNode(grammarAccess.getElDiagAccess().getEnableBOOLfalseDefaultEnumRuleCall_4_1_0()); 
                    	    
                    pushFollow(FOLLOW_70);
                    lv_enable_5_0=ruleBOOLfalseDefault();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getElDiagRule());
                    	        }
                           		set(
                           			current, 
                           			"enable",
                            		lv_enable_5_0, 
                            		"zf.pios.Configurator.BOOLfalseDefault");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:4202:4: (otherlv_6= 'DiagnosisEnable' ( (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault ) ) )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==70) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalConfigurator.g:4202:6: otherlv_6= 'DiagnosisEnable' ( (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault ) )
                    {
                    otherlv_6=(Token)match(input,70,FOLLOW_69); 

                        	newLeafNode(otherlv_6, grammarAccess.getElDiagAccess().getDiagnosisEnableKeyword_5_0());
                        
                    // InternalConfigurator.g:4206:1: ( (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault ) )
                    // InternalConfigurator.g:4207:1: (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault )
                    {
                    // InternalConfigurator.g:4207:1: (lv_diagnosisEnable_7_0= ruleBOOLfalseDefault )
                    // InternalConfigurator.g:4208:3: lv_diagnosisEnable_7_0= ruleBOOLfalseDefault
                    {
                     
                    	        newCompositeNode(grammarAccess.getElDiagAccess().getDiagnosisEnableBOOLfalseDefaultEnumRuleCall_5_1_0()); 
                    	    
                    pushFollow(FOLLOW_63);
                    lv_diagnosisEnable_7_0=ruleBOOLfalseDefault();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getElDiagRule());
                    	        }
                           		set(
                           			current, 
                           			"diagnosisEnable",
                            		lv_diagnosisEnable_7_0, 
                            		"zf.pios.Configurator.BOOLfalseDefault");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,63,FOLLOW_21); 

                	newLeafNode(otherlv_8, grammarAccess.getElDiagAccess().getDriverIndexKeyword_6());
                
            // InternalConfigurator.g:4228:1: ( (lv_driverIndex_9_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4229:1: (lv_driverIndex_9_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4229:1: (lv_driverIndex_9_0= ruleINTORHEX )
            // InternalConfigurator.g:4230:3: lv_driverIndex_9_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getElDiagAccess().getDriverIndexINTORHEXParserRuleCall_7_0()); 
            	    
            pushFollow(FOLLOW_71);
            lv_driverIndex_9_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getElDiagRule());
            	        }
                   		set(
                   			current, 
                   			"driverIndex",
                    		lv_driverIndex_9_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_10=(Token)match(input,71,FOLLOW_21); 

                	newLeafNode(otherlv_10, grammarAccess.getElDiagAccess().getPWMDiagnosisKeyword_8());
                
            // InternalConfigurator.g:4250:1: ( (lv_pwmDiagnosis_11_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4251:1: (lv_pwmDiagnosis_11_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4251:1: (lv_pwmDiagnosis_11_0= ruleINTORHEX )
            // InternalConfigurator.g:4252:3: lv_pwmDiagnosis_11_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getElDiagAccess().getPwmDiagnosisINTORHEXParserRuleCall_9_0()); 
            	    
            pushFollow(FOLLOW_72);
            lv_pwmDiagnosis_11_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getElDiagRule());
            	        }
                   		set(
                   			current, 
                   			"pwmDiagnosis",
                    		lv_pwmDiagnosis_11_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_12=(Token)match(input,72,FOLLOW_3); 

                	newLeafNode(otherlv_12, grammarAccess.getElDiagAccess().getPowerSupplySignalKeyword_10());
                
            // InternalConfigurator.g:4272:1: ( ( ruleQualifiedName ) )
            // InternalConfigurator.g:4273:1: ( ruleQualifiedName )
            {
            // InternalConfigurator.g:4273:1: ( ruleQualifiedName )
            // InternalConfigurator.g:4274:3: ruleQualifiedName
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getElDiagRule());
            	        }
                    
             
            	        newCompositeNode(grammarAccess.getElDiagAccess().getPowerSupplySignalInputSignalCrossReference_11_0()); 
            	    
            pushFollow(FOLLOW_73);
            ruleQualifiedName();

            state._fsp--;

             
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:4287:2: (otherlv_14= 'Description' ( (lv_description_15_0= RULE_STRING ) ) )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==35) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalConfigurator.g:4287:4: otherlv_14= 'Description' ( (lv_description_15_0= RULE_STRING ) )
                    {
                    otherlv_14=(Token)match(input,35,FOLLOW_32); 

                        	newLeafNode(otherlv_14, grammarAccess.getElDiagAccess().getDescriptionKeyword_12_0());
                        
                    // InternalConfigurator.g:4291:1: ( (lv_description_15_0= RULE_STRING ) )
                    // InternalConfigurator.g:4292:1: (lv_description_15_0= RULE_STRING )
                    {
                    // InternalConfigurator.g:4292:1: (lv_description_15_0= RULE_STRING )
                    // InternalConfigurator.g:4293:3: lv_description_15_0= RULE_STRING
                    {
                    lv_description_15_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                    			newLeafNode(lv_description_15_0, grammarAccess.getElDiagAccess().getDescriptionSTRINGTerminalRuleCall_12_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getElDiagRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"description",
                            		lv_description_15_0, 
                            		"org.eclipse.xtext.common.Terminals.STRING");
                    	    

                    }


                    }


                    }
                    break;

            }

            otherlv_16=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_16, grammarAccess.getElDiagAccess().getRightCurlyBracketKeyword_13());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElDiag"


    // $ANTLR start "entryRuleFrequencySubsystem"
    // InternalConfigurator.g:4321:1: entryRuleFrequencySubsystem returns [EObject current=null] : iv_ruleFrequencySubsystem= ruleFrequencySubsystem EOF ;
    public final EObject entryRuleFrequencySubsystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFrequencySubsystem = null;


        try {
            // InternalConfigurator.g:4322:2: (iv_ruleFrequencySubsystem= ruleFrequencySubsystem EOF )
            // InternalConfigurator.g:4323:2: iv_ruleFrequencySubsystem= ruleFrequencySubsystem EOF
            {
             newCompositeNode(grammarAccess.getFrequencySubsystemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFrequencySubsystem=ruleFrequencySubsystem();

            state._fsp--;

             current =iv_ruleFrequencySubsystem; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFrequencySubsystem"


    // $ANTLR start "ruleFrequencySubsystem"
    // InternalConfigurator.g:4330:1: ruleFrequencySubsystem returns [EObject current=null] : (otherlv_0= 'FrequencySubsystem' () otherlv_2= '{' ( (lv_ifrqSensor_3_0= ruleIFRQSensor ) )* ( (lv_ifrq_4_0= ruleIFRQ ) )* otherlv_5= '}' ) ;
    public final EObject ruleFrequencySubsystem() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_5=null;
        EObject lv_ifrqSensor_3_0 = null;

        EObject lv_ifrq_4_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:4333:28: ( (otherlv_0= 'FrequencySubsystem' () otherlv_2= '{' ( (lv_ifrqSensor_3_0= ruleIFRQSensor ) )* ( (lv_ifrq_4_0= ruleIFRQ ) )* otherlv_5= '}' ) )
            // InternalConfigurator.g:4334:1: (otherlv_0= 'FrequencySubsystem' () otherlv_2= '{' ( (lv_ifrqSensor_3_0= ruleIFRQSensor ) )* ( (lv_ifrq_4_0= ruleIFRQ ) )* otherlv_5= '}' )
            {
            // InternalConfigurator.g:4334:1: (otherlv_0= 'FrequencySubsystem' () otherlv_2= '{' ( (lv_ifrqSensor_3_0= ruleIFRQSensor ) )* ( (lv_ifrq_4_0= ruleIFRQ ) )* otherlv_5= '}' )
            // InternalConfigurator.g:4334:3: otherlv_0= 'FrequencySubsystem' () otherlv_2= '{' ( (lv_ifrqSensor_3_0= ruleIFRQSensor ) )* ( (lv_ifrq_4_0= ruleIFRQ ) )* otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,73,FOLLOW_4); 

                	newLeafNode(otherlv_0, grammarAccess.getFrequencySubsystemAccess().getFrequencySubsystemKeyword_0());
                
            // InternalConfigurator.g:4338:1: ()
            // InternalConfigurator.g:4339:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getFrequencySubsystemAccess().getFRQSubsystemAction_1(),
                        current);
                

            }

            otherlv_2=(Token)match(input,15,FOLLOW_74); 

                	newLeafNode(otherlv_2, grammarAccess.getFrequencySubsystemAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:4348:1: ( (lv_ifrqSensor_3_0= ruleIFRQSensor ) )*
            loop57:
            do {
                int alt57=2;
                int LA57_0 = input.LA(1);

                if ( (LA57_0==74) ) {
                    alt57=1;
                }


                switch (alt57) {
            	case 1 :
            	    // InternalConfigurator.g:4349:1: (lv_ifrqSensor_3_0= ruleIFRQSensor )
            	    {
            	    // InternalConfigurator.g:4349:1: (lv_ifrqSensor_3_0= ruleIFRQSensor )
            	    // InternalConfigurator.g:4350:3: lv_ifrqSensor_3_0= ruleIFRQSensor
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getFrequencySubsystemAccess().getIfrqSensorIFRQSensorParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_74);
            	    lv_ifrqSensor_3_0=ruleIFRQSensor();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getFrequencySubsystemRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"ifrqSensor",
            	            		lv_ifrqSensor_3_0, 
            	            		"zf.pios.Configurator.IFRQSensor");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop57;
                }
            } while (true);

            // InternalConfigurator.g:4366:3: ( (lv_ifrq_4_0= ruleIFRQ ) )*
            loop58:
            do {
                int alt58=2;
                int LA58_0 = input.LA(1);

                if ( (LA58_0==62) ) {
                    alt58=1;
                }


                switch (alt58) {
            	case 1 :
            	    // InternalConfigurator.g:4367:1: (lv_ifrq_4_0= ruleIFRQ )
            	    {
            	    // InternalConfigurator.g:4367:1: (lv_ifrq_4_0= ruleIFRQ )
            	    // InternalConfigurator.g:4368:3: lv_ifrq_4_0= ruleIFRQ
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getFrequencySubsystemAccess().getIfrqIFRQParserRuleCall_4_0()); 
            	    	    
            	    pushFollow(FOLLOW_62);
            	    lv_ifrq_4_0=ruleIFRQ();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getFrequencySubsystemRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"ifrq",
            	            		lv_ifrq_4_0, 
            	            		"zf.pios.Configurator.IFRQ");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop58;
                }
            } while (true);

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getFrequencySubsystemAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFrequencySubsystem"


    // $ANTLR start "entryRuleIFRQ"
    // InternalConfigurator.g:4396:1: entryRuleIFRQ returns [EObject current=null] : iv_ruleIFRQ= ruleIFRQ EOF ;
    public final EObject entryRuleIFRQ() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIFRQ = null;


        try {
            // InternalConfigurator.g:4397:2: (iv_ruleIFRQ= ruleIFRQ EOF )
            // InternalConfigurator.g:4398:2: iv_ruleIFRQ= ruleIFRQ EOF
            {
             newCompositeNode(grammarAccess.getIFRQRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIFRQ=ruleIFRQ();

            state._fsp--;

             current =iv_ruleIFRQ; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIFRQ"


    // $ANTLR start "ruleIFRQ"
    // InternalConfigurator.g:4405:1: ruleIFRQ returns [EObject current=null] : (otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Sensor' ( ( ruleQualifiedName ) ) otherlv_8= 'UpdateTime' ( (lv_updateTime_9_0= ruleINTORHEX ) ) otherlv_10= 'Active' ( (lv_active_11_0= ruleINTORHEX ) ) otherlv_12= '}' ) ;
    public final EObject ruleIFRQ() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        AntlrDatatypeRuleToken lv_driverIndex_5_0 = null;

        AntlrDatatypeRuleToken lv_updateTime_9_0 = null;

        AntlrDatatypeRuleToken lv_active_11_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:4408:28: ( (otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Sensor' ( ( ruleQualifiedName ) ) otherlv_8= 'UpdateTime' ( (lv_updateTime_9_0= ruleINTORHEX ) ) otherlv_10= 'Active' ( (lv_active_11_0= ruleINTORHEX ) ) otherlv_12= '}' ) )
            // InternalConfigurator.g:4409:1: (otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Sensor' ( ( ruleQualifiedName ) ) otherlv_8= 'UpdateTime' ( (lv_updateTime_9_0= ruleINTORHEX ) ) otherlv_10= 'Active' ( (lv_active_11_0= ruleINTORHEX ) ) otherlv_12= '}' )
            {
            // InternalConfigurator.g:4409:1: (otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Sensor' ( ( ruleQualifiedName ) ) otherlv_8= 'UpdateTime' ( (lv_updateTime_9_0= ruleINTORHEX ) ) otherlv_10= 'Active' ( (lv_active_11_0= ruleINTORHEX ) ) otherlv_12= '}' )
            // InternalConfigurator.g:4409:3: otherlv_0= 'Port' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Sensor' ( ( ruleQualifiedName ) ) otherlv_8= 'UpdateTime' ( (lv_updateTime_9_0= ruleINTORHEX ) ) otherlv_10= 'Active' ( (lv_active_11_0= ruleINTORHEX ) ) otherlv_12= '}'
            {
            otherlv_0=(Token)match(input,62,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getIFRQAccess().getPortKeyword_0());
                
            // InternalConfigurator.g:4413:1: ()
            // InternalConfigurator.g:4414:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getIFRQAccess().getIFRQAction_1(),
                        current);
                

            }

            // InternalConfigurator.g:4419:2: ( (lv_name_2_0= RULE_ID ) )
            // InternalConfigurator.g:4420:1: (lv_name_2_0= RULE_ID )
            {
            // InternalConfigurator.g:4420:1: (lv_name_2_0= RULE_ID )
            // InternalConfigurator.g:4421:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_2_0, grammarAccess.getIFRQAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getIFRQRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_63); 

                	newLeafNode(otherlv_3, grammarAccess.getIFRQAccess().getLeftCurlyBracketKeyword_3());
                
            otherlv_4=(Token)match(input,63,FOLLOW_21); 

                	newLeafNode(otherlv_4, grammarAccess.getIFRQAccess().getDriverIndexKeyword_4());
                
            // InternalConfigurator.g:4445:1: ( (lv_driverIndex_5_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4446:1: (lv_driverIndex_5_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4446:1: (lv_driverIndex_5_0= ruleINTORHEX )
            // InternalConfigurator.g:4447:3: lv_driverIndex_5_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getIFRQAccess().getDriverIndexINTORHEXParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_75);
            lv_driverIndex_5_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getIFRQRule());
            	        }
                   		set(
                   			current, 
                   			"driverIndex",
                    		lv_driverIndex_5_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_6=(Token)match(input,74,FOLLOW_3); 

                	newLeafNode(otherlv_6, grammarAccess.getIFRQAccess().getSensorKeyword_6());
                
            // InternalConfigurator.g:4467:1: ( ( ruleQualifiedName ) )
            // InternalConfigurator.g:4468:1: ( ruleQualifiedName )
            {
            // InternalConfigurator.g:4468:1: ( ruleQualifiedName )
            // InternalConfigurator.g:4469:3: ruleQualifiedName
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getIFRQRule());
            	        }
                    
             
            	        newCompositeNode(grammarAccess.getIFRQAccess().getSensorIndexIFRQSensorCrossReference_7_0()); 
            	    
            pushFollow(FOLLOW_76);
            ruleQualifiedName();

            state._fsp--;

             
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_8=(Token)match(input,75,FOLLOW_21); 

                	newLeafNode(otherlv_8, grammarAccess.getIFRQAccess().getUpdateTimeKeyword_8());
                
            // InternalConfigurator.g:4486:1: ( (lv_updateTime_9_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4487:1: (lv_updateTime_9_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4487:1: (lv_updateTime_9_0= ruleINTORHEX )
            // InternalConfigurator.g:4488:3: lv_updateTime_9_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getIFRQAccess().getUpdateTimeINTORHEXParserRuleCall_9_0()); 
            	    
            pushFollow(FOLLOW_77);
            lv_updateTime_9_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getIFRQRule());
            	        }
                   		set(
                   			current, 
                   			"updateTime",
                    		lv_updateTime_9_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_10=(Token)match(input,76,FOLLOW_21); 

                	newLeafNode(otherlv_10, grammarAccess.getIFRQAccess().getActiveKeyword_10());
                
            // InternalConfigurator.g:4508:1: ( (lv_active_11_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4509:1: (lv_active_11_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4509:1: (lv_active_11_0= ruleINTORHEX )
            // InternalConfigurator.g:4510:3: lv_active_11_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getIFRQAccess().getActiveINTORHEXParserRuleCall_11_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_active_11_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getIFRQRule());
            	        }
                   		set(
                   			current, 
                   			"active",
                    		lv_active_11_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_12=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_12, grammarAccess.getIFRQAccess().getRightCurlyBracketKeyword_12());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIFRQ"


    // $ANTLR start "entryRuleIFRQSensor"
    // InternalConfigurator.g:4538:1: entryRuleIFRQSensor returns [EObject current=null] : iv_ruleIFRQSensor= ruleIFRQSensor EOF ;
    public final EObject entryRuleIFRQSensor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIFRQSensor = null;


        try {
            // InternalConfigurator.g:4539:2: (iv_ruleIFRQSensor= ruleIFRQSensor EOF )
            // InternalConfigurator.g:4540:2: iv_ruleIFRQSensor= ruleIFRQSensor EOF
            {
             newCompositeNode(grammarAccess.getIFRQSensorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIFRQSensor=ruleIFRQSensor();

            state._fsp--;

             current =iv_ruleIFRQSensor; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIFRQSensor"


    // $ANTLR start "ruleIFRQSensor"
    // InternalConfigurator.g:4547:1: ruleIFRQSensor returns [EObject current=null] : (otherlv_0= 'Sensor' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'InitialWaitingTime' ( (lv_initialWaitingTime_5_0= ruleINTORHEX ) ) otherlv_6= 'DirChangeMinPeriods' ( (lv_dirChangeMinPeriods_7_0= ruleINTORHEX ) ) otherlv_8= 'DirectionChangeDebounceTime' ( (lv_directionChangeDebounceTime_9_0= ruleINTORHEX ) ) otherlv_10= '}' ) ;
    public final EObject ruleIFRQSensor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_initialWaitingTime_5_0 = null;

        AntlrDatatypeRuleToken lv_dirChangeMinPeriods_7_0 = null;

        AntlrDatatypeRuleToken lv_directionChangeDebounceTime_9_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:4550:28: ( (otherlv_0= 'Sensor' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'InitialWaitingTime' ( (lv_initialWaitingTime_5_0= ruleINTORHEX ) ) otherlv_6= 'DirChangeMinPeriods' ( (lv_dirChangeMinPeriods_7_0= ruleINTORHEX ) ) otherlv_8= 'DirectionChangeDebounceTime' ( (lv_directionChangeDebounceTime_9_0= ruleINTORHEX ) ) otherlv_10= '}' ) )
            // InternalConfigurator.g:4551:1: (otherlv_0= 'Sensor' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'InitialWaitingTime' ( (lv_initialWaitingTime_5_0= ruleINTORHEX ) ) otherlv_6= 'DirChangeMinPeriods' ( (lv_dirChangeMinPeriods_7_0= ruleINTORHEX ) ) otherlv_8= 'DirectionChangeDebounceTime' ( (lv_directionChangeDebounceTime_9_0= ruleINTORHEX ) ) otherlv_10= '}' )
            {
            // InternalConfigurator.g:4551:1: (otherlv_0= 'Sensor' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'InitialWaitingTime' ( (lv_initialWaitingTime_5_0= ruleINTORHEX ) ) otherlv_6= 'DirChangeMinPeriods' ( (lv_dirChangeMinPeriods_7_0= ruleINTORHEX ) ) otherlv_8= 'DirectionChangeDebounceTime' ( (lv_directionChangeDebounceTime_9_0= ruleINTORHEX ) ) otherlv_10= '}' )
            // InternalConfigurator.g:4551:3: otherlv_0= 'Sensor' () ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'InitialWaitingTime' ( (lv_initialWaitingTime_5_0= ruleINTORHEX ) ) otherlv_6= 'DirChangeMinPeriods' ( (lv_dirChangeMinPeriods_7_0= ruleINTORHEX ) ) otherlv_8= 'DirectionChangeDebounceTime' ( (lv_directionChangeDebounceTime_9_0= ruleINTORHEX ) ) otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,74,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getIFRQSensorAccess().getSensorKeyword_0());
                
            // InternalConfigurator.g:4555:1: ()
            // InternalConfigurator.g:4556:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getIFRQSensorAccess().getIFRQSensorAction_1(),
                        current);
                

            }

            // InternalConfigurator.g:4561:2: ( (lv_name_2_0= RULE_ID ) )
            // InternalConfigurator.g:4562:1: (lv_name_2_0= RULE_ID )
            {
            // InternalConfigurator.g:4562:1: (lv_name_2_0= RULE_ID )
            // InternalConfigurator.g:4563:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_2_0, grammarAccess.getIFRQSensorAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getIFRQSensorRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_78); 

                	newLeafNode(otherlv_3, grammarAccess.getIFRQSensorAccess().getLeftCurlyBracketKeyword_3());
                
            otherlv_4=(Token)match(input,77,FOLLOW_21); 

                	newLeafNode(otherlv_4, grammarAccess.getIFRQSensorAccess().getInitialWaitingTimeKeyword_4());
                
            // InternalConfigurator.g:4587:1: ( (lv_initialWaitingTime_5_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4588:1: (lv_initialWaitingTime_5_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4588:1: (lv_initialWaitingTime_5_0= ruleINTORHEX )
            // InternalConfigurator.g:4589:3: lv_initialWaitingTime_5_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getIFRQSensorAccess().getInitialWaitingTimeINTORHEXParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_79);
            lv_initialWaitingTime_5_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getIFRQSensorRule());
            	        }
                   		set(
                   			current, 
                   			"initialWaitingTime",
                    		lv_initialWaitingTime_5_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_6=(Token)match(input,78,FOLLOW_21); 

                	newLeafNode(otherlv_6, grammarAccess.getIFRQSensorAccess().getDirChangeMinPeriodsKeyword_6());
                
            // InternalConfigurator.g:4609:1: ( (lv_dirChangeMinPeriods_7_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4610:1: (lv_dirChangeMinPeriods_7_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4610:1: (lv_dirChangeMinPeriods_7_0= ruleINTORHEX )
            // InternalConfigurator.g:4611:3: lv_dirChangeMinPeriods_7_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getIFRQSensorAccess().getDirChangeMinPeriodsINTORHEXParserRuleCall_7_0()); 
            	    
            pushFollow(FOLLOW_80);
            lv_dirChangeMinPeriods_7_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getIFRQSensorRule());
            	        }
                   		set(
                   			current, 
                   			"dirChangeMinPeriods",
                    		lv_dirChangeMinPeriods_7_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_8=(Token)match(input,79,FOLLOW_21); 

                	newLeafNode(otherlv_8, grammarAccess.getIFRQSensorAccess().getDirectionChangeDebounceTimeKeyword_8());
                
            // InternalConfigurator.g:4631:1: ( (lv_directionChangeDebounceTime_9_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4632:1: (lv_directionChangeDebounceTime_9_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4632:1: (lv_directionChangeDebounceTime_9_0= ruleINTORHEX )
            // InternalConfigurator.g:4633:3: lv_directionChangeDebounceTime_9_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getIFRQSensorAccess().getDirectionChangeDebounceTimeINTORHEXParserRuleCall_9_0()); 
            	    
            pushFollow(FOLLOW_11);
            lv_directionChangeDebounceTime_9_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getIFRQSensorRule());
            	        }
                   		set(
                   			current, 
                   			"directionChangeDebounceTime",
                    		lv_directionChangeDebounceTime_9_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_10=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_10, grammarAccess.getIFRQSensorAccess().getRightCurlyBracketKeyword_10());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIFRQSensor"


    // $ANTLR start "entryRuleSPIinputSys"
    // InternalConfigurator.g:4661:1: entryRuleSPIinputSys returns [EObject current=null] : iv_ruleSPIinputSys= ruleSPIinputSys EOF ;
    public final EObject entryRuleSPIinputSys() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSPIinputSys = null;


        try {
            // InternalConfigurator.g:4662:2: (iv_ruleSPIinputSys= ruleSPIinputSys EOF )
            // InternalConfigurator.g:4663:2: iv_ruleSPIinputSys= ruleSPIinputSys EOF
            {
             newCompositeNode(grammarAccess.getSPIinputSysRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSPIinputSys=ruleSPIinputSys();

            state._fsp--;

             current =iv_ruleSPIinputSys; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSPIinputSys"


    // $ANTLR start "ruleSPIinputSys"
    // InternalConfigurator.g:4670:1: ruleSPIinputSys returns [EObject current=null] : (otherlv_0= 'SPIinput' () otherlv_2= '{' ( (lv_spi_3_0= ruleSPI ) )+ otherlv_4= '}' ) ;
    public final EObject ruleSPIinputSys() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_spi_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:4673:28: ( (otherlv_0= 'SPIinput' () otherlv_2= '{' ( (lv_spi_3_0= ruleSPI ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:4674:1: (otherlv_0= 'SPIinput' () otherlv_2= '{' ( (lv_spi_3_0= ruleSPI ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:4674:1: (otherlv_0= 'SPIinput' () otherlv_2= '{' ( (lv_spi_3_0= ruleSPI ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:4674:3: otherlv_0= 'SPIinput' () otherlv_2= '{' ( (lv_spi_3_0= ruleSPI ) )+ otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,80,FOLLOW_4); 

                	newLeafNode(otherlv_0, grammarAccess.getSPIinputSysAccess().getSPIinputKeyword_0());
                
            // InternalConfigurator.g:4678:1: ()
            // InternalConfigurator.g:4679:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getSPIinputSysAccess().getSPIinputSysAction_1(),
                        current);
                

            }

            otherlv_2=(Token)match(input,15,FOLLOW_61); 

                	newLeafNode(otherlv_2, grammarAccess.getSPIinputSysAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:4688:1: ( (lv_spi_3_0= ruleSPI ) )+
            int cnt59=0;
            loop59:
            do {
                int alt59=2;
                int LA59_0 = input.LA(1);

                if ( (LA59_0==62) ) {
                    alt59=1;
                }


                switch (alt59) {
            	case 1 :
            	    // InternalConfigurator.g:4689:1: (lv_spi_3_0= ruleSPI )
            	    {
            	    // InternalConfigurator.g:4689:1: (lv_spi_3_0= ruleSPI )
            	    // InternalConfigurator.g:4690:3: lv_spi_3_0= ruleSPI
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getSPIinputSysAccess().getSpiSPIParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_62);
            	    lv_spi_3_0=ruleSPI();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getSPIinputSysRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"spi",
            	            		lv_spi_3_0, 
            	            		"zf.pios.Configurator.SPI");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt59 >= 1 ) break loop59;
                        EarlyExitException eee =
                            new EarlyExitException(59, input);
                        throw eee;
                }
                cnt59++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getSPIinputSysAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSPIinputSys"


    // $ANTLR start "entryRuleSPI"
    // InternalConfigurator.g:4718:1: entryRuleSPI returns [EObject current=null] : iv_ruleSPI= ruleSPI EOF ;
    public final EObject entryRuleSPI() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSPI = null;


        try {
            // InternalConfigurator.g:4719:2: (iv_ruleSPI= ruleSPI EOF )
            // InternalConfigurator.g:4720:2: iv_ruleSPI= ruleSPI EOF
            {
             newCompositeNode(grammarAccess.getSPIRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSPI=ruleSPI();

            state._fsp--;

             current =iv_ruleSPI; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSPI"


    // $ANTLR start "ruleSPI"
    // InternalConfigurator.g:4727:1: ruleSPI returns [EObject current=null] : ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'DataStorageMode' ( (lv_dataStorageMode_7_0= ruleINTORHEX ) ) otherlv_8= 'SPIcommand' ( (lv_command_9_0= ruleINTORHEX ) ) otherlv_10= 'DataLength' ( (lv_dataLength_11_0= ruleINTORHEX ) ) ( (lv_spitxData_12_0= ruleSPITXData ) ) otherlv_13= 'Module' ( (lv_module_14_0= ruleINTORHEX ) ) (otherlv_15= 'Description' ( (lv_description_16_0= RULE_STRING ) ) )? otherlv_17= '}' ) ;
    public final EObject ruleSPI() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token lv_description_16_0=null;
        Token otherlv_17=null;
        AntlrDatatypeRuleToken lv_driverIndex_5_0 = null;

        AntlrDatatypeRuleToken lv_dataStorageMode_7_0 = null;

        AntlrDatatypeRuleToken lv_command_9_0 = null;

        AntlrDatatypeRuleToken lv_dataLength_11_0 = null;

        EObject lv_spitxData_12_0 = null;

        AntlrDatatypeRuleToken lv_module_14_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:4730:28: ( ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'DataStorageMode' ( (lv_dataStorageMode_7_0= ruleINTORHEX ) ) otherlv_8= 'SPIcommand' ( (lv_command_9_0= ruleINTORHEX ) ) otherlv_10= 'DataLength' ( (lv_dataLength_11_0= ruleINTORHEX ) ) ( (lv_spitxData_12_0= ruleSPITXData ) ) otherlv_13= 'Module' ( (lv_module_14_0= ruleINTORHEX ) ) (otherlv_15= 'Description' ( (lv_description_16_0= RULE_STRING ) ) )? otherlv_17= '}' ) )
            // InternalConfigurator.g:4731:1: ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'DataStorageMode' ( (lv_dataStorageMode_7_0= ruleINTORHEX ) ) otherlv_8= 'SPIcommand' ( (lv_command_9_0= ruleINTORHEX ) ) otherlv_10= 'DataLength' ( (lv_dataLength_11_0= ruleINTORHEX ) ) ( (lv_spitxData_12_0= ruleSPITXData ) ) otherlv_13= 'Module' ( (lv_module_14_0= ruleINTORHEX ) ) (otherlv_15= 'Description' ( (lv_description_16_0= RULE_STRING ) ) )? otherlv_17= '}' )
            {
            // InternalConfigurator.g:4731:1: ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'DataStorageMode' ( (lv_dataStorageMode_7_0= ruleINTORHEX ) ) otherlv_8= 'SPIcommand' ( (lv_command_9_0= ruleINTORHEX ) ) otherlv_10= 'DataLength' ( (lv_dataLength_11_0= ruleINTORHEX ) ) ( (lv_spitxData_12_0= ruleSPITXData ) ) otherlv_13= 'Module' ( (lv_module_14_0= ruleINTORHEX ) ) (otherlv_15= 'Description' ( (lv_description_16_0= RULE_STRING ) ) )? otherlv_17= '}' )
            // InternalConfigurator.g:4731:2: () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'DataStorageMode' ( (lv_dataStorageMode_7_0= ruleINTORHEX ) ) otherlv_8= 'SPIcommand' ( (lv_command_9_0= ruleINTORHEX ) ) otherlv_10= 'DataLength' ( (lv_dataLength_11_0= ruleINTORHEX ) ) ( (lv_spitxData_12_0= ruleSPITXData ) ) otherlv_13= 'Module' ( (lv_module_14_0= ruleINTORHEX ) ) (otherlv_15= 'Description' ( (lv_description_16_0= RULE_STRING ) ) )? otherlv_17= '}'
            {
            // InternalConfigurator.g:4731:2: ()
            // InternalConfigurator.g:4732:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getSPIAccess().getSPIAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,62,FOLLOW_3); 

                	newLeafNode(otherlv_1, grammarAccess.getSPIAccess().getPortKeyword_1());
                
            // InternalConfigurator.g:4741:1: ( (lv_name_2_0= RULE_ID ) )
            // InternalConfigurator.g:4742:1: (lv_name_2_0= RULE_ID )
            {
            // InternalConfigurator.g:4742:1: (lv_name_2_0= RULE_ID )
            // InternalConfigurator.g:4743:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_2_0, grammarAccess.getSPIAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSPIRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_63); 

                	newLeafNode(otherlv_3, grammarAccess.getSPIAccess().getLeftCurlyBracketKeyword_3());
                
            otherlv_4=(Token)match(input,63,FOLLOW_21); 

                	newLeafNode(otherlv_4, grammarAccess.getSPIAccess().getDriverIndexKeyword_4());
                
            // InternalConfigurator.g:4767:1: ( (lv_driverIndex_5_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4768:1: (lv_driverIndex_5_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4768:1: (lv_driverIndex_5_0= ruleINTORHEX )
            // InternalConfigurator.g:4769:3: lv_driverIndex_5_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getSPIAccess().getDriverIndexINTORHEXParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_81);
            lv_driverIndex_5_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getSPIRule());
            	        }
                   		set(
                   			current, 
                   			"driverIndex",
                    		lv_driverIndex_5_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_6=(Token)match(input,81,FOLLOW_21); 

                	newLeafNode(otherlv_6, grammarAccess.getSPIAccess().getDataStorageModeKeyword_6());
                
            // InternalConfigurator.g:4789:1: ( (lv_dataStorageMode_7_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4790:1: (lv_dataStorageMode_7_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4790:1: (lv_dataStorageMode_7_0= ruleINTORHEX )
            // InternalConfigurator.g:4791:3: lv_dataStorageMode_7_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getSPIAccess().getDataStorageModeINTORHEXParserRuleCall_7_0()); 
            	    
            pushFollow(FOLLOW_82);
            lv_dataStorageMode_7_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getSPIRule());
            	        }
                   		set(
                   			current, 
                   			"dataStorageMode",
                    		lv_dataStorageMode_7_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_8=(Token)match(input,82,FOLLOW_21); 

                	newLeafNode(otherlv_8, grammarAccess.getSPIAccess().getSPIcommandKeyword_8());
                
            // InternalConfigurator.g:4811:1: ( (lv_command_9_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4812:1: (lv_command_9_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4812:1: (lv_command_9_0= ruleINTORHEX )
            // InternalConfigurator.g:4813:3: lv_command_9_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getSPIAccess().getCommandINTORHEXParserRuleCall_9_0()); 
            	    
            pushFollow(FOLLOW_83);
            lv_command_9_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getSPIRule());
            	        }
                   		set(
                   			current, 
                   			"command",
                    		lv_command_9_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_10=(Token)match(input,83,FOLLOW_21); 

                	newLeafNode(otherlv_10, grammarAccess.getSPIAccess().getDataLengthKeyword_10());
                
            // InternalConfigurator.g:4833:1: ( (lv_dataLength_11_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4834:1: (lv_dataLength_11_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4834:1: (lv_dataLength_11_0= ruleINTORHEX )
            // InternalConfigurator.g:4835:3: lv_dataLength_11_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getSPIAccess().getDataLengthINTORHEXParserRuleCall_11_0()); 
            	    
            pushFollow(FOLLOW_84);
            lv_dataLength_11_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getSPIRule());
            	        }
                   		set(
                   			current, 
                   			"dataLength",
                    		lv_dataLength_11_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:4851:2: ( (lv_spitxData_12_0= ruleSPITXData ) )
            // InternalConfigurator.g:4852:1: (lv_spitxData_12_0= ruleSPITXData )
            {
            // InternalConfigurator.g:4852:1: (lv_spitxData_12_0= ruleSPITXData )
            // InternalConfigurator.g:4853:3: lv_spitxData_12_0= ruleSPITXData
            {
             
            	        newCompositeNode(grammarAccess.getSPIAccess().getSpitxDataSPITXDataParserRuleCall_12_0()); 
            	    
            pushFollow(FOLLOW_85);
            lv_spitxData_12_0=ruleSPITXData();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getSPIRule());
            	        }
                   		set(
                   			current, 
                   			"spitxData",
                    		lv_spitxData_12_0, 
                    		"zf.pios.Configurator.SPITXData");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_13=(Token)match(input,84,FOLLOW_21); 

                	newLeafNode(otherlv_13, grammarAccess.getSPIAccess().getModuleKeyword_13());
                
            // InternalConfigurator.g:4873:1: ( (lv_module_14_0= ruleINTORHEX ) )
            // InternalConfigurator.g:4874:1: (lv_module_14_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:4874:1: (lv_module_14_0= ruleINTORHEX )
            // InternalConfigurator.g:4875:3: lv_module_14_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getSPIAccess().getModuleINTORHEXParserRuleCall_14_0()); 
            	    
            pushFollow(FOLLOW_73);
            lv_module_14_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getSPIRule());
            	        }
                   		set(
                   			current, 
                   			"module",
                    		lv_module_14_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:4891:2: (otherlv_15= 'Description' ( (lv_description_16_0= RULE_STRING ) ) )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==35) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalConfigurator.g:4891:4: otherlv_15= 'Description' ( (lv_description_16_0= RULE_STRING ) )
                    {
                    otherlv_15=(Token)match(input,35,FOLLOW_32); 

                        	newLeafNode(otherlv_15, grammarAccess.getSPIAccess().getDescriptionKeyword_15_0());
                        
                    // InternalConfigurator.g:4895:1: ( (lv_description_16_0= RULE_STRING ) )
                    // InternalConfigurator.g:4896:1: (lv_description_16_0= RULE_STRING )
                    {
                    // InternalConfigurator.g:4896:1: (lv_description_16_0= RULE_STRING )
                    // InternalConfigurator.g:4897:3: lv_description_16_0= RULE_STRING
                    {
                    lv_description_16_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                    			newLeafNode(lv_description_16_0, grammarAccess.getSPIAccess().getDescriptionSTRINGTerminalRuleCall_15_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getSPIRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"description",
                            		lv_description_16_0, 
                            		"org.eclipse.xtext.common.Terminals.STRING");
                    	    

                    }


                    }


                    }
                    break;

            }

            otherlv_17=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_17, grammarAccess.getSPIAccess().getRightCurlyBracketKeyword_16());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSPI"


    // $ANTLR start "entryRuleSPITXData"
    // InternalConfigurator.g:4925:1: entryRuleSPITXData returns [EObject current=null] : iv_ruleSPITXData= ruleSPITXData EOF ;
    public final EObject entryRuleSPITXData() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSPITXData = null;


        try {
            // InternalConfigurator.g:4926:2: (iv_ruleSPITXData= ruleSPITXData EOF )
            // InternalConfigurator.g:4927:2: iv_ruleSPITXData= ruleSPITXData EOF
            {
             newCompositeNode(grammarAccess.getSPITXDataRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSPITXData=ruleSPITXData();

            state._fsp--;

             current =iv_ruleSPITXData; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSPITXData"


    // $ANTLR start "ruleSPITXData"
    // InternalConfigurator.g:4934:1: ruleSPITXData returns [EObject current=null] : (otherlv_0= 'SPITXData' otherlv_1= '{' otherlv_2= 'Byte1' ( (lv_byteOne_3_0= RULE_HEX ) ) otherlv_4= 'Byte2' ( (lv_byteTwo_5_0= RULE_HEX ) ) otherlv_6= 'Byte3' ( (lv_byteThree_7_0= RULE_HEX ) ) otherlv_8= 'Byte4' ( (lv_byteFour_9_0= RULE_HEX ) ) otherlv_10= '}' ) ;
    public final EObject ruleSPITXData() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_byteOne_3_0=null;
        Token otherlv_4=null;
        Token lv_byteTwo_5_0=null;
        Token otherlv_6=null;
        Token lv_byteThree_7_0=null;
        Token otherlv_8=null;
        Token lv_byteFour_9_0=null;
        Token otherlv_10=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:4937:28: ( (otherlv_0= 'SPITXData' otherlv_1= '{' otherlv_2= 'Byte1' ( (lv_byteOne_3_0= RULE_HEX ) ) otherlv_4= 'Byte2' ( (lv_byteTwo_5_0= RULE_HEX ) ) otherlv_6= 'Byte3' ( (lv_byteThree_7_0= RULE_HEX ) ) otherlv_8= 'Byte4' ( (lv_byteFour_9_0= RULE_HEX ) ) otherlv_10= '}' ) )
            // InternalConfigurator.g:4938:1: (otherlv_0= 'SPITXData' otherlv_1= '{' otherlv_2= 'Byte1' ( (lv_byteOne_3_0= RULE_HEX ) ) otherlv_4= 'Byte2' ( (lv_byteTwo_5_0= RULE_HEX ) ) otherlv_6= 'Byte3' ( (lv_byteThree_7_0= RULE_HEX ) ) otherlv_8= 'Byte4' ( (lv_byteFour_9_0= RULE_HEX ) ) otherlv_10= '}' )
            {
            // InternalConfigurator.g:4938:1: (otherlv_0= 'SPITXData' otherlv_1= '{' otherlv_2= 'Byte1' ( (lv_byteOne_3_0= RULE_HEX ) ) otherlv_4= 'Byte2' ( (lv_byteTwo_5_0= RULE_HEX ) ) otherlv_6= 'Byte3' ( (lv_byteThree_7_0= RULE_HEX ) ) otherlv_8= 'Byte4' ( (lv_byteFour_9_0= RULE_HEX ) ) otherlv_10= '}' )
            // InternalConfigurator.g:4938:3: otherlv_0= 'SPITXData' otherlv_1= '{' otherlv_2= 'Byte1' ( (lv_byteOne_3_0= RULE_HEX ) ) otherlv_4= 'Byte2' ( (lv_byteTwo_5_0= RULE_HEX ) ) otherlv_6= 'Byte3' ( (lv_byteThree_7_0= RULE_HEX ) ) otherlv_8= 'Byte4' ( (lv_byteFour_9_0= RULE_HEX ) ) otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,85,FOLLOW_4); 

                	newLeafNode(otherlv_0, grammarAccess.getSPITXDataAccess().getSPITXDataKeyword_0());
                
            otherlv_1=(Token)match(input,15,FOLLOW_86); 

                	newLeafNode(otherlv_1, grammarAccess.getSPITXDataAccess().getLeftCurlyBracketKeyword_1());
                
            otherlv_2=(Token)match(input,86,FOLLOW_87); 

                	newLeafNode(otherlv_2, grammarAccess.getSPITXDataAccess().getByte1Keyword_2());
                
            // InternalConfigurator.g:4950:1: ( (lv_byteOne_3_0= RULE_HEX ) )
            // InternalConfigurator.g:4951:1: (lv_byteOne_3_0= RULE_HEX )
            {
            // InternalConfigurator.g:4951:1: (lv_byteOne_3_0= RULE_HEX )
            // InternalConfigurator.g:4952:3: lv_byteOne_3_0= RULE_HEX
            {
            lv_byteOne_3_0=(Token)match(input,RULE_HEX,FOLLOW_88); 

            			newLeafNode(lv_byteOne_3_0, grammarAccess.getSPITXDataAccess().getByteOneHEXTerminalRuleCall_3_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSPITXDataRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"byteOne",
                    		lv_byteOne_3_0, 
                    		"zf.pios.Configurator.HEX");
            	    

            }


            }

            otherlv_4=(Token)match(input,87,FOLLOW_87); 

                	newLeafNode(otherlv_4, grammarAccess.getSPITXDataAccess().getByte2Keyword_4());
                
            // InternalConfigurator.g:4972:1: ( (lv_byteTwo_5_0= RULE_HEX ) )
            // InternalConfigurator.g:4973:1: (lv_byteTwo_5_0= RULE_HEX )
            {
            // InternalConfigurator.g:4973:1: (lv_byteTwo_5_0= RULE_HEX )
            // InternalConfigurator.g:4974:3: lv_byteTwo_5_0= RULE_HEX
            {
            lv_byteTwo_5_0=(Token)match(input,RULE_HEX,FOLLOW_89); 

            			newLeafNode(lv_byteTwo_5_0, grammarAccess.getSPITXDataAccess().getByteTwoHEXTerminalRuleCall_5_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSPITXDataRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"byteTwo",
                    		lv_byteTwo_5_0, 
                    		"zf.pios.Configurator.HEX");
            	    

            }


            }

            otherlv_6=(Token)match(input,88,FOLLOW_87); 

                	newLeafNode(otherlv_6, grammarAccess.getSPITXDataAccess().getByte3Keyword_6());
                
            // InternalConfigurator.g:4994:1: ( (lv_byteThree_7_0= RULE_HEX ) )
            // InternalConfigurator.g:4995:1: (lv_byteThree_7_0= RULE_HEX )
            {
            // InternalConfigurator.g:4995:1: (lv_byteThree_7_0= RULE_HEX )
            // InternalConfigurator.g:4996:3: lv_byteThree_7_0= RULE_HEX
            {
            lv_byteThree_7_0=(Token)match(input,RULE_HEX,FOLLOW_90); 

            			newLeafNode(lv_byteThree_7_0, grammarAccess.getSPITXDataAccess().getByteThreeHEXTerminalRuleCall_7_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSPITXDataRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"byteThree",
                    		lv_byteThree_7_0, 
                    		"zf.pios.Configurator.HEX");
            	    

            }


            }

            otherlv_8=(Token)match(input,89,FOLLOW_87); 

                	newLeafNode(otherlv_8, grammarAccess.getSPITXDataAccess().getByte4Keyword_8());
                
            // InternalConfigurator.g:5016:1: ( (lv_byteFour_9_0= RULE_HEX ) )
            // InternalConfigurator.g:5017:1: (lv_byteFour_9_0= RULE_HEX )
            {
            // InternalConfigurator.g:5017:1: (lv_byteFour_9_0= RULE_HEX )
            // InternalConfigurator.g:5018:3: lv_byteFour_9_0= RULE_HEX
            {
            lv_byteFour_9_0=(Token)match(input,RULE_HEX,FOLLOW_11); 

            			newLeafNode(lv_byteFour_9_0, grammarAccess.getSPITXDataAccess().getByteFourHEXTerminalRuleCall_9_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSPITXDataRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"byteFour",
                    		lv_byteFour_9_0, 
                    		"zf.pios.Configurator.HEX");
            	    

            }


            }

            otherlv_10=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_10, grammarAccess.getSPITXDataAccess().getRightCurlyBracketKeyword_10());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSPITXData"


    // $ANTLR start "entryRuleOPWMSubsystem"
    // InternalConfigurator.g:5046:1: entryRuleOPWMSubsystem returns [EObject current=null] : iv_ruleOPWMSubsystem= ruleOPWMSubsystem EOF ;
    public final EObject entryRuleOPWMSubsystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOPWMSubsystem = null;


        try {
            // InternalConfigurator.g:5047:2: (iv_ruleOPWMSubsystem= ruleOPWMSubsystem EOF )
            // InternalConfigurator.g:5048:2: iv_ruleOPWMSubsystem= ruleOPWMSubsystem EOF
            {
             newCompositeNode(grammarAccess.getOPWMSubsystemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOPWMSubsystem=ruleOPWMSubsystem();

            state._fsp--;

             current =iv_ruleOPWMSubsystem; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOPWMSubsystem"


    // $ANTLR start "ruleOPWMSubsystem"
    // InternalConfigurator.g:5055:1: ruleOPWMSubsystem returns [EObject current=null] : (otherlv_0= 'OPWM' () otherlv_2= '{' ( (lv_opwm_3_0= ruleOPWM ) )+ otherlv_4= '}' ) ;
    public final EObject ruleOPWMSubsystem() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_opwm_3_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5058:28: ( (otherlv_0= 'OPWM' () otherlv_2= '{' ( (lv_opwm_3_0= ruleOPWM ) )+ otherlv_4= '}' ) )
            // InternalConfigurator.g:5059:1: (otherlv_0= 'OPWM' () otherlv_2= '{' ( (lv_opwm_3_0= ruleOPWM ) )+ otherlv_4= '}' )
            {
            // InternalConfigurator.g:5059:1: (otherlv_0= 'OPWM' () otherlv_2= '{' ( (lv_opwm_3_0= ruleOPWM ) )+ otherlv_4= '}' )
            // InternalConfigurator.g:5059:3: otherlv_0= 'OPWM' () otherlv_2= '{' ( (lv_opwm_3_0= ruleOPWM ) )+ otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,90,FOLLOW_4); 

                	newLeafNode(otherlv_0, grammarAccess.getOPWMSubsystemAccess().getOPWMKeyword_0());
                
            // InternalConfigurator.g:5063:1: ()
            // InternalConfigurator.g:5064:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getOPWMSubsystemAccess().getOPWMSubsystemAction_1(),
                        current);
                

            }

            otherlv_2=(Token)match(input,15,FOLLOW_61); 

                	newLeafNode(otherlv_2, grammarAccess.getOPWMSubsystemAccess().getLeftCurlyBracketKeyword_2());
                
            // InternalConfigurator.g:5073:1: ( (lv_opwm_3_0= ruleOPWM ) )+
            int cnt61=0;
            loop61:
            do {
                int alt61=2;
                int LA61_0 = input.LA(1);

                if ( (LA61_0==62) ) {
                    alt61=1;
                }


                switch (alt61) {
            	case 1 :
            	    // InternalConfigurator.g:5074:1: (lv_opwm_3_0= ruleOPWM )
            	    {
            	    // InternalConfigurator.g:5074:1: (lv_opwm_3_0= ruleOPWM )
            	    // InternalConfigurator.g:5075:3: lv_opwm_3_0= ruleOPWM
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOPWMSubsystemAccess().getOpwmOPWMParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_62);
            	    lv_opwm_3_0=ruleOPWM();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOPWMSubsystemRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"opwm",
            	            		lv_opwm_3_0, 
            	            		"zf.pios.Configurator.OPWM");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt61 >= 1 ) break loop61;
                        EarlyExitException eee =
                            new EarlyExitException(61, input);
                        throw eee;
                }
                cnt61++;
            } while (true);

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_4, grammarAccess.getOPWMSubsystemAccess().getRightCurlyBracketKeyword_4());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOPWMSubsystem"


    // $ANTLR start "entryRuleOPWM"
    // InternalConfigurator.g:5103:1: entryRuleOPWM returns [EObject current=null] : iv_ruleOPWM= ruleOPWM EOF ;
    public final EObject entryRuleOPWM() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOPWM = null;


        try {
            // InternalConfigurator.g:5104:2: (iv_ruleOPWM= ruleOPWM EOF )
            // InternalConfigurator.g:5105:2: iv_ruleOPWM= ruleOPWM EOF
            {
             newCompositeNode(grammarAccess.getOPWMRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOPWM=ruleOPWM();

            state._fsp--;

             current =iv_ruleOPWM; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOPWM"


    // $ANTLR start "ruleOPWM"
    // InternalConfigurator.g:5112:1: ruleOPWM returns [EObject current=null] : ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Period' ( (lv_Period_7_0= ruleSINT ) ) (otherlv_8= 'Description' ( (lv_description_9_0= RULE_STRING ) ) )? otherlv_10= '}' ) ;
    public final EObject ruleOPWM() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token lv_description_9_0=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_driverIndex_5_0 = null;

        AntlrDatatypeRuleToken lv_Period_7_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5115:28: ( ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Period' ( (lv_Period_7_0= ruleSINT ) ) (otherlv_8= 'Description' ( (lv_description_9_0= RULE_STRING ) ) )? otherlv_10= '}' ) )
            // InternalConfigurator.g:5116:1: ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Period' ( (lv_Period_7_0= ruleSINT ) ) (otherlv_8= 'Description' ( (lv_description_9_0= RULE_STRING ) ) )? otherlv_10= '}' )
            {
            // InternalConfigurator.g:5116:1: ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Period' ( (lv_Period_7_0= ruleSINT ) ) (otherlv_8= 'Description' ( (lv_description_9_0= RULE_STRING ) ) )? otherlv_10= '}' )
            // InternalConfigurator.g:5116:2: () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) otherlv_6= 'Period' ( (lv_Period_7_0= ruleSINT ) ) (otherlv_8= 'Description' ( (lv_description_9_0= RULE_STRING ) ) )? otherlv_10= '}'
            {
            // InternalConfigurator.g:5116:2: ()
            // InternalConfigurator.g:5117:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getOPWMAccess().getOPWMAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,62,FOLLOW_3); 

                	newLeafNode(otherlv_1, grammarAccess.getOPWMAccess().getPortKeyword_1());
                
            // InternalConfigurator.g:5126:1: ( (lv_name_2_0= RULE_ID ) )
            // InternalConfigurator.g:5127:1: (lv_name_2_0= RULE_ID )
            {
            // InternalConfigurator.g:5127:1: (lv_name_2_0= RULE_ID )
            // InternalConfigurator.g:5128:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_2_0, grammarAccess.getOPWMAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getOPWMRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_63); 

                	newLeafNode(otherlv_3, grammarAccess.getOPWMAccess().getLeftCurlyBracketKeyword_3());
                
            otherlv_4=(Token)match(input,63,FOLLOW_21); 

                	newLeafNode(otherlv_4, grammarAccess.getOPWMAccess().getDriverIndexKeyword_4());
                
            // InternalConfigurator.g:5152:1: ( (lv_driverIndex_5_0= ruleINTORHEX ) )
            // InternalConfigurator.g:5153:1: (lv_driverIndex_5_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:5153:1: (lv_driverIndex_5_0= ruleINTORHEX )
            // InternalConfigurator.g:5154:3: lv_driverIndex_5_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getOPWMAccess().getDriverIndexINTORHEXParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_91);
            lv_driverIndex_5_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getOPWMRule());
            	        }
                   		set(
                   			current, 
                   			"driverIndex",
                    		lv_driverIndex_5_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_6=(Token)match(input,91,FOLLOW_92); 

                	newLeafNode(otherlv_6, grammarAccess.getOPWMAccess().getPeriodKeyword_6());
                
            // InternalConfigurator.g:5174:1: ( (lv_Period_7_0= ruleSINT ) )
            // InternalConfigurator.g:5175:1: (lv_Period_7_0= ruleSINT )
            {
            // InternalConfigurator.g:5175:1: (lv_Period_7_0= ruleSINT )
            // InternalConfigurator.g:5176:3: lv_Period_7_0= ruleSINT
            {
             
            	        newCompositeNode(grammarAccess.getOPWMAccess().getPeriodSINTParserRuleCall_7_0()); 
            	    
            pushFollow(FOLLOW_73);
            lv_Period_7_0=ruleSINT();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getOPWMRule());
            	        }
                   		set(
                   			current, 
                   			"Period",
                    		lv_Period_7_0, 
                    		"zf.pios.Configurator.SINT");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:5192:2: (otherlv_8= 'Description' ( (lv_description_9_0= RULE_STRING ) ) )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==35) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalConfigurator.g:5192:4: otherlv_8= 'Description' ( (lv_description_9_0= RULE_STRING ) )
                    {
                    otherlv_8=(Token)match(input,35,FOLLOW_32); 

                        	newLeafNode(otherlv_8, grammarAccess.getOPWMAccess().getDescriptionKeyword_8_0());
                        
                    // InternalConfigurator.g:5196:1: ( (lv_description_9_0= RULE_STRING ) )
                    // InternalConfigurator.g:5197:1: (lv_description_9_0= RULE_STRING )
                    {
                    // InternalConfigurator.g:5197:1: (lv_description_9_0= RULE_STRING )
                    // InternalConfigurator.g:5198:3: lv_description_9_0= RULE_STRING
                    {
                    lv_description_9_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                    			newLeafNode(lv_description_9_0, grammarAccess.getOPWMAccess().getDescriptionSTRINGTerminalRuleCall_8_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getOPWMRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"description",
                            		lv_description_9_0, 
                            		"org.eclipse.xtext.common.Terminals.STRING");
                    	    

                    }


                    }


                    }
                    break;

            }

            otherlv_10=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_10, grammarAccess.getOPWMAccess().getRightCurlyBracketKeyword_9());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOPWM"


    // $ANTLR start "entryRuleIADC"
    // InternalConfigurator.g:5226:1: entryRuleIADC returns [EObject current=null] : iv_ruleIADC= ruleIADC EOF ;
    public final EObject entryRuleIADC() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIADC = null;


        try {
            // InternalConfigurator.g:5227:2: (iv_ruleIADC= ruleIADC EOF )
            // InternalConfigurator.g:5228:2: iv_ruleIADC= ruleIADC EOF
            {
             newCompositeNode(grammarAccess.getIADCRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIADC=ruleIADC();

            state._fsp--;

             current =iv_ruleIADC; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIADC"


    // $ANTLR start "ruleIADC"
    // InternalConfigurator.g:5235:1: ruleIADC returns [EObject current=null] : ( () otherlv_1= 'DriverIndex' ( (lv_driverIndex_2_0= ruleINTORHEX ) ) (otherlv_3= 'Enable' ( (lv_enable_4_0= ruleiadcEnableEnumeration ) ) )? (otherlv_5= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) )? ( (lv_enableElDiagPowerSupplyOff_7_0= 'EnableDiagnosisPowerSupplyOff' ) )? (otherlv_8= 'ElDiagInstanceIdx' ( (lv_elDiagInstanceIdx_9_0= ruleINTORHEX ) ) )? (otherlv_10= 'ControllerPinName' ( (lv_controllerPinName_11_0= RULE_STRING ) ) )? (otherlv_12= 'Description' ( (lv_description_13_0= RULE_STRING ) ) )? ) ;
    public final EObject ruleIADC() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token lv_enableElDiagPowerSupplyOff_7_0=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token lv_controllerPinName_11_0=null;
        Token otherlv_12=null;
        Token lv_description_13_0=null;
        AntlrDatatypeRuleToken lv_driverIndex_2_0 = null;

        Enumerator lv_enable_4_0 = null;

        AntlrDatatypeRuleToken lv_elDiagInstanceIdx_9_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5238:28: ( ( () otherlv_1= 'DriverIndex' ( (lv_driverIndex_2_0= ruleINTORHEX ) ) (otherlv_3= 'Enable' ( (lv_enable_4_0= ruleiadcEnableEnumeration ) ) )? (otherlv_5= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) )? ( (lv_enableElDiagPowerSupplyOff_7_0= 'EnableDiagnosisPowerSupplyOff' ) )? (otherlv_8= 'ElDiagInstanceIdx' ( (lv_elDiagInstanceIdx_9_0= ruleINTORHEX ) ) )? (otherlv_10= 'ControllerPinName' ( (lv_controllerPinName_11_0= RULE_STRING ) ) )? (otherlv_12= 'Description' ( (lv_description_13_0= RULE_STRING ) ) )? ) )
            // InternalConfigurator.g:5239:1: ( () otherlv_1= 'DriverIndex' ( (lv_driverIndex_2_0= ruleINTORHEX ) ) (otherlv_3= 'Enable' ( (lv_enable_4_0= ruleiadcEnableEnumeration ) ) )? (otherlv_5= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) )? ( (lv_enableElDiagPowerSupplyOff_7_0= 'EnableDiagnosisPowerSupplyOff' ) )? (otherlv_8= 'ElDiagInstanceIdx' ( (lv_elDiagInstanceIdx_9_0= ruleINTORHEX ) ) )? (otherlv_10= 'ControllerPinName' ( (lv_controllerPinName_11_0= RULE_STRING ) ) )? (otherlv_12= 'Description' ( (lv_description_13_0= RULE_STRING ) ) )? )
            {
            // InternalConfigurator.g:5239:1: ( () otherlv_1= 'DriverIndex' ( (lv_driverIndex_2_0= ruleINTORHEX ) ) (otherlv_3= 'Enable' ( (lv_enable_4_0= ruleiadcEnableEnumeration ) ) )? (otherlv_5= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) )? ( (lv_enableElDiagPowerSupplyOff_7_0= 'EnableDiagnosisPowerSupplyOff' ) )? (otherlv_8= 'ElDiagInstanceIdx' ( (lv_elDiagInstanceIdx_9_0= ruleINTORHEX ) ) )? (otherlv_10= 'ControllerPinName' ( (lv_controllerPinName_11_0= RULE_STRING ) ) )? (otherlv_12= 'Description' ( (lv_description_13_0= RULE_STRING ) ) )? )
            // InternalConfigurator.g:5239:2: () otherlv_1= 'DriverIndex' ( (lv_driverIndex_2_0= ruleINTORHEX ) ) (otherlv_3= 'Enable' ( (lv_enable_4_0= ruleiadcEnableEnumeration ) ) )? (otherlv_5= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) )? ( (lv_enableElDiagPowerSupplyOff_7_0= 'EnableDiagnosisPowerSupplyOff' ) )? (otherlv_8= 'ElDiagInstanceIdx' ( (lv_elDiagInstanceIdx_9_0= ruleINTORHEX ) ) )? (otherlv_10= 'ControllerPinName' ( (lv_controllerPinName_11_0= RULE_STRING ) ) )? (otherlv_12= 'Description' ( (lv_description_13_0= RULE_STRING ) ) )?
            {
            // InternalConfigurator.g:5239:2: ()
            // InternalConfigurator.g:5240:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getIADCAccess().getIADCAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,63,FOLLOW_21); 

                	newLeafNode(otherlv_1, grammarAccess.getIADCAccess().getDriverIndexKeyword_1());
                
            // InternalConfigurator.g:5249:1: ( (lv_driverIndex_2_0= ruleINTORHEX ) )
            // InternalConfigurator.g:5250:1: (lv_driverIndex_2_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:5250:1: (lv_driverIndex_2_0= ruleINTORHEX )
            // InternalConfigurator.g:5251:3: lv_driverIndex_2_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getIADCAccess().getDriverIndexINTORHEXParserRuleCall_2_0()); 
            	    
            pushFollow(FOLLOW_93);
            lv_driverIndex_2_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getIADCRule());
            	        }
                   		set(
                   			current, 
                   			"driverIndex",
                    		lv_driverIndex_2_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:5267:2: (otherlv_3= 'Enable' ( (lv_enable_4_0= ruleiadcEnableEnumeration ) ) )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==69) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalConfigurator.g:5267:4: otherlv_3= 'Enable' ( (lv_enable_4_0= ruleiadcEnableEnumeration ) )
                    {
                    otherlv_3=(Token)match(input,69,FOLLOW_94); 

                        	newLeafNode(otherlv_3, grammarAccess.getIADCAccess().getEnableKeyword_3_0());
                        
                    // InternalConfigurator.g:5271:1: ( (lv_enable_4_0= ruleiadcEnableEnumeration ) )
                    // InternalConfigurator.g:5272:1: (lv_enable_4_0= ruleiadcEnableEnumeration )
                    {
                    // InternalConfigurator.g:5272:1: (lv_enable_4_0= ruleiadcEnableEnumeration )
                    // InternalConfigurator.g:5273:3: lv_enable_4_0= ruleiadcEnableEnumeration
                    {
                     
                    	        newCompositeNode(grammarAccess.getIADCAccess().getEnableIadcEnableEnumerationEnumRuleCall_3_1_0()); 
                    	    
                    pushFollow(FOLLOW_95);
                    lv_enable_4_0=ruleiadcEnableEnumeration();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getIADCRule());
                    	        }
                           		set(
                           			current, 
                           			"enable",
                            		lv_enable_4_0, 
                            		"zf.pios.Configurator.iadcEnableEnumeration");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:5289:4: (otherlv_5= 'PowerSupplySignal' ( ( ruleQualifiedName ) ) )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==72) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalConfigurator.g:5289:6: otherlv_5= 'PowerSupplySignal' ( ( ruleQualifiedName ) )
                    {
                    otherlv_5=(Token)match(input,72,FOLLOW_3); 

                        	newLeafNode(otherlv_5, grammarAccess.getIADCAccess().getPowerSupplySignalKeyword_4_0());
                        
                    // InternalConfigurator.g:5293:1: ( ( ruleQualifiedName ) )
                    // InternalConfigurator.g:5294:1: ( ruleQualifiedName )
                    {
                    // InternalConfigurator.g:5294:1: ( ruleQualifiedName )
                    // InternalConfigurator.g:5295:3: ruleQualifiedName
                    {

                    			if (current==null) {
                    	            current = createModelElement(grammarAccess.getIADCRule());
                    	        }
                            
                     
                    	        newCompositeNode(grammarAccess.getIADCAccess().getPowerSupplySignalInputSignalCrossReference_4_1_0()); 
                    	    
                    pushFollow(FOLLOW_96);
                    ruleQualifiedName();

                    state._fsp--;

                     
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:5308:4: ( (lv_enableElDiagPowerSupplyOff_7_0= 'EnableDiagnosisPowerSupplyOff' ) )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==92) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalConfigurator.g:5309:1: (lv_enableElDiagPowerSupplyOff_7_0= 'EnableDiagnosisPowerSupplyOff' )
                    {
                    // InternalConfigurator.g:5309:1: (lv_enableElDiagPowerSupplyOff_7_0= 'EnableDiagnosisPowerSupplyOff' )
                    // InternalConfigurator.g:5310:3: lv_enableElDiagPowerSupplyOff_7_0= 'EnableDiagnosisPowerSupplyOff'
                    {
                    lv_enableElDiagPowerSupplyOff_7_0=(Token)match(input,92,FOLLOW_97); 

                            newLeafNode(lv_enableElDiagPowerSupplyOff_7_0, grammarAccess.getIADCAccess().getEnableElDiagPowerSupplyOffEnableDiagnosisPowerSupplyOffKeyword_5_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getIADCRule());
                    	        }
                           		setWithLastConsumed(current, "enableElDiagPowerSupplyOff", lv_enableElDiagPowerSupplyOff_7_0, "EnableDiagnosisPowerSupplyOff");
                    	    

                    }


                    }
                    break;

            }

            // InternalConfigurator.g:5323:3: (otherlv_8= 'ElDiagInstanceIdx' ( (lv_elDiagInstanceIdx_9_0= ruleINTORHEX ) ) )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==93) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalConfigurator.g:5323:5: otherlv_8= 'ElDiagInstanceIdx' ( (lv_elDiagInstanceIdx_9_0= ruleINTORHEX ) )
                    {
                    otherlv_8=(Token)match(input,93,FOLLOW_21); 

                        	newLeafNode(otherlv_8, grammarAccess.getIADCAccess().getElDiagInstanceIdxKeyword_6_0());
                        
                    // InternalConfigurator.g:5327:1: ( (lv_elDiagInstanceIdx_9_0= ruleINTORHEX ) )
                    // InternalConfigurator.g:5328:1: (lv_elDiagInstanceIdx_9_0= ruleINTORHEX )
                    {
                    // InternalConfigurator.g:5328:1: (lv_elDiagInstanceIdx_9_0= ruleINTORHEX )
                    // InternalConfigurator.g:5329:3: lv_elDiagInstanceIdx_9_0= ruleINTORHEX
                    {
                     
                    	        newCompositeNode(grammarAccess.getIADCAccess().getElDiagInstanceIdxINTORHEXParserRuleCall_6_1_0()); 
                    	    
                    pushFollow(FOLLOW_64);
                    lv_elDiagInstanceIdx_9_0=ruleINTORHEX();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getIADCRule());
                    	        }
                           		set(
                           			current, 
                           			"elDiagInstanceIdx",
                            		lv_elDiagInstanceIdx_9_0, 
                            		"zf.pios.Configurator.INTORHEX");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:5345:4: (otherlv_10= 'ControllerPinName' ( (lv_controllerPinName_11_0= RULE_STRING ) ) )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==64) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalConfigurator.g:5345:6: otherlv_10= 'ControllerPinName' ( (lv_controllerPinName_11_0= RULE_STRING ) )
                    {
                    otherlv_10=(Token)match(input,64,FOLLOW_32); 

                        	newLeafNode(otherlv_10, grammarAccess.getIADCAccess().getControllerPinNameKeyword_7_0());
                        
                    // InternalConfigurator.g:5349:1: ( (lv_controllerPinName_11_0= RULE_STRING ) )
                    // InternalConfigurator.g:5350:1: (lv_controllerPinName_11_0= RULE_STRING )
                    {
                    // InternalConfigurator.g:5350:1: (lv_controllerPinName_11_0= RULE_STRING )
                    // InternalConfigurator.g:5351:3: lv_controllerPinName_11_0= RULE_STRING
                    {
                    lv_controllerPinName_11_0=(Token)match(input,RULE_STRING,FOLLOW_65); 

                    			newLeafNode(lv_controllerPinName_11_0, grammarAccess.getIADCAccess().getControllerPinNameSTRINGTerminalRuleCall_7_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getIADCRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"controllerPinName",
                            		lv_controllerPinName_11_0, 
                            		"org.eclipse.xtext.common.Terminals.STRING");
                    	    

                    }


                    }


                    }
                    break;

            }

            // InternalConfigurator.g:5367:4: (otherlv_12= 'Description' ( (lv_description_13_0= RULE_STRING ) ) )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==35) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalConfigurator.g:5367:6: otherlv_12= 'Description' ( (lv_description_13_0= RULE_STRING ) )
                    {
                    otherlv_12=(Token)match(input,35,FOLLOW_32); 

                        	newLeafNode(otherlv_12, grammarAccess.getIADCAccess().getDescriptionKeyword_8_0());
                        
                    // InternalConfigurator.g:5371:1: ( (lv_description_13_0= RULE_STRING ) )
                    // InternalConfigurator.g:5372:1: (lv_description_13_0= RULE_STRING )
                    {
                    // InternalConfigurator.g:5372:1: (lv_description_13_0= RULE_STRING )
                    // InternalConfigurator.g:5373:3: lv_description_13_0= RULE_STRING
                    {
                    lv_description_13_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			newLeafNode(lv_description_13_0, grammarAccess.getIADCAccess().getDescriptionSTRINGTerminalRuleCall_8_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getIADCRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"description",
                            		lv_description_13_0, 
                            		"org.eclipse.xtext.common.Terminals.STRING");
                    	    

                    }


                    }


                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIADC"


    // $ANTLR start "entryRuleUserDefinedSubsystem"
    // InternalConfigurator.g:5397:1: entryRuleUserDefinedSubsystem returns [EObject current=null] : iv_ruleUserDefinedSubsystem= ruleUserDefinedSubsystem EOF ;
    public final EObject entryRuleUserDefinedSubsystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUserDefinedSubsystem = null;


        try {
            // InternalConfigurator.g:5398:2: (iv_ruleUserDefinedSubsystem= ruleUserDefinedSubsystem EOF )
            // InternalConfigurator.g:5399:2: iv_ruleUserDefinedSubsystem= ruleUserDefinedSubsystem EOF
            {
             newCompositeNode(grammarAccess.getUserDefinedSubsystemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUserDefinedSubsystem=ruleUserDefinedSubsystem();

            state._fsp--;

             current =iv_ruleUserDefinedSubsystem; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUserDefinedSubsystem"


    // $ANTLR start "ruleUserDefinedSubsystem"
    // InternalConfigurator.g:5406:1: ruleUserDefinedSubsystem returns [EObject current=null] : ( () otherlv_1= 'User' ( ( ruleQualifiedName ) ) otherlv_3= '{' ( (lv_userPort_4_0= ruleUserPort ) )+ otherlv_5= '}' ) ;
    public final EObject ruleUserDefinedSubsystem() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_userPort_4_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5409:28: ( ( () otherlv_1= 'User' ( ( ruleQualifiedName ) ) otherlv_3= '{' ( (lv_userPort_4_0= ruleUserPort ) )+ otherlv_5= '}' ) )
            // InternalConfigurator.g:5410:1: ( () otherlv_1= 'User' ( ( ruleQualifiedName ) ) otherlv_3= '{' ( (lv_userPort_4_0= ruleUserPort ) )+ otherlv_5= '}' )
            {
            // InternalConfigurator.g:5410:1: ( () otherlv_1= 'User' ( ( ruleQualifiedName ) ) otherlv_3= '{' ( (lv_userPort_4_0= ruleUserPort ) )+ otherlv_5= '}' )
            // InternalConfigurator.g:5410:2: () otherlv_1= 'User' ( ( ruleQualifiedName ) ) otherlv_3= '{' ( (lv_userPort_4_0= ruleUserPort ) )+ otherlv_5= '}'
            {
            // InternalConfigurator.g:5410:2: ()
            // InternalConfigurator.g:5411:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getUserDefinedSubsystemAccess().getUserDefinedSubsystemAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,94,FOLLOW_3); 

                	newLeafNode(otherlv_1, grammarAccess.getUserDefinedSubsystemAccess().getUserKeyword_1());
                
            // InternalConfigurator.g:5420:1: ( ( ruleQualifiedName ) )
            // InternalConfigurator.g:5421:1: ( ruleQualifiedName )
            {
            // InternalConfigurator.g:5421:1: ( ruleQualifiedName )
            // InternalConfigurator.g:5422:3: ruleQualifiedName
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getUserDefinedSubsystemRule());
            	        }
                    
             
            	        newCompositeNode(grammarAccess.getUserDefinedSubsystemAccess().getNameConfigSubsystemItemCrossReference_2_0()); 
            	    
            pushFollow(FOLLOW_4);
            ruleQualifiedName();

            state._fsp--;

             
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_61); 

                	newLeafNode(otherlv_3, grammarAccess.getUserDefinedSubsystemAccess().getLeftCurlyBracketKeyword_3());
                
            // InternalConfigurator.g:5439:1: ( (lv_userPort_4_0= ruleUserPort ) )+
            int cnt69=0;
            loop69:
            do {
                int alt69=2;
                int LA69_0 = input.LA(1);

                if ( (LA69_0==62) ) {
                    alt69=1;
                }


                switch (alt69) {
            	case 1 :
            	    // InternalConfigurator.g:5440:1: (lv_userPort_4_0= ruleUserPort )
            	    {
            	    // InternalConfigurator.g:5440:1: (lv_userPort_4_0= ruleUserPort )
            	    // InternalConfigurator.g:5441:3: lv_userPort_4_0= ruleUserPort
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getUserDefinedSubsystemAccess().getUserPortUserPortParserRuleCall_4_0()); 
            	    	    
            	    pushFollow(FOLLOW_62);
            	    lv_userPort_4_0=ruleUserPort();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getUserDefinedSubsystemRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"userPort",
            	            		lv_userPort_4_0, 
            	            		"zf.pios.Configurator.UserPort");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt69 >= 1 ) break loop69;
                        EarlyExitException eee =
                            new EarlyExitException(69, input);
                        throw eee;
                }
                cnt69++;
            } while (true);

            otherlv_5=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_5, grammarAccess.getUserDefinedSubsystemAccess().getRightCurlyBracketKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUserDefinedSubsystem"


    // $ANTLR start "entryRuleUserPort"
    // InternalConfigurator.g:5471:1: entryRuleUserPort returns [EObject current=null] : iv_ruleUserPort= ruleUserPort EOF ;
    public final EObject entryRuleUserPort() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUserPort = null;


        try {
            // InternalConfigurator.g:5472:2: (iv_ruleUserPort= ruleUserPort EOF )
            // InternalConfigurator.g:5473:2: iv_ruleUserPort= ruleUserPort EOF
            {
             newCompositeNode(grammarAccess.getUserPortRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUserPort=ruleUserPort();

            state._fsp--;

             current =iv_ruleUserPort; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUserPort"


    // $ANTLR start "ruleUserPort"
    // InternalConfigurator.g:5480:1: ruleUserPort returns [EObject current=null] : ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) (otherlv_6= 'Description' ( (lv_description_7_0= RULE_STRING ) ) )? otherlv_8= '}' ) ;
    public final EObject ruleUserPort() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token lv_description_7_0=null;
        Token otherlv_8=null;
        AntlrDatatypeRuleToken lv_driverIndex_5_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5483:28: ( ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) (otherlv_6= 'Description' ( (lv_description_7_0= RULE_STRING ) ) )? otherlv_8= '}' ) )
            // InternalConfigurator.g:5484:1: ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) (otherlv_6= 'Description' ( (lv_description_7_0= RULE_STRING ) ) )? otherlv_8= '}' )
            {
            // InternalConfigurator.g:5484:1: ( () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) (otherlv_6= 'Description' ( (lv_description_7_0= RULE_STRING ) ) )? otherlv_8= '}' )
            // InternalConfigurator.g:5484:2: () otherlv_1= 'Port' ( (lv_name_2_0= RULE_ID ) ) otherlv_3= '{' otherlv_4= 'DriverIndex' ( (lv_driverIndex_5_0= ruleINTORHEX ) ) (otherlv_6= 'Description' ( (lv_description_7_0= RULE_STRING ) ) )? otherlv_8= '}'
            {
            // InternalConfigurator.g:5484:2: ()
            // InternalConfigurator.g:5485:5: 
            {

                    current = forceCreateModelElement(
                        grammarAccess.getUserPortAccess().getUserPortAction_0(),
                        current);
                

            }

            otherlv_1=(Token)match(input,62,FOLLOW_3); 

                	newLeafNode(otherlv_1, grammarAccess.getUserPortAccess().getPortKeyword_1());
                
            // InternalConfigurator.g:5494:1: ( (lv_name_2_0= RULE_ID ) )
            // InternalConfigurator.g:5495:1: (lv_name_2_0= RULE_ID )
            {
            // InternalConfigurator.g:5495:1: (lv_name_2_0= RULE_ID )
            // InternalConfigurator.g:5496:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            			newLeafNode(lv_name_2_0, grammarAccess.getUserPortAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getUserPortRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"org.eclipse.xtext.common.Terminals.ID");
            	    

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_63); 

                	newLeafNode(otherlv_3, grammarAccess.getUserPortAccess().getLeftCurlyBracketKeyword_3());
                
            otherlv_4=(Token)match(input,63,FOLLOW_21); 

                	newLeafNode(otherlv_4, grammarAccess.getUserPortAccess().getDriverIndexKeyword_4());
                
            // InternalConfigurator.g:5520:1: ( (lv_driverIndex_5_0= ruleINTORHEX ) )
            // InternalConfigurator.g:5521:1: (lv_driverIndex_5_0= ruleINTORHEX )
            {
            // InternalConfigurator.g:5521:1: (lv_driverIndex_5_0= ruleINTORHEX )
            // InternalConfigurator.g:5522:3: lv_driverIndex_5_0= ruleINTORHEX
            {
             
            	        newCompositeNode(grammarAccess.getUserPortAccess().getDriverIndexINTORHEXParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_73);
            lv_driverIndex_5_0=ruleINTORHEX();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getUserPortRule());
            	        }
                   		set(
                   			current, 
                   			"driverIndex",
                    		lv_driverIndex_5_0, 
                    		"zf.pios.Configurator.INTORHEX");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // InternalConfigurator.g:5538:2: (otherlv_6= 'Description' ( (lv_description_7_0= RULE_STRING ) ) )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==35) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalConfigurator.g:5538:4: otherlv_6= 'Description' ( (lv_description_7_0= RULE_STRING ) )
                    {
                    otherlv_6=(Token)match(input,35,FOLLOW_32); 

                        	newLeafNode(otherlv_6, grammarAccess.getUserPortAccess().getDescriptionKeyword_6_0());
                        
                    // InternalConfigurator.g:5542:1: ( (lv_description_7_0= RULE_STRING ) )
                    // InternalConfigurator.g:5543:1: (lv_description_7_0= RULE_STRING )
                    {
                    // InternalConfigurator.g:5543:1: (lv_description_7_0= RULE_STRING )
                    // InternalConfigurator.g:5544:3: lv_description_7_0= RULE_STRING
                    {
                    lv_description_7_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                    			newLeafNode(lv_description_7_0, grammarAccess.getUserPortAccess().getDescriptionSTRINGTerminalRuleCall_6_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getUserPortRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"description",
                            		lv_description_7_0, 
                            		"org.eclipse.xtext.common.Terminals.STRING");
                    	    

                    }


                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,18,FOLLOW_2); 

                	newLeafNode(otherlv_8, grammarAccess.getUserPortAccess().getRightCurlyBracketKeyword_7());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUserPort"


    // $ANTLR start "entryRuleINTORHEX"
    // InternalConfigurator.g:5572:1: entryRuleINTORHEX returns [String current=null] : iv_ruleINTORHEX= ruleINTORHEX EOF ;
    public final String entryRuleINTORHEX() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleINTORHEX = null;


        try {
            // InternalConfigurator.g:5573:2: (iv_ruleINTORHEX= ruleINTORHEX EOF )
            // InternalConfigurator.g:5574:2: iv_ruleINTORHEX= ruleINTORHEX EOF
            {
             newCompositeNode(grammarAccess.getINTORHEXRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleINTORHEX=ruleINTORHEX();

            state._fsp--;

             current =iv_ruleINTORHEX.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleINTORHEX"


    // $ANTLR start "ruleINTORHEX"
    // InternalConfigurator.g:5581:1: ruleINTORHEX returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_SINT_0= ruleSINT | this_HEX_1= RULE_HEX ) ;
    public final AntlrDatatypeRuleToken ruleINTORHEX() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_HEX_1=null;
        AntlrDatatypeRuleToken this_SINT_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5584:28: ( (this_SINT_0= ruleSINT | this_HEX_1= RULE_HEX ) )
            // InternalConfigurator.g:5585:1: (this_SINT_0= ruleSINT | this_HEX_1= RULE_HEX )
            {
            // InternalConfigurator.g:5585:1: (this_SINT_0= ruleSINT | this_HEX_1= RULE_HEX )
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==RULE_UINT||LA71_0==RULE_INT) ) {
                alt71=1;
            }
            else if ( (LA71_0==RULE_HEX) ) {
                alt71=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 71, 0, input);

                throw nvae;
            }
            switch (alt71) {
                case 1 :
                    // InternalConfigurator.g:5586:5: this_SINT_0= ruleSINT
                    {
                     
                            newCompositeNode(grammarAccess.getINTORHEXAccess().getSINTParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_2);
                    this_SINT_0=ruleSINT();

                    state._fsp--;


                    		current.merge(this_SINT_0);
                        
                     
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:5597:10: this_HEX_1= RULE_HEX
                    {
                    this_HEX_1=(Token)match(input,RULE_HEX,FOLLOW_2); 

                    		current.merge(this_HEX_1);
                        
                     
                        newLeafNode(this_HEX_1, grammarAccess.getINTORHEXAccess().getHEXTerminalRuleCall_1()); 
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleINTORHEX"


    // $ANTLR start "entryRuleNUMBER"
    // InternalConfigurator.g:5612:1: entryRuleNUMBER returns [String current=null] : iv_ruleNUMBER= ruleNUMBER EOF ;
    public final String entryRuleNUMBER() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNUMBER = null;


        try {
            // InternalConfigurator.g:5613:2: (iv_ruleNUMBER= ruleNUMBER EOF )
            // InternalConfigurator.g:5614:2: iv_ruleNUMBER= ruleNUMBER EOF
            {
             newCompositeNode(grammarAccess.getNUMBERRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNUMBER=ruleNUMBER();

            state._fsp--;

             current =iv_ruleNUMBER.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNUMBER"


    // $ANTLR start "ruleNUMBER"
    // InternalConfigurator.g:5621:1: ruleNUMBER returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_FLOAT_0= ruleFLOAT | this_HEX_1= RULE_HEX ) ;
    public final AntlrDatatypeRuleToken ruleNUMBER() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_HEX_1=null;
        AntlrDatatypeRuleToken this_FLOAT_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5624:28: ( (this_FLOAT_0= ruleFLOAT | this_HEX_1= RULE_HEX ) )
            // InternalConfigurator.g:5625:1: (this_FLOAT_0= ruleFLOAT | this_HEX_1= RULE_HEX )
            {
            // InternalConfigurator.g:5625:1: (this_FLOAT_0= ruleFLOAT | this_HEX_1= RULE_HEX )
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==RULE_UINT||(LA72_0>=RULE_NATIVE_FLOAT && LA72_0<=RULE_INT)) ) {
                alt72=1;
            }
            else if ( (LA72_0==RULE_HEX) ) {
                alt72=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 72, 0, input);

                throw nvae;
            }
            switch (alt72) {
                case 1 :
                    // InternalConfigurator.g:5626:5: this_FLOAT_0= ruleFLOAT
                    {
                     
                            newCompositeNode(grammarAccess.getNUMBERAccess().getFLOATParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_2);
                    this_FLOAT_0=ruleFLOAT();

                    state._fsp--;


                    		current.merge(this_FLOAT_0);
                        
                     
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:5637:10: this_HEX_1= RULE_HEX
                    {
                    this_HEX_1=(Token)match(input,RULE_HEX,FOLLOW_2); 

                    		current.merge(this_HEX_1);
                        
                     
                        newLeafNode(this_HEX_1, grammarAccess.getNUMBERAccess().getHEXTerminalRuleCall_1()); 
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNUMBER"


    // $ANTLR start "entryRuleFLOAT"
    // InternalConfigurator.g:5652:1: entryRuleFLOAT returns [String current=null] : iv_ruleFLOAT= ruleFLOAT EOF ;
    public final String entryRuleFLOAT() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleFLOAT = null;


        try {
            // InternalConfigurator.g:5653:2: (iv_ruleFLOAT= ruleFLOAT EOF )
            // InternalConfigurator.g:5654:2: iv_ruleFLOAT= ruleFLOAT EOF
            {
             newCompositeNode(grammarAccess.getFLOATRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFLOAT=ruleFLOAT();

            state._fsp--;

             current =iv_ruleFLOAT.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFLOAT"


    // $ANTLR start "ruleFLOAT"
    // InternalConfigurator.g:5661:1: ruleFLOAT returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_NATIVE_FLOAT_0= RULE_NATIVE_FLOAT | this_SINT_1= ruleSINT ) ;
    public final AntlrDatatypeRuleToken ruleFLOAT() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_NATIVE_FLOAT_0=null;
        AntlrDatatypeRuleToken this_SINT_1 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5664:28: ( (this_NATIVE_FLOAT_0= RULE_NATIVE_FLOAT | this_SINT_1= ruleSINT ) )
            // InternalConfigurator.g:5665:1: (this_NATIVE_FLOAT_0= RULE_NATIVE_FLOAT | this_SINT_1= ruleSINT )
            {
            // InternalConfigurator.g:5665:1: (this_NATIVE_FLOAT_0= RULE_NATIVE_FLOAT | this_SINT_1= ruleSINT )
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==RULE_NATIVE_FLOAT) ) {
                alt73=1;
            }
            else if ( (LA73_0==RULE_UINT||LA73_0==RULE_INT) ) {
                alt73=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 73, 0, input);

                throw nvae;
            }
            switch (alt73) {
                case 1 :
                    // InternalConfigurator.g:5665:6: this_NATIVE_FLOAT_0= RULE_NATIVE_FLOAT
                    {
                    this_NATIVE_FLOAT_0=(Token)match(input,RULE_NATIVE_FLOAT,FOLLOW_2); 

                    		current.merge(this_NATIVE_FLOAT_0);
                        
                     
                        newLeafNode(this_NATIVE_FLOAT_0, grammarAccess.getFLOATAccess().getNATIVE_FLOATTerminalRuleCall_0()); 
                        

                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:5674:5: this_SINT_1= ruleSINT
                    {
                     
                            newCompositeNode(grammarAccess.getFLOATAccess().getSINTParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_2);
                    this_SINT_1=ruleSINT();

                    state._fsp--;


                    		current.merge(this_SINT_1);
                        
                     
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFLOAT"


    // $ANTLR start "entryRuleSINT"
    // InternalConfigurator.g:5692:1: entryRuleSINT returns [String current=null] : iv_ruleSINT= ruleSINT EOF ;
    public final String entryRuleSINT() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleSINT = null;


        try {
            // InternalConfigurator.g:5693:2: (iv_ruleSINT= ruleSINT EOF )
            // InternalConfigurator.g:5694:2: iv_ruleSINT= ruleSINT EOF
            {
             newCompositeNode(grammarAccess.getSINTRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSINT=ruleSINT();

            state._fsp--;

             current =iv_ruleSINT.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSINT"


    // $ANTLR start "ruleSINT"
    // InternalConfigurator.g:5701:1: ruleSINT returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_UINT_0= RULE_UINT | this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleSINT() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_UINT_0=null;
        Token this_INT_1=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:5704:28: ( (this_UINT_0= RULE_UINT | this_INT_1= RULE_INT ) )
            // InternalConfigurator.g:5705:1: (this_UINT_0= RULE_UINT | this_INT_1= RULE_INT )
            {
            // InternalConfigurator.g:5705:1: (this_UINT_0= RULE_UINT | this_INT_1= RULE_INT )
            int alt74=2;
            int LA74_0 = input.LA(1);

            if ( (LA74_0==RULE_UINT) ) {
                alt74=1;
            }
            else if ( (LA74_0==RULE_INT) ) {
                alt74=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 74, 0, input);

                throw nvae;
            }
            switch (alt74) {
                case 1 :
                    // InternalConfigurator.g:5705:6: this_UINT_0= RULE_UINT
                    {
                    this_UINT_0=(Token)match(input,RULE_UINT,FOLLOW_2); 

                    		current.merge(this_UINT_0);
                        
                     
                        newLeafNode(this_UINT_0, grammarAccess.getSINTAccess().getUINTTerminalRuleCall_0()); 
                        

                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:5713:10: this_INT_1= RULE_INT
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

                    		current.merge(this_INT_1);
                        
                     
                        newLeafNode(this_INT_1, grammarAccess.getSINTAccess().getINTTerminalRuleCall_1()); 
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSINT"


    // $ANTLR start "entryRuleQualifiedName"
    // InternalConfigurator.g:5728:1: entryRuleQualifiedName returns [String current=null] : iv_ruleQualifiedName= ruleQualifiedName EOF ;
    public final String entryRuleQualifiedName() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleQualifiedName = null;


        try {
            // InternalConfigurator.g:5729:2: (iv_ruleQualifiedName= ruleQualifiedName EOF )
            // InternalConfigurator.g:5730:2: iv_ruleQualifiedName= ruleQualifiedName EOF
            {
             newCompositeNode(grammarAccess.getQualifiedNameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualifiedName=ruleQualifiedName();

            state._fsp--;

             current =iv_ruleQualifiedName.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualifiedName"


    // $ANTLR start "ruleQualifiedName"
    // InternalConfigurator.g:5737:1: ruleQualifiedName returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleQualifiedName() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:5740:28: ( (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) )
            // InternalConfigurator.g:5741:1: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            {
            // InternalConfigurator.g:5741:1: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            // InternalConfigurator.g:5741:6: this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_98); 

            		current.merge(this_ID_0);
                
             
                newLeafNode(this_ID_0, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_0()); 
                
            // InternalConfigurator.g:5748:1: (kw= '.' this_ID_2= RULE_ID )*
            loop75:
            do {
                int alt75=2;
                int LA75_0 = input.LA(1);

                if ( (LA75_0==95) ) {
                    alt75=1;
                }


                switch (alt75) {
            	case 1 :
            	    // InternalConfigurator.g:5749:2: kw= '.' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,95,FOLLOW_3); 

            	            current.merge(kw);
            	            newLeafNode(kw, grammarAccess.getQualifiedNameAccess().getFullStopKeyword_1_0()); 
            	        
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_98); 

            	    		current.merge(this_ID_2);
            	        
            	     
            	        newLeafNode(this_ID_2, grammarAccess.getQualifiedNameAccess().getIDTerminalRuleCall_1_1()); 
            	        

            	    }
            	    break;

            	default :
            	    break loop75;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualifiedName"


    // $ANTLR start "entryRuleUiInt"
    // InternalConfigurator.g:5769:1: entryRuleUiInt returns [String current=null] : iv_ruleUiInt= ruleUiInt EOF ;
    public final String entryRuleUiInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleUiInt = null;


        try {
            // InternalConfigurator.g:5770:2: (iv_ruleUiInt= ruleUiInt EOF )
            // InternalConfigurator.g:5771:2: iv_ruleUiInt= ruleUiInt EOF
            {
             newCompositeNode(grammarAccess.getUiIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUiInt=ruleUiInt();

            state._fsp--;

             current =iv_ruleUiInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUiInt"


    // $ANTLR start "ruleUiInt"
    // InternalConfigurator.g:5778:1: ruleUiInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_UINT_0= RULE_UINT ;
    public final AntlrDatatypeRuleToken ruleUiInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_UINT_0=null;

         enterRule(); 
            
        try {
            // InternalConfigurator.g:5781:28: (this_UINT_0= RULE_UINT )
            // InternalConfigurator.g:5782:5: this_UINT_0= RULE_UINT
            {
            this_UINT_0=(Token)match(input,RULE_UINT,FOLLOW_2); 

            		current.merge(this_UINT_0);
                
             
                newLeafNode(this_UINT_0, grammarAccess.getUiIntAccess().getUINTTerminalRuleCall()); 
                

            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUiInt"


    // $ANTLR start "entryRuleImports"
    // InternalConfigurator.g:5801:1: entryRuleImports returns [EObject current=null] : iv_ruleImports= ruleImports EOF ;
    public final EObject entryRuleImports() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleImports = null;


        try {
            // InternalConfigurator.g:5802:2: (iv_ruleImports= ruleImports EOF )
            // InternalConfigurator.g:5803:2: iv_ruleImports= ruleImports EOF
            {
             newCompositeNode(grammarAccess.getImportsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleImports=ruleImports();

            state._fsp--;

             current =iv_ruleImports; 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImports"


    // $ANTLR start "ruleImports"
    // InternalConfigurator.g:5810:1: ruleImports returns [EObject current=null] : (otherlv_0= 'use' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildCard ) ) ) ;
    public final EObject ruleImports() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_importedNamespace_1_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5813:28: ( (otherlv_0= 'use' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildCard ) ) ) )
            // InternalConfigurator.g:5814:1: (otherlv_0= 'use' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildCard ) ) )
            {
            // InternalConfigurator.g:5814:1: (otherlv_0= 'use' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildCard ) ) )
            // InternalConfigurator.g:5814:3: otherlv_0= 'use' ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildCard ) )
            {
            otherlv_0=(Token)match(input,96,FOLLOW_3); 

                	newLeafNode(otherlv_0, grammarAccess.getImportsAccess().getUseKeyword_0());
                
            // InternalConfigurator.g:5818:1: ( (lv_importedNamespace_1_0= ruleQualifiedNameWithWildCard ) )
            // InternalConfigurator.g:5819:1: (lv_importedNamespace_1_0= ruleQualifiedNameWithWildCard )
            {
            // InternalConfigurator.g:5819:1: (lv_importedNamespace_1_0= ruleQualifiedNameWithWildCard )
            // InternalConfigurator.g:5820:3: lv_importedNamespace_1_0= ruleQualifiedNameWithWildCard
            {
             
            	        newCompositeNode(grammarAccess.getImportsAccess().getImportedNamespaceQualifiedNameWithWildCardParserRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_2);
            lv_importedNamespace_1_0=ruleQualifiedNameWithWildCard();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getImportsRule());
            	        }
                   		set(
                   			current, 
                   			"importedNamespace",
                    		lv_importedNamespace_1_0, 
                    		"zf.pios.Configurator.QualifiedNameWithWildCard");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImports"


    // $ANTLR start "entryRuleQualifiedNameWithWildCard"
    // InternalConfigurator.g:5844:1: entryRuleQualifiedNameWithWildCard returns [String current=null] : iv_ruleQualifiedNameWithWildCard= ruleQualifiedNameWithWildCard EOF ;
    public final String entryRuleQualifiedNameWithWildCard() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleQualifiedNameWithWildCard = null;


        try {
            // InternalConfigurator.g:5845:2: (iv_ruleQualifiedNameWithWildCard= ruleQualifiedNameWithWildCard EOF )
            // InternalConfigurator.g:5846:2: iv_ruleQualifiedNameWithWildCard= ruleQualifiedNameWithWildCard EOF
            {
             newCompositeNode(grammarAccess.getQualifiedNameWithWildCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualifiedNameWithWildCard=ruleQualifiedNameWithWildCard();

            state._fsp--;

             current =iv_ruleQualifiedNameWithWildCard.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualifiedNameWithWildCard"


    // $ANTLR start "ruleQualifiedNameWithWildCard"
    // InternalConfigurator.g:5853:1: ruleQualifiedNameWithWildCard returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_QualifiedName_0= ruleQualifiedName kw= '.*' ) ;
    public final AntlrDatatypeRuleToken ruleQualifiedNameWithWildCard() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        AntlrDatatypeRuleToken this_QualifiedName_0 = null;


         enterRule(); 
            
        try {
            // InternalConfigurator.g:5856:28: ( (this_QualifiedName_0= ruleQualifiedName kw= '.*' ) )
            // InternalConfigurator.g:5857:1: (this_QualifiedName_0= ruleQualifiedName kw= '.*' )
            {
            // InternalConfigurator.g:5857:1: (this_QualifiedName_0= ruleQualifiedName kw= '.*' )
            // InternalConfigurator.g:5858:5: this_QualifiedName_0= ruleQualifiedName kw= '.*'
            {
             
                    newCompositeNode(grammarAccess.getQualifiedNameWithWildCardAccess().getQualifiedNameParserRuleCall_0()); 
                
            pushFollow(FOLLOW_99);
            this_QualifiedName_0=ruleQualifiedName();

            state._fsp--;


            		current.merge(this_QualifiedName_0);
                
             
                    afterParserOrEnumRuleCall();
                
            kw=(Token)match(input,97,FOLLOW_2); 

                    current.merge(kw);
                    newLeafNode(kw, grammarAccess.getQualifiedNameWithWildCardAccess().getFullStopAsteriskKeyword_1()); 
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualifiedNameWithWildCard"


    // $ANTLR start "ruledataTypeEnumeration"
    // InternalConfigurator.g:5882:1: ruledataTypeEnumeration returns [Enumerator current=null] : ( (enumLiteral_0= 'fl32' ) | (enumLiteral_1= 'si8' ) | (enumLiteral_2= 'si16' ) | (enumLiteral_3= 'si32' ) | (enumLiteral_4= 'ui8' ) | (enumLiteral_5= 'ui16' ) ) ;
    public final Enumerator ruledataTypeEnumeration() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;

         enterRule(); 
        try {
            // InternalConfigurator.g:5884:28: ( ( (enumLiteral_0= 'fl32' ) | (enumLiteral_1= 'si8' ) | (enumLiteral_2= 'si16' ) | (enumLiteral_3= 'si32' ) | (enumLiteral_4= 'ui8' ) | (enumLiteral_5= 'ui16' ) ) )
            // InternalConfigurator.g:5885:1: ( (enumLiteral_0= 'fl32' ) | (enumLiteral_1= 'si8' ) | (enumLiteral_2= 'si16' ) | (enumLiteral_3= 'si32' ) | (enumLiteral_4= 'ui8' ) | (enumLiteral_5= 'ui16' ) )
            {
            // InternalConfigurator.g:5885:1: ( (enumLiteral_0= 'fl32' ) | (enumLiteral_1= 'si8' ) | (enumLiteral_2= 'si16' ) | (enumLiteral_3= 'si32' ) | (enumLiteral_4= 'ui8' ) | (enumLiteral_5= 'ui16' ) )
            int alt76=6;
            switch ( input.LA(1) ) {
            case 98:
                {
                alt76=1;
                }
                break;
            case 99:
                {
                alt76=2;
                }
                break;
            case 100:
                {
                alt76=3;
                }
                break;
            case 101:
                {
                alt76=4;
                }
                break;
            case 102:
                {
                alt76=5;
                }
                break;
            case 103:
                {
                alt76=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 76, 0, input);

                throw nvae;
            }

            switch (alt76) {
                case 1 :
                    // InternalConfigurator.g:5885:2: (enumLiteral_0= 'fl32' )
                    {
                    // InternalConfigurator.g:5885:2: (enumLiteral_0= 'fl32' )
                    // InternalConfigurator.g:5885:4: enumLiteral_0= 'fl32'
                    {
                    enumLiteral_0=(Token)match(input,98,FOLLOW_2); 

                            current = grammarAccess.getDataTypeEnumerationAccess().getFL32EnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_0, grammarAccess.getDataTypeEnumerationAccess().getFL32EnumLiteralDeclaration_0()); 
                        

                    }


                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:5891:6: (enumLiteral_1= 'si8' )
                    {
                    // InternalConfigurator.g:5891:6: (enumLiteral_1= 'si8' )
                    // InternalConfigurator.g:5891:8: enumLiteral_1= 'si8'
                    {
                    enumLiteral_1=(Token)match(input,99,FOLLOW_2); 

                            current = grammarAccess.getDataTypeEnumerationAccess().getSI8EnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_1, grammarAccess.getDataTypeEnumerationAccess().getSI8EnumLiteralDeclaration_1()); 
                        

                    }


                    }
                    break;
                case 3 :
                    // InternalConfigurator.g:5897:6: (enumLiteral_2= 'si16' )
                    {
                    // InternalConfigurator.g:5897:6: (enumLiteral_2= 'si16' )
                    // InternalConfigurator.g:5897:8: enumLiteral_2= 'si16'
                    {
                    enumLiteral_2=(Token)match(input,100,FOLLOW_2); 

                            current = grammarAccess.getDataTypeEnumerationAccess().getSI16EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_2, grammarAccess.getDataTypeEnumerationAccess().getSI16EnumLiteralDeclaration_2()); 
                        

                    }


                    }
                    break;
                case 4 :
                    // InternalConfigurator.g:5903:6: (enumLiteral_3= 'si32' )
                    {
                    // InternalConfigurator.g:5903:6: (enumLiteral_3= 'si32' )
                    // InternalConfigurator.g:5903:8: enumLiteral_3= 'si32'
                    {
                    enumLiteral_3=(Token)match(input,101,FOLLOW_2); 

                            current = grammarAccess.getDataTypeEnumerationAccess().getSI32EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_3, grammarAccess.getDataTypeEnumerationAccess().getSI32EnumLiteralDeclaration_3()); 
                        

                    }


                    }
                    break;
                case 5 :
                    // InternalConfigurator.g:5909:6: (enumLiteral_4= 'ui8' )
                    {
                    // InternalConfigurator.g:5909:6: (enumLiteral_4= 'ui8' )
                    // InternalConfigurator.g:5909:8: enumLiteral_4= 'ui8'
                    {
                    enumLiteral_4=(Token)match(input,102,FOLLOW_2); 

                            current = grammarAccess.getDataTypeEnumerationAccess().getUI8EnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_4, grammarAccess.getDataTypeEnumerationAccess().getUI8EnumLiteralDeclaration_4()); 
                        

                    }


                    }
                    break;
                case 6 :
                    // InternalConfigurator.g:5915:6: (enumLiteral_5= 'ui16' )
                    {
                    // InternalConfigurator.g:5915:6: (enumLiteral_5= 'ui16' )
                    // InternalConfigurator.g:5915:8: enumLiteral_5= 'ui16'
                    {
                    enumLiteral_5=(Token)match(input,103,FOLLOW_2); 

                            current = grammarAccess.getDataTypeEnumerationAccess().getUI16EnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_5, grammarAccess.getDataTypeEnumerationAccess().getUI16EnumLiteralDeclaration_5()); 
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruledataTypeEnumeration"


    // $ANTLR start "ruleiadcEnableEnumeration"
    // InternalConfigurator.g:5925:1: ruleiadcEnableEnumeration returns [Enumerator current=null] : ( (enumLiteral_0= 'ADC_CHANNEL_DISABLED' ) | (enumLiteral_1= 'ADC_CHANNEL_ENABLED' ) ) ;
    public final Enumerator ruleiadcEnableEnumeration() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;

         enterRule(); 
        try {
            // InternalConfigurator.g:5927:28: ( ( (enumLiteral_0= 'ADC_CHANNEL_DISABLED' ) | (enumLiteral_1= 'ADC_CHANNEL_ENABLED' ) ) )
            // InternalConfigurator.g:5928:1: ( (enumLiteral_0= 'ADC_CHANNEL_DISABLED' ) | (enumLiteral_1= 'ADC_CHANNEL_ENABLED' ) )
            {
            // InternalConfigurator.g:5928:1: ( (enumLiteral_0= 'ADC_CHANNEL_DISABLED' ) | (enumLiteral_1= 'ADC_CHANNEL_ENABLED' ) )
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==104) ) {
                alt77=1;
            }
            else if ( (LA77_0==105) ) {
                alt77=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 77, 0, input);

                throw nvae;
            }
            switch (alt77) {
                case 1 :
                    // InternalConfigurator.g:5928:2: (enumLiteral_0= 'ADC_CHANNEL_DISABLED' )
                    {
                    // InternalConfigurator.g:5928:2: (enumLiteral_0= 'ADC_CHANNEL_DISABLED' )
                    // InternalConfigurator.g:5928:4: enumLiteral_0= 'ADC_CHANNEL_DISABLED'
                    {
                    enumLiteral_0=(Token)match(input,104,FOLLOW_2); 

                            current = grammarAccess.getIadcEnableEnumerationAccess().getADC_CHANNEL_DISABLEDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_0, grammarAccess.getIadcEnableEnumerationAccess().getADC_CHANNEL_DISABLEDEnumLiteralDeclaration_0()); 
                        

                    }


                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:5934:6: (enumLiteral_1= 'ADC_CHANNEL_ENABLED' )
                    {
                    // InternalConfigurator.g:5934:6: (enumLiteral_1= 'ADC_CHANNEL_ENABLED' )
                    // InternalConfigurator.g:5934:8: enumLiteral_1= 'ADC_CHANNEL_ENABLED'
                    {
                    enumLiteral_1=(Token)match(input,105,FOLLOW_2); 

                            current = grammarAccess.getIadcEnableEnumerationAccess().getADC_CHANNEL_ENABLEDEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_1, grammarAccess.getIadcEnableEnumerationAccess().getADC_CHANNEL_ENABLEDEnumLiteralDeclaration_1()); 
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleiadcEnableEnumeration"


    // $ANTLR start "ruleBOOLfalseDefault"
    // InternalConfigurator.g:5944:1: ruleBOOLfalseDefault returns [Enumerator current=null] : ( (enumLiteral_0= 'False' ) | (enumLiteral_1= 'True' ) ) ;
    public final Enumerator ruleBOOLfalseDefault() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;

         enterRule(); 
        try {
            // InternalConfigurator.g:5946:28: ( ( (enumLiteral_0= 'False' ) | (enumLiteral_1= 'True' ) ) )
            // InternalConfigurator.g:5947:1: ( (enumLiteral_0= 'False' ) | (enumLiteral_1= 'True' ) )
            {
            // InternalConfigurator.g:5947:1: ( (enumLiteral_0= 'False' ) | (enumLiteral_1= 'True' ) )
            int alt78=2;
            int LA78_0 = input.LA(1);

            if ( (LA78_0==106) ) {
                alt78=1;
            }
            else if ( (LA78_0==107) ) {
                alt78=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 78, 0, input);

                throw nvae;
            }
            switch (alt78) {
                case 1 :
                    // InternalConfigurator.g:5947:2: (enumLiteral_0= 'False' )
                    {
                    // InternalConfigurator.g:5947:2: (enumLiteral_0= 'False' )
                    // InternalConfigurator.g:5947:4: enumLiteral_0= 'False'
                    {
                    enumLiteral_0=(Token)match(input,106,FOLLOW_2); 

                            current = grammarAccess.getBOOLfalseDefaultAccess().getFalseEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_0, grammarAccess.getBOOLfalseDefaultAccess().getFalseEnumLiteralDeclaration_0()); 
                        

                    }


                    }
                    break;
                case 2 :
                    // InternalConfigurator.g:5953:6: (enumLiteral_1= 'True' )
                    {
                    // InternalConfigurator.g:5953:6: (enumLiteral_1= 'True' )
                    // InternalConfigurator.g:5953:8: enumLiteral_1= 'True'
                    {
                    enumLiteral_1=(Token)match(input,107,FOLLOW_2); 

                            current = grammarAccess.getBOOLfalseDefaultAccess().getTrueEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                            newLeafNode(enumLiteral_1, grammarAccess.getBOOLfalseDefaultAccess().getTrueEnumLiteralDeclaration_1()); 
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBOOLfalseDefault"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x00000020801E0000L,0x0000000100000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x00000020801C0000L,0x0000000100000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000020001C0000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000002000140000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000140000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000A40000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000A00002L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000002400000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000002440000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000003000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000003040000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x000000003C000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x00000000000003C0L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000038000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000030000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000050L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000300000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000300040000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000000L,0x000000FC00000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000001800000002L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x000000000C040000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000008040000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0600000000040000L,0x0000000044010210L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0400000000040000L,0x0000000044010210L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000040000L,0x0000000044010210L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000040000L,0x0000000044010200L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000040000L,0x0000000044010000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000040000L,0x0000000044000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000040000L,0x0000000040000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x009CC80000040000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0161200000040000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x009CC80000000002L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0080000000000002L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0161200000000002L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0100000000000002L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x3800000000040000L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x3000000000040000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x2000000000040000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x4000000000040000L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x8000000000000000L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000800000002L,0x0000000000000001L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000800000002L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000000010L,0x0000000000000008L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000040010L,0x0000000000000008L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x8000000000000000L,0x0000000000000060L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000000000L,0x00000C0000000000L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x8000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000800040000L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x4000000000040000L,0x0000000000000400L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000000000L,0x0000000000002000L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_83 = new BitSet(new long[]{0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_84 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_85 = new BitSet(new long[]{0x0000000000000000L,0x0000000000100000L});
    public static final BitSet FOLLOW_86 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_87 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_88 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_89 = new BitSet(new long[]{0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_90 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_91 = new BitSet(new long[]{0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_92 = new BitSet(new long[]{0x0000000000000340L});
    public static final BitSet FOLLOW_93 = new BitSet(new long[]{0x0000000800000002L,0x0000000030000121L});
    public static final BitSet FOLLOW_94 = new BitSet(new long[]{0x0000000000000000L,0x0000030000000000L});
    public static final BitSet FOLLOW_95 = new BitSet(new long[]{0x0000000800000002L,0x0000000030000101L});
    public static final BitSet FOLLOW_96 = new BitSet(new long[]{0x0000000800000002L,0x0000000030000001L});
    public static final BitSet FOLLOW_97 = new BitSet(new long[]{0x0000000800000002L,0x0000000020000001L});
    public static final BitSet FOLLOW_98 = new BitSet(new long[]{0x0000000000000002L,0x0000000080000000L});
    public static final BitSet FOLLOW_99 = new BitSet(new long[]{0x0000000000000000L,0x0000000200000000L});

}
