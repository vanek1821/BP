//******************************************************************************
//
//    ZZZZZZZZZZ   FFFFFFFFFF
//    ZZZZZZZZZZ   FFFFFFFFFF
//          ZZZ    FFF
//         ZZZ     FFF
//        ZZZ      FFFFFFFF
//       ZZZ       FFFFFFFF
//      ZZZ        FFF
//     ZZZ         FFF
//    ZZZZZZZZZZ   FFF
//    ZZZZZZZZZZ   FFF          ENGINEERING PLZEN
//
/***************************************************************************//**
//  \file        ConfiguratorProposalProvider.java
//  \author      Martin Butnikosarovski
//  Department   ZF PLZ EDS
*******************************************************************************/
//  Description : 
//  This class servers to provide costume proposals.
//
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
package zf.pios.ui.contentassist;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.xtext.Assignment;
import org.eclipse.xtext.RuleCall;
import org.eclipse.xtext.ui.editor.contentassist.ConfigurableCompletionProposal;
import org.eclipse.xtext.ui.editor.contentassist.ContentAssistContext;
import org.eclipse.xtext.ui.editor.contentassist.ICompletionProposalAcceptor;

import zf.pios.configurator.Configuration;
import zf.pios.configurator.InputConfigSubsystemItem;
import zf.pios.configurator.InputConfigSubsystemNull;
import zf.pios.configurator.InputDatafield;
import zf.pios.configurator.OutputConfigSubsystemItem;
import zf.pios.configurator.OutputConfigSubsystemNull;
import zf.pios.configurator.OutputDatafield;

/**
 * see
 * http://www.eclipse.org/Xtext/documentation/latest/xtext.html#contentAssist on
 * how to customize content assistant
 */
public class ConfiguratorProposalProvider extends
		AbstractConfiguratorProposalProvider {

	// content assist for port names of output data-fields to offer only
	// desirable options.
	public void completeOutputDatafield_Portname(OutputDatafield model,
			Assignment assignment, ContentAssistContext context,
			ICompletionProposalAcceptor acceptor) {
		String proposalValue = "1";
		ICompletionProposal proposal = null;

		// For null subsystem, pwmKTX subsystem and user defined subsystems
		// offer number for portname
		// For all other subsystems offer only references
		if (model.getSubSystem() instanceof OutputConfigSubsystemNull
				|| model.getSubSystem() instanceof OutputConfigSubsystemItem) {
			RuleCall ruleCall = (RuleCall) assignment.getTerminal();
			String feature = assignment.getFeature();
			String displayText = proposalValue + " - "
					+ ruleCall.getRule().getName();
			if (feature != null)
				displayText = proposalValue + " - " + feature;
			proposal = createCompletionProposal(proposalValue, displayText,
					null, context);
			if (proposal instanceof ConfigurableCompletionProposal) {
				ConfigurableCompletionProposal configurable = (ConfigurableCompletionProposal) proposal;
				configurable.setSelectionStart(configurable
						.getReplacementOffset());
				configurable.setSelectionLength(proposalValue.length());
				configurable.setAutoInsertable(false);
				configurable
						.setSimpleLinkedMode(context.getViewer(), '\t', ' ');
			}
		} else {
			proposal = createCompletionProposal(null, context);
		}

		acceptor.accept(proposal);
	}

	// content assist for port names of input data-fields to offer only
	// desirable options.
	public void completeInputDatafield_Portname(InputDatafield model,
			Assignment assignment, ContentAssistContext context,
			ICompletionProposalAcceptor acceptor) {
		String proposalValue = "1";
		ICompletionProposal proposal = null;

		// For null subsystem, analog KTX subsystem and user defined subsystems
		// offer number for portname
		// For all other subsystems offer only references
		if (model.getSubSystem() instanceof InputConfigSubsystemNull
				|| model.getSubSystem() instanceof InputConfigSubsystemItem) {
			RuleCall ruleCall = (RuleCall) assignment.getTerminal();
			String feature = assignment.getFeature();
			String displayText = proposalValue + " - "
					+ ruleCall.getRule().getName();
			if (feature != null)
				displayText = proposalValue + " - " + feature;
			proposal = createCompletionProposal(proposalValue, displayText,
					null, context);
			if (proposal instanceof ConfigurableCompletionProposal) {
				ConfigurableCompletionProposal configurable = (ConfigurableCompletionProposal) proposal;
				configurable.setSelectionStart(configurable
						.getReplacementOffset());
				configurable.setSelectionLength(proposalValue.length());
				configurable.setAutoInsertable(false);
				configurable
						.setSimpleLinkedMode(context.getViewer(), '\t', ' ');
			}
		} else {
			proposal = createCompletionProposal(null, context);
		}

		acceptor.accept(proposal);
	}

	// content assist for type NUMBER
	@Override
	public void complete_NUMBER(EObject model, RuleCall ruleCall,
			ContentAssistContext context, ICompletionProposalAcceptor acceptor) {
		String proposalValue = "number or hex";
		ICompletionProposal proposal = null;

		String displayText = ruleCall.getRule().getName() + " - "
				+ proposalValue;
		proposal = createCompletionProposal(proposalValue, displayText, null,
				context);
		if (proposal instanceof ConfigurableCompletionProposal) {
			ConfigurableCompletionProposal configurable = (ConfigurableCompletionProposal) proposal;
			configurable.setSelectionStart(configurable.getReplacementOffset());
			configurable.setReplacementString("number_or_hex");
			configurable.setSelectionLength(proposalValue.length());
			configurable.setAutoInsertable(false);
			configurable.setSimpleLinkedMode(context.getViewer(), '\t', ' ');
		}
		acceptor.accept(proposal);
	}

	// content assist for type INTORHEX
	@Override
	public void complete_INTORHEX(EObject model, RuleCall ruleCall,
			ContentAssistContext context, ICompletionProposalAcceptor acceptor) {
		String proposalValue = "int or hex";
		ICompletionProposal proposal = null;

		String displayText = ruleCall.getRule().getName() + " - "
				+ proposalValue;
		proposal = createCompletionProposal(proposalValue, displayText, null,
				context);
		if (proposal instanceof ConfigurableCompletionProposal) {
			ConfigurableCompletionProposal configurable = (ConfigurableCompletionProposal) proposal;
			configurable.setSelectionStart(configurable.getReplacementOffset());
			configurable.setReplacementString("int_or_hex");
			configurable.setSelectionLength(proposalValue.length());
			configurable.setAutoInsertable(false);
			configurable.setSimpleLinkedMode(context.getViewer(), '\t', ' ');
		}
		acceptor.accept(proposal);
	}

	// content assist for type FLOAT
	@Override
	public void complete_FLOAT(EObject model, RuleCall ruleCall,
			ContentAssistContext context, ICompletionProposalAcceptor acceptor) {
		String proposalValue = "float";
		ICompletionProposal proposal = null;

		String displayText = ruleCall.getRule().getName() + " - "
				+ proposalValue;
		proposal = createCompletionProposal(proposalValue, displayText, null,
				context);
		if (proposal instanceof ConfigurableCompletionProposal) {
			ConfigurableCompletionProposal configurable = (ConfigurableCompletionProposal) proposal;
			configurable.setSelectionStart(configurable.getReplacementOffset());
			configurable.setReplacementString("0.0");
			configurable.setSelectionLength("0.0".length());
			configurable.setAutoInsertable(false);
			configurable.setSimpleLinkedMode(context.getViewer(), '\t', ' ');
		}
		acceptor.accept(proposal);
	}

	// content assist for type UINT
	@Override
	public void complete_UINT(EObject model, RuleCall ruleCall,
			ContentAssistContext context, ICompletionProposalAcceptor acceptor) {
		String proposalValue = "1";
		ICompletionProposal proposal = null;

		String displayText = ruleCall.getRule().getName() + " - "
				+ proposalValue;
		proposal = createCompletionProposal(proposalValue, displayText, null,
				context);
		if (proposal instanceof ConfigurableCompletionProposal) {
			ConfigurableCompletionProposal configurable = (ConfigurableCompletionProposal) proposal;
			configurable.setSelectionStart(configurable.getReplacementOffset());
			configurable.setReplacementString("1");
			configurable.setSelectionLength(proposalValue.length());
			configurable.setAutoInsertable(false);
			configurable.setSimpleLinkedMode(context.getViewer(), '\t', ' ');
		}
		acceptor.accept(proposal);
	}

	// content assist for type HEX
	@Override
	public void complete_HEX(EObject model, RuleCall ruleCall,
			ContentAssistContext context, ICompletionProposalAcceptor acceptor) {
		String proposalValue = "0x00";
		ICompletionProposal proposal = null;

		String displayText = ruleCall.getRule().getName() + " - "
				+ proposalValue;
		proposal = createCompletionProposal(proposalValue, displayText, null,
				context);
		if (proposal instanceof ConfigurableCompletionProposal) {
			ConfigurableCompletionProposal configurable = (ConfigurableCompletionProposal) proposal;
			configurable.setSelectionStart(configurable.getReplacementOffset());
			configurable.setReplacementString("0x00");
			configurable.setSelectionLength(proposalValue.length());
			configurable.setAutoInsertable(false);
			configurable.setSimpleLinkedMode(context.getViewer(), '\t', ' ');
		}
		acceptor.accept(proposal);
	}

	// content assist for type singed int
	@Override
	public void complete_SINT(EObject model, RuleCall ruleCall,
			ContentAssistContext context, ICompletionProposalAcceptor acceptor) {
		String proposalValue = "1";
		ICompletionProposal proposal = null;

		String displayText = ruleCall.getRule().getName() + " - "
				+ proposalValue;
		proposal = createCompletionProposal(proposalValue, displayText, null,
				context);
		if (proposal instanceof ConfigurableCompletionProposal) {
			ConfigurableCompletionProposal configurable = (ConfigurableCompletionProposal) proposal;
			configurable.setSelectionStart(configurable.getReplacementOffset());
			configurable.setReplacementString("1");
			configurable.setSelectionLength(1);
			configurable.setAutoInsertable(false);
			configurable.setSimpleLinkedMode(context.getViewer(), '\t', ' ');
		}
		acceptor.accept(proposal);
	}

	// content assist for type number or ID
	public void complete_NumberOrID(EObject model, RuleCall ruleCall,
			ContentAssistContext context, ICompletionProposalAcceptor acceptor) {
		String proposalValue = "number or ID value";
		ICompletionProposal proposal = null;

		String displayText = ruleCall.getRule().getName() + " - "
				+ proposalValue;
		proposal = createCompletionProposal(proposalValue, displayText, null,
				context);
		if (proposal instanceof ConfigurableCompletionProposal) {
			ConfigurableCompletionProposal configurable = (ConfigurableCompletionProposal) proposal;
			configurable.setSelectionStart(configurable.getReplacementOffset());
			configurable.setReplacementString("number_or_ID");
			configurable.setSelectionLength("number_or_ID".length());
			configurable.setAutoInsertable(false);
			configurable.setSimpleLinkedMode(context.getViewer(), '\t', ' ');
		}
		acceptor.accept(proposal);
	}
	
	// content assist for imported models
	public void complete_QualifiedNameWithWildCard(EObject model,
			RuleCall ruleCall, ContentAssistContext context,
			ICompletionProposalAcceptor acceptor) {
		
		// get all know resources.
		EList<Resource> resources = model.eResource().getResourceSet()
				.getResources();
		
		// go through all founded models and as first take their names as proposal,
		// second, in each model find parts which have a "name" and offer them as well
		for (Resource resource : resources) {
			if ((resource.getContents().get(0) instanceof Configuration)
					&& (resource != model.eResource())) {
				Configuration config = (Configuration) resource.getContents()
						.get(0);

				acceptor.accept(createCompletionProposal(config.getConfigurationName()
						+ ".*", config.getConfigurationName() + ".*", null, context));

				EList<EObject> listOfParts = config.eContents();
				for (EObject part : listOfParts) {
					if (part.eClass().getEStructuralFeature("name") != null) {
						String name = part.eGet(
								part.eClass().getEStructuralFeature("name"))
								.toString();
						acceptor.accept(createCompletionProposal(
								config.getConfigurationName()+ "." + name + ".*",
								config.getConfigurationName()+ "." + name + ".*", null, context));
					}
				}

			}

		}
	}
}
