//******************************************************************************
//
//    ZZZZZZZZZZ   FFFFFFFFFF
//    ZZZZZZZZZZ   FFFFFFFFFF
//          ZZZ    FFF
//         ZZZ     FFF
//        ZZZ      FFFFFFFF
//       ZZZ       FFFFFFFF
//      ZZZ        FFF
//     ZZZ         FFF
//    ZZZZZZZZZZ   FFF
//    ZZZZZZZZZZ   FFF          ENGINEERING PLZEN
//
/***************************************************************************//**
//  \file        TesaTkHyperlinkHelper.java
//  \author      Martin Butnikosarovski
//  Department   ZF PLZ EDS
*******************************************************************************/
//  Description : 
//  We need this class for use of our hyper-link helper. Otherwise is same as 
//  default hyper-link detector.
//
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
package zf.pios.ui.hyperlink;

import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.hyperlink.IHyperlink;
import org.eclipse.xtext.resource.XtextResource;
import org.eclipse.xtext.ui.editor.hyperlinking.DefaultHyperlinkDetector;
import org.eclipse.xtext.ui.editor.model.IXtextDocument;
import org.eclipse.xtext.util.concurrent.IUnitOfWork;

import com.google.inject.Inject;

public class TesaTkHyperlinkDetector extends DefaultHyperlinkDetector {

	@Inject
	private TesaTkHyperlinkHelper helper;

	public IHyperlink[] detectHyperlinks(ITextViewer textViewer, final IRegion region, final boolean canShowMultipleHyperlinks) {
		return ((IXtextDocument)textViewer.getDocument()).readOnly(new IUnitOfWork<IHyperlink[],XtextResource>() {
			public IHyperlink[] exec(XtextResource resource) throws Exception {
				return helper.createHyperlinksByOffset(resource, region.getOffset(), canShowMultipleHyperlinks);
			}
		});
	}
	
}
