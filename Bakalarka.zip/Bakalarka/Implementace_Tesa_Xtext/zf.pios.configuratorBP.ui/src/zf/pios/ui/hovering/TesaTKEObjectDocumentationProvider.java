package zf.pios.ui.hovering;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.documentation.IEObjectDocumentationProvider;

public class TesaTKEObjectDocumentationProvider implements
		IEObjectDocumentationProvider {

	@Override
	public String getDocumentation(EObject o) {
		// TODO Auto-generated method stub
		return null;
	}

}
