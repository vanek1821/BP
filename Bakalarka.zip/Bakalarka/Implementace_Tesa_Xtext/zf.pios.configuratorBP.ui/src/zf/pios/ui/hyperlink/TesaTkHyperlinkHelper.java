//******************************************************************************
//
//    ZZZZZZZZZZ   FFFFFFFFFF
//    ZZZZZZZZZZ   FFFFFFFFFF
//          ZZZ    FFF
//         ZZZ     FFF
//        ZZZ      FFFFFFFF
//       ZZZ       FFFFFFFF
//      ZZZ        FFF
//     ZZZ         FFF
//    ZZZZZZZZZZ   FFF
//    ZZZZZZZZZZ   FFF          ENGINEERING PLZEN
//
/***************************************************************************//**
//  \file        TesaTkHyperlinkHelper.java
//  \author      Martin Butnikosarovski
//  Department   ZF PLZ EDS
*******************************************************************************/
//  Description : 
//  This class servers to provide hyper-links for cross-references(build-in) 
//  and for imported models.
//
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------

package zf.pios.ui.hyperlink;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.jface.text.Region;
import org.eclipse.xtext.nodemodel.ICompositeNode;
import org.eclipse.xtext.nodemodel.INode;
import org.eclipse.xtext.nodemodel.util.NodeModelUtils;
import org.eclipse.xtext.resource.EObjectAtOffsetHelper;
import org.eclipse.xtext.resource.XtextResource;
import org.eclipse.xtext.ui.editor.hyperlinking.HyperlinkHelper;
import org.eclipse.xtext.ui.editor.hyperlinking.IHyperlinkAcceptor;
import org.eclipse.xtext.util.TextRegion;

import zf.pios.configurator.Configuration;
import zf.pios.configurator.Imports;

import com.google.inject.Inject;

public class TesaTkHyperlinkHelper extends HyperlinkHelper {

	@Inject
	private EObjectAtOffsetHelper eObjectAtOffsetHelper;

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.xtext.ui.editor.hyperlinking.HyperlinkHelper#createHyperlinksByOffset(org.eclipse.xtext.resource.XtextResource, int, org.eclipse.xtext.ui.editor.hyperlinking.IHyperlinkAcceptor)
	 * 
	 * Creates hyper-links for cross-references (build-in only copy&paste) and also links for used models.
	 */
	@Override
	public void createHyperlinksByOffset(XtextResource resource, int offset, IHyperlinkAcceptor acceptor) {

		if(resource.isLoaded() && resource.getContents().get(0) instanceof Configuration){
			EObject obj = eObjectAtOffsetHelper.resolveElementAt(resource, offset);
			if( obj instanceof Imports){
					
				for(Resource iterResource : resource.getResourceSet().getResources()){
					if(iterResource.getContents().get(0) instanceof Configuration){
						Configuration iterConfig = (Configuration)iterResource.getContents().get(0);
						String[] nameOfImport = ((Imports)obj).getImportedNamespace().replace(".*", "").split("\\.");
						String nameOfImportedModel = nameOfImport[0];
						// check that the model is the imported one.
						if( nameOfImportedModel.matches(iterConfig.getConfigurationName()) ){
							EObject referencedPart = referencedObject(nameOfImport, iterConfig);
							
							// find the node which is related to the imported model
							ICompositeNode node = NodeModelUtils.getNode(obj);
							// the last child of the node should be a node which is the name of imported model (and part)
							INode lastChild = node.getLastChild();
							if(lastChild != null){
								Region region = new Region(lastChild.getOffset(), lastChild.getLength());
								createHyperlinksTo(resource, region, referencedPart, acceptor);
							}
						}
					}
				}
			}
		}


		//  build-in hyper-links for cross-references
		INode crossRefNode = eObjectAtOffsetHelper.getCrossReferenceNode(resource, new TextRegion(offset, 0));
		if (crossRefNode == null)
			return;
		EObject crossLinkedEObject = eObjectAtOffsetHelper.getCrossReferencedElement(crossRefNode);
		if (crossLinkedEObject != null && !crossLinkedEObject.eIsProxy()) {
			Region region = new Region(crossRefNode.getOffset(), crossRefNode.getLength());
			createHyperlinksTo(resource, region, crossLinkedEObject, acceptor);
		}
		

	}
	
	// the parsed name of import contains the name of model and optionally the name of part.
	// returns either the model or the parts according the passed name.
	private EObject referencedObject(String[] parsedNameOfImport, Configuration config){
		if(parsedNameOfImport.length <= 1)
			return config;
		else{
			String nameOfPart = parsedNameOfImport[1];

			EList<EObject> listOfParts = config.eContents();
			for (EObject part : listOfParts) {
				if (part != null && part.eClass().getEStructuralFeature("name") != null) {
					String name = part.eGet(part.eClass().getEStructuralFeature("name")).toString();
					if(name.matches(nameOfPart))
						return part;
				}
			}			
		}
		
		return config;
	}
	
}
