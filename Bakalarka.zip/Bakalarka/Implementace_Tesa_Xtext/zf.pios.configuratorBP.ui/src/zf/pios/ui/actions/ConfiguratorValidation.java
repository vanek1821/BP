package zf.pios.ui.actions;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.preferences.DefaultScope;
import org.eclipse.core.runtime.preferences.IScopeContext;
import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

import zf.pios.ui.internal.ConfiguratorActivator;

public class ConfiguratorValidation implements IWorkbenchWindowActionDelegate {
	public static final String TEXT_VALIDATE_TRUE = "Disable CANMsgTable validation";
	public static final String TEXT_VALIDATE_FALSE = "Enable CANMsgTable validation";
	public static final String PREFERENCES_VALIDATE = "preference-validate-combined-variants";

	@Override
	public void run(IAction arg0) {
		// TODO Auto-generated method stub

		for (IProject p : ResourcesPlugin.getWorkspace().getRoot().getProjects())
			if (p.isOpen())
				try {
 					p.build(IncrementalProjectBuilder.FULL_BUILD, null);
 					//p.refreshLocal(IResource.DEPTH_INFINITE, null);
				} catch (CoreException e) {
					e.printStackTrace();
				}
	}


	@Override
	public void selectionChanged(IAction arg0, ISelection arg1) {
		// TODO Auto-generated method stub
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public void init(IWorkbenchWindow arg0) {
		// TODO Auto-generated method stub

	}

	public static Boolean getValidation()
	{
		String result = createPreferenceScopes()[0].getNode(getPreferenceNodeQualifier()).get(PREFERENCES_VALIDATE, "false");
		return Boolean.valueOf(result);
	}

	@SuppressWarnings("deprecation")
	protected static IScopeContext[] createPreferenceScopes() {
		return new IScopeContext[] { new InstanceScope(), new DefaultScope() };
	}

	protected static String getPreferenceNodeQualifier() {
		return ConfiguratorActivator.getInstance().getBundle().getSymbolicName();
	}
}
