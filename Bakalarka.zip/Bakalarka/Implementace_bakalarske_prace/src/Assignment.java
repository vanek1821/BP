/**
 * Class representing Assignment. Extends GrammarElement.
 * @author Jakub Vanek 2019
 *
 */
public class Assignment extends GrammarElement{
	/**
	 * Default Constructor
	 * 
	 */
	public Assignment() {
		this.setCardinality(null);
		this.setName(null);
	}
	/**
	 * Constructor
	 * @param name name of element
	 */
	public Assignment(String name) {
		this.setName(name);
		this.setCardinality(null);
	}
	/**
	 * Constructor
	 * @param name element name
	 * @param cardinality element cardinality
	 */
	public Assignment(String name, String cardinality) {
		this.setName(name);
		this.setCardinality(cardinality);
	}
}
