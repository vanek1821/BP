/**
 * Class representing Keyword. Extends GrammarElement.
 * @author Jakub Vanek 2019
 *
 */
public class Keyword extends GrammarElement{
	/**
	 * Setter of Keyword Value
	 * @param value
	 */
	public Keyword(String value) {
		this.setName(value);
	}
}
