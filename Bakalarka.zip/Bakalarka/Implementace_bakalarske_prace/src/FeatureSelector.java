import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
/**
 * Main class of application
 * @author Jakub Vanek 2019
 *
 */
public class FeatureSelector {

	static BufferedReader reader; 				//Reader for file reading
	static HashMap<String, Rule> ruleMap = new HashMap<String, Rule>();					 //HashMap of loaded rules
	static ArrayList<GrammarElement> alternativesList = new ArrayList<GrammarElement>(); //List of alternative elements
	static HashMap<Integer, String> exportMap = new HashMap<Integer, String>(); 		 //Map of feature for export with its ID
	static int printIndicator = -1; 			//Indicator for offset
	static int idCounter = 0; 					//Counter for ID assignment
	static FeatureModelNode rootNode; 			//RootNode of AST
	static String EXPORT_TESA_FILE;				//Name of file for export
	static String IMPORT_GRAMMAR_FILE;		    //Name of grammar file
	static String EXPORT_CSV_FILE;				//Name of exported csv for P::V
	static GrammarElement lastGeneratedElement; //Last generated element
	static int sortingIndexCounter = 0; 		//Index counter for SortingIndex
	static int portIndexCounter = 0; 			//Index counter for PortIndex
	static int MODE = 0;						//Mode
	static String FEATURE_MODEL;  				//File with feature model exported from P::V
	static boolean inputConfigSubsystemFlag = false;	//Flag for appending IUser or OUser
	

	/**
	 * Main method. Controls input arguments
	 * @param args input arguments
	 */
	public static void main(String[] args) {
		System.out.println("Hello to FeatureSelector");
		//if arguments don't exist
		if(args.length == 0 ) {
			System.out.println("Missing arguments. Use parameter help for instructions.");
			return;
		}
		
		//help argument
		if(args[0].equals("help")) {
			System.out.println("Use parameters:\n"
					+ "GRAMMAR_FILE MODEL EXPORT_FILE_FOR_PV\n"
					+ "GRAMMAR_FILE TESA FEATURE_MODEL_FILE TESA_EXPORT_FILE");
			return;
		}
		
		//setting file variables
		IMPORT_GRAMMAR_FILE = args[0];
		if(args.length>1) {
			switch(args[1]) {
				case "MODEL":
					if(args.length>2) {
						MODE = 1;
						EXPORT_CSV_FILE = args[2];
					}
					else {
						System.out.println("Missing arguments. Use parameter help for instructions.");
						return;
					}
					break;
				case "TESA":
					if(args.length>3) {
						MODE = 2;
						FEATURE_MODEL = args[2];
						EXPORT_TESA_FILE = args[3];
					}
					else {
						System.out.println("Missing arguments. Use parameter help for instructions.");
						return;
					}
					break;
				default:
					System.out.println("Wrong input mode.\nMODEL: export CSV file for Pure::Variants.\n"
							+ "TESA: import Feature Model from Pure::Variants and export Tesa file");
					return;
			}
		}
		try {
			loadGrammar();
			createFeatureModel();
			switch(MODE) {
			case 1:
				writeToCSV();
				break;
			case 2:
				exportTesa();
				break;
			}
		} catch (IOException e) {
			System.out.println("Error000: Files not found");
			e.printStackTrace();
		}
		
		
	}
	
	public static void loadGrammar() throws IOException {
		GrammarElement tmpElement;
		
		//Loading file
		File grammarFile = new File(IMPORT_GRAMMAR_FILE);
		
		System.out.println("Grammar file succesfully opened");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = null;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			System.out.println("Error001: Something went wrong with newDocumentBuilder");
			e.printStackTrace();
		}

		try {
			doc = dBuilder.parse(grammarFile);
		} catch (SAXException e) {
			System.out.println("Error002: Something went wrong with parsing xml");
			e.printStackTrace();
		}

		//Loading rules into ruleMap
		NodeList nList = doc.getElementsByTagName("Rule");
		for(int i = 0; i < nList.getLength(); i++) {
			Element element = (Element) nList.item(i);

			ruleMap.put(element.getAttribute("name"), new Rule(element.getAttribute("name")));
			ruleMap.get(element.getAttribute("name")).setElementType("Rule");

			if(element.hasAttribute("cardinality")) {
				ruleMap.get(element.getAttribute("name")).setCardinality(element.getAttribute("cardinality"));
			}
		}
				
		//Loading features under rules
		for (int i = 0; i < nList.getLength(); i++) {
			Element parentElement = (Element) nList.item(i);
			tmpElement = ruleMap.get(parentElement.getAttribute("name"));
			if(parentElement.hasChildNodes()) {
				addGrammarElements(parentElement, tmpElement);
			}
			
		}
		for (GrammarElement element : alternativesList) {
			element.setCardinality("|");
		}
		
		System.out.println("Grammar Loaded");
	}

	/**
	 * Creates GrammarTree with P::V needed information
	 */
	private static void createFeatureModel() {
		Rule root = ruleMap.get("Configuration");
		rootNode = new FeatureModelNode();
		rootNode.setId(idCounter);
		rootNode.setUniqueName("root");
		rootNode.setPuid(-1);
		rootNode.setName(root.getName());
		rootNode.setCardinality(root.getPVCardinality());
		rootNode.setElement(root);
		idCounter++;
		
		addNode(root, rootNode);
		System.out.println("AST created");
	}
	
	/**
	 * Adds nodes to GrammarTree needed for P::V
	 * @param element Grammar element loaded from grammar
	 * @param node last created node for GrammarTree
	 */
	private static void addNode(GrammarElement element, FeatureModelNode node) {
		GrammarElement tmpElement;
		FeatureModelNode newNode;
		
		//Cycle for all elements in elementList
		for (int i = 0; i < element.getElementList().size(); i++) {
			tmpElement = element.getElementList().get(i);
			
			//Switching types of elements and adding them to GrammarTree
			switch(tmpElement.getElementType()) {
			case "Assignment":
				newNode = new FeatureModelNode();
				newNode.setId(idCounter);
				newNode.setUniqueName(tmpElement.getName() + String.valueOf(idCounter));
				newNode.setName(tmpElement.getName());
				newNode.setPuid(node.getId());
				newNode.setElement(tmpElement);
				newNode.setCardinality(tmpElement.getPVCardinality());
				node.addNode(newNode);
				idCounter++;
				if(!tmpElement.getElementList().isEmpty()) {
					addNode(tmpElement, newNode);
				}
				break;
			case "Rule":
				newNode = new FeatureModelNode();
				newNode.setId(idCounter);
				newNode.setUniqueName(tmpElement.getName() + String.valueOf(idCounter));
				newNode.setName(tmpElement.getName());
				newNode.setPuid(node.getId());
				newNode.setElement(tmpElement);
				newNode.setCardinality(tmpElement.getPVCardinality());
				node.addNode(newNode);
				idCounter++;
				if(!tmpElement.getElementList().isEmpty()) {
					addNode(tmpElement, newNode);
				}
				break;
			case "Parent":
				if(ruleMap.containsKey(tmpElement.getName())) {
					tmpElement = ruleMap.get(tmpElement.getName());
					newNode = new FeatureModelNode();
					newNode.setId(idCounter);
					newNode.setUniqueName(tmpElement.getName() + String.valueOf(idCounter));
					newNode.setName(tmpElement.getName());
					newNode.setPuid(node.getId());
					newNode.setElement(tmpElement);
					newNode.setCardinality(tmpElement.getPVCardinality());
					node.addNode(newNode);
					idCounter++;
					addNode(tmpElement, newNode);
				}
				
				break;
			case "Group":
				addNode(tmpElement, node);
				break;
			
			case "Enum":
				newNode = new FeatureModelNode();
				newNode.setId(idCounter);
				newNode.setUniqueName(tmpElement.getName() + String.valueOf(idCounter));
				newNode.setName(tmpElement.getName());
				newNode.setPuid(node.getId());
				newNode.setElement(tmpElement);
				newNode.setCardinality(tmpElement.getPVCardinality());
				node.addNode(newNode);
				idCounter++;
			break;
			}
		}
	}
	
	/**
	 * Creating AbstractSyntaxTree of elements loaded from grammar
	 * @param element new element
	 * @param grammarElement last created element
	 */
	private static void addGrammarElements(Element element, GrammarElement grammarElement) {
		Element childElement;
		NodeList childList = element.getChildNodes();
		
		//Cycles through all childrenNodes in xml
		for(int i = 0; i<childList.getLength(); i++) {
			
			//Switching between types of elements and adding them to AbstractSyntaxTree
			switch(childList.item(i).getNodeName()) {
				case "Group":
					childElement = (Element) childList.item(i);
					Group group = new Group(childElement.getAttribute("cardinality"));
					group.setElementType("Group");
					grammarElement.getElementList().add(group);
					group.setParentElement(grammarElement);
					if(grammarElement.getCardinality().equals("|")) {
						alternativesList.add(group);
					}
					addGrammarElements(childElement, group);
					break;
				case "Keyword":
					childElement = (Element) childList.item(i);
					Keyword keyword = new Keyword(childElement.getAttribute("value"));
					grammarElement.getElementList().add(keyword);
					keyword.setElementType("Keyword");
					keyword.setParentElement(grammarElement);
					addGrammarElements(childElement, keyword);
					break;
				case "Assignment":
					childElement = (Element) childList.item(i);
					Assignment assignment = new Assignment(childElement.getAttribute("name"), childElement.getAttribute("cardinality"));
					assignment.setElementType("Assignment");
					if(grammarElement.getElementType().equals("Group")) {
						if(!grammarElement.getCardinality().equals("")) {
							assignment.setCardinality(grammarElement.getCardinality());
						}
					}
					if(grammarElement.getCardinality().equals("|")) {
						alternativesList.add(assignment);
					}
					grammarElement.getElementList().add(assignment);
					assignment.setParentElement(grammarElement);
					addGrammarElements(childElement, assignment);
					break;
					
				case "Parent":	
					childElement = (Element) childList.item(i);
					if(ruleMap.containsKey(childElement.getAttribute("name"))) {
						Parent parent = new Parent(childElement.getAttribute("name"));
						parent.setElementType("Parent");
						parent.setRule(ruleMap.get(childElement.getAttribute("name")));
						if(grammarElement.getCardinality().equals("|")) {
							alternativesList.add(parent);
							alternativesList.add(ruleMap.get(childElement.getAttribute("name")));
					
						}
						grammarElement.getElementList().add(parent);
						parent.setParentElement(grammarElement);
						addGrammarElements(childElement, parent);
					}
					else {
						grammarElement.setReference(childElement.getAttribute("name"));
					}
					break;
				case "Reference":
					childElement = (Element) childList.item(i);
					grammarElement.setReference(childElement.getAttribute("name"));
					break;
				case "Enum":
					childElement = (Element) childList.item(i);
					EnumLiteral enumLiteral = new EnumLiteral(childElement.getAttribute("name"), childElement.getAttribute("cardinality"));
					enumLiteral.setValue(childElement.getAttribute("value"));
					enumLiteral.setElementType("Enum");
					if(grammarElement.getCardinality().equals("|")) {
						alternativesList.add(enumLiteral);
					}
					grammarElement.getElementList().add(enumLiteral);
					enumLiteral.setParentElement(grammarElement);
					break;
			}
			
		}
	}
	
	/**
	 * Exports components into tesa file.
	 * @throws IOException if File with FeatureModel isn't found
	 */
	private static void exportTesa() throws IOException {
		File pvFile = new File(FEATURE_MODEL);
		int featureID;
		String line, featureName;
		String[] splitLine;
		try {
			reader = new BufferedReader(new FileReader(pvFile));
			reader.readLine();
			
			//Reads all lines from P::V file and adding them to exportMap with ID and name
			while((line = reader.readLine())!=null) {
				splitLine = line.split(";");
				featureID = Integer.parseInt(splitLine[0]);
				featureName = splitLine[2];
				exportMap.put(featureID, featureName);
			}
			
			
		} catch (FileNotFoundException e) {
			System.out.println("Error003: Something wrong with P::V exported file.");
		}
		
		//Exports components into file
		try (PrintWriter writer = new PrintWriter(new File(EXPORT_TESA_FILE))){
			StringBuilder stringBuilder = new StringBuilder();

			parseTree(rootNode, stringBuilder);
			//System.out.println(stringBuilder);
			writer.write(stringBuilder.toString());
		
			//Copying output into clipboard
			/*
			StringSelection selection = new StringSelection(stringBuilder.toString());
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			clipboard.setContents(selection, selection);
			*/
			
			System.out.println("Generating complete");
		} catch (FileNotFoundException e) {
			System.out.println("Error004: Something wrong with file for tesa export");
			System.out.println(e.getMessage());
		}	
	}
	/**
	 * Method goes through original GrammarTree and examines, if PV exported file contains elements.
	 * @param node Node of grammar
	 * @param sb StringBuilder
	 */
	public static void parseTree(FeatureModelNode node, StringBuilder sb) {
		boolean bracketFlag = false;
		boolean endBracket = false;
		
		//Cycles through all nodes in GrammarTree
		for (FeatureModelNode tmpNode : node.getNodeList()) {
			//checks if PV Exported file contains actual node 
			if(exportMap.containsKey(tmpNode.getId())){
				if(tmpNode.getElement().getName().equals("inputConfigSubsystem")) inputConfigSubsystemFlag = true;
				endBracket = exportElement(tmpNode.getElement(), sb);
				if(endBracket) bracketFlag = true;
				parseTree(tmpNode, sb);
			}
		}
		if(bracketFlag) {
			space(sb);
			sb.append("}\n");
			printIndicator--;
		}
	}
	/**
	 * Exports all components into stringBuilder
	 * @param element element for exporting
	 * @param sb StringBuilder
	 * @return true if curly bracket ({) was generated. Used for spacing
	 */
	public static boolean exportElement(GrammarElement element, StringBuilder sb) {
		GrammarElement parentElement;
		boolean returnValue = false;
		int index = element.getIndex(); //position of element in elementList of its parent
			
		//Specific conditions which requires special names for exporting
		//element is outputDigitalDriverTable
		if(element.getName().equals("OutDigitalDriverTableRef")) {
			space(sb);
			sb.append("Null\n");
			lastGeneratedElement = element;
			return returnValue;
		}
		//element is inputDigitalDriverTable
		if(element.getName().equals("InDigitalDriverTableRef")) {
			space(sb);
			sb.append("Null\n");
			lastGeneratedElement = element;
			return returnValue;
		}
		//element is tempSensor
		if(element.getName().equals("tempSensor")) {
			space(sb);
			sb.append("TemperatureSensor Signals_name.InputSignal_name\n");
			lastGeneratedElement = element;
			return returnValue;
		}
		//element is importedNamespace
		else if(element.getName().equals("importedNamespace")) {
			space(sb);
			sb.append("use importedNamespace.*\n");
			lastGeneratedElement = element;
			return returnValue;
		}
		//there is something generated
		else if(lastGeneratedElement!=null) {
			//element is maximalNumberInputSubsystems
			if(lastGeneratedElement.getName().equals("maximalNumberInputSubsystems")) {
				sortingIndexCounter = 0;
				sb.append("7\n"); 				//there are max 7 subsystems
				lastGeneratedElement = null;
				return returnValue;
			}
			//element is maximalNumberOutputSubsystems
			else if(lastGeneratedElement.getName().equals("maximalNumberOutputSubsystems")) {
				sortingIndexCounter = 0;
				sb.append("5\n");
				lastGeneratedElement = null;
				return returnValue;
			}
			//element is sortingIndex which needs counter
			else if(lastGeneratedElement.getName().equals("sortingIndex")) {
				sb.append(sortingIndexCounter + "\n");
				sortingIndexCounter++;
				lastGeneratedElement = null;
				return returnValue;
			}
		}
		
		//switching type of elements
		switch(element.getElementType()) {
		//element is Assignment
		case "Assignment":
			//Element has empty elementList
			if(element.getElementList().isEmpty()) {
				parentElement = element.getParentElement();
				
				//Element position is greater than first
				if(index>0) {
					//if element in front of assignment is keyword
					if(parentElement.getElementList().get(index-1).getElementType().equals("Keyword")) {
						space(sb);
						//if element doesn't have reference
						if(element.getReference()==null) {
							sb.append(parentElement.getElementList().get(index-1).getName()+ " " + parentElement.getElementList().get(index-1).getName()+ "_" + element.getName());
							lastGeneratedElement = element;
						}
						//element has reference
						else {
							sb.append(parentElement.getElementList().get(index-1).getName()+ " ");
							//switching reference
							switch(element.getReference()) {
							case "STRING":
								sb.append("'" + element.getName() + "'");
								lastGeneratedElement = element;
								break;
							case "ID":
								//Keyword in front of element is "Port"
								if(element.getParentElement().getElementList().get(index - 1).getName().equals("Port")) {
									sb.append("Port" + portIndexCounter + "_" + element.getName() + " ");
									portIndexCounter++;
								}
								//Different keyword than "Port"
								else {
									sb.append(parentElement.getElementList().get(index-1).getName()+ "_" + element.getName() + " ");
								}
								lastGeneratedElement = element;
								break;
							//special cases
							case "ConfigSubsystemItem":
								if(inputConfigSubsystemFlag) {
									sb.append("System_name.NameIUser_name");
								} 
								else {
									sb.append("System_name.NameOUser_name");
								}
								break;
							case "InputDriverType":
								sb.append("System_name.NameINull_name");
								break;
							case "OutputDriverType":
								sb.append("System_name.NameONull_name");
								break;
							default:
								//Keyword in front of element is "PowerSupplySignal"
								if(element.getParentElement().getElementList().get(index - 1).getName().equals("PowerSupplySignal")) {
									sb.append("Signals_name.InputSignal_name\n");
								}
								//Keyword in front of element is "SensorIndex"
								else if(element.getName().equals("sensorIndex")) {
									sb.append("Sensor_name");
								}
								//all other cases. Generates name of reference + _name
								else {
									sb.append(element.getReference() + "_name ");
								}
								break;
							}
						}
					}
					//if assignment is not last 
					if(parentElement.getElementList().size()>(index+1)) {
						//if element after generated element is keyword
						if(parentElement.getElementList().get(index+1).getElementType().equals("Keyword")){
							//if that keyword is curly bracket ({)
							if(parentElement.getElementList().get(index+1).getName().equals("{")) {
								sb.append(parentElement.getElementList().get(index+1).getName() + " ");
								lastGeneratedElement = element;
								printIndicator++;
								returnValue = true;
							}
						}
					}
				}
				sb.append("\n");
			}
			//If element has only one element in element list and it is keyword. Generates that keyword
			else if((element.getElementList().size()==1) && element.getElementList().get(0).getElementType().equals("Keyword")) {
				space(sb);
				sb.append(element.getElementList().get(0).getName() + "\n");
				lastGeneratedElement = element;
			}
			//Element isn't first and in front of element is keyword
			else if(index>0 && element.getParentElement().getElementList().get(index-1).getElementType().equals("Keyword")){
				//keyword isn't curly bracket
				if(!element.getParentElement().getElementList().get(index-1).getName().equals("{")) {
					space(sb);
					sb.append(element.getParentElement().getElementList().get(index-1).getName() + " ");
					lastGeneratedElement = element;
				
				}
			}
			
			return returnValue;
			
		//element is Rule	
		case "Rule":
			//if element is one of default data types
			if (exportDataType(element, sb));
			//if only element in elementlist is group
			else if(element.getElementList().get(0).getElementType().equals("Group")) {
				//group becomes new element
				element = element.getElementList().get(0);
				//if first element is keyword
				if(element.getElementList().get(0).getElementType().equals("Keyword")) {
					Keyword keyword = (Keyword) element.getElementList().get(0);
					//If second element is keyword and curly bracket
					if(element.getElementList().get(1).getElementType().equals("Keyword") && element.getElementList().get(1).getName().equals("{")) {
						space(sb);
						sb.append(keyword.getName() + " ");
						sb.append(element.getElementList().get(1).getName() + "\n");
						printIndicator++;
						returnValue = true;
					}
				}
			}
		return returnValue;	
		//element is enum
		case "Enum":
			EnumLiteral enumerator = (EnumLiteral) element;
			sb.append(enumerator.getValue() + "\n");
			returnValue = false;
			return returnValue;
		}
		return returnValue;
	}
	
	/**
	 * Writes Grammar Tree into csv importable to P::V
	 */
	private static void writeToCSV() {
		//Writting to csv
		//Rule root = ruleMap.get("Configuration");
		try (PrintWriter writer = new PrintWriter(new File(EXPORT_CSV_FILE))){
			StringBuilder sb = new StringBuilder();
			sb.append("Unique Name;Unique ID;Visible Name;Variation Type;Parent Unique ID;Parent Unique Name;Parent Visible Name;Parent Type;Class;Type;\n");
			sb.append("root;0;Configuration;ps:mandatory;;;;;ps:feature;ps:feature;\n");
			printNodeToCSV(rootNode, sb);
			writer.write(sb.toString());
			System.out.println("FEATURE MODEL GENERATED TO CSV");
		} catch (FileNotFoundException e){
			System.out.println("Error005: Something wrong with csv file for P::V");
			System.out.println(e.getMessage());
		}
		
	}
	
	/**
	 * prints node into csv File
	 * @param node node
	 * @param sb StringBuilder
	 */
	private static void printNodeToCSV(FeatureModelNode node, StringBuilder sb ) {
		for (FeatureModelNode tmpNode : node.getNodeList()) {
			sb.append(tmpNode.getPVString());
			printNodeToCSV(tmpNode, sb);
		}
	}
	/**
	 * Prints AST
	 */
	public static void printMap(){
		GrammarElement root = ruleMap.get("Configuration");
		printElement(root);
	}
	/**
	 * Prints elements recursively
	 * @param element element for printing
	 */
	public static void printElement(GrammarElement element) {
		System.out.println("el:" + element.getElementType() + " name: " + element.getName());
		for (GrammarElement el : element.getElementList()) {
			if(el.getElementType().equals("Parent")) {
				if(ruleMap.containsKey(el.getName())) {
					printElement(ruleMap.get(el.getName()));
				}
			}
			else {
				printElement(el);
			}
			
		}
	}
	/**
	 * Generated default used dataTypes
	 * @param element element of dataType
	 * @param sb StringBuilder
	 * @return true if element was one of default data type
	 */
	public static boolean exportDataType(GrammarElement element, StringBuilder sb) {
		switch (element.getName()) {
		case "UINT":
			sb.append("0\n");
			return true;
		case "INT":
			sb.append("0\n");
			return true;
		case "NATIVE_FLOAT":
			sb.append("0.0\n");
			return true;
		case "HEX":
			sb.append("0x00\n");
			return true;
		}
		return false;
	}
	
	/**
	 * adds spacing into stringBuilder
	 * @param sb StringBuilder
	 */
	public static void space(StringBuilder sb) {
		for (int i = 0; i < printIndicator; i++) {
			sb.append("  ");
		}
	}
}


