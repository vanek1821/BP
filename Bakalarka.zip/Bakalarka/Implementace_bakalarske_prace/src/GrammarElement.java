import java.util.ArrayList;

/**
 * Class representing GrammarElement. All types of elements extend this class.
 * @author Jakub Vanek 2019
 *
 */
public class GrammarElement {

	private int ID;																			//element ID
	private String name;																	//element name
	private String cardinality;																//element cardinality
	private String elementType;																//type of element
	private GrammarElement parentElement;													//parent element
	private ArrayList<GrammarElement> elementList = new ArrayList<GrammarElement>();		//list of child elements	
	private String reference;																//element reference
	
	/**
	 * Default Constructor
	 */
	public GrammarElement() {
		this.name = "";
		this.setCardinality("");
	}
	/**
	 * Constructor
	 * @param name name of element
	 */
	public GrammarElement(String name) {
		this.setName(name);
		this.setCardinality("");
	}
	/**
	 * Getter of name
	 * @return String name of element
	 */
	public String getName() {
		return name;
	}
	/**
	 * Setter of name 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Getter of cardinality in P::V form
	 * @return String of P::V cardinality
	 */
	public String getPVCardinality() {
		switch(this.cardinality) {
		case "":
			return "ps:mandatory";
		case "?":
			return "ps:optional";
		case "+":
			return "ps:mandatory";
		case "*":
			return "ps:optional";
		case "|":
			return "ps:alternative";		
		}
		return "";
	}
	/**
	 * Getter of cardinality
	 * @return String cardinality
	 */
	public String getCardinality() {
		return this.cardinality;
	}
	/**
	 * Setter of cardinality
	 * @param cardinality
	 */
	public void setCardinality(String cardinality) {
		this.cardinality = cardinality;
	}
	/**
	 * Getter of list of child elements
	 * @return ArrayList of elements
	 */
	public ArrayList<GrammarElement> getElementList() {
		return elementList;
	}
	/**
	 * Setter of list of child elements
	 * @param elementList ArrayList of elements
	 */
	public void setElementList(ArrayList<GrammarElement> elementList) {
		this.elementList = elementList;
	}
	/**
	 * Getter of ID
	 * @return int ID
	 */
	public int getID() {
		return this.ID;
	}
	/**
	 * Setter of ID
	 * @param ID int
	 */
	public void setID(int ID) {
		this.ID = ID;
	}
	/**
	 * Getter of element type
	 * @return String Type of element
	 */
	public String getElementType() {
		return elementType;
	}
	/**
	 * Setter of element type
	 * @param elementType type of element
	 */
	public void setElementType(String elementType) {
		this.elementType = elementType;
	}
	/**
	 * Getter for parent of element
	 * @return GrammarElement parent of element
	 */
	public GrammarElement getParentElement() {
		return parentElement;
	}
	/**
	 * Sets parent to element
	 * @param parentElement GrammarElement parent element
	 */
	public void setParentElement(GrammarElement parentElement) {
		this.parentElement = parentElement;
	}
	/**
	 * Looks for element in its elementList
	 * @param seekElementName name of seeked element
	 * @return GrammarElement element
	 * @return null if not found
	 */
	public GrammarElement getElement(String seekElementName) {
		for (GrammarElement grammarElement : elementList) {
			if(grammarElement.getName().equals(seekElementName)) {
				return grammarElement;
			}
		}
		return null;
	}
	/**
	 * Getter of element position inside element list
	 * @return index of element
	 * @return -1 if element not found
	 */
	public int getIndex() {
		GrammarElement tmp = this.parentElement;
		if(tmp == null) return -1;
		int index = 0;
		for (GrammarElement grammarElement : tmp.getElementList()) {
			if(grammarElement.equals(this)) return index;
			index++;
		}
		return -1;
	}
	/**
	 * Getter of element reference
	 * @return String reference of element
	 */
	public String getReference() {
		return reference;
	}
	/**
	 * Setter of element reference
	 * @param reference String reference of element
	 */
	public void setReference(String reference) {
		this.reference = reference;
	}

}
