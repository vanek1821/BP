/**
 * Class representing Group. Extends GrammarElement.
 * @author Jakub Vanek 2019
 *
 */
public class Group extends GrammarElement{
	/**
	 * Constructor
	 * @param cardinality Cardinality of element
	 */
	public Group(String cardinality) {
		this.setCardinality(cardinality);
	}

}
