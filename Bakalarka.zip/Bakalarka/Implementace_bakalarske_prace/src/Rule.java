/**
 * Class representing Rule. Extends GrammarElement.
 * @author Jakub Vanek 2019
 *
 */
public class Rule extends GrammarElement {
	/**
	 * Constructor
	 * @param name String name of rule
	 */
	public Rule(String name) {
		super.setName(name);
	}
	/**
	 * Constructor
	 * @param name String name of rule
	 * @param cardinality String cardinality of rule
	 */
	public Rule(String name, String cardinality) {
		this.setName(name);
		this.setCardinality(cardinality);
		}	
}
