import java.util.ArrayList;
/**
 * Nodes representing Grammar tree used for P::V
 * Main reason of this class is specific format of P::V importable file
 * @author Jakub Vanek
 *
 */
public class FeatureModelNode {

	private int id;												//ID of element
	private int puid;											//ID of parent element
	private String uniqueName;									//Unique name of element
	private String name;										//Visible name of element
	private ArrayList<FeatureModelNode> nodeList;				//list of child nodes
	private GrammarElement element;								//reference to element which this object represents
	private String cardinality;									//cardinality used for PV
	/**
	 * Constructor
	 */
	public FeatureModelNode() {
		this.nodeList = new ArrayList<FeatureModelNode>();
	}
	/**
	 * Getter of ID
	 * @return int ID
	 */
	public int getId() {
		return id;
	}
	/**
	 * setter of ID
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * Getter of parent UID
	 * @return
	 */
	public int getPuid() {
		return puid;
	}
	/**
	 * Setter of parent ID
	 * @param puid
	 */
	public void setPuid(int puid) {
		this.puid = puid;
	}
	
	/**
	 * Getter of unique name
	 * @return String unique name
	 */
	public String getUniqueName() {
		return uniqueName;
	}
	/**
	 * setter of uniqueName
	 * @param uniqueName string uniqueName
	 */
	public void setUniqueName(String uniqueName) {
		this.uniqueName = uniqueName;
	}
	/**
	 * Getter of element name
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * Setter of element Name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Getter of child node list of element
	 * @return
	 */
	public ArrayList<FeatureModelNode> getNodeList() {
		return nodeList;
	}
	/**
	 * setter of child node list
	 * @param nodeList
	 */
	public void setNodeList(ArrayList<FeatureModelNode> nodeList) {
		this.nodeList = nodeList;
	}
	/**
	 * Getter of element which this node represents
	 * @return GrammarElement element
	 */
	public GrammarElement getElement() {
		return element;
	}
	/**
	 * Setter of element which this node represents
	 * @param element
	 */
	public void setElement(GrammarElement element) {
		this.element = element;
	}
	/**
	 * Getter of cardinality
	 * @return String cardinality
	 */
	public String getCardinality() {
		return cardinality;
	}
	/**
	 * Setter of cardinality
	 * @param cardinality
	 */
	public void setCardinality(String cardinality) {
		this.cardinality = cardinality;
	}
	/**
	 * Adds node into list of child nodes
	 * @param node
	 */
	public void addNode(FeatureModelNode node) {
		this.nodeList.add(node);
	}
	/**
	 * Getter of PV formatted String of this node
	 * @return String PV formatted
	 */
	public String getPVString() {
		return this.uniqueName+ ";" + String.valueOf(this.id)+ ";" + this.name+ ";" + this.cardinality + ";" + String.valueOf(this.puid) +";;;;ps:feature;ps:feature;\n";
		
	}
}
