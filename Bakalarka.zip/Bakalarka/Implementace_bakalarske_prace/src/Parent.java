/**
 * Class representing Parent. Extends GrammarElement.
 * @author Jakub Vanek 2019
 *
 */
public class Parent extends GrammarElement{

	private Rule rule; 				//Referebce to Rule which parent represents
	/**
	 * Constructor
	 * @param name String name of element
	 */
	public Parent(String name) {
		this.setName(name);
	}
	/**
	 * Getter of rule which Parent represents
	 * @return
	 */
	public Rule getRule() {
		return rule;
	}
	/**
	 * Setter of rule which Parent represents
	 * @param rule Rule rule
	 */
	public void setRule(Rule rule) {
		this.rule = rule;
	}
	
}
