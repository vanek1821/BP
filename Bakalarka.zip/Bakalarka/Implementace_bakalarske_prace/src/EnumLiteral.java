
/**
 * Class representing Enum. Extends GrammarElement.
 * @author Jakub Vanek 2019
 *
 */
public class EnumLiteral  extends GrammarElement{
	private String value;
	
	/**
	 * Default Constructor
	 */
	public EnumLiteral() {
		this.setCardinality(null);
		this.setName(null);
	}
	/**
	 * Constructor
	 * @param name name of element
	 */
	public EnumLiteral(String name) {
		this.setName(name);
		this.setCardinality(null);
	}
	/**
	 * Constructor
	 * @param name name of element
	 * @param cardinality cardinality of element
	 */
	public EnumLiteral(String name, String cardinality) {
		this.setName(name);
		this.setCardinality(cardinality);
	}
	/**
	 * Getter of value of enumLiteral
	 * @return value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * setter of value of enumLiteral
	 * @param value value of enumLiteral value
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
